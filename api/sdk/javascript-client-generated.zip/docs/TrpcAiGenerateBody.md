# JekyllForgeApi.TrpcAiGenerateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiGenerateJson**](ApitrpcaiGenerateJson.md) |  | 
