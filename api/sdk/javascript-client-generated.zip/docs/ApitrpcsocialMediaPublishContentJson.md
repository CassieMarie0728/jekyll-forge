# JekyllForgeApi.ApitrpcsocialMediaPublishContentJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposedContentId** | **Number** |  | 
**accountId** | **Number** |  | 
