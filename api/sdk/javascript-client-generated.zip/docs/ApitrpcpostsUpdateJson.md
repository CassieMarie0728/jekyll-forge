# JekyllForgeApi.ApitrpcpostsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**path** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**slug** | **String** |  | [optional] 
**status** | **Object** |  | [optional] 
**frontMatter** | **Object** |  | [optional] 
**markdown** | **String** |  | [optional] 
**sha** | **String** |  | [optional] 
**scheduledAt** | **Object** |  | [optional] 
