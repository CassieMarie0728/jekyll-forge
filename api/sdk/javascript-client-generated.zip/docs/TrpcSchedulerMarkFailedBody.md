# JekyllForgeApi.TrpcSchedulerMarkFailedBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulerMarkFailedJson**](ApitrpcschedulerMarkFailedJson.md) |  | 
