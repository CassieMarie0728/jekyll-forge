# JekyllForgeApi.ApitrpcassetsReoptimizeJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**maxWidth** | **Number** |  | [optional] 
**outputFormat** | **String** |  | [optional] 
**quality** | **Number** |  | [optional] 

<a name="OutputFormatEnum"></a>
## Enum: OutputFormatEnum

* `webp` (value: `"webp"`)
* `jpeg` (value: `"jpeg"`)
* `png` (value: `"png"`)

