# JekyllForgeApi.ApitrpcassetsGenerateAltTextJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assetId** | **Number** |  | 
