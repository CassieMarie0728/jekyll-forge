# JekyllForgeApi.AbTestingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**abTestingApplyWinner**](AbTestingApi.md#abTestingApplyWinner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
[**abTestingCompleteTest**](AbTestingApi.md#abTestingCompleteTest) | **POST** /api/trpc/abTesting.completeTest | Complete Test
[**abTestingGenerateVariations**](AbTestingApi.md#abTestingGenerateVariations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
[**abTestingGetResults**](AbTestingApi.md#abTestingGetResults) | **GET** /api/trpc/abTesting.getResults | Get Results
[**abTestingGetVariations**](AbTestingApi.md#abTestingGetVariations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
[**abTestingPublishVariation**](AbTestingApi.md#abTestingPublishVariation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
[**abTestingUpdateMetrics**](AbTestingApi.md#abTestingUpdateMetrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics

<a name="abTestingApplyWinner"></a>
# **abTestingApplyWinner**
> TRPCResponse abTestingApplyWinner(body)

Apply Winner

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let body = new JekyllForgeApi.TrpcAbTestingApplyWinnerBody(); // TrpcAbTestingApplyWinnerBody | 

apiInstance.abTestingApplyWinner(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingApplyWinnerBody**](TrpcAbTestingApplyWinnerBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingCompleteTest"></a>
# **abTestingCompleteTest**
> TRPCResponse abTestingCompleteTest(body)

Complete Test

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let body = new JekyllForgeApi.TrpcAbTestingCompleteTestBody(); // TrpcAbTestingCompleteTestBody | 

apiInstance.abTestingCompleteTest(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingCompleteTestBody**](TrpcAbTestingCompleteTestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingGenerateVariations"></a>
# **abTestingGenerateVariations**
> TRPCResponse abTestingGenerateVariations(body)

Generate Variations

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let body = new JekyllForgeApi.TrpcAbTestingGenerateVariationsBody(); // TrpcAbTestingGenerateVariationsBody | 

apiInstance.abTestingGenerateVariations(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingGenerateVariationsBody**](TrpcAbTestingGenerateVariationsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingGetResults"></a>
# **abTestingGetResults**
> TRPCResponse abTestingGetResults(input)

Get Results

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.abTestingGetResults(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="abTestingGetVariations"></a>
# **abTestingGetVariations**
> TRPCResponse abTestingGetVariations(input)

Get Variations

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.abTestingGetVariations(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="abTestingPublishVariation"></a>
# **abTestingPublishVariation**
> TRPCResponse abTestingPublishVariation(body)

Publish Variation

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let body = new JekyllForgeApi.TrpcAbTestingPublishVariationBody(); // TrpcAbTestingPublishVariationBody | 

apiInstance.abTestingPublishVariation(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingPublishVariationBody**](TrpcAbTestingPublishVariationBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingUpdateMetrics"></a>
# **abTestingUpdateMetrics**
> TRPCResponse abTestingUpdateMetrics(body)

Update Metrics

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AbTestingApi();
let body = new JekyllForgeApi.TrpcAbTestingUpdateMetricsBody(); // TrpcAbTestingUpdateMetricsBody | 

apiInstance.abTestingUpdateMetrics(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingUpdateMetricsBody**](TrpcAbTestingUpdateMetricsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

