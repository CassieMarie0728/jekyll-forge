# JekyllForgeApi.ApitrpcgithubConnectJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | 
