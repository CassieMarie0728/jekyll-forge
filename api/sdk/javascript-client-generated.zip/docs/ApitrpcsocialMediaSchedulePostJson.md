# JekyllForgeApi.ApitrpcsocialMediaSchedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposedContentId** | **Number** |  | 
**socialMediaAccountId** | **Number** |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  | [optional] 
