# JekyllForgeApi.ApitrpcnotificationsUnregisterDeviceJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | 
