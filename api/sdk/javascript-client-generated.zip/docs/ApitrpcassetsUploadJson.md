# JekyllForgeApi.ApitrpcassetsUploadJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | **Number** |  | 
**name** | **String** |  | 
**path** | **String** |  | 
**base64Content** | **String** |  | 
**mimeType** | **String** |  | 
**size** | **Number** |  | 
**width** | **Number** |  | [optional] 
**height** | **Number** |  | [optional] 
**optimize** | **Boolean** |  | 
**maxWidth** | **Number** |  | [optional] 
**outputFormat** | **String** |  | [optional] 
**quality** | **Number** |  | [optional] 

<a name="OutputFormatEnum"></a>
## Enum: OutputFormatEnum

* `webp` (value: `"webp"`)
* `jpeg` (value: `"jpeg"`)
* `png` (value: `"png"`)
* `original` (value: `"original"`)

