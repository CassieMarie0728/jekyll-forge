# JekyllForgeApi.ApitrpcblocksUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | [optional] 
**category** | **String** |  | [optional] 
**content** | **String** |  | [optional] 
**contentType** | **String** |  | [optional] 

<a name="ContentTypeEnum"></a>
## Enum: ContentTypeEnum

* `markdown` (value: `"markdown"`)
* `html` (value: `"html"`)
* `liquid` (value: `"liquid"`)

