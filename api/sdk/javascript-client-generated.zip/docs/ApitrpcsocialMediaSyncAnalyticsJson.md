# JekyllForgeApi.ApitrpcsocialMediaSyncAnalyticsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**analyticsId** | **Number** |  | 
