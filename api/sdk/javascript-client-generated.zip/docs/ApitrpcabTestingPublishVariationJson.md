# JekyllForgeApi.ApitrpcabTestingPublishVariationJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
**variationIndex** | **Number** |  | 
**platforms** | **[String]** |  | 

<a name="[PlatformsEnum]"></a>
## Enum: [PlatformsEnum]

* `twitter` (value: `"twitter"`)
* `linkedin` (value: `"linkedin"`)
* `facebook` (value: `"facebook"`)
* `instagram` (value: `"instagram"`)
* `email` (value: `"email"`)
* `direct` (value: `"direct"`)

