# JekyllForgeApi.TrpcBlocksCreateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcblocksCreateJson**](ApitrpcblocksCreateJson.md) |  | 
