# JekyllForgeApi.SitesApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sitesDelete**](SitesApi.md#sitesDelete) | **POST** /api/trpc/sites.delete | Delete
[**sitesGet**](SitesApi.md#sitesGet) | **GET** /api/trpc/sites.get | Get
[**sitesList**](SitesApi.md#sitesList) | **GET** /api/trpc/sites.list | List
[**sitesUpdate**](SitesApi.md#sitesUpdate) | **POST** /api/trpc/sites.update | Update
[**sitesUpsert**](SitesApi.md#sitesUpsert) | **POST** /api/trpc/sites.upsert | Upsert

<a name="sitesDelete"></a>
# **sitesDelete**
> TRPCResponse sitesDelete(body)

Delete

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SitesApi();
let body = new JekyllForgeApi.TrpcSitesDeleteBody(); // TrpcSitesDeleteBody | 

apiInstance.sitesDelete(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesDeleteBody**](TrpcSitesDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sitesGet"></a>
# **sitesGet**
> TRPCResponse sitesGet(input)

Get

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SitesApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.sitesGet(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="sitesList"></a>
# **sitesList**
> TRPCResponse sitesList()

List

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SitesApi();
apiInstance.sitesList((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="sitesUpdate"></a>
# **sitesUpdate**
> TRPCResponse sitesUpdate(body)

Update

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SitesApi();
let body = new JekyllForgeApi.TrpcSitesUpdateBody(); // TrpcSitesUpdateBody | 

apiInstance.sitesUpdate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpdateBody**](TrpcSitesUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sitesUpsert"></a>
# **sitesUpsert**
> TRPCResponse sitesUpsert(body)

Upsert

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SitesApi();
let body = new JekyllForgeApi.TrpcSitesUpsertBody(); // TrpcSitesUpsertBody | 

apiInstance.sitesUpsert(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpsertBody**](TrpcSitesUpsertBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

