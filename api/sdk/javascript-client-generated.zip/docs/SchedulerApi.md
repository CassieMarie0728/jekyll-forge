# JekyllForgeApi.SchedulerApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**schedulerCancel**](SchedulerApi.md#schedulerCancel) | **POST** /api/trpc/scheduler.cancel | Cancel
[**schedulerCancelAll**](SchedulerApi.md#schedulerCancelAll) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
[**schedulerList**](SchedulerApi.md#schedulerList) | **GET** /api/trpc/scheduler.list | List
[**schedulerListHeartbeatJobs**](SchedulerApi.md#schedulerListHeartbeatJobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**schedulerMarkFailed**](SchedulerApi.md#schedulerMarkFailed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
[**schedulerMarkPublished**](SchedulerApi.md#schedulerMarkPublished) | **POST** /api/trpc/scheduler.markPublished | Mark Published
[**schedulerReschedule**](SchedulerApi.md#schedulerReschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
[**schedulerSchedule**](SchedulerApi.md#schedulerSchedule) | **POST** /api/trpc/scheduler.schedule | Schedule

<a name="schedulerCancel"></a>
# **schedulerCancel**
> TRPCResponse schedulerCancel(body)

Cancel

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let body = new JekyllForgeApi.TrpcSchedulerCancelBody(); // TrpcSchedulerCancelBody | 

apiInstance.schedulerCancel(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelBody**](TrpcSchedulerCancelBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerCancelAll"></a>
# **schedulerCancelAll**
> TRPCResponse schedulerCancelAll(body)

Cancel All

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let body = new JekyllForgeApi.TrpcSchedulerCancelAllBody(); // TrpcSchedulerCancelAllBody | 

apiInstance.schedulerCancelAll(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelAllBody**](TrpcSchedulerCancelAllBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerList"></a>
# **schedulerList**
> TRPCResponse schedulerList(input)

List

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.schedulerList(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="schedulerListHeartbeatJobs"></a>
# **schedulerListHeartbeatJobs**
> TRPCResponse schedulerListHeartbeatJobs(input)

List Heartbeat Jobs

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.schedulerListHeartbeatJobs(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="schedulerMarkFailed"></a>
# **schedulerMarkFailed**
> TRPCResponse schedulerMarkFailed(body)

Mark Failed

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let body = new JekyllForgeApi.TrpcSchedulerMarkFailedBody(); // TrpcSchedulerMarkFailedBody | 

apiInstance.schedulerMarkFailed(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkFailedBody**](TrpcSchedulerMarkFailedBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerMarkPublished"></a>
# **schedulerMarkPublished**
> TRPCResponse schedulerMarkPublished(body)

Mark Published

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let body = new JekyllForgeApi.TrpcSchedulerMarkPublishedBody(); // TrpcSchedulerMarkPublishedBody | 

apiInstance.schedulerMarkPublished(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkPublishedBody**](TrpcSchedulerMarkPublishedBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerReschedule"></a>
# **schedulerReschedule**
> TRPCResponse schedulerReschedule(body)

Reschedule

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let body = new JekyllForgeApi.TrpcSchedulerRescheduleBody(); // TrpcSchedulerRescheduleBody | 

apiInstance.schedulerReschedule(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerRescheduleBody**](TrpcSchedulerRescheduleBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerSchedule"></a>
# **schedulerSchedule**
> TRPCResponse schedulerSchedule(body)

Schedule

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SchedulerApi();
let body = new JekyllForgeApi.TrpcSchedulerScheduleBody(); // TrpcSchedulerScheduleBody | 

apiInstance.schedulerSchedule(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerScheduleBody**](TrpcSchedulerScheduleBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

