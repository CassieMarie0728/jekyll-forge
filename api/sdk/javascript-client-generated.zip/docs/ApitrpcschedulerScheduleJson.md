# JekyllForgeApi.ApitrpcschedulerScheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | **Number** |  | 
**postId** | **Number** |  | [optional] 
**draftPath** | **String** |  | 
**targetPath** | **String** |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  | 
**commitMessage** | **String** |  | [optional] 
