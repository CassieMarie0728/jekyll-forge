# JekyllForgeApi.TrpcAiProvidersTestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiProvidersSaveJson**](ApitrpcaiProvidersSaveJson.md) |  | 
