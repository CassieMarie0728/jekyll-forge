# JekyllForgeApi.ApitrpcsocialMediaReschedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  | [optional] 
