# JekyllForgeApi.ApitrpcabTestingGenerateVariationsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
**count** | **Number** |  | [optional] 
**tones** | **[String]** |  | [optional] 
**angles** | **[String]** |  | [optional] 
**headline** | **String** |  | 
**content** | **String** |  | 
