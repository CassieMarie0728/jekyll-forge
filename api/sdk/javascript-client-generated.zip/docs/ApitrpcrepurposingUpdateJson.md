# JekyllForgeApi.ApitrpcrepurposingUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**content** | **String** |  | [optional] 
**status** | **Object** |  | [optional] 
**isCustomized** | **Boolean** |  | [optional] 
