# JekyllForgeApi.TrpcAssetsGenerateAltTextBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsGenerateAltTextJson**](ApitrpcassetsGenerateAltTextJson.md) |  | 
