# JekyllForgeApi.ApitrpcsocialMediaConnectAccountJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | **String** |  | 
**accessToken** | **String** |  | 
**refreshToken** | **String** |  | [optional] 
**expiresAt** | **Object** |  | [optional] 
**accountId** | **String** |  | 
**username** | **String** |  | [optional] 
**displayName** | **String** |  | [optional] 
**profileImageUrl** | **String** |  | [optional] 

<a name="PlatformEnum"></a>
## Enum: PlatformEnum

* `twitter` (value: `"twitter"`)
* `linkedin` (value: `"linkedin"`)
* `facebook` (value: `"facebook"`)
* `instagram` (value: `"instagram"`)

