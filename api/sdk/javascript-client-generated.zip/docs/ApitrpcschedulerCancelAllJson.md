# JekyllForgeApi.ApitrpcschedulerCancelAllJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | **Number** |  | 
