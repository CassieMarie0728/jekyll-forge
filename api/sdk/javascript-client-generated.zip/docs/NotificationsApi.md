# JekyllForgeApi.NotificationsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**notificationsRegisterDevice**](NotificationsApi.md#notificationsRegisterDevice) | **POST** /api/trpc/notifications.registerDevice | Register Device
[**notificationsUnregisterDevice**](NotificationsApi.md#notificationsUnregisterDevice) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device

<a name="notificationsRegisterDevice"></a>
# **notificationsRegisterDevice**
> TRPCResponse notificationsRegisterDevice(body)

Register Device

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.NotificationsApi();
let body = new JekyllForgeApi.TrpcNotificationsRegisterDeviceBody(); // TrpcNotificationsRegisterDeviceBody | 

apiInstance.notificationsRegisterDevice(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsRegisterDeviceBody**](TrpcNotificationsRegisterDeviceBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="notificationsUnregisterDevice"></a>
# **notificationsUnregisterDevice**
> TRPCResponse notificationsUnregisterDevice(body)

Unregister Device

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.NotificationsApi();
let body = new JekyllForgeApi.TrpcNotificationsUnregisterDeviceBody(); // TrpcNotificationsUnregisterDeviceBody | 

apiInstance.notificationsUnregisterDevice(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsUnregisterDeviceBody**](TrpcNotificationsUnregisterDeviceBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

