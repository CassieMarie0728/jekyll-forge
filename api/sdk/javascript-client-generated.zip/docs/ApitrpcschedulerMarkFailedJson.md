# JekyllForgeApi.ApitrpcschedulerMarkFailedJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**errorMessage** | **String** |  | 
