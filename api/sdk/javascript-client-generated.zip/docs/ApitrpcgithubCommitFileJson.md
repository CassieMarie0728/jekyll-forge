# JekyllForgeApi.ApitrpcgithubCommitFileJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**path** | **String** |  | 
**branch** | **String** |  | 
**content** | **String** |  | 
**message** | **String** |  | 
**sha** | **String** |  | [optional] 
