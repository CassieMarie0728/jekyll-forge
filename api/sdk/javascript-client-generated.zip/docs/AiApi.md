# JekyllForgeApi.AiApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiGenerate**](AiApi.md#aiGenerate) | **POST** /api/trpc/ai.generate | Generate
[**aiGetSettings**](AiApi.md#aiGetSettings) | **GET** /api/trpc/ai.getSettings | Get Settings
[**aiGetUsageStats**](AiApi.md#aiGetUsageStats) | **GET** /api/trpc/ai.getUsageStats | Get Usage Stats
[**aiUpdateSettings**](AiApi.md#aiUpdateSettings) | **POST** /api/trpc/ai.updateSettings | Update Settings

<a name="aiGenerate"></a>
# **aiGenerate**
> TRPCResponse aiGenerate(body)

Generate

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiApi();
let body = new JekyllForgeApi.TrpcAiGenerateBody(); // TrpcAiGenerateBody | 

apiInstance.aiGenerate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiGenerateBody**](TrpcAiGenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiGetSettings"></a>
# **aiGetSettings**
> TRPCResponse aiGetSettings()

Get Settings

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiApi();
apiInstance.aiGetSettings((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiGetUsageStats"></a>
# **aiGetUsageStats**
> TRPCResponse aiGetUsageStats()

Get Usage Stats

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiApi();
apiInstance.aiGetUsageStats((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiUpdateSettings"></a>
# **aiUpdateSettings**
> TRPCResponse aiUpdateSettings(body)

Update Settings

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiApi();
let body = new JekyllForgeApi.TrpcAiUpdateSettingsBody(); // TrpcAiUpdateSettingsBody | 

apiInstance.aiUpdateSettings(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiUpdateSettingsBody**](TrpcAiUpdateSettingsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

