# JekyllForgeApi.ApitrpcabTestingApplyWinnerJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
**winningVariationIndex** | **Number** |  | 
