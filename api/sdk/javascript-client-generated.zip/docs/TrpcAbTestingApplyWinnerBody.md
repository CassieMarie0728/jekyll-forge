# JekyllForgeApi.TrpcAbTestingApplyWinnerBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingApplyWinnerJson**](ApitrpcabTestingApplyWinnerJson.md) |  | 
