# JekyllForgeApi.PostsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**postsAutosave**](PostsApi.md#postsAutosave) | **POST** /api/trpc/posts.autosave | Autosave
[**postsDelete**](PostsApi.md#postsDelete) | **POST** /api/trpc/posts.delete | Delete
[**postsGet**](PostsApi.md#postsGet) | **GET** /api/trpc/posts.get | Get
[**postsGetFrontMatterTemplates**](PostsApi.md#postsGetFrontMatterTemplates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
[**postsList**](PostsApi.md#postsList) | **GET** /api/trpc/posts.list | List
[**postsUpdate**](PostsApi.md#postsUpdate) | **POST** /api/trpc/posts.update | Update
[**postsUpsert**](PostsApi.md#postsUpsert) | **POST** /api/trpc/posts.upsert | Upsert

<a name="postsAutosave"></a>
# **postsAutosave**
> TRPCResponse postsAutosave(body)

Autosave

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let body = new JekyllForgeApi.TrpcPostsAutosaveBody(); // TrpcPostsAutosaveBody | 

apiInstance.postsAutosave(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsAutosaveBody**](TrpcPostsAutosaveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsDelete"></a>
# **postsDelete**
> TRPCResponse postsDelete(body)

Delete

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let body = new JekyllForgeApi.TrpcPostsDeleteBody(); // TrpcPostsDeleteBody | 

apiInstance.postsDelete(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsDeleteBody**](TrpcPostsDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsGet"></a>
# **postsGet**
> TRPCResponse postsGet(input)

Get

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.postsGet(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsGetFrontMatterTemplates"></a>
# **postsGetFrontMatterTemplates**
> TRPCResponse postsGetFrontMatterTemplates(input)

Get Front Matter Templates

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.postsGetFrontMatterTemplates(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsList"></a>
# **postsList**
> TRPCResponse postsList(input)

List

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.postsList(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsUpdate"></a>
# **postsUpdate**
> TRPCResponse postsUpdate(body)

Update

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let body = new JekyllForgeApi.TrpcPostsUpdateBody(); // TrpcPostsUpdateBody | 

apiInstance.postsUpdate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpdateBody**](TrpcPostsUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsUpsert"></a>
# **postsUpsert**
> TRPCResponse postsUpsert(body)

Upsert

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.PostsApi();
let body = new JekyllForgeApi.TrpcPostsUpsertBody(); // TrpcPostsUpsertBody | 

apiInstance.postsUpsert(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpsertBody**](TrpcPostsUpsertBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

