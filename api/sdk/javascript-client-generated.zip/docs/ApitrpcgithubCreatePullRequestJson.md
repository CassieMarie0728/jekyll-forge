# JekyllForgeApi.ApitrpcgithubCreatePullRequestJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**title** | **String** |  | 
**head** | **String** |  | 
**base** | **String** |  | 
**body** | **String** |  | [optional] 
