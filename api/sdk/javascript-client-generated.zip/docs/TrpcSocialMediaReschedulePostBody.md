# JekyllForgeApi.TrpcSocialMediaReschedulePostBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaReschedulePostJson**](ApitrpcsocialMediaReschedulePostJson.md) |  | 
