# JekyllForgeApi.ApitrpcrepurposingRegenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**postId** | **Number** |  | 
**siteId** | **Number** |  | 
