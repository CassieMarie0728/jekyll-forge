# JekyllForgeApi.ApitrpcnotificationsRegisterDeviceJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | 
**platform** | **String** |  | 

<a name="PlatformEnum"></a>
## Enum: PlatformEnum

* `android` (value: `"android"`)

