# JekyllForgeApi.ApitrpcrepurposingGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
**siteId** | **Number** |  | 
**format** | **String** |  | 

<a name="FormatEnum"></a>
## Enum: FormatEnum

* `twitter` (value: `"twitter"`)
* `linkedin` (value: `"linkedin"`)
* `tiktok` (value: `"tiktok"`)
* `youtube` (value: `"youtube"`)
* `newsletter` (value: `"newsletter"`)
* `email` (value: `"email"`)
* `podcast` (value: `"podcast"`)
* `slides` (value: `"slides"`)

