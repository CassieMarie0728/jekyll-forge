# JekyllForgeApi.TrpcGithubCreateBranchBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubCreateBranchJson**](ApitrpcgithubCreateBranchJson.md) |  | 
