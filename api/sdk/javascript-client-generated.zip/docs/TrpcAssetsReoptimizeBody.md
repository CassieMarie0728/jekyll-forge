# JekyllForgeApi.TrpcAssetsReoptimizeBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsReoptimizeJson**](ApitrpcassetsReoptimizeJson.md) |  | 
