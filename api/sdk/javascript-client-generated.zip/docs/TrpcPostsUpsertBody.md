# JekyllForgeApi.TrpcPostsUpsertBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcpostsUpsertJson**](ApitrpcpostsUpsertJson.md) |  | 
