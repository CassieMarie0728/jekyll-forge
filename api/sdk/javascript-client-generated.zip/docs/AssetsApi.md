# JekyllForgeApi.AssetsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**assetsDelete**](AssetsApi.md#assetsDelete) | **POST** /api/trpc/assets.delete | Delete
[**assetsGenerateAltText**](AssetsApi.md#assetsGenerateAltText) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
[**assetsList**](AssetsApi.md#assetsList) | **GET** /api/trpc/assets.list | List
[**assetsReoptimize**](AssetsApi.md#assetsReoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
[**assetsUpdate**](AssetsApi.md#assetsUpdate) | **POST** /api/trpc/assets.update | Update
[**assetsUpload**](AssetsApi.md#assetsUpload) | **POST** /api/trpc/assets.upload | Upload

<a name="assetsDelete"></a>
# **assetsDelete**
> TRPCResponse assetsDelete(body)

Delete

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AssetsApi();
let body = new JekyllForgeApi.TrpcAssetsDeleteBody(); // TrpcAssetsDeleteBody | 

apiInstance.assetsDelete(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsDeleteBody**](TrpcAssetsDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsGenerateAltText"></a>
# **assetsGenerateAltText**
> TRPCResponse assetsGenerateAltText(body)

Generate Alt Text

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AssetsApi();
let body = new JekyllForgeApi.TrpcAssetsGenerateAltTextBody(); // TrpcAssetsGenerateAltTextBody | 

apiInstance.assetsGenerateAltText(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsGenerateAltTextBody**](TrpcAssetsGenerateAltTextBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsList"></a>
# **assetsList**
> TRPCResponse assetsList(input)

List

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AssetsApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.assetsList(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="assetsReoptimize"></a>
# **assetsReoptimize**
> TRPCResponse assetsReoptimize(body)

Reoptimize

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AssetsApi();
let body = new JekyllForgeApi.TrpcAssetsReoptimizeBody(); // TrpcAssetsReoptimizeBody | 

apiInstance.assetsReoptimize(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsReoptimizeBody**](TrpcAssetsReoptimizeBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsUpdate"></a>
# **assetsUpdate**
> TRPCResponse assetsUpdate(body)

Update

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AssetsApi();
let body = new JekyllForgeApi.TrpcAssetsUpdateBody(); // TrpcAssetsUpdateBody | 

apiInstance.assetsUpdate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUpdateBody**](TrpcAssetsUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsUpload"></a>
# **assetsUpload**
> TRPCResponse assetsUpload(body)

Upload

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AssetsApi();
let body = new JekyllForgeApi.TrpcAssetsUploadBody(); // TrpcAssetsUploadBody | 

apiInstance.assetsUpload(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUploadBody**](TrpcAssetsUploadBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

