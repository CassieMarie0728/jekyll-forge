# JekyllForgeApi.ApitrpcsnapshotsCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | **Number** |  | 
**postId** | **Number** |  | [optional] 
**postPath** | **String** |  | [optional] 
**label** | **String** |  | 
**reason** | **Object** |  | 
**markdown** | **String** |  | [optional] 
**frontMatter** | **Object** |  | [optional] 
