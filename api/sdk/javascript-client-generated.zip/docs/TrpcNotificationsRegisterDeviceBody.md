# JekyllForgeApi.TrpcNotificationsRegisterDeviceBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcnotificationsRegisterDeviceJson**](ApitrpcnotificationsRegisterDeviceJson.md) |  | 
