# JekyllForgeApi.TrpcSocialMediaDisconnectAccountBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsDeleteJson**](ApitrpcassetsDeleteJson.md) |  | 
