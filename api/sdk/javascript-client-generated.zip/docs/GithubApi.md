# JekyllForgeApi.GithubApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**githubCheckPluginCompatibility**](GithubApi.md#githubCheckPluginCompatibility) | **GET** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
[**githubCommitFile**](GithubApi.md#githubCommitFile) | **POST** /api/trpc/github.commitFile | Commit File
[**githubConnect**](GithubApi.md#githubConnect) | **POST** /api/trpc/github.connect | Connect
[**githubCreateBranch**](GithubApi.md#githubCreateBranch) | **POST** /api/trpc/github.createBranch | Create Branch
[**githubCreatePullRequest**](GithubApi.md#githubCreatePullRequest) | **POST** /api/trpc/github.createPullRequest | Create Pull Request
[**githubDeleteFile**](GithubApi.md#githubDeleteFile) | **POST** /api/trpc/github.deleteFile | Delete File
[**githubDetectJekyll**](GithubApi.md#githubDetectJekyll) | **GET** /api/trpc/github.detectJekyll | Detect Jekyll
[**githubDisconnect**](GithubApi.md#githubDisconnect) | **POST** /api/trpc/github.disconnect | Disconnect
[**githubGenerateActionsWorkflow**](GithubApi.md#githubGenerateActionsWorkflow) | **POST** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
[**githubGetFile**](GithubApi.md#githubGetFile) | **GET** /api/trpc/github.getFile | Get File
[**githubGetJekyllConfig**](GithubApi.md#githubGetJekyllConfig) | **GET** /api/trpc/github.getJekyllConfig | Get Jekyll Config
[**githubGetPagesStatus**](GithubApi.md#githubGetPagesStatus) | **GET** /api/trpc/github.getPagesStatus | Get Pages Status
[**githubGetRateLimit**](GithubApi.md#githubGetRateLimit) | **GET** /api/trpc/github.getRateLimit | Get Rate Limit
[**githubInventory**](GithubApi.md#githubInventory) | **GET** /api/trpc/github.inventory | Inventory
[**githubListBranches**](GithubApi.md#githubListBranches) | **GET** /api/trpc/github.listBranches | List Branches
[**githubListFiles**](GithubApi.md#githubListFiles) | **GET** /api/trpc/github.listFiles | List Files
[**githubListRepos**](GithubApi.md#githubListRepos) | **GET** /api/trpc/github.listRepos | List Repos
[**githubRepositories**](GithubApi.md#githubRepositories) | **GET** /api/trpc/github.repositories | Repositories
[**githubReviewFile**](GithubApi.md#githubReviewFile) | **GET** /api/trpc/github.reviewFile | Review File
[**githubStatus**](GithubApi.md#githubStatus) | **GET** /api/trpc/github.status | Status
[**githubUpdateJekyllConfig**](GithubApi.md#githubUpdateJekyllConfig) | **POST** /api/trpc/github.updateJekyllConfig | Update Jekyll Config

<a name="githubCheckPluginCompatibility"></a>
# **githubCheckPluginCompatibility**
> TRPCResponse githubCheckPluginCompatibility(input)

Check Plugin Compatibility

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubCheckPluginCompatibility(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubCommitFile"></a>
# **githubCommitFile**
> TRPCResponse githubCommitFile(body)

Commit File

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubCommitFileBody(); // TrpcGithubCommitFileBody | 

apiInstance.githubCommitFile(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCommitFileBody**](TrpcGithubCommitFileBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubConnect"></a>
# **githubConnect**
> TRPCResponse githubConnect(body)

Connect

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubConnectBody(); // TrpcGithubConnectBody | 

apiInstance.githubConnect(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubConnectBody**](TrpcGithubConnectBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubCreateBranch"></a>
# **githubCreateBranch**
> TRPCResponse githubCreateBranch(body)

Create Branch

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubCreateBranchBody(); // TrpcGithubCreateBranchBody | 

apiInstance.githubCreateBranch(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreateBranchBody**](TrpcGithubCreateBranchBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubCreatePullRequest"></a>
# **githubCreatePullRequest**
> TRPCResponse githubCreatePullRequest(body)

Create Pull Request

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubCreatePullRequestBody(); // TrpcGithubCreatePullRequestBody | 

apiInstance.githubCreatePullRequest(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreatePullRequestBody**](TrpcGithubCreatePullRequestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubDeleteFile"></a>
# **githubDeleteFile**
> TRPCResponse githubDeleteFile(body)

Delete File

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubDeleteFileBody(); // TrpcGithubDeleteFileBody | 

apiInstance.githubDeleteFile(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDeleteFileBody**](TrpcGithubDeleteFileBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubDetectJekyll"></a>
# **githubDetectJekyll**
> TRPCResponse githubDetectJekyll(input)

Detect Jekyll

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubDetectJekyll(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubDisconnect"></a>
# **githubDisconnect**
> TRPCResponse githubDisconnect(opts)

Disconnect

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let opts = { 
  'body': new JekyllForgeApi.TrpcGithubDisconnectBody() // TrpcGithubDisconnectBody | 
};
apiInstance.githubDisconnect(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDisconnectBody**](TrpcGithubDisconnectBody.md)|  | [optional] 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubGenerateActionsWorkflow"></a>
# **githubGenerateActionsWorkflow**
> TRPCResponse githubGenerateActionsWorkflow(body)

Generate Actions Workflow

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubGenerateActionsWorkflowBody(); // TrpcGithubGenerateActionsWorkflowBody | 

apiInstance.githubGenerateActionsWorkflow(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubGenerateActionsWorkflowBody**](TrpcGithubGenerateActionsWorkflowBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubGetFile"></a>
# **githubGetFile**
> TRPCResponse githubGetFile(input)

Get File

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubGetFile(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetJekyllConfig"></a>
# **githubGetJekyllConfig**
> TRPCResponse githubGetJekyllConfig(input)

Get Jekyll Config

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubGetJekyllConfig(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetPagesStatus"></a>
# **githubGetPagesStatus**
> TRPCResponse githubGetPagesStatus(input)

Get Pages Status

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubGetPagesStatus(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetRateLimit"></a>
# **githubGetRateLimit**
> TRPCResponse githubGetRateLimit()

Get Rate Limit

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
apiInstance.githubGetRateLimit((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubInventory"></a>
# **githubInventory**
> TRPCResponse githubInventory(input)

Inventory

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubInventory(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListBranches"></a>
# **githubListBranches**
> TRPCResponse githubListBranches(input)

List Branches

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubListBranches(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListFiles"></a>
# **githubListFiles**
> TRPCResponse githubListFiles(input)

List Files

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubListFiles(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListRepos"></a>
# **githubListRepos**
> TRPCResponse githubListRepos(input)

List Repos

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubListRepos(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubRepositories"></a>
# **githubRepositories**
> TRPCResponse githubRepositories(input)

Repositories

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubRepositories(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubReviewFile"></a>
# **githubReviewFile**
> TRPCResponse githubReviewFile(input)

Review File

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.githubReviewFile(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubStatus"></a>
# **githubStatus**
> TRPCResponse githubStatus()

Status

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
apiInstance.githubStatus((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubUpdateJekyllConfig"></a>
# **githubUpdateJekyllConfig**
> TRPCResponse githubUpdateJekyllConfig(body)

Update Jekyll Config

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.GithubApi();
let body = new JekyllForgeApi.TrpcGithubUpdateJekyllConfigBody(); // TrpcGithubUpdateJekyllConfigBody | 

apiInstance.githubUpdateJekyllConfig(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubUpdateJekyllConfigBody**](TrpcGithubUpdateJekyllConfigBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

