# JekyllForgeApi.ApitrpcassetsDeleteJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
