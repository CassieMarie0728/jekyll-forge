# JekyllForgeApi.ApitrpcabTestingUpdateMetricsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
**variationIndex** | **Number** |  | 
**platform** | **String** |  | 
**metrics** | [**ApitrpcabTestingUpdateMetricsJsonMetrics**](ApitrpcabTestingUpdateMetricsJsonMetrics.md) |  | [optional] 
