# JekyllForgeApi.TrpcAssetsUploadBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsUploadJson**](ApitrpcassetsUploadJson.md) |  | 
