# JekyllForgeApi.TrpcRepurposingGenerateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcrepurposingGenerateJson**](ApitrpcrepurposingGenerateJson.md) |  | 
