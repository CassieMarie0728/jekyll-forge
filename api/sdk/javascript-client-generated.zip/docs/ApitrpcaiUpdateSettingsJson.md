# JekyllForgeApi.ApitrpcaiUpdateSettingsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  | [optional] 
**temperature** | **Number** |  | [optional] 
**maxTokens** | **Number** |  | [optional] 
**systemPrompt** | **String** |  | [optional] 
**brandVoicePrompt** | **String** |  | [optional] 
**safetyPrompt** | **String** |  | [optional] 
**streaming** | **Boolean** |  | [optional] 
**defaultLanguage** | **String** |  | [optional] 
**defaultTone** | **String** |  | [optional] 
**budgetLimitCents** | **Number** |  | [optional] 
