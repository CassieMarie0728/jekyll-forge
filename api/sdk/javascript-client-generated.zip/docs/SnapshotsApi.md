# JekyllForgeApi.SnapshotsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**snapshotsCreate**](SnapshotsApi.md#snapshotsCreate) | **POST** /api/trpc/snapshots.create | Create
[**snapshotsGet**](SnapshotsApi.md#snapshotsGet) | **GET** /api/trpc/snapshots.get | Get
[**snapshotsListByPost**](SnapshotsApi.md#snapshotsListByPost) | **GET** /api/trpc/snapshots.listByPost | List By Post

<a name="snapshotsCreate"></a>
# **snapshotsCreate**
> TRPCResponse snapshotsCreate(body)

Create

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SnapshotsApi();
let body = new JekyllForgeApi.TrpcSnapshotsCreateBody(); // TrpcSnapshotsCreateBody | 

apiInstance.snapshotsCreate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSnapshotsCreateBody**](TrpcSnapshotsCreateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="snapshotsGet"></a>
# **snapshotsGet**
> TRPCResponse snapshotsGet(input)

Get

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SnapshotsApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.snapshotsGet(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="snapshotsListByPost"></a>
# **snapshotsListByPost**
> TRPCResponse snapshotsListByPost(input)

List By Post

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SnapshotsApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.snapshotsListByPost(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

