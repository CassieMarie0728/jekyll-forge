# JekyllForgeApi.TrpcSocialMediaConnectAccountBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaConnectAccountJson**](ApitrpcsocialMediaConnectAccountJson.md) |  | 
