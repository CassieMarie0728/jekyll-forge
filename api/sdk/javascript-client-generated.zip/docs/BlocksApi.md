# JekyllForgeApi.BlocksApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**blocksCreate**](BlocksApi.md#blocksCreate) | **POST** /api/trpc/blocks.create | Create
[**blocksDelete**](BlocksApi.md#blocksDelete) | **POST** /api/trpc/blocks.delete | Delete
[**blocksList**](BlocksApi.md#blocksList) | **GET** /api/trpc/blocks.list | List
[**blocksUpdate**](BlocksApi.md#blocksUpdate) | **POST** /api/trpc/blocks.update | Update

<a name="blocksCreate"></a>
# **blocksCreate**
> TRPCResponse blocksCreate(body)

Create

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.BlocksApi();
let body = new JekyllForgeApi.TrpcBlocksCreateBody(); // TrpcBlocksCreateBody | 

apiInstance.blocksCreate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksCreateBody**](TrpcBlocksCreateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="blocksDelete"></a>
# **blocksDelete**
> TRPCResponse blocksDelete(body)

Delete

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.BlocksApi();
let body = new JekyllForgeApi.TrpcBlocksDeleteBody(); // TrpcBlocksDeleteBody | 

apiInstance.blocksDelete(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksDeleteBody**](TrpcBlocksDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="blocksList"></a>
# **blocksList**
> TRPCResponse blocksList()

List

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.BlocksApi();
apiInstance.blocksList((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="blocksUpdate"></a>
# **blocksUpdate**
> TRPCResponse blocksUpdate(body)

Update

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.BlocksApi();
let body = new JekyllForgeApi.TrpcBlocksUpdateBody(); // TrpcBlocksUpdateBody | 

apiInstance.blocksUpdate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksUpdateBody**](TrpcBlocksUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

