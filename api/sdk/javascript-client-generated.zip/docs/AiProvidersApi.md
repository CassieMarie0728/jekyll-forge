# JekyllForgeApi.AiProvidersApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiProvidersActivate**](AiProvidersApi.md#aiProvidersActivate) | **POST** /api/trpc/aiProviders.activate | Activate
[**aiProvidersGetSettings**](AiProvidersApi.md#aiProvidersGetSettings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
[**aiProvidersRemove**](AiProvidersApi.md#aiProvidersRemove) | **POST** /api/trpc/aiProviders.remove | Remove
[**aiProvidersSave**](AiProvidersApi.md#aiProvidersSave) | **POST** /api/trpc/aiProviders.save | Save
[**aiProvidersTest**](AiProvidersApi.md#aiProvidersTest) | **POST** /api/trpc/aiProviders.test | Test

<a name="aiProvidersActivate"></a>
# **aiProvidersActivate**
> TRPCResponse aiProvidersActivate(body)

Activate

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiProvidersApi();
let body = new JekyllForgeApi.TrpcAiProvidersActivateBody(); // TrpcAiProvidersActivateBody | 

apiInstance.aiProvidersActivate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersActivateBody**](TrpcAiProvidersActivateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersGetSettings"></a>
# **aiProvidersGetSettings**
> TRPCResponse aiProvidersGetSettings()

Get Settings

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiProvidersApi();
apiInstance.aiProvidersGetSettings((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiProvidersRemove"></a>
# **aiProvidersRemove**
> TRPCResponse aiProvidersRemove(body)

Remove

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiProvidersApi();
let body = new JekyllForgeApi.TrpcAiProvidersRemoveBody(); // TrpcAiProvidersRemoveBody | 

apiInstance.aiProvidersRemove(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersRemoveBody**](TrpcAiProvidersRemoveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersSave"></a>
# **aiProvidersSave**
> TRPCResponse aiProvidersSave(body)

Save

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiProvidersApi();
let body = new JekyllForgeApi.TrpcAiProvidersSaveBody(); // TrpcAiProvidersSaveBody | 

apiInstance.aiProvidersSave(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersSaveBody**](TrpcAiProvidersSaveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersTest"></a>
# **aiProvidersTest**
> TRPCResponse aiProvidersTest(body)

Test

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.AiProvidersApi();
let body = new JekyllForgeApi.TrpcAiProvidersTestBody(); // TrpcAiProvidersTestBody | 

apiInstance.aiProvidersTest(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersTestBody**](TrpcAiProvidersTestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

