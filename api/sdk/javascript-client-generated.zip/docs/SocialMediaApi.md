# JekyllForgeApi.SocialMediaApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**socialMediaCancelScheduledPost**](SocialMediaApi.md#socialMediaCancelScheduledPost) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**socialMediaConnectAccount**](SocialMediaApi.md#socialMediaConnectAccount) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
[**socialMediaDisconnectAccount**](SocialMediaApi.md#socialMediaDisconnectAccount) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**socialMediaGetAccountDetails**](SocialMediaApi.md#socialMediaGetAccountDetails) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**socialMediaGetAccounts**](SocialMediaApi.md#socialMediaGetAccounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
[**socialMediaGetAnalyticsByPlatform**](SocialMediaApi.md#socialMediaGetAnalyticsByPlatform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**socialMediaGetAnalyticsSummary**](SocialMediaApi.md#socialMediaGetAnalyticsSummary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**socialMediaGetContentAnalytics**](SocialMediaApi.md#socialMediaGetContentAnalytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**socialMediaGetScheduledPosts**](SocialMediaApi.md#socialMediaGetScheduledPosts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**socialMediaPublishContent**](SocialMediaApi.md#socialMediaPublishContent) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
[**socialMediaReschedulePost**](SocialMediaApi.md#socialMediaReschedulePost) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**socialMediaSchedulePost**](SocialMediaApi.md#socialMediaSchedulePost) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
[**socialMediaSyncAnalytics**](SocialMediaApi.md#socialMediaSyncAnalytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

<a name="socialMediaCancelScheduledPost"></a>
# **socialMediaCancelScheduledPost**
> TRPCResponse socialMediaCancelScheduledPost(body)

Cancel Scheduled Post

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaCancelScheduledPostBody(); // TrpcSocialMediaCancelScheduledPostBody | 

apiInstance.socialMediaCancelScheduledPost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaCancelScheduledPostBody**](TrpcSocialMediaCancelScheduledPostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaConnectAccount"></a>
# **socialMediaConnectAccount**
> TRPCResponse socialMediaConnectAccount(body)

Connect Account

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaConnectAccountBody(); // TrpcSocialMediaConnectAccountBody | 

apiInstance.socialMediaConnectAccount(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaConnectAccountBody**](TrpcSocialMediaConnectAccountBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaDisconnectAccount"></a>
# **socialMediaDisconnectAccount**
> TRPCResponse socialMediaDisconnectAccount(body)

Disconnect Account

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaDisconnectAccountBody(); // TrpcSocialMediaDisconnectAccountBody | 

apiInstance.socialMediaDisconnectAccount(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaDisconnectAccountBody**](TrpcSocialMediaDisconnectAccountBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaGetAccountDetails"></a>
# **socialMediaGetAccountDetails**
> TRPCResponse socialMediaGetAccountDetails(input)

Get Account Details

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.socialMediaGetAccountDetails(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAccounts"></a>
# **socialMediaGetAccounts**
> TRPCResponse socialMediaGetAccounts()

Get Accounts

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
apiInstance.socialMediaGetAccounts((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAnalyticsByPlatform"></a>
# **socialMediaGetAnalyticsByPlatform**
> TRPCResponse socialMediaGetAnalyticsByPlatform(input)

Get Analytics By Platform

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.socialMediaGetAnalyticsByPlatform(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAnalyticsSummary"></a>
# **socialMediaGetAnalyticsSummary**
> TRPCResponse socialMediaGetAnalyticsSummary()

Get Analytics Summary

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
apiInstance.socialMediaGetAnalyticsSummary((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetContentAnalytics"></a>
# **socialMediaGetContentAnalytics**
> TRPCResponse socialMediaGetContentAnalytics(input)

Get Content Analytics

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.socialMediaGetContentAnalytics(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetScheduledPosts"></a>
# **socialMediaGetScheduledPosts**
> TRPCResponse socialMediaGetScheduledPosts(input)

Get Scheduled Posts

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.socialMediaGetScheduledPosts(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaPublishContent"></a>
# **socialMediaPublishContent**
> TRPCResponse socialMediaPublishContent(body)

Publish Content

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaPublishContentBody(); // TrpcSocialMediaPublishContentBody | 

apiInstance.socialMediaPublishContent(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaPublishContentBody**](TrpcSocialMediaPublishContentBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaReschedulePost"></a>
# **socialMediaReschedulePost**
> TRPCResponse socialMediaReschedulePost(body)

Reschedule Post

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaReschedulePostBody(); // TrpcSocialMediaReschedulePostBody | 

apiInstance.socialMediaReschedulePost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaReschedulePostBody**](TrpcSocialMediaReschedulePostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaSchedulePost"></a>
# **socialMediaSchedulePost**
> TRPCResponse socialMediaSchedulePost(body)

Schedule Post

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaSchedulePostBody(); // TrpcSocialMediaSchedulePostBody | 

apiInstance.socialMediaSchedulePost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSchedulePostBody**](TrpcSocialMediaSchedulePostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaSyncAnalytics"></a>
# **socialMediaSyncAnalytics**
> TRPCResponse socialMediaSyncAnalytics(body)

Sync Analytics

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.SocialMediaApi();
let body = new JekyllForgeApi.TrpcSocialMediaSyncAnalyticsBody(); // TrpcSocialMediaSyncAnalyticsBody | 

apiInstance.socialMediaSyncAnalytics(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSyncAnalyticsBody**](TrpcSocialMediaSyncAnalyticsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

