# JekyllForgeApi.TrpcSocialMediaSchedulePostBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaSchedulePostJson**](ApitrpcsocialMediaSchedulePostJson.md) |  | 
