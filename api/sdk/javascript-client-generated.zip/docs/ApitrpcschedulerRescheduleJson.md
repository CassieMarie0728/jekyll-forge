# JekyllForgeApi.ApitrpcschedulerRescheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  | [optional] 
