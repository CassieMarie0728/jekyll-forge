# JekyllForgeApi.ApitrpcblocksCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**category** | **String** |  | [optional] 
**content** | **String** |  | 
**contentType** | **String** |  | 

<a name="ContentTypeEnum"></a>
## Enum: ContentTypeEnum

* `markdown` (value: `"markdown"`)
* `html` (value: `"html"`)
* `liquid` (value: `"liquid"`)

