# JekyllForgeApi.RepurposingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**repurposingDelete**](RepurposingApi.md#repurposingDelete) | **POST** /api/trpc/repurposing.delete | Delete
[**repurposingGenerate**](RepurposingApi.md#repurposingGenerate) | **POST** /api/trpc/repurposing.generate | Generate
[**repurposingGetById**](RepurposingApi.md#repurposingGetById) | **GET** /api/trpc/repurposing.getById | Get By Id
[**repurposingGetByPost**](RepurposingApi.md#repurposingGetByPost) | **GET** /api/trpc/repurposing.getByPost | Get By Post
[**repurposingRegenerate**](RepurposingApi.md#repurposingRegenerate) | **POST** /api/trpc/repurposing.regenerate | Regenerate
[**repurposingUpdate**](RepurposingApi.md#repurposingUpdate) | **POST** /api/trpc/repurposing.update | Update

<a name="repurposingDelete"></a>
# **repurposingDelete**
> TRPCResponse repurposingDelete(body)

Delete

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.RepurposingApi();
let body = new JekyllForgeApi.TrpcRepurposingDeleteBody(); // TrpcRepurposingDeleteBody | 

apiInstance.repurposingDelete(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingDeleteBody**](TrpcRepurposingDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingGenerate"></a>
# **repurposingGenerate**
> TRPCResponse repurposingGenerate(body)

Generate

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.RepurposingApi();
let body = new JekyllForgeApi.TrpcRepurposingGenerateBody(); // TrpcRepurposingGenerateBody | 

apiInstance.repurposingGenerate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingGenerateBody**](TrpcRepurposingGenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingGetById"></a>
# **repurposingGetById**
> TRPCResponse repurposingGetById(input)

Get By Id

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.RepurposingApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.repurposingGetById(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="repurposingGetByPost"></a>
# **repurposingGetByPost**
> TRPCResponse repurposingGetByPost(input)

Get By Post

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.RepurposingApi();
let input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

apiInstance.repurposingGetByPost(input, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="repurposingRegenerate"></a>
# **repurposingRegenerate**
> TRPCResponse repurposingRegenerate(body)

Regenerate

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.RepurposingApi();
let body = new JekyllForgeApi.TrpcRepurposingRegenerateBody(); // TrpcRepurposingRegenerateBody | 

apiInstance.repurposingRegenerate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingRegenerateBody**](TrpcRepurposingRegenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingUpdate"></a>
# **repurposingUpdate**
> TRPCResponse repurposingUpdate(body)

Update

### Example
```javascript
import {JekyllForgeApi} from 'jekyll_forge_api';
let defaultClient = JekyllForgeApi.ApiClient.instance;


let apiInstance = new JekyllForgeApi.RepurposingApi();
let body = new JekyllForgeApi.TrpcRepurposingUpdateBody(); // TrpcRepurposingUpdateBody | 

apiInstance.repurposingUpdate(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingUpdateBody**](TrpcRepurposingUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

