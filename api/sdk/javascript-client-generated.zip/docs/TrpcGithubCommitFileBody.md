# JekyllForgeApi.TrpcGithubCommitFileBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubCommitFileJson**](ApitrpcgithubCommitFileJson.md) |  | 
