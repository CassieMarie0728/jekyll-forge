# JekyllForgeApi.ApitrpcabTestingCompleteTestJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | **Number** |  | 
