# JekyllForgeApi.TrpcSitesUpsertBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsitesUpsertJson**](ApitrpcsitesUpsertJson.md) |  | 
