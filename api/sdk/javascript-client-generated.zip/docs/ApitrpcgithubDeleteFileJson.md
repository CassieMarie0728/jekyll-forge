# JekyllForgeApi.ApitrpcgithubDeleteFileJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**path** | **String** |  | 
**branch** | **String** |  | 
**sha** | **String** |  | 
**message** | **String** |  | 
