# JekyllForgeApi.TrpcSocialMediaSyncAnalyticsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaSyncAnalyticsJson**](ApitrpcsocialMediaSyncAnalyticsJson.md) |  | 
