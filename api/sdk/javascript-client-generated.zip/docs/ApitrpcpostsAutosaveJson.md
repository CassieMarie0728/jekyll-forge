# JekyllForgeApi.ApitrpcpostsAutosaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**markdown** | **String** |  | 
**frontMatter** | **Object** |  | 
