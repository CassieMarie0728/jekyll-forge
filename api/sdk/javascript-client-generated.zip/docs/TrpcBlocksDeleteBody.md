# JekyllForgeApi.TrpcBlocksDeleteBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsDeleteJson**](ApitrpcassetsDeleteJson.md) |  | 
