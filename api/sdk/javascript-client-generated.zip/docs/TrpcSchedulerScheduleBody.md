# JekyllForgeApi.TrpcSchedulerScheduleBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulerScheduleJson**](ApitrpcschedulerScheduleJson.md) |  | 
