# JekyllForgeApi.ApitrpcabTestingUpdateMetricsJsonMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**impressions** | **Number** |  | [optional] 
**engagements** | **Number** |  | [optional] 
**clicks** | **Number** |  | [optional] 
**shares** | **Number** |  | [optional] 
**likes** | **Number** |  | [optional] 
**replies** | **Number** |  | [optional] 
