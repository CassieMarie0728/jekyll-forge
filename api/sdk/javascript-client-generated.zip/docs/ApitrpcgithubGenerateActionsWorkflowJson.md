# JekyllForgeApi.ApitrpcgithubGenerateActionsWorkflowJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**branch** | **String** |  | 
