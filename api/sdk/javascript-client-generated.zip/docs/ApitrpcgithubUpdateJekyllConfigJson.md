# JekyllForgeApi.ApitrpcgithubUpdateJekyllConfigJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**rootPath** | **String** |  | 
**branch** | **String** |  | 
**commitMessage** | **String** |  | [optional] 
