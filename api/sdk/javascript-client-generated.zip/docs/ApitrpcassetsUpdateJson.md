# JekyllForgeApi.ApitrpcassetsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | [optional] 
**path** | **String** |  | [optional] 
**alt** | **String** |  | [optional] 
