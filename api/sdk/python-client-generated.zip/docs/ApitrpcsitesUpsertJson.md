# ApitrpcsitesUpsertJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **str** |  | 
**repo** | **str** |  | 
**default_branch** | **str** |  | [optional] 
**selected_branch** | **str** |  | [optional] 
**root_path** | **str** |  | [optional] 
**is_jekyll** | **bool** |  | [optional] 
**is_favorite** | **bool** |  | [optional] 
**timezone** | **str** |  | [optional] 
**default_layout** | **str** |  | [optional] 
**default_asset_path** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

