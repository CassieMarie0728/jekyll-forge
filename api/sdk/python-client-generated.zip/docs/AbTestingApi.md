# swagger_client.AbTestingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ab_testing_apply_winner**](AbTestingApi.md#ab_testing_apply_winner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
[**ab_testing_complete_test**](AbTestingApi.md#ab_testing_complete_test) | **POST** /api/trpc/abTesting.completeTest | Complete Test
[**ab_testing_generate_variations**](AbTestingApi.md#ab_testing_generate_variations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
[**ab_testing_get_results**](AbTestingApi.md#ab_testing_get_results) | **GET** /api/trpc/abTesting.getResults | Get Results
[**ab_testing_get_variations**](AbTestingApi.md#ab_testing_get_variations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
[**ab_testing_publish_variation**](AbTestingApi.md#ab_testing_publish_variation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
[**ab_testing_update_metrics**](AbTestingApi.md#ab_testing_update_metrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics

# **ab_testing_apply_winner**
> TRPCResponse ab_testing_apply_winner(body)

Apply Winner

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAbTestingApplyWinnerBody() # TrpcAbTestingApplyWinnerBody | 

try:
    # Apply Winner
    api_response = api_instance.ab_testing_apply_winner(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_apply_winner: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingApplyWinnerBody**](TrpcAbTestingApplyWinnerBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ab_testing_complete_test**
> TRPCResponse ab_testing_complete_test(body)

Complete Test

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAbTestingCompleteTestBody() # TrpcAbTestingCompleteTestBody | 

try:
    # Complete Test
    api_response = api_instance.ab_testing_complete_test(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_complete_test: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingCompleteTestBody**](TrpcAbTestingCompleteTestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ab_testing_generate_variations**
> TRPCResponse ab_testing_generate_variations(body)

Generate Variations

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAbTestingGenerateVariationsBody() # TrpcAbTestingGenerateVariationsBody | 

try:
    # Generate Variations
    api_response = api_instance.ab_testing_generate_variations(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_generate_variations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingGenerateVariationsBody**](TrpcAbTestingGenerateVariationsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ab_testing_get_results**
> TRPCResponse ab_testing_get_results(input)

Get Results

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Results
    api_response = api_instance.ab_testing_get_results(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_get_results: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ab_testing_get_variations**
> TRPCResponse ab_testing_get_variations(input)

Get Variations

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Variations
    api_response = api_instance.ab_testing_get_variations(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_get_variations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ab_testing_publish_variation**
> TRPCResponse ab_testing_publish_variation(body)

Publish Variation

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAbTestingPublishVariationBody() # TrpcAbTestingPublishVariationBody | 

try:
    # Publish Variation
    api_response = api_instance.ab_testing_publish_variation(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_publish_variation: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingPublishVariationBody**](TrpcAbTestingPublishVariationBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ab_testing_update_metrics**
> TRPCResponse ab_testing_update_metrics(body)

Update Metrics

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AbTestingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAbTestingUpdateMetricsBody() # TrpcAbTestingUpdateMetricsBody | 

try:
    # Update Metrics
    api_response = api_instance.ab_testing_update_metrics(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AbTestingApi->ab_testing_update_metrics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingUpdateMetricsBody**](TrpcAbTestingUpdateMetricsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

