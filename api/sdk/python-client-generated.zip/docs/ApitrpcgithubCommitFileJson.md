# ApitrpcgithubCommitFileJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **str** |  | 
**repo** | **str** |  | 
**path** | **str** |  | 
**branch** | **str** |  | 
**content** | **str** |  | 
**message** | **str** |  | 
**sha** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

