# swagger_client.GithubApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**github_check_plugin_compatibility**](GithubApi.md#github_check_plugin_compatibility) | **GET** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
[**github_commit_file**](GithubApi.md#github_commit_file) | **POST** /api/trpc/github.commitFile | Commit File
[**github_connect**](GithubApi.md#github_connect) | **POST** /api/trpc/github.connect | Connect
[**github_create_branch**](GithubApi.md#github_create_branch) | **POST** /api/trpc/github.createBranch | Create Branch
[**github_create_pull_request**](GithubApi.md#github_create_pull_request) | **POST** /api/trpc/github.createPullRequest | Create Pull Request
[**github_delete_file**](GithubApi.md#github_delete_file) | **POST** /api/trpc/github.deleteFile | Delete File
[**github_detect_jekyll**](GithubApi.md#github_detect_jekyll) | **GET** /api/trpc/github.detectJekyll | Detect Jekyll
[**github_disconnect**](GithubApi.md#github_disconnect) | **POST** /api/trpc/github.disconnect | Disconnect
[**github_generate_actions_workflow**](GithubApi.md#github_generate_actions_workflow) | **POST** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
[**github_get_file**](GithubApi.md#github_get_file) | **GET** /api/trpc/github.getFile | Get File
[**github_get_jekyll_config**](GithubApi.md#github_get_jekyll_config) | **GET** /api/trpc/github.getJekyllConfig | Get Jekyll Config
[**github_get_pages_status**](GithubApi.md#github_get_pages_status) | **GET** /api/trpc/github.getPagesStatus | Get Pages Status
[**github_get_rate_limit**](GithubApi.md#github_get_rate_limit) | **GET** /api/trpc/github.getRateLimit | Get Rate Limit
[**github_inventory**](GithubApi.md#github_inventory) | **GET** /api/trpc/github.inventory | Inventory
[**github_list_branches**](GithubApi.md#github_list_branches) | **GET** /api/trpc/github.listBranches | List Branches
[**github_list_files**](GithubApi.md#github_list_files) | **GET** /api/trpc/github.listFiles | List Files
[**github_list_repos**](GithubApi.md#github_list_repos) | **GET** /api/trpc/github.listRepos | List Repos
[**github_repositories**](GithubApi.md#github_repositories) | **GET** /api/trpc/github.repositories | Repositories
[**github_review_file**](GithubApi.md#github_review_file) | **GET** /api/trpc/github.reviewFile | Review File
[**github_status**](GithubApi.md#github_status) | **GET** /api/trpc/github.status | Status
[**github_update_jekyll_config**](GithubApi.md#github_update_jekyll_config) | **POST** /api/trpc/github.updateJekyllConfig | Update Jekyll Config

# **github_check_plugin_compatibility**
> TRPCResponse github_check_plugin_compatibility(input)

Check Plugin Compatibility

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Check Plugin Compatibility
    api_response = api_instance.github_check_plugin_compatibility(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_check_plugin_compatibility: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_commit_file**
> TRPCResponse github_commit_file(body)

Commit File

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubCommitFileBody() # TrpcGithubCommitFileBody | 

try:
    # Commit File
    api_response = api_instance.github_commit_file(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_commit_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCommitFileBody**](TrpcGithubCommitFileBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_connect**
> TRPCResponse github_connect(body)

Connect

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubConnectBody() # TrpcGithubConnectBody | 

try:
    # Connect
    api_response = api_instance.github_connect(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_connect: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubConnectBody**](TrpcGithubConnectBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_create_branch**
> TRPCResponse github_create_branch(body)

Create Branch

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubCreateBranchBody() # TrpcGithubCreateBranchBody | 

try:
    # Create Branch
    api_response = api_instance.github_create_branch(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_create_branch: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreateBranchBody**](TrpcGithubCreateBranchBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_create_pull_request**
> TRPCResponse github_create_pull_request(body)

Create Pull Request

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubCreatePullRequestBody() # TrpcGithubCreatePullRequestBody | 

try:
    # Create Pull Request
    api_response = api_instance.github_create_pull_request(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_create_pull_request: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreatePullRequestBody**](TrpcGithubCreatePullRequestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_delete_file**
> TRPCResponse github_delete_file(body)

Delete File

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubDeleteFileBody() # TrpcGithubDeleteFileBody | 

try:
    # Delete File
    api_response = api_instance.github_delete_file(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_delete_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDeleteFileBody**](TrpcGithubDeleteFileBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_detect_jekyll**
> TRPCResponse github_detect_jekyll(input)

Detect Jekyll

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Detect Jekyll
    api_response = api_instance.github_detect_jekyll(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_detect_jekyll: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_disconnect**
> TRPCResponse github_disconnect(body=body)

Disconnect

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubDisconnectBody() # TrpcGithubDisconnectBody |  (optional)

try:
    # Disconnect
    api_response = api_instance.github_disconnect(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_disconnect: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDisconnectBody**](TrpcGithubDisconnectBody.md)|  | [optional] 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_generate_actions_workflow**
> TRPCResponse github_generate_actions_workflow(body)

Generate Actions Workflow

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubGenerateActionsWorkflowBody() # TrpcGithubGenerateActionsWorkflowBody | 

try:
    # Generate Actions Workflow
    api_response = api_instance.github_generate_actions_workflow(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_generate_actions_workflow: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubGenerateActionsWorkflowBody**](TrpcGithubGenerateActionsWorkflowBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_get_file**
> TRPCResponse github_get_file(input)

Get File

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get File
    api_response = api_instance.github_get_file(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_get_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_get_jekyll_config**
> TRPCResponse github_get_jekyll_config(input)

Get Jekyll Config

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Jekyll Config
    api_response = api_instance.github_get_jekyll_config(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_get_jekyll_config: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_get_pages_status**
> TRPCResponse github_get_pages_status(input)

Get Pages Status

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Pages Status
    api_response = api_instance.github_get_pages_status(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_get_pages_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_get_rate_limit**
> TRPCResponse github_get_rate_limit()

Get Rate Limit

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))

try:
    # Get Rate Limit
    api_response = api_instance.github_get_rate_limit()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_get_rate_limit: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_inventory**
> TRPCResponse github_inventory(input)

Inventory

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Inventory
    api_response = api_instance.github_inventory(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_inventory: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_list_branches**
> TRPCResponse github_list_branches(input)

List Branches

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List Branches
    api_response = api_instance.github_list_branches(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_list_branches: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_list_files**
> TRPCResponse github_list_files(input)

List Files

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List Files
    api_response = api_instance.github_list_files(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_list_files: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_list_repos**
> TRPCResponse github_list_repos(input)

List Repos

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List Repos
    api_response = api_instance.github_list_repos(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_list_repos: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_repositories**
> TRPCResponse github_repositories(input)

Repositories

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Repositories
    api_response = api_instance.github_repositories(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_repositories: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_review_file**
> TRPCResponse github_review_file(input)

Review File

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Review File
    api_response = api_instance.github_review_file(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_review_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_status**
> TRPCResponse github_status()

Status

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))

try:
    # Status
    api_response = api_instance.github_status()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_status: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **github_update_jekyll_config**
> TRPCResponse github_update_jekyll_config(body)

Update Jekyll Config

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.GithubApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcGithubUpdateJekyllConfigBody() # TrpcGithubUpdateJekyllConfigBody | 

try:
    # Update Jekyll Config
    api_response = api_instance.github_update_jekyll_config(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GithubApi->github_update_jekyll_config: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubUpdateJekyllConfigBody**](TrpcGithubUpdateJekyllConfigBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

