# ApitrpcaiUpdateSettingsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**temperature** | **float** |  | [optional] 
**max_tokens** | **float** |  | [optional] 
**system_prompt** | **str** |  | [optional] 
**brand_voice_prompt** | **str** |  | [optional] 
**safety_prompt** | **str** |  | [optional] 
**streaming** | **bool** |  | [optional] 
**default_language** | **str** |  | [optional] 
**default_tone** | **str** |  | [optional] 
**budget_limit_cents** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

