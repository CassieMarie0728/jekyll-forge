# ApitrpcaiGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task** | **str** |  | 
**user_prompt** | **str** |  | [optional] 
**selected_text** | **str** |  | [optional] 
**post_markdown** | **str** |  | [optional] 
**front_matter** | **object** |  | [optional] 
**tone** | **str** |  | [optional] 
**voice_profile_id** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

