# ApitrpcschedulerScheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_id** | **float** |  | 
**post_id** | **float** |  | [optional] 
**draft_path** | **str** |  | 
**target_path** | **str** |  | 
**scheduled_at** | **object** |  | 
**timezone** | **str** |  | 
**commit_message** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

