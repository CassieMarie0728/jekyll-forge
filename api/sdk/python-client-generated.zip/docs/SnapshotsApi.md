# swagger_client.SnapshotsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**snapshots_create**](SnapshotsApi.md#snapshots_create) | **POST** /api/trpc/snapshots.create | Create
[**snapshots_get**](SnapshotsApi.md#snapshots_get) | **GET** /api/trpc/snapshots.get | Get
[**snapshots_list_by_post**](SnapshotsApi.md#snapshots_list_by_post) | **GET** /api/trpc/snapshots.listByPost | List By Post

# **snapshots_create**
> TRPCResponse snapshots_create(body)

Create

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SnapshotsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSnapshotsCreateBody() # TrpcSnapshotsCreateBody | 

try:
    # Create
    api_response = api_instance.snapshots_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SnapshotsApi->snapshots_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSnapshotsCreateBody**](TrpcSnapshotsCreateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **snapshots_get**
> TRPCResponse snapshots_get(input)

Get

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SnapshotsApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get
    api_response = api_instance.snapshots_get(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SnapshotsApi->snapshots_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **snapshots_list_by_post**
> TRPCResponse snapshots_list_by_post(input)

List By Post

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SnapshotsApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List By Post
    api_response = api_instance.snapshots_list_by_post(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SnapshotsApi->snapshots_list_by_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

