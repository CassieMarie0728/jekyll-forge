# ApitrpcsocialMediaSyncAnalyticsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**analytics_id** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

