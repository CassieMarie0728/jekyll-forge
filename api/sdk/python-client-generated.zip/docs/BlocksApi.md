# swagger_client.BlocksApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**blocks_create**](BlocksApi.md#blocks_create) | **POST** /api/trpc/blocks.create | Create
[**blocks_delete**](BlocksApi.md#blocks_delete) | **POST** /api/trpc/blocks.delete | Delete
[**blocks_list**](BlocksApi.md#blocks_list) | **GET** /api/trpc/blocks.list | List
[**blocks_update**](BlocksApi.md#blocks_update) | **POST** /api/trpc/blocks.update | Update

# **blocks_create**
> TRPCResponse blocks_create(body)

Create

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.BlocksApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcBlocksCreateBody() # TrpcBlocksCreateBody | 

try:
    # Create
    api_response = api_instance.blocks_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BlocksApi->blocks_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksCreateBody**](TrpcBlocksCreateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **blocks_delete**
> TRPCResponse blocks_delete(body)

Delete

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.BlocksApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcBlocksDeleteBody() # TrpcBlocksDeleteBody | 

try:
    # Delete
    api_response = api_instance.blocks_delete(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BlocksApi->blocks_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksDeleteBody**](TrpcBlocksDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **blocks_list**
> TRPCResponse blocks_list()

List

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.BlocksApi(swagger_client.ApiClient(configuration))

try:
    # List
    api_response = api_instance.blocks_list()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BlocksApi->blocks_list: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **blocks_update**
> TRPCResponse blocks_update(body)

Update

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.BlocksApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcBlocksUpdateBody() # TrpcBlocksUpdateBody | 

try:
    # Update
    api_response = api_instance.blocks_update(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BlocksApi->blocks_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksUpdateBody**](TrpcBlocksUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

