# swagger_client.AiApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ai_generate**](AiApi.md#ai_generate) | **POST** /api/trpc/ai.generate | Generate
[**ai_get_settings**](AiApi.md#ai_get_settings) | **GET** /api/trpc/ai.getSettings | Get Settings
[**ai_get_usage_stats**](AiApi.md#ai_get_usage_stats) | **GET** /api/trpc/ai.getUsageStats | Get Usage Stats
[**ai_update_settings**](AiApi.md#ai_update_settings) | **POST** /api/trpc/ai.updateSettings | Update Settings

# **ai_generate**
> TRPCResponse ai_generate(body)

Generate

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAiGenerateBody() # TrpcAiGenerateBody | 

try:
    # Generate
    api_response = api_instance.ai_generate(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiApi->ai_generate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiGenerateBody**](TrpcAiGenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_get_settings**
> TRPCResponse ai_get_settings()

Get Settings

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiApi(swagger_client.ApiClient(configuration))

try:
    # Get Settings
    api_response = api_instance.ai_get_settings()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiApi->ai_get_settings: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_get_usage_stats**
> TRPCResponse ai_get_usage_stats()

Get Usage Stats

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiApi(swagger_client.ApiClient(configuration))

try:
    # Get Usage Stats
    api_response = api_instance.ai_get_usage_stats()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiApi->ai_get_usage_stats: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_update_settings**
> TRPCResponse ai_update_settings(body)

Update Settings

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAiUpdateSettingsBody() # TrpcAiUpdateSettingsBody | 

try:
    # Update Settings
    api_response = api_instance.ai_update_settings(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiApi->ai_update_settings: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiUpdateSettingsBody**](TrpcAiUpdateSettingsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

