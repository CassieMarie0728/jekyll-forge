# ApitrpcsitesUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | 
**is_favorite** | **bool** |  | [optional] 
**selected_branch** | **str** |  | [optional] 
**root_path** | **str** |  | [optional] 
**timezone** | **str** |  | [optional] 
**default_layout** | **str** |  | [optional] 
**default_asset_path** | **str** |  | [optional] 
**ai_voice_profile** | **str** |  | [optional] 
**settings** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

