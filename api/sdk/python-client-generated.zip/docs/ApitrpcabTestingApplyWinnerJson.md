# ApitrpcabTestingApplyWinnerJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post_id** | **float** |  | 
**winning_variation_index** | **float** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

