# ApitrpcabTestingGenerateVariationsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post_id** | **float** |  | 
**count** | **float** |  | [optional] 
**tones** | **list[str]** |  | [optional] 
**angles** | **list[str]** |  | [optional] 
**headline** | **str** |  | 
**content** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

