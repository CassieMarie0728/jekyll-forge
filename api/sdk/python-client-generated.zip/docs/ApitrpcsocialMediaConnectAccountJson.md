# ApitrpcsocialMediaConnectAccountJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | **str** |  | 
**access_token** | **str** |  | 
**refresh_token** | **str** |  | [optional] 
**expires_at** | **object** |  | [optional] 
**account_id** | **str** |  | 
**username** | **str** |  | [optional] 
**display_name** | **str** |  | [optional] 
**profile_image_url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

