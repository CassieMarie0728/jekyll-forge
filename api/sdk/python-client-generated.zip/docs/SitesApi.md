# swagger_client.SitesApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sites_delete**](SitesApi.md#sites_delete) | **POST** /api/trpc/sites.delete | Delete
[**sites_get**](SitesApi.md#sites_get) | **GET** /api/trpc/sites.get | Get
[**sites_list**](SitesApi.md#sites_list) | **GET** /api/trpc/sites.list | List
[**sites_update**](SitesApi.md#sites_update) | **POST** /api/trpc/sites.update | Update
[**sites_upsert**](SitesApi.md#sites_upsert) | **POST** /api/trpc/sites.upsert | Upsert

# **sites_delete**
> TRPCResponse sites_delete(body)

Delete

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SitesApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSitesDeleteBody() # TrpcSitesDeleteBody | 

try:
    # Delete
    api_response = api_instance.sites_delete(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SitesApi->sites_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesDeleteBody**](TrpcSitesDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sites_get**
> TRPCResponse sites_get(input)

Get

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SitesApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get
    api_response = api_instance.sites_get(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SitesApi->sites_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sites_list**
> TRPCResponse sites_list()

List

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SitesApi(swagger_client.ApiClient(configuration))

try:
    # List
    api_response = api_instance.sites_list()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SitesApi->sites_list: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sites_update**
> TRPCResponse sites_update(body)

Update

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SitesApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSitesUpdateBody() # TrpcSitesUpdateBody | 

try:
    # Update
    api_response = api_instance.sites_update(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SitesApi->sites_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpdateBody**](TrpcSitesUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sites_upsert**
> TRPCResponse sites_upsert(body)

Upsert

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SitesApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSitesUpsertBody() # TrpcSitesUpsertBody | 

try:
    # Upsert
    api_response = api_instance.sites_upsert(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SitesApi->sites_upsert: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpsertBody**](TrpcSitesUpsertBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

