# ApitrpcgithubCreatePullRequestJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **str** |  | 
**repo** | **str** |  | 
**title** | **str** |  | 
**head** | **str** |  | 
**base** | **str** |  | 
**body** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

