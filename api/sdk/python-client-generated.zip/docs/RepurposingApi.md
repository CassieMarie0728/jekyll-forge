# swagger_client.RepurposingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**repurposing_delete**](RepurposingApi.md#repurposing_delete) | **POST** /api/trpc/repurposing.delete | Delete
[**repurposing_generate**](RepurposingApi.md#repurposing_generate) | **POST** /api/trpc/repurposing.generate | Generate
[**repurposing_get_by_id**](RepurposingApi.md#repurposing_get_by_id) | **GET** /api/trpc/repurposing.getById | Get By Id
[**repurposing_get_by_post**](RepurposingApi.md#repurposing_get_by_post) | **GET** /api/trpc/repurposing.getByPost | Get By Post
[**repurposing_regenerate**](RepurposingApi.md#repurposing_regenerate) | **POST** /api/trpc/repurposing.regenerate | Regenerate
[**repurposing_update**](RepurposingApi.md#repurposing_update) | **POST** /api/trpc/repurposing.update | Update

# **repurposing_delete**
> TRPCResponse repurposing_delete(body)

Delete

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.RepurposingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcRepurposingDeleteBody() # TrpcRepurposingDeleteBody | 

try:
    # Delete
    api_response = api_instance.repurposing_delete(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RepurposingApi->repurposing_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingDeleteBody**](TrpcRepurposingDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **repurposing_generate**
> TRPCResponse repurposing_generate(body)

Generate

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.RepurposingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcRepurposingGenerateBody() # TrpcRepurposingGenerateBody | 

try:
    # Generate
    api_response = api_instance.repurposing_generate(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RepurposingApi->repurposing_generate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingGenerateBody**](TrpcRepurposingGenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **repurposing_get_by_id**
> TRPCResponse repurposing_get_by_id(input)

Get By Id

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.RepurposingApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get By Id
    api_response = api_instance.repurposing_get_by_id(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RepurposingApi->repurposing_get_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **repurposing_get_by_post**
> TRPCResponse repurposing_get_by_post(input)

Get By Post

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.RepurposingApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get By Post
    api_response = api_instance.repurposing_get_by_post(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RepurposingApi->repurposing_get_by_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **repurposing_regenerate**
> TRPCResponse repurposing_regenerate(body)

Regenerate

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.RepurposingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcRepurposingRegenerateBody() # TrpcRepurposingRegenerateBody | 

try:
    # Regenerate
    api_response = api_instance.repurposing_regenerate(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RepurposingApi->repurposing_regenerate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingRegenerateBody**](TrpcRepurposingRegenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **repurposing_update**
> TRPCResponse repurposing_update(body)

Update

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.RepurposingApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcRepurposingUpdateBody() # TrpcRepurposingUpdateBody | 

try:
    # Update
    api_response = api_instance.repurposing_update(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling RepurposingApi->repurposing_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingUpdateBody**](TrpcRepurposingUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

