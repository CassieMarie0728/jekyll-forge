# swagger_client.AiProvidersApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ai_providers_activate**](AiProvidersApi.md#ai_providers_activate) | **POST** /api/trpc/aiProviders.activate | Activate
[**ai_providers_get_settings**](AiProvidersApi.md#ai_providers_get_settings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
[**ai_providers_remove**](AiProvidersApi.md#ai_providers_remove) | **POST** /api/trpc/aiProviders.remove | Remove
[**ai_providers_save**](AiProvidersApi.md#ai_providers_save) | **POST** /api/trpc/aiProviders.save | Save
[**ai_providers_test**](AiProvidersApi.md#ai_providers_test) | **POST** /api/trpc/aiProviders.test | Test

# **ai_providers_activate**
> TRPCResponse ai_providers_activate(body)

Activate

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiProvidersApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAiProvidersActivateBody() # TrpcAiProvidersActivateBody | 

try:
    # Activate
    api_response = api_instance.ai_providers_activate(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiProvidersApi->ai_providers_activate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersActivateBody**](TrpcAiProvidersActivateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_providers_get_settings**
> TRPCResponse ai_providers_get_settings()

Get Settings

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiProvidersApi(swagger_client.ApiClient(configuration))

try:
    # Get Settings
    api_response = api_instance.ai_providers_get_settings()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiProvidersApi->ai_providers_get_settings: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_providers_remove**
> TRPCResponse ai_providers_remove(body)

Remove

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiProvidersApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAiProvidersRemoveBody() # TrpcAiProvidersRemoveBody | 

try:
    # Remove
    api_response = api_instance.ai_providers_remove(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiProvidersApi->ai_providers_remove: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersRemoveBody**](TrpcAiProvidersRemoveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_providers_save**
> TRPCResponse ai_providers_save(body)

Save

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiProvidersApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAiProvidersSaveBody() # TrpcAiProvidersSaveBody | 

try:
    # Save
    api_response = api_instance.ai_providers_save(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiProvidersApi->ai_providers_save: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersSaveBody**](TrpcAiProvidersSaveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ai_providers_test**
> TRPCResponse ai_providers_test(body)

Test

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AiProvidersApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAiProvidersTestBody() # TrpcAiProvidersTestBody | 

try:
    # Test
    api_response = api_instance.ai_providers_test(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AiProvidersApi->ai_providers_test: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersTestBody**](TrpcAiProvidersTestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

