# ApitrpcsocialMediaSchedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposed_content_id** | **float** |  | 
**social_media_account_id** | **float** |  | 
**scheduled_at** | **object** |  | 
**timezone** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

