# ApitrpcgithubDeleteFileJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **str** |  | 
**repo** | **str** |  | 
**path** | **str** |  | 
**branch** | **str** |  | 
**sha** | **str** |  | 
**message** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

