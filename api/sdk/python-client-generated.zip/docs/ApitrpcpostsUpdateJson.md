# ApitrpcpostsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | 
**path** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**slug** | **str** |  | [optional] 
**status** | **object** |  | [optional] 
**front_matter** | **object** |  | [optional] 
**markdown** | **str** |  | [optional] 
**sha** | **str** |  | [optional] 
**scheduled_at** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

