# swagger_client.SocialMediaApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**social_media_cancel_scheduled_post**](SocialMediaApi.md#social_media_cancel_scheduled_post) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**social_media_connect_account**](SocialMediaApi.md#social_media_connect_account) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
[**social_media_disconnect_account**](SocialMediaApi.md#social_media_disconnect_account) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**social_media_get_account_details**](SocialMediaApi.md#social_media_get_account_details) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**social_media_get_accounts**](SocialMediaApi.md#social_media_get_accounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
[**social_media_get_analytics_by_platform**](SocialMediaApi.md#social_media_get_analytics_by_platform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**social_media_get_analytics_summary**](SocialMediaApi.md#social_media_get_analytics_summary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**social_media_get_content_analytics**](SocialMediaApi.md#social_media_get_content_analytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**social_media_get_scheduled_posts**](SocialMediaApi.md#social_media_get_scheduled_posts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**social_media_publish_content**](SocialMediaApi.md#social_media_publish_content) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
[**social_media_reschedule_post**](SocialMediaApi.md#social_media_reschedule_post) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**social_media_schedule_post**](SocialMediaApi.md#social_media_schedule_post) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
[**social_media_sync_analytics**](SocialMediaApi.md#social_media_sync_analytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

# **social_media_cancel_scheduled_post**
> TRPCResponse social_media_cancel_scheduled_post(body)

Cancel Scheduled Post

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaCancelScheduledPostBody() # TrpcSocialMediaCancelScheduledPostBody | 

try:
    # Cancel Scheduled Post
    api_response = api_instance.social_media_cancel_scheduled_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_cancel_scheduled_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaCancelScheduledPostBody**](TrpcSocialMediaCancelScheduledPostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_connect_account**
> TRPCResponse social_media_connect_account(body)

Connect Account

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaConnectAccountBody() # TrpcSocialMediaConnectAccountBody | 

try:
    # Connect Account
    api_response = api_instance.social_media_connect_account(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_connect_account: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaConnectAccountBody**](TrpcSocialMediaConnectAccountBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_disconnect_account**
> TRPCResponse social_media_disconnect_account(body)

Disconnect Account

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaDisconnectAccountBody() # TrpcSocialMediaDisconnectAccountBody | 

try:
    # Disconnect Account
    api_response = api_instance.social_media_disconnect_account(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_disconnect_account: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaDisconnectAccountBody**](TrpcSocialMediaDisconnectAccountBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_get_account_details**
> TRPCResponse social_media_get_account_details(input)

Get Account Details

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Account Details
    api_response = api_instance.social_media_get_account_details(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_get_account_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_get_accounts**
> TRPCResponse social_media_get_accounts()

Get Accounts

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))

try:
    # Get Accounts
    api_response = api_instance.social_media_get_accounts()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_get_accounts: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_get_analytics_by_platform**
> TRPCResponse social_media_get_analytics_by_platform(input)

Get Analytics By Platform

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Analytics By Platform
    api_response = api_instance.social_media_get_analytics_by_platform(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_get_analytics_by_platform: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_get_analytics_summary**
> TRPCResponse social_media_get_analytics_summary()

Get Analytics Summary

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))

try:
    # Get Analytics Summary
    api_response = api_instance.social_media_get_analytics_summary()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_get_analytics_summary: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_get_content_analytics**
> TRPCResponse social_media_get_content_analytics(input)

Get Content Analytics

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Content Analytics
    api_response = api_instance.social_media_get_content_analytics(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_get_content_analytics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_get_scheduled_posts**
> TRPCResponse social_media_get_scheduled_posts(input)

Get Scheduled Posts

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Scheduled Posts
    api_response = api_instance.social_media_get_scheduled_posts(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_get_scheduled_posts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_publish_content**
> TRPCResponse social_media_publish_content(body)

Publish Content

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaPublishContentBody() # TrpcSocialMediaPublishContentBody | 

try:
    # Publish Content
    api_response = api_instance.social_media_publish_content(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_publish_content: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaPublishContentBody**](TrpcSocialMediaPublishContentBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_reschedule_post**
> TRPCResponse social_media_reschedule_post(body)

Reschedule Post

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaReschedulePostBody() # TrpcSocialMediaReschedulePostBody | 

try:
    # Reschedule Post
    api_response = api_instance.social_media_reschedule_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_reschedule_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaReschedulePostBody**](TrpcSocialMediaReschedulePostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_schedule_post**
> TRPCResponse social_media_schedule_post(body)

Schedule Post

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaSchedulePostBody() # TrpcSocialMediaSchedulePostBody | 

try:
    # Schedule Post
    api_response = api_instance.social_media_schedule_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_schedule_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSchedulePostBody**](TrpcSocialMediaSchedulePostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **social_media_sync_analytics**
> TRPCResponse social_media_sync_analytics(body)

Sync Analytics

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SocialMediaApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSocialMediaSyncAnalyticsBody() # TrpcSocialMediaSyncAnalyticsBody | 

try:
    # Sync Analytics
    api_response = api_instance.social_media_sync_analytics(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SocialMediaApi->social_media_sync_analytics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSyncAnalyticsBody**](TrpcSocialMediaSyncAnalyticsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

