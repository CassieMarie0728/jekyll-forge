# swagger_client.PostsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**posts_autosave**](PostsApi.md#posts_autosave) | **POST** /api/trpc/posts.autosave | Autosave
[**posts_delete**](PostsApi.md#posts_delete) | **POST** /api/trpc/posts.delete | Delete
[**posts_get**](PostsApi.md#posts_get) | **GET** /api/trpc/posts.get | Get
[**posts_get_front_matter_templates**](PostsApi.md#posts_get_front_matter_templates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
[**posts_list**](PostsApi.md#posts_list) | **GET** /api/trpc/posts.list | List
[**posts_update**](PostsApi.md#posts_update) | **POST** /api/trpc/posts.update | Update
[**posts_upsert**](PostsApi.md#posts_upsert) | **POST** /api/trpc/posts.upsert | Upsert

# **posts_autosave**
> TRPCResponse posts_autosave(body)

Autosave

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcPostsAutosaveBody() # TrpcPostsAutosaveBody | 

try:
    # Autosave
    api_response = api_instance.posts_autosave(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_autosave: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsAutosaveBody**](TrpcPostsAutosaveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **posts_delete**
> TRPCResponse posts_delete(body)

Delete

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcPostsDeleteBody() # TrpcPostsDeleteBody | 

try:
    # Delete
    api_response = api_instance.posts_delete(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsDeleteBody**](TrpcPostsDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **posts_get**
> TRPCResponse posts_get(input)

Get

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get
    api_response = api_instance.posts_get(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **posts_get_front_matter_templates**
> TRPCResponse posts_get_front_matter_templates(input)

Get Front Matter Templates

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # Get Front Matter Templates
    api_response = api_instance.posts_get_front_matter_templates(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_get_front_matter_templates: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **posts_list**
> TRPCResponse posts_list(input)

List

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List
    api_response = api_instance.posts_list(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **posts_update**
> TRPCResponse posts_update(body)

Update

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcPostsUpdateBody() # TrpcPostsUpdateBody | 

try:
    # Update
    api_response = api_instance.posts_update(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpdateBody**](TrpcPostsUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **posts_upsert**
> TRPCResponse posts_upsert(body)

Upsert

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PostsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcPostsUpsertBody() # TrpcPostsUpsertBody | 

try:
    # Upsert
    api_response = api_instance.posts_upsert(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PostsApi->posts_upsert: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpsertBody**](TrpcPostsUpsertBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

