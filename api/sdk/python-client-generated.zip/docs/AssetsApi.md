# swagger_client.AssetsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**assets_delete**](AssetsApi.md#assets_delete) | **POST** /api/trpc/assets.delete | Delete
[**assets_generate_alt_text**](AssetsApi.md#assets_generate_alt_text) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
[**assets_list**](AssetsApi.md#assets_list) | **GET** /api/trpc/assets.list | List
[**assets_reoptimize**](AssetsApi.md#assets_reoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
[**assets_update**](AssetsApi.md#assets_update) | **POST** /api/trpc/assets.update | Update
[**assets_upload**](AssetsApi.md#assets_upload) | **POST** /api/trpc/assets.upload | Upload

# **assets_delete**
> TRPCResponse assets_delete(body)

Delete

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AssetsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAssetsDeleteBody() # TrpcAssetsDeleteBody | 

try:
    # Delete
    api_response = api_instance.assets_delete(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->assets_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsDeleteBody**](TrpcAssetsDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **assets_generate_alt_text**
> TRPCResponse assets_generate_alt_text(body)

Generate Alt Text

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AssetsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAssetsGenerateAltTextBody() # TrpcAssetsGenerateAltTextBody | 

try:
    # Generate Alt Text
    api_response = api_instance.assets_generate_alt_text(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->assets_generate_alt_text: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsGenerateAltTextBody**](TrpcAssetsGenerateAltTextBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **assets_list**
> TRPCResponse assets_list(input)

List

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AssetsApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List
    api_response = api_instance.assets_list(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->assets_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **assets_reoptimize**
> TRPCResponse assets_reoptimize(body)

Reoptimize

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AssetsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAssetsReoptimizeBody() # TrpcAssetsReoptimizeBody | 

try:
    # Reoptimize
    api_response = api_instance.assets_reoptimize(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->assets_reoptimize: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsReoptimizeBody**](TrpcAssetsReoptimizeBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **assets_update**
> TRPCResponse assets_update(body)

Update

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AssetsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAssetsUpdateBody() # TrpcAssetsUpdateBody | 

try:
    # Update
    api_response = api_instance.assets_update(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->assets_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUpdateBody**](TrpcAssetsUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **assets_upload**
> TRPCResponse assets_upload(body)

Upload

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AssetsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcAssetsUploadBody() # TrpcAssetsUploadBody | 

try:
    # Upload
    api_response = api_instance.assets_upload(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AssetsApi->assets_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUploadBody**](TrpcAssetsUploadBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

