# swagger_client.NotificationsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**notifications_register_device**](NotificationsApi.md#notifications_register_device) | **POST** /api/trpc/notifications.registerDevice | Register Device
[**notifications_unregister_device**](NotificationsApi.md#notifications_unregister_device) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device

# **notifications_register_device**
> TRPCResponse notifications_register_device(body)

Register Device

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.NotificationsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcNotificationsRegisterDeviceBody() # TrpcNotificationsRegisterDeviceBody | 

try:
    # Register Device
    api_response = api_instance.notifications_register_device(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NotificationsApi->notifications_register_device: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsRegisterDeviceBody**](TrpcNotificationsRegisterDeviceBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **notifications_unregister_device**
> TRPCResponse notifications_unregister_device(body)

Unregister Device

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.NotificationsApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcNotificationsUnregisterDeviceBody() # TrpcNotificationsUnregisterDeviceBody | 

try:
    # Unregister Device
    api_response = api_instance.notifications_unregister_device(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NotificationsApi->notifications_unregister_device: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsUnregisterDeviceBody**](TrpcNotificationsUnregisterDeviceBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

