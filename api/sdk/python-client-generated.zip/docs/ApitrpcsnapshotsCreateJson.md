# ApitrpcsnapshotsCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_id** | **float** |  | 
**post_id** | **float** |  | [optional] 
**post_path** | **str** |  | [optional] 
**label** | **str** |  | 
**reason** | **object** |  | 
**markdown** | **str** |  | [optional] 
**front_matter** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

