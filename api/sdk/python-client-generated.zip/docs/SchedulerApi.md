# swagger_client.SchedulerApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**scheduler_cancel**](SchedulerApi.md#scheduler_cancel) | **POST** /api/trpc/scheduler.cancel | Cancel
[**scheduler_cancel_all**](SchedulerApi.md#scheduler_cancel_all) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
[**scheduler_list**](SchedulerApi.md#scheduler_list) | **GET** /api/trpc/scheduler.list | List
[**scheduler_list_heartbeat_jobs**](SchedulerApi.md#scheduler_list_heartbeat_jobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**scheduler_mark_failed**](SchedulerApi.md#scheduler_mark_failed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
[**scheduler_mark_published**](SchedulerApi.md#scheduler_mark_published) | **POST** /api/trpc/scheduler.markPublished | Mark Published
[**scheduler_reschedule**](SchedulerApi.md#scheduler_reschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
[**scheduler_schedule**](SchedulerApi.md#scheduler_schedule) | **POST** /api/trpc/scheduler.schedule | Schedule

# **scheduler_cancel**
> TRPCResponse scheduler_cancel(body)

Cancel

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSchedulerCancelBody() # TrpcSchedulerCancelBody | 

try:
    # Cancel
    api_response = api_instance.scheduler_cancel(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_cancel: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelBody**](TrpcSchedulerCancelBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_cancel_all**
> TRPCResponse scheduler_cancel_all(body)

Cancel All

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSchedulerCancelAllBody() # TrpcSchedulerCancelAllBody | 

try:
    # Cancel All
    api_response = api_instance.scheduler_cancel_all(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_cancel_all: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelAllBody**](TrpcSchedulerCancelAllBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_list**
> TRPCResponse scheduler_list(input)

List

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List
    api_response = api_instance.scheduler_list(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_list_heartbeat_jobs**
> TRPCResponse scheduler_list_heartbeat_jobs(input)

List Heartbeat Jobs

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
input = 'input_example' # str | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try:
    # List Heartbeat Jobs
    api_response = api_instance.scheduler_list_heartbeat_jobs(input)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_list_heartbeat_jobs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **str**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_mark_failed**
> TRPCResponse scheduler_mark_failed(body)

Mark Failed

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSchedulerMarkFailedBody() # TrpcSchedulerMarkFailedBody | 

try:
    # Mark Failed
    api_response = api_instance.scheduler_mark_failed(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_mark_failed: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkFailedBody**](TrpcSchedulerMarkFailedBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_mark_published**
> TRPCResponse scheduler_mark_published(body)

Mark Published

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSchedulerMarkPublishedBody() # TrpcSchedulerMarkPublishedBody | 

try:
    # Mark Published
    api_response = api_instance.scheduler_mark_published(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_mark_published: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkPublishedBody**](TrpcSchedulerMarkPublishedBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_reschedule**
> TRPCResponse scheduler_reschedule(body)

Reschedule

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSchedulerRescheduleBody() # TrpcSchedulerRescheduleBody | 

try:
    # Reschedule
    api_response = api_instance.scheduler_reschedule(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_reschedule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerRescheduleBody**](TrpcSchedulerRescheduleBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **scheduler_schedule**
> TRPCResponse scheduler_schedule(body)

Schedule

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.SchedulerApi(swagger_client.ApiClient(configuration))
body = swagger_client.TrpcSchedulerScheduleBody() # TrpcSchedulerScheduleBody | 

try:
    # Schedule
    api_response = api_instance.scheduler_schedule(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SchedulerApi->scheduler_schedule: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerScheduleBody**](TrpcSchedulerScheduleBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

