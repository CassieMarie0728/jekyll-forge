# Swagger\Client\SnapshotsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**snapshotsCreate**](SnapshotsApi.md#snapshotscreate) | **POST** /api/trpc/snapshots.create | Create
[**snapshotsGet**](SnapshotsApi.md#snapshotsget) | **GET** /api/trpc/snapshots.get | Get
[**snapshotsListByPost**](SnapshotsApi.md#snapshotslistbypost) | **GET** /api/trpc/snapshots.listByPost | List By Post

# **snapshotsCreate**
> \Swagger\Client\Model\TRPCResponse snapshotsCreate($body)

Create

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SnapshotsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSnapshotsCreateBody(); // \Swagger\Client\Model\TrpcSnapshotsCreateBody | 

try {
    $result = $apiInstance->snapshotsCreate($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SnapshotsApi->snapshotsCreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSnapshotsCreateBody**](../Model/TrpcSnapshotsCreateBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **snapshotsGet**
> \Swagger\Client\Model\TRPCResponse snapshotsGet($input)

Get

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SnapshotsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->snapshotsGet($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SnapshotsApi->snapshotsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **snapshotsListByPost**
> \Swagger\Client\Model\TRPCResponse snapshotsListByPost($input)

List By Post

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SnapshotsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->snapshotsListByPost($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SnapshotsApi->snapshotsListByPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

