# Swagger\Client\AssetsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**assetsDelete**](AssetsApi.md#assetsdelete) | **POST** /api/trpc/assets.delete | Delete
[**assetsGenerateAltText**](AssetsApi.md#assetsgeneratealttext) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
[**assetsList**](AssetsApi.md#assetslist) | **GET** /api/trpc/assets.list | List
[**assetsReoptimize**](AssetsApi.md#assetsreoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
[**assetsUpdate**](AssetsApi.md#assetsupdate) | **POST** /api/trpc/assets.update | Update
[**assetsUpload**](AssetsApi.md#assetsupload) | **POST** /api/trpc/assets.upload | Upload

# **assetsDelete**
> \Swagger\Client\Model\TRPCResponse assetsDelete($body)

Delete

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AssetsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAssetsDeleteBody(); // \Swagger\Client\Model\TrpcAssetsDeleteBody | 

try {
    $result = $apiInstance->assetsDelete($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AssetsApi->assetsDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAssetsDeleteBody**](../Model/TrpcAssetsDeleteBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **assetsGenerateAltText**
> \Swagger\Client\Model\TRPCResponse assetsGenerateAltText($body)

Generate Alt Text

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AssetsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAssetsGenerateAltTextBody(); // \Swagger\Client\Model\TrpcAssetsGenerateAltTextBody | 

try {
    $result = $apiInstance->assetsGenerateAltText($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AssetsApi->assetsGenerateAltText: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAssetsGenerateAltTextBody**](../Model/TrpcAssetsGenerateAltTextBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **assetsList**
> \Swagger\Client\Model\TRPCResponse assetsList($input)

List

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AssetsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->assetsList($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AssetsApi->assetsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **assetsReoptimize**
> \Swagger\Client\Model\TRPCResponse assetsReoptimize($body)

Reoptimize

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AssetsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAssetsReoptimizeBody(); // \Swagger\Client\Model\TrpcAssetsReoptimizeBody | 

try {
    $result = $apiInstance->assetsReoptimize($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AssetsApi->assetsReoptimize: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAssetsReoptimizeBody**](../Model/TrpcAssetsReoptimizeBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **assetsUpdate**
> \Swagger\Client\Model\TRPCResponse assetsUpdate($body)

Update

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AssetsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAssetsUpdateBody(); // \Swagger\Client\Model\TrpcAssetsUpdateBody | 

try {
    $result = $apiInstance->assetsUpdate($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AssetsApi->assetsUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAssetsUpdateBody**](../Model/TrpcAssetsUpdateBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **assetsUpload**
> \Swagger\Client\Model\TRPCResponse assetsUpload($body)

Upload

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AssetsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAssetsUploadBody(); // \Swagger\Client\Model\TrpcAssetsUploadBody | 

try {
    $result = $apiInstance->assetsUpload($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AssetsApi->assetsUpload: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAssetsUploadBody**](../Model/TrpcAssetsUploadBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

