# Swagger\Client\PostsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**postsAutosave**](PostsApi.md#postsautosave) | **POST** /api/trpc/posts.autosave | Autosave
[**postsDelete**](PostsApi.md#postsdelete) | **POST** /api/trpc/posts.delete | Delete
[**postsGet**](PostsApi.md#postsget) | **GET** /api/trpc/posts.get | Get
[**postsGetFrontMatterTemplates**](PostsApi.md#postsgetfrontmattertemplates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
[**postsList**](PostsApi.md#postslist) | **GET** /api/trpc/posts.list | List
[**postsUpdate**](PostsApi.md#postsupdate) | **POST** /api/trpc/posts.update | Update
[**postsUpsert**](PostsApi.md#postsupsert) | **POST** /api/trpc/posts.upsert | Upsert

# **postsAutosave**
> \Swagger\Client\Model\TRPCResponse postsAutosave($body)

Autosave

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcPostsAutosaveBody(); // \Swagger\Client\Model\TrpcPostsAutosaveBody | 

try {
    $result = $apiInstance->postsAutosave($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsAutosave: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcPostsAutosaveBody**](../Model/TrpcPostsAutosaveBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postsDelete**
> \Swagger\Client\Model\TRPCResponse postsDelete($body)

Delete

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcPostsDeleteBody(); // \Swagger\Client\Model\TrpcPostsDeleteBody | 

try {
    $result = $apiInstance->postsDelete($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcPostsDeleteBody**](../Model/TrpcPostsDeleteBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postsGet**
> \Swagger\Client\Model\TRPCResponse postsGet($input)

Get

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->postsGet($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postsGetFrontMatterTemplates**
> \Swagger\Client\Model\TRPCResponse postsGetFrontMatterTemplates($input)

Get Front Matter Templates

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->postsGetFrontMatterTemplates($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsGetFrontMatterTemplates: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postsList**
> \Swagger\Client\Model\TRPCResponse postsList($input)

List

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->postsList($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postsUpdate**
> \Swagger\Client\Model\TRPCResponse postsUpdate($body)

Update

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcPostsUpdateBody(); // \Swagger\Client\Model\TrpcPostsUpdateBody | 

try {
    $result = $apiInstance->postsUpdate($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsUpdate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcPostsUpdateBody**](../Model/TrpcPostsUpdateBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postsUpsert**
> \Swagger\Client\Model\TRPCResponse postsUpsert($body)

Upsert

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\PostsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcPostsUpsertBody(); // \Swagger\Client\Model\TrpcPostsUpsertBody | 

try {
    $result = $apiInstance->postsUpsert($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->postsUpsert: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcPostsUpsertBody**](../Model/TrpcPostsUpsertBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

