# Swagger\Client\AbTestingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**abTestingApplyWinner**](AbTestingApi.md#abtestingapplywinner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
[**abTestingCompleteTest**](AbTestingApi.md#abtestingcompletetest) | **POST** /api/trpc/abTesting.completeTest | Complete Test
[**abTestingGenerateVariations**](AbTestingApi.md#abtestinggeneratevariations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
[**abTestingGetResults**](AbTestingApi.md#abtestinggetresults) | **GET** /api/trpc/abTesting.getResults | Get Results
[**abTestingGetVariations**](AbTestingApi.md#abtestinggetvariations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
[**abTestingPublishVariation**](AbTestingApi.md#abtestingpublishvariation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
[**abTestingUpdateMetrics**](AbTestingApi.md#abtestingupdatemetrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics

# **abTestingApplyWinner**
> \Swagger\Client\Model\TRPCResponse abTestingApplyWinner($body)

Apply Winner

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAbTestingApplyWinnerBody(); // \Swagger\Client\Model\TrpcAbTestingApplyWinnerBody | 

try {
    $result = $apiInstance->abTestingApplyWinner($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingApplyWinner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAbTestingApplyWinnerBody**](../Model/TrpcAbTestingApplyWinnerBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **abTestingCompleteTest**
> \Swagger\Client\Model\TRPCResponse abTestingCompleteTest($body)

Complete Test

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAbTestingCompleteTestBody(); // \Swagger\Client\Model\TrpcAbTestingCompleteTestBody | 

try {
    $result = $apiInstance->abTestingCompleteTest($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingCompleteTest: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAbTestingCompleteTestBody**](../Model/TrpcAbTestingCompleteTestBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **abTestingGenerateVariations**
> \Swagger\Client\Model\TRPCResponse abTestingGenerateVariations($body)

Generate Variations

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAbTestingGenerateVariationsBody(); // \Swagger\Client\Model\TrpcAbTestingGenerateVariationsBody | 

try {
    $result = $apiInstance->abTestingGenerateVariations($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingGenerateVariations: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAbTestingGenerateVariationsBody**](../Model/TrpcAbTestingGenerateVariationsBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **abTestingGetResults**
> \Swagger\Client\Model\TRPCResponse abTestingGetResults($input)

Get Results

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->abTestingGetResults($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingGetResults: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **abTestingGetVariations**
> \Swagger\Client\Model\TRPCResponse abTestingGetVariations($input)

Get Variations

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->abTestingGetVariations($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingGetVariations: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **abTestingPublishVariation**
> \Swagger\Client\Model\TRPCResponse abTestingPublishVariation($body)

Publish Variation

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAbTestingPublishVariationBody(); // \Swagger\Client\Model\TrpcAbTestingPublishVariationBody | 

try {
    $result = $apiInstance->abTestingPublishVariation($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingPublishVariation: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAbTestingPublishVariationBody**](../Model/TrpcAbTestingPublishVariationBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **abTestingUpdateMetrics**
> \Swagger\Client\Model\TRPCResponse abTestingUpdateMetrics($body)

Update Metrics

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AbTestingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAbTestingUpdateMetricsBody(); // \Swagger\Client\Model\TrpcAbTestingUpdateMetricsBody | 

try {
    $result = $apiInstance->abTestingUpdateMetrics($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AbTestingApi->abTestingUpdateMetrics: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAbTestingUpdateMetricsBody**](../Model/TrpcAbTestingUpdateMetricsBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

