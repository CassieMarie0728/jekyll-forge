# Swagger\Client\SchedulerApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**schedulerCancel**](SchedulerApi.md#schedulercancel) | **POST** /api/trpc/scheduler.cancel | Cancel
[**schedulerCancelAll**](SchedulerApi.md#schedulercancelall) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
[**schedulerList**](SchedulerApi.md#schedulerlist) | **GET** /api/trpc/scheduler.list | List
[**schedulerListHeartbeatJobs**](SchedulerApi.md#schedulerlistheartbeatjobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**schedulerMarkFailed**](SchedulerApi.md#schedulermarkfailed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
[**schedulerMarkPublished**](SchedulerApi.md#schedulermarkpublished) | **POST** /api/trpc/scheduler.markPublished | Mark Published
[**schedulerReschedule**](SchedulerApi.md#schedulerreschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
[**schedulerSchedule**](SchedulerApi.md#schedulerschedule) | **POST** /api/trpc/scheduler.schedule | Schedule

# **schedulerCancel**
> \Swagger\Client\Model\TRPCResponse schedulerCancel($body)

Cancel

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSchedulerCancelBody(); // \Swagger\Client\Model\TrpcSchedulerCancelBody | 

try {
    $result = $apiInstance->schedulerCancel($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerCancel: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSchedulerCancelBody**](../Model/TrpcSchedulerCancelBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerCancelAll**
> \Swagger\Client\Model\TRPCResponse schedulerCancelAll($body)

Cancel All

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSchedulerCancelAllBody(); // \Swagger\Client\Model\TrpcSchedulerCancelAllBody | 

try {
    $result = $apiInstance->schedulerCancelAll($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerCancelAll: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSchedulerCancelAllBody**](../Model/TrpcSchedulerCancelAllBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerList**
> \Swagger\Client\Model\TRPCResponse schedulerList($input)

List

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->schedulerList($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerListHeartbeatJobs**
> \Swagger\Client\Model\TRPCResponse schedulerListHeartbeatJobs($input)

List Heartbeat Jobs

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->schedulerListHeartbeatJobs($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerListHeartbeatJobs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerMarkFailed**
> \Swagger\Client\Model\TRPCResponse schedulerMarkFailed($body)

Mark Failed

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSchedulerMarkFailedBody(); // \Swagger\Client\Model\TrpcSchedulerMarkFailedBody | 

try {
    $result = $apiInstance->schedulerMarkFailed($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerMarkFailed: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSchedulerMarkFailedBody**](../Model/TrpcSchedulerMarkFailedBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerMarkPublished**
> \Swagger\Client\Model\TRPCResponse schedulerMarkPublished($body)

Mark Published

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSchedulerMarkPublishedBody(); // \Swagger\Client\Model\TrpcSchedulerMarkPublishedBody | 

try {
    $result = $apiInstance->schedulerMarkPublished($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerMarkPublished: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSchedulerMarkPublishedBody**](../Model/TrpcSchedulerMarkPublishedBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerReschedule**
> \Swagger\Client\Model\TRPCResponse schedulerReschedule($body)

Reschedule

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSchedulerRescheduleBody(); // \Swagger\Client\Model\TrpcSchedulerRescheduleBody | 

try {
    $result = $apiInstance->schedulerReschedule($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerReschedule: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSchedulerRescheduleBody**](../Model/TrpcSchedulerRescheduleBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **schedulerSchedule**
> \Swagger\Client\Model\TRPCResponse schedulerSchedule($body)

Schedule

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SchedulerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSchedulerScheduleBody(); // \Swagger\Client\Model\TrpcSchedulerScheduleBody | 

try {
    $result = $apiInstance->schedulerSchedule($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SchedulerApi->schedulerSchedule: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSchedulerScheduleBody**](../Model/TrpcSchedulerScheduleBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

