# Swagger\Client\NotificationsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**notificationsRegisterDevice**](NotificationsApi.md#notificationsregisterdevice) | **POST** /api/trpc/notifications.registerDevice | Register Device
[**notificationsUnregisterDevice**](NotificationsApi.md#notificationsunregisterdevice) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device

# **notificationsRegisterDevice**
> \Swagger\Client\Model\TRPCResponse notificationsRegisterDevice($body)

Register Device

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\NotificationsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcNotificationsRegisterDeviceBody(); // \Swagger\Client\Model\TrpcNotificationsRegisterDeviceBody | 

try {
    $result = $apiInstance->notificationsRegisterDevice($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling NotificationsApi->notificationsRegisterDevice: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcNotificationsRegisterDeviceBody**](../Model/TrpcNotificationsRegisterDeviceBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **notificationsUnregisterDevice**
> \Swagger\Client\Model\TRPCResponse notificationsUnregisterDevice($body)

Unregister Device

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\NotificationsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcNotificationsUnregisterDeviceBody(); // \Swagger\Client\Model\TrpcNotificationsUnregisterDeviceBody | 

try {
    $result = $apiInstance->notificationsUnregisterDevice($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling NotificationsApi->notificationsUnregisterDevice: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcNotificationsUnregisterDeviceBody**](../Model/TrpcNotificationsUnregisterDeviceBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

