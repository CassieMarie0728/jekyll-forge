# Swagger\Client\AiProvidersApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiProvidersActivate**](AiProvidersApi.md#aiprovidersactivate) | **POST** /api/trpc/aiProviders.activate | Activate
[**aiProvidersGetSettings**](AiProvidersApi.md#aiprovidersgetsettings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
[**aiProvidersRemove**](AiProvidersApi.md#aiprovidersremove) | **POST** /api/trpc/aiProviders.remove | Remove
[**aiProvidersSave**](AiProvidersApi.md#aiproviderssave) | **POST** /api/trpc/aiProviders.save | Save
[**aiProvidersTest**](AiProvidersApi.md#aiproviderstest) | **POST** /api/trpc/aiProviders.test | Test

# **aiProvidersActivate**
> \Swagger\Client\Model\TRPCResponse aiProvidersActivate($body)

Activate

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AiProvidersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAiProvidersActivateBody(); // \Swagger\Client\Model\TrpcAiProvidersActivateBody | 

try {
    $result = $apiInstance->aiProvidersActivate($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AiProvidersApi->aiProvidersActivate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAiProvidersActivateBody**](../Model/TrpcAiProvidersActivateBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **aiProvidersGetSettings**
> \Swagger\Client\Model\TRPCResponse aiProvidersGetSettings()

Get Settings

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AiProvidersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->aiProvidersGetSettings();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AiProvidersApi->aiProvidersGetSettings: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **aiProvidersRemove**
> \Swagger\Client\Model\TRPCResponse aiProvidersRemove($body)

Remove

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AiProvidersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAiProvidersRemoveBody(); // \Swagger\Client\Model\TrpcAiProvidersRemoveBody | 

try {
    $result = $apiInstance->aiProvidersRemove($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AiProvidersApi->aiProvidersRemove: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAiProvidersRemoveBody**](../Model/TrpcAiProvidersRemoveBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **aiProvidersSave**
> \Swagger\Client\Model\TRPCResponse aiProvidersSave($body)

Save

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AiProvidersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAiProvidersSaveBody(); // \Swagger\Client\Model\TrpcAiProvidersSaveBody | 

try {
    $result = $apiInstance->aiProvidersSave($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AiProvidersApi->aiProvidersSave: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAiProvidersSaveBody**](../Model/TrpcAiProvidersSaveBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **aiProvidersTest**
> \Swagger\Client\Model\TRPCResponse aiProvidersTest($body)

Test

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AiProvidersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcAiProvidersTestBody(); // \Swagger\Client\Model\TrpcAiProvidersTestBody | 

try {
    $result = $apiInstance->aiProvidersTest($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AiProvidersApi->aiProvidersTest: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcAiProvidersTestBody**](../Model/TrpcAiProvidersTestBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

