# Swagger\Client\SocialMediaApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**socialMediaCancelScheduledPost**](SocialMediaApi.md#socialmediacancelscheduledpost) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**socialMediaConnectAccount**](SocialMediaApi.md#socialmediaconnectaccount) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
[**socialMediaDisconnectAccount**](SocialMediaApi.md#socialmediadisconnectaccount) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**socialMediaGetAccountDetails**](SocialMediaApi.md#socialmediagetaccountdetails) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**socialMediaGetAccounts**](SocialMediaApi.md#socialmediagetaccounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
[**socialMediaGetAnalyticsByPlatform**](SocialMediaApi.md#socialmediagetanalyticsbyplatform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**socialMediaGetAnalyticsSummary**](SocialMediaApi.md#socialmediagetanalyticssummary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**socialMediaGetContentAnalytics**](SocialMediaApi.md#socialmediagetcontentanalytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**socialMediaGetScheduledPosts**](SocialMediaApi.md#socialmediagetscheduledposts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**socialMediaPublishContent**](SocialMediaApi.md#socialmediapublishcontent) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
[**socialMediaReschedulePost**](SocialMediaApi.md#socialmediareschedulepost) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**socialMediaSchedulePost**](SocialMediaApi.md#socialmediaschedulepost) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
[**socialMediaSyncAnalytics**](SocialMediaApi.md#socialmediasyncanalytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

# **socialMediaCancelScheduledPost**
> \Swagger\Client\Model\TRPCResponse socialMediaCancelScheduledPost($body)

Cancel Scheduled Post

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaCancelScheduledPostBody(); // \Swagger\Client\Model\TrpcSocialMediaCancelScheduledPostBody | 

try {
    $result = $apiInstance->socialMediaCancelScheduledPost($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaCancelScheduledPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaCancelScheduledPostBody**](../Model/TrpcSocialMediaCancelScheduledPostBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaConnectAccount**
> \Swagger\Client\Model\TRPCResponse socialMediaConnectAccount($body)

Connect Account

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaConnectAccountBody(); // \Swagger\Client\Model\TrpcSocialMediaConnectAccountBody | 

try {
    $result = $apiInstance->socialMediaConnectAccount($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaConnectAccount: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaConnectAccountBody**](../Model/TrpcSocialMediaConnectAccountBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaDisconnectAccount**
> \Swagger\Client\Model\TRPCResponse socialMediaDisconnectAccount($body)

Disconnect Account

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaDisconnectAccountBody(); // \Swagger\Client\Model\TrpcSocialMediaDisconnectAccountBody | 

try {
    $result = $apiInstance->socialMediaDisconnectAccount($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaDisconnectAccount: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaDisconnectAccountBody**](../Model/TrpcSocialMediaDisconnectAccountBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaGetAccountDetails**
> \Swagger\Client\Model\TRPCResponse socialMediaGetAccountDetails($input)

Get Account Details

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->socialMediaGetAccountDetails($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaGetAccountDetails: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaGetAccounts**
> \Swagger\Client\Model\TRPCResponse socialMediaGetAccounts()

Get Accounts

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->socialMediaGetAccounts();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaGetAccounts: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaGetAnalyticsByPlatform**
> \Swagger\Client\Model\TRPCResponse socialMediaGetAnalyticsByPlatform($input)

Get Analytics By Platform

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->socialMediaGetAnalyticsByPlatform($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaGetAnalyticsByPlatform: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaGetAnalyticsSummary**
> \Swagger\Client\Model\TRPCResponse socialMediaGetAnalyticsSummary()

Get Analytics Summary

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->socialMediaGetAnalyticsSummary();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaGetAnalyticsSummary: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaGetContentAnalytics**
> \Swagger\Client\Model\TRPCResponse socialMediaGetContentAnalytics($input)

Get Content Analytics

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->socialMediaGetContentAnalytics($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaGetContentAnalytics: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaGetScheduledPosts**
> \Swagger\Client\Model\TRPCResponse socialMediaGetScheduledPosts($input)

Get Scheduled Posts

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$input = "input_example"; // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

try {
    $result = $apiInstance->socialMediaGetScheduledPosts($input);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaGetScheduledPosts: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaPublishContent**
> \Swagger\Client\Model\TRPCResponse socialMediaPublishContent($body)

Publish Content

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaPublishContentBody(); // \Swagger\Client\Model\TrpcSocialMediaPublishContentBody | 

try {
    $result = $apiInstance->socialMediaPublishContent($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaPublishContent: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaPublishContentBody**](../Model/TrpcSocialMediaPublishContentBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaReschedulePost**
> \Swagger\Client\Model\TRPCResponse socialMediaReschedulePost($body)

Reschedule Post

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaReschedulePostBody(); // \Swagger\Client\Model\TrpcSocialMediaReschedulePostBody | 

try {
    $result = $apiInstance->socialMediaReschedulePost($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaReschedulePost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaReschedulePostBody**](../Model/TrpcSocialMediaReschedulePostBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaSchedulePost**
> \Swagger\Client\Model\TRPCResponse socialMediaSchedulePost($body)

Schedule Post

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaSchedulePostBody(); // \Swagger\Client\Model\TrpcSocialMediaSchedulePostBody | 

try {
    $result = $apiInstance->socialMediaSchedulePost($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaSchedulePost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaSchedulePostBody**](../Model/TrpcSocialMediaSchedulePostBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **socialMediaSyncAnalytics**
> \Swagger\Client\Model\TRPCResponse socialMediaSyncAnalytics($body)

Sync Analytics

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: bearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\SocialMediaApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\TrpcSocialMediaSyncAnalyticsBody(); // \Swagger\Client\Model\TrpcSocialMediaSyncAnalyticsBody | 

try {
    $result = $apiInstance->socialMediaSyncAnalytics($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SocialMediaApi->socialMediaSyncAnalytics: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TrpcSocialMediaSyncAnalyticsBody**](../Model/TrpcSocialMediaSyncAnalyticsBody.md)|  |

### Return type

[**\Swagger\Client\Model\TRPCResponse**](../Model/TRPCResponse.md)

### Authorization

[bearerAuth](../../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

