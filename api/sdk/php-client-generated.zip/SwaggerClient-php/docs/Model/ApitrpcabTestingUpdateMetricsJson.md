# ApitrpcabTestingUpdateMetricsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post_id** | **float** |  | 
**variation_index** | **float** |  | 
**platform** | **string** |  | 
**metrics** | [**\Swagger\Client\Model\ApitrpcabTestingUpdateMetricsJsonMetrics**](ApitrpcabTestingUpdateMetricsJsonMetrics.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

