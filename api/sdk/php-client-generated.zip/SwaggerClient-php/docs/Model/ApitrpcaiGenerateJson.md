# ApitrpcaiGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task** | **string** |  | 
**user_prompt** | **string** |  | [optional] 
**selected_text** | **string** |  | [optional] 
**post_markdown** | **string** |  | [optional] 
**front_matter** | [****](.md) |  | [optional] 
**tone** | **string** |  | [optional] 
**voice_profile_id** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

