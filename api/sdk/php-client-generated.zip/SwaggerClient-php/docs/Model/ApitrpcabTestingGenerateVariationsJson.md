# ApitrpcabTestingGenerateVariationsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post_id** | **float** |  | 
**count** | **float** |  | [optional] 
**tones** | **string[]** |  | [optional] 
**angles** | **string[]** |  | [optional] 
**headline** | **string** |  | 
**content** | **string** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

