# ApitrpcgithubUpdateJekyllConfigJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **string** |  | 
**repo** | **string** |  | 
**root_path** | **string** |  | 
**branch** | **string** |  | 
**commit_message** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

