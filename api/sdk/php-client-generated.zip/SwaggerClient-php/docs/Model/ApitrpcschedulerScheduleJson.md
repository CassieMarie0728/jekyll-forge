# ApitrpcschedulerScheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_id** | **float** |  | 
**post_id** | **float** |  | [optional] 
**draft_path** | **string** |  | 
**target_path** | **string** |  | 
**scheduled_at** | [****](.md) |  | 
**timezone** | **string** |  | 
**commit_message** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

