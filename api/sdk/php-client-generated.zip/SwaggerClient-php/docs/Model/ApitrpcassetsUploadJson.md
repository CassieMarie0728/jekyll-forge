# ApitrpcassetsUploadJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_id** | **float** |  | 
**name** | **string** |  | 
**path** | **string** |  | 
**base64_content** | **string** |  | 
**mime_type** | **string** |  | 
**size** | **float** |  | 
**width** | **float** |  | [optional] 
**height** | **float** |  | [optional] 
**optimize** | **bool** |  | 
**max_width** | **float** |  | [optional] 
**output_format** | **string** |  | [optional] 
**quality** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

