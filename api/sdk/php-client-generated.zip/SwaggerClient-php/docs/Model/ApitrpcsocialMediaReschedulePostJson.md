# ApitrpcsocialMediaReschedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post_id** | **float** |  | 
**scheduled_at** | [****](.md) |  | 
**timezone** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

