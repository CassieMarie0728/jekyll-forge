# ApitrpcsnapshotsCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_id** | **float** |  | 
**post_id** | **float** |  | [optional] 
**post_path** | **string** |  | [optional] 
**label** | **string** |  | 
**reason** | [****](.md) |  | 
**markdown** | **string** |  | [optional] 
**front_matter** | [****](.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

