# ApitrpcabTestingUpdateMetricsJsonMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**impressions** | **float** |  | [optional] 
**engagements** | **float** |  | [optional] 
**clicks** | **float** |  | [optional] 
**shares** | **float** |  | [optional] 
**likes** | **float** |  | [optional] 
**replies** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

