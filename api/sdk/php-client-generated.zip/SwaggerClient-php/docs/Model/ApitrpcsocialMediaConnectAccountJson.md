# ApitrpcsocialMediaConnectAccountJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | **string** |  | 
**access_token** | **string** |  | 
**refresh_token** | **string** |  | [optional] 
**expires_at** | [****](.md) |  | [optional] 
**account_id** | **string** |  | 
**username** | **string** |  | [optional] 
**display_name** | **string** |  | [optional] 
**profile_image_url** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

