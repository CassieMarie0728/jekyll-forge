# ApitrpcaiUpdateSettingsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**temperature** | **float** |  | [optional] 
**max_tokens** | **float** |  | [optional] 
**system_prompt** | **string** |  | [optional] 
**brand_voice_prompt** | **string** |  | [optional] 
**safety_prompt** | **string** |  | [optional] 
**streaming** | **bool** |  | [optional] 
**default_language** | **string** |  | [optional] 
**default_tone** | **string** |  | [optional] 
**budget_limit_cents** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

