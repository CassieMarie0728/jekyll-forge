# ApitrpcgithubDeleteFileJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **string** |  | 
**repo** | **string** |  | 
**path** | **string** |  | 
**branch** | **string** |  | 
**sha** | **string** |  | 
**message** | **string** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

