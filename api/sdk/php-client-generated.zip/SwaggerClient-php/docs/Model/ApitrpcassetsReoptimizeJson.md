# ApitrpcassetsReoptimizeJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | 
**max_width** | **float** |  | [optional] 
**output_format** | **string** |  | [optional] 
**quality** | **float** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

