# ApitrpcsitesUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | 
**is_favorite** | **bool** |  | [optional] 
**selected_branch** | **string** |  | [optional] 
**root_path** | **string** |  | [optional] 
**timezone** | **string** |  | [optional] 
**default_layout** | **string** |  | [optional] 
**default_asset_path** | **string** |  | [optional] 
**ai_voice_profile** | **string** |  | [optional] 
**settings** | [****](.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

