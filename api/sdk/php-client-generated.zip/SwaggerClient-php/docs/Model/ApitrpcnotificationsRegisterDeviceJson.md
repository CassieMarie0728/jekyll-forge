# ApitrpcnotificationsRegisterDeviceJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **string** |  | 
**platform** | **string** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

