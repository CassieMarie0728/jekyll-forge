# ApitrpcpostsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** |  | 
**path** | **string** |  | [optional] 
**title** | **string** |  | [optional] 
**slug** | **string** |  | [optional] 
**status** | [****](.md) |  | [optional] 
**front_matter** | [****](.md) |  | [optional] 
**markdown** | **string** |  | [optional] 
**sha** | **string** |  | [optional] 
**scheduled_at** | [****](.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

