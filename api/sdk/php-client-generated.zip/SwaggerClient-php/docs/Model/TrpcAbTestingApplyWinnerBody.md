# TrpcAbTestingApplyWinnerBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**\Swagger\Client\Model\ApitrpcabTestingApplyWinnerJson**](ApitrpcabTestingApplyWinnerJson.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

