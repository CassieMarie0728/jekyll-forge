# ApitrpcsitesUpsertJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **string** |  | 
**repo** | **string** |  | 
**default_branch** | **string** |  | [optional] 
**selected_branch** | **string** |  | [optional] 
**root_path** | **string** |  | [optional] 
**is_jekyll** | **bool** |  | [optional] 
**is_favorite** | **bool** |  | [optional] 
**timezone** | **string** |  | [optional] 
**default_layout** | **string** |  | [optional] 
**default_asset_path** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

