import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { Configuration } from './configuration';
import { HttpClient } from '@angular/common/http';


import { AbTestingService } from './api/abTesting.service';
import { AiService } from './api/ai.service';
import { AiProvidersService } from './api/aiProviders.service';
import { AssetsService } from './api/assets.service';
import { BlocksService } from './api/blocks.service';
import { GithubService } from './api/github.service';
import { NotificationsService } from './api/notifications.service';
import { PostsService } from './api/posts.service';
import { RepurposingService } from './api/repurposing.service';
import { SchedulerService } from './api/scheduler.service';
import { SitesService } from './api/sites.service';
import { SnapshotsService } from './api/snapshots.service';
import { SocialMediaService } from './api/socialMedia.service';

@NgModule({
  imports:      [],
  declarations: [],
  exports:      [],
  providers: [
    AbTestingService,
    AiService,
    AiProvidersService,
    AssetsService,
    BlocksService,
    GithubService,
    NotificationsService,
    PostsService,
    RepurposingService,
    SchedulerService,
    SitesService,
    SnapshotsService,
    SocialMediaService ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders<ApiModule> {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        };
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule,
                 @Optional() http: HttpClient) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
            'See also https://github.com/angular/angular/issues/20575');
        }
    }
}
