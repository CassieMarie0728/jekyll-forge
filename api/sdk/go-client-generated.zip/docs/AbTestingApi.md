# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AbTestingApplyWinner**](AbTestingApi.md#AbTestingApplyWinner) | **Post** /api/trpc/abTesting.applyWinner | Apply Winner
[**AbTestingCompleteTest**](AbTestingApi.md#AbTestingCompleteTest) | **Post** /api/trpc/abTesting.completeTest | Complete Test
[**AbTestingGenerateVariations**](AbTestingApi.md#AbTestingGenerateVariations) | **Post** /api/trpc/abTesting.generateVariations | Generate Variations
[**AbTestingGetResults**](AbTestingApi.md#AbTestingGetResults) | **Get** /api/trpc/abTesting.getResults | Get Results
[**AbTestingGetVariations**](AbTestingApi.md#AbTestingGetVariations) | **Get** /api/trpc/abTesting.getVariations | Get Variations
[**AbTestingPublishVariation**](AbTestingApi.md#AbTestingPublishVariation) | **Post** /api/trpc/abTesting.publishVariation | Publish Variation
[**AbTestingUpdateMetrics**](AbTestingApi.md#AbTestingUpdateMetrics) | **Post** /api/trpc/abTesting.updateMetrics | Update Metrics

# **AbTestingApplyWinner**
> ModelMap AbTestingApplyWinner(ctx, body)
Apply Winner

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAbTestingApplyWinnerBody**](TrpcAbTestingApplyWinnerBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AbTestingCompleteTest**
> ModelMap AbTestingCompleteTest(ctx, body)
Complete Test

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAbTestingCompleteTestBody**](TrpcAbTestingCompleteTestBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AbTestingGenerateVariations**
> ModelMap AbTestingGenerateVariations(ctx, body)
Generate Variations

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAbTestingGenerateVariationsBody**](TrpcAbTestingGenerateVariationsBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AbTestingGetResults**
> ModelMap AbTestingGetResults(ctx, input)
Get Results

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AbTestingGetVariations**
> ModelMap AbTestingGetVariations(ctx, input)
Get Variations

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AbTestingPublishVariation**
> ModelMap AbTestingPublishVariation(ctx, body)
Publish Variation

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAbTestingPublishVariationBody**](TrpcAbTestingPublishVariationBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AbTestingUpdateMetrics**
> ModelMap AbTestingUpdateMetrics(ctx, body)
Update Metrics

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAbTestingUpdateMetricsBody**](TrpcAbTestingUpdateMetricsBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

