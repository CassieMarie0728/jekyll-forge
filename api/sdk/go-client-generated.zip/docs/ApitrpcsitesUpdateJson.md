# ApitrpcsitesUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **float64** |  | [default to null]
**IsFavorite** | **bool** |  | [optional] [default to null]
**SelectedBranch** | **string** |  | [optional] [default to null]
**RootPath** | **string** |  | [optional] [default to null]
**Timezone** | **string** |  | [optional] [default to null]
**DefaultLayout** | **string** |  | [optional] [default to null]
**DefaultAssetPath** | **string** |  | [optional] [default to null]
**AiVoiceProfile** | **string** |  | [optional] [default to null]
**Settings** | [***Object**](.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

