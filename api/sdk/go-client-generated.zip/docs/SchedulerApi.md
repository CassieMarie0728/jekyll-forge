# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SchedulerCancel**](SchedulerApi.md#SchedulerCancel) | **Post** /api/trpc/scheduler.cancel | Cancel
[**SchedulerCancelAll**](SchedulerApi.md#SchedulerCancelAll) | **Post** /api/trpc/scheduler.cancelAll | Cancel All
[**SchedulerList**](SchedulerApi.md#SchedulerList) | **Get** /api/trpc/scheduler.list | List
[**SchedulerListHeartbeatJobs**](SchedulerApi.md#SchedulerListHeartbeatJobs) | **Get** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**SchedulerMarkFailed**](SchedulerApi.md#SchedulerMarkFailed) | **Post** /api/trpc/scheduler.markFailed | Mark Failed
[**SchedulerMarkPublished**](SchedulerApi.md#SchedulerMarkPublished) | **Post** /api/trpc/scheduler.markPublished | Mark Published
[**SchedulerReschedule**](SchedulerApi.md#SchedulerReschedule) | **Post** /api/trpc/scheduler.reschedule | Reschedule
[**SchedulerSchedule**](SchedulerApi.md#SchedulerSchedule) | **Post** /api/trpc/scheduler.schedule | Schedule

# **SchedulerCancel**
> ModelMap SchedulerCancel(ctx, body)
Cancel

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSchedulerCancelBody**](TrpcSchedulerCancelBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerCancelAll**
> ModelMap SchedulerCancelAll(ctx, body)
Cancel All

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSchedulerCancelAllBody**](TrpcSchedulerCancelAllBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerList**
> ModelMap SchedulerList(ctx, input)
List

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerListHeartbeatJobs**
> ModelMap SchedulerListHeartbeatJobs(ctx, input)
List Heartbeat Jobs

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerMarkFailed**
> ModelMap SchedulerMarkFailed(ctx, body)
Mark Failed

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSchedulerMarkFailedBody**](TrpcSchedulerMarkFailedBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerMarkPublished**
> ModelMap SchedulerMarkPublished(ctx, body)
Mark Published

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSchedulerMarkPublishedBody**](TrpcSchedulerMarkPublishedBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerReschedule**
> ModelMap SchedulerReschedule(ctx, body)
Reschedule

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSchedulerRescheduleBody**](TrpcSchedulerRescheduleBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SchedulerSchedule**
> ModelMap SchedulerSchedule(ctx, body)
Schedule

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSchedulerScheduleBody**](TrpcSchedulerScheduleBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

