# ApitrpcassetsUploadJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **float64** |  | [default to null]
**Name** | **string** |  | [default to null]
**Path** | **string** |  | [default to null]
**Base64Content** | **string** |  | [default to null]
**MimeType** | **string** |  | [default to null]
**Size** | **float64** |  | [default to null]
**Width** | **float64** |  | [optional] [default to null]
**Height** | **float64** |  | [optional] [default to null]
**Optimize** | **bool** |  | [default to null]
**MaxWidth** | **float64** |  | [optional] [default to null]
**OutputFormat** | **string** |  | [optional] [default to null]
**Quality** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

