# ApitrpcrepurposingGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **float64** |  | [default to null]
**SiteId** | **float64** |  | [default to null]
**Format** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

