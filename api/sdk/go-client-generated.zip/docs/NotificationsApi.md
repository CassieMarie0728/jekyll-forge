# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**NotificationsRegisterDevice**](NotificationsApi.md#NotificationsRegisterDevice) | **Post** /api/trpc/notifications.registerDevice | Register Device
[**NotificationsUnregisterDevice**](NotificationsApi.md#NotificationsUnregisterDevice) | **Post** /api/trpc/notifications.unregisterDevice | Unregister Device

# **NotificationsRegisterDevice**
> ModelMap NotificationsRegisterDevice(ctx, body)
Register Device

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcNotificationsRegisterDeviceBody**](TrpcNotificationsRegisterDeviceBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **NotificationsUnregisterDevice**
> ModelMap NotificationsUnregisterDevice(ctx, body)
Unregister Device

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcNotificationsUnregisterDeviceBody**](TrpcNotificationsUnregisterDeviceBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

