# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SocialMediaCancelScheduledPost**](SocialMediaApi.md#SocialMediaCancelScheduledPost) | **Post** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**SocialMediaConnectAccount**](SocialMediaApi.md#SocialMediaConnectAccount) | **Post** /api/trpc/socialMedia.connectAccount | Connect Account
[**SocialMediaDisconnectAccount**](SocialMediaApi.md#SocialMediaDisconnectAccount) | **Post** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**SocialMediaGetAccountDetails**](SocialMediaApi.md#SocialMediaGetAccountDetails) | **Get** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**SocialMediaGetAccounts**](SocialMediaApi.md#SocialMediaGetAccounts) | **Get** /api/trpc/socialMedia.getAccounts | Get Accounts
[**SocialMediaGetAnalyticsByPlatform**](SocialMediaApi.md#SocialMediaGetAnalyticsByPlatform) | **Get** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**SocialMediaGetAnalyticsSummary**](SocialMediaApi.md#SocialMediaGetAnalyticsSummary) | **Get** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**SocialMediaGetContentAnalytics**](SocialMediaApi.md#SocialMediaGetContentAnalytics) | **Get** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**SocialMediaGetScheduledPosts**](SocialMediaApi.md#SocialMediaGetScheduledPosts) | **Get** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**SocialMediaPublishContent**](SocialMediaApi.md#SocialMediaPublishContent) | **Post** /api/trpc/socialMedia.publishContent | Publish Content
[**SocialMediaReschedulePost**](SocialMediaApi.md#SocialMediaReschedulePost) | **Post** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**SocialMediaSchedulePost**](SocialMediaApi.md#SocialMediaSchedulePost) | **Post** /api/trpc/socialMedia.schedulePost | Schedule Post
[**SocialMediaSyncAnalytics**](SocialMediaApi.md#SocialMediaSyncAnalytics) | **Post** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

# **SocialMediaCancelScheduledPost**
> ModelMap SocialMediaCancelScheduledPost(ctx, body)
Cancel Scheduled Post

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaCancelScheduledPostBody**](TrpcSocialMediaCancelScheduledPostBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaConnectAccount**
> ModelMap SocialMediaConnectAccount(ctx, body)
Connect Account

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaConnectAccountBody**](TrpcSocialMediaConnectAccountBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaDisconnectAccount**
> ModelMap SocialMediaDisconnectAccount(ctx, body)
Disconnect Account

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaDisconnectAccountBody**](TrpcSocialMediaDisconnectAccountBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaGetAccountDetails**
> ModelMap SocialMediaGetAccountDetails(ctx, input)
Get Account Details

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaGetAccounts**
> ModelMap SocialMediaGetAccounts(ctx, )
Get Accounts

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaGetAnalyticsByPlatform**
> ModelMap SocialMediaGetAnalyticsByPlatform(ctx, input)
Get Analytics By Platform

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaGetAnalyticsSummary**
> ModelMap SocialMediaGetAnalyticsSummary(ctx, )
Get Analytics Summary

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaGetContentAnalytics**
> ModelMap SocialMediaGetContentAnalytics(ctx, input)
Get Content Analytics

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaGetScheduledPosts**
> ModelMap SocialMediaGetScheduledPosts(ctx, input)
Get Scheduled Posts

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaPublishContent**
> ModelMap SocialMediaPublishContent(ctx, body)
Publish Content

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaPublishContentBody**](TrpcSocialMediaPublishContentBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaReschedulePost**
> ModelMap SocialMediaReschedulePost(ctx, body)
Reschedule Post

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaReschedulePostBody**](TrpcSocialMediaReschedulePostBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaSchedulePost**
> ModelMap SocialMediaSchedulePost(ctx, body)
Schedule Post

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaSchedulePostBody**](TrpcSocialMediaSchedulePostBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SocialMediaSyncAnalytics**
> ModelMap SocialMediaSyncAnalytics(ctx, body)
Sync Analytics

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcSocialMediaSyncAnalyticsBody**](TrpcSocialMediaSyncAnalyticsBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

