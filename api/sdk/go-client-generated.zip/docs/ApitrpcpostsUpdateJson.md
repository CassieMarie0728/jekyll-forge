# ApitrpcpostsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **float64** |  | [default to null]
**Path** | **string** |  | [optional] [default to null]
**Title** | **string** |  | [optional] [default to null]
**Slug** | **string** |  | [optional] [default to null]
**Status** | [***Object**](.md) |  | [optional] [default to null]
**FrontMatter** | [***Object**](.md) |  | [optional] [default to null]
**Markdown** | **string** |  | [optional] [default to null]
**Sha** | **string** |  | [optional] [default to null]
**ScheduledAt** | [***Object**](.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

