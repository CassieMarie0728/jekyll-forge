# ApitrpcabTestingUpdateMetricsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **float64** |  | [default to null]
**VariationIndex** | **float64** |  | [default to null]
**Platform** | **string** |  | [default to null]
**Metrics** | [***ApitrpcabTestingUpdateMetricsJsonMetrics**](apitrpcabTesting.updateMetrics_json_metrics.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

