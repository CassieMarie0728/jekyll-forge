# ApitrpcgithubCreatePullRequestJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | [default to null]
**Repo** | **string** |  | [default to null]
**Title** | **string** |  | [default to null]
**Head** | **string** |  | [default to null]
**Base** | **string** |  | [default to null]
**Body** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

