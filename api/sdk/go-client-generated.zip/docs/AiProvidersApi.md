# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AiProvidersActivate**](AiProvidersApi.md#AiProvidersActivate) | **Post** /api/trpc/aiProviders.activate | Activate
[**AiProvidersGetSettings**](AiProvidersApi.md#AiProvidersGetSettings) | **Get** /api/trpc/aiProviders.getSettings | Get Settings
[**AiProvidersRemove**](AiProvidersApi.md#AiProvidersRemove) | **Post** /api/trpc/aiProviders.remove | Remove
[**AiProvidersSave**](AiProvidersApi.md#AiProvidersSave) | **Post** /api/trpc/aiProviders.save | Save
[**AiProvidersTest**](AiProvidersApi.md#AiProvidersTest) | **Post** /api/trpc/aiProviders.test | Test

# **AiProvidersActivate**
> ModelMap AiProvidersActivate(ctx, body)
Activate

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAiProvidersActivateBody**](TrpcAiProvidersActivateBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AiProvidersGetSettings**
> ModelMap AiProvidersGetSettings(ctx, )
Get Settings

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AiProvidersRemove**
> ModelMap AiProvidersRemove(ctx, body)
Remove

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAiProvidersRemoveBody**](TrpcAiProvidersRemoveBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AiProvidersSave**
> ModelMap AiProvidersSave(ctx, body)
Save

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAiProvidersSaveBody**](TrpcAiProvidersSaveBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **AiProvidersTest**
> ModelMap AiProvidersTest(ctx, body)
Test

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcAiProvidersTestBody**](TrpcAiProvidersTestBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

