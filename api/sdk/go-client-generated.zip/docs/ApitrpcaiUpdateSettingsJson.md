# ApitrpcaiUpdateSettingsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool** |  | [optional] [default to null]
**Temperature** | **float64** |  | [optional] [default to null]
**MaxTokens** | **float64** |  | [optional] [default to null]
**SystemPrompt** | **string** |  | [optional] [default to null]
**BrandVoicePrompt** | **string** |  | [optional] [default to null]
**SafetyPrompt** | **string** |  | [optional] [default to null]
**Streaming** | **bool** |  | [optional] [default to null]
**DefaultLanguage** | **string** |  | [optional] [default to null]
**DefaultTone** | **string** |  | [optional] [default to null]
**BudgetLimitCents** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

