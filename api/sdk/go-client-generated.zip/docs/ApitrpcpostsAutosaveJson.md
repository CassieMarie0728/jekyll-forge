# ApitrpcpostsAutosaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **float64** |  | [default to null]
**Markdown** | **string** |  | [default to null]
**FrontMatter** | [***Object**](.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

