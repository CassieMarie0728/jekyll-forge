# ApitrpcsnapshotsCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **float64** |  | [default to null]
**PostId** | **float64** |  | [optional] [default to null]
**PostPath** | **string** |  | [optional] [default to null]
**Label** | **string** |  | [default to null]
**Reason** | [***Object**](.md) |  | [default to null]
**Markdown** | **string** |  | [optional] [default to null]
**FrontMatter** | [***Object**](.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

