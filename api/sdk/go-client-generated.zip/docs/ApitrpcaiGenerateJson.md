# ApitrpcaiGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Task** | **string** |  | [default to null]
**UserPrompt** | **string** |  | [optional] [default to null]
**SelectedText** | **string** |  | [optional] [default to null]
**PostMarkdown** | **string** |  | [optional] [default to null]
**FrontMatter** | [***Object**](.md) |  | [optional] [default to null]
**Tone** | **string** |  | [optional] [default to null]
**VoiceProfileId** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

