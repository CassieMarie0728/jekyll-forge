# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GithubCheckPluginCompatibility**](GithubApi.md#GithubCheckPluginCompatibility) | **Get** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
[**GithubCommitFile**](GithubApi.md#GithubCommitFile) | **Post** /api/trpc/github.commitFile | Commit File
[**GithubConnect**](GithubApi.md#GithubConnect) | **Post** /api/trpc/github.connect | Connect
[**GithubCreateBranch**](GithubApi.md#GithubCreateBranch) | **Post** /api/trpc/github.createBranch | Create Branch
[**GithubCreatePullRequest**](GithubApi.md#GithubCreatePullRequest) | **Post** /api/trpc/github.createPullRequest | Create Pull Request
[**GithubDeleteFile**](GithubApi.md#GithubDeleteFile) | **Post** /api/trpc/github.deleteFile | Delete File
[**GithubDetectJekyll**](GithubApi.md#GithubDetectJekyll) | **Get** /api/trpc/github.detectJekyll | Detect Jekyll
[**GithubDisconnect**](GithubApi.md#GithubDisconnect) | **Post** /api/trpc/github.disconnect | Disconnect
[**GithubGenerateActionsWorkflow**](GithubApi.md#GithubGenerateActionsWorkflow) | **Post** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
[**GithubGetFile**](GithubApi.md#GithubGetFile) | **Get** /api/trpc/github.getFile | Get File
[**GithubGetJekyllConfig**](GithubApi.md#GithubGetJekyllConfig) | **Get** /api/trpc/github.getJekyllConfig | Get Jekyll Config
[**GithubGetPagesStatus**](GithubApi.md#GithubGetPagesStatus) | **Get** /api/trpc/github.getPagesStatus | Get Pages Status
[**GithubGetRateLimit**](GithubApi.md#GithubGetRateLimit) | **Get** /api/trpc/github.getRateLimit | Get Rate Limit
[**GithubInventory**](GithubApi.md#GithubInventory) | **Get** /api/trpc/github.inventory | Inventory
[**GithubListBranches**](GithubApi.md#GithubListBranches) | **Get** /api/trpc/github.listBranches | List Branches
[**GithubListFiles**](GithubApi.md#GithubListFiles) | **Get** /api/trpc/github.listFiles | List Files
[**GithubListRepos**](GithubApi.md#GithubListRepos) | **Get** /api/trpc/github.listRepos | List Repos
[**GithubRepositories**](GithubApi.md#GithubRepositories) | **Get** /api/trpc/github.repositories | Repositories
[**GithubReviewFile**](GithubApi.md#GithubReviewFile) | **Get** /api/trpc/github.reviewFile | Review File
[**GithubStatus**](GithubApi.md#GithubStatus) | **Get** /api/trpc/github.status | Status
[**GithubUpdateJekyllConfig**](GithubApi.md#GithubUpdateJekyllConfig) | **Post** /api/trpc/github.updateJekyllConfig | Update Jekyll Config

# **GithubCheckPluginCompatibility**
> ModelMap GithubCheckPluginCompatibility(ctx, input)
Check Plugin Compatibility

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubCommitFile**
> ModelMap GithubCommitFile(ctx, body)
Commit File

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubCommitFileBody**](TrpcGithubCommitFileBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubConnect**
> ModelMap GithubConnect(ctx, body)
Connect

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubConnectBody**](TrpcGithubConnectBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubCreateBranch**
> ModelMap GithubCreateBranch(ctx, body)
Create Branch

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubCreateBranchBody**](TrpcGithubCreateBranchBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubCreatePullRequest**
> ModelMap GithubCreatePullRequest(ctx, body)
Create Pull Request

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubCreatePullRequestBody**](TrpcGithubCreatePullRequestBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubDeleteFile**
> ModelMap GithubDeleteFile(ctx, body)
Delete File

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubDeleteFileBody**](TrpcGithubDeleteFileBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubDetectJekyll**
> ModelMap GithubDetectJekyll(ctx, input)
Detect Jekyll

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubDisconnect**
> ModelMap GithubDisconnect(ctx, optional)
Disconnect

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GithubApiGithubDisconnectOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a GithubApiGithubDisconnectOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**optional.Interface of TrpcGithubDisconnectBody**](TrpcGithubDisconnectBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubGenerateActionsWorkflow**
> ModelMap GithubGenerateActionsWorkflow(ctx, body)
Generate Actions Workflow

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubGenerateActionsWorkflowBody**](TrpcGithubGenerateActionsWorkflowBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubGetFile**
> ModelMap GithubGetFile(ctx, input)
Get File

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubGetJekyllConfig**
> ModelMap GithubGetJekyllConfig(ctx, input)
Get Jekyll Config

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubGetPagesStatus**
> ModelMap GithubGetPagesStatus(ctx, input)
Get Pages Status

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubGetRateLimit**
> ModelMap GithubGetRateLimit(ctx, )
Get Rate Limit

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubInventory**
> ModelMap GithubInventory(ctx, input)
Inventory

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubListBranches**
> ModelMap GithubListBranches(ctx, input)
List Branches

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubListFiles**
> ModelMap GithubListFiles(ctx, input)
List Files

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubListRepos**
> ModelMap GithubListRepos(ctx, input)
List Repos

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubRepositories**
> ModelMap GithubRepositories(ctx, input)
Repositories

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubReviewFile**
> ModelMap GithubReviewFile(ctx, input)
Review File

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubStatus**
> ModelMap GithubStatus(ctx, )
Status

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GithubUpdateJekyllConfig**
> ModelMap GithubUpdateJekyllConfig(ctx, body)
Update Jekyll Config

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcGithubUpdateJekyllConfigBody**](TrpcGithubUpdateJekyllConfigBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

