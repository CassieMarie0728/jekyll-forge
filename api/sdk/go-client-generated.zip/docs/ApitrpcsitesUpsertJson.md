# ApitrpcsitesUpsertJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | [default to null]
**Repo** | **string** |  | [default to null]
**DefaultBranch** | **string** |  | [optional] [default to null]
**SelectedBranch** | **string** |  | [optional] [default to null]
**RootPath** | **string** |  | [optional] [default to null]
**IsJekyll** | **bool** |  | [optional] [default to null]
**IsFavorite** | **bool** |  | [optional] [default to null]
**Timezone** | **string** |  | [optional] [default to null]
**DefaultLayout** | **string** |  | [optional] [default to null]
**DefaultAssetPath** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

