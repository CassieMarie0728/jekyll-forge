# ApitrpcrepurposingUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **float64** |  | [default to null]
**Content** | **string** |  | [optional] [default to null]
**Status** | [***Object**](.md) |  | [optional] [default to null]
**IsCustomized** | **bool** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

