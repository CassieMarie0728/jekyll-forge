# ApitrpcschedulerScheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **float64** |  | [default to null]
**PostId** | **float64** |  | [optional] [default to null]
**DraftPath** | **string** |  | [default to null]
**TargetPath** | **string** |  | [default to null]
**ScheduledAt** | [***Object**](.md) |  | [default to null]
**Timezone** | **string** |  | [default to null]
**CommitMessage** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

