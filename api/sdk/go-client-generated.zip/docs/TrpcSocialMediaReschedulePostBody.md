# TrpcSocialMediaReschedulePostBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [***ApitrpcsocialMediaReschedulePostJson**](apitrpcsocialMedia.reschedulePost_json.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

