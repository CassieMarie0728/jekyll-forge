# ApitrpcsocialMediaSchedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RepurposedContentId** | **float64** |  | [default to null]
**SocialMediaAccountId** | **float64** |  | [default to null]
**ScheduledAt** | [***Object**](.md) |  | [default to null]
**Timezone** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

