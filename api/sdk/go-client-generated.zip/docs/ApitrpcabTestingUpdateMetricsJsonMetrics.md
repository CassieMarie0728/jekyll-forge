# ApitrpcabTestingUpdateMetricsJsonMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Impressions** | **float64** |  | [optional] [default to null]
**Engagements** | **float64** |  | [optional] [default to null]
**Clicks** | **float64** |  | [optional] [default to null]
**Shares** | **float64** |  | [optional] [default to null]
**Likes** | **float64** |  | [optional] [default to null]
**Replies** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

