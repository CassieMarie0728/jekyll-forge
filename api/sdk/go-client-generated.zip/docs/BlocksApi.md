# {{classname}}

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BlocksCreate**](BlocksApi.md#BlocksCreate) | **Post** /api/trpc/blocks.create | Create
[**BlocksDelete**](BlocksApi.md#BlocksDelete) | **Post** /api/trpc/blocks.delete | Delete
[**BlocksList**](BlocksApi.md#BlocksList) | **Get** /api/trpc/blocks.list | List
[**BlocksUpdate**](BlocksApi.md#BlocksUpdate) | **Post** /api/trpc/blocks.update | Update

# **BlocksCreate**
> ModelMap BlocksCreate(ctx, body)
Create

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcBlocksCreateBody**](TrpcBlocksCreateBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BlocksDelete**
> ModelMap BlocksDelete(ctx, body)
Delete

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcBlocksDeleteBody**](TrpcBlocksDeleteBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BlocksList**
> ModelMap BlocksList(ctx, )
List

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BlocksUpdate**
> ModelMap BlocksUpdate(ctx, body)
Update

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**TrpcBlocksUpdateBody**](TrpcBlocksUpdateBody.md)|  | 

### Return type

[**ModelMap**](map.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

