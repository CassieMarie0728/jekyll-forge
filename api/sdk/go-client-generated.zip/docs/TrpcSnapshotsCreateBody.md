# TrpcSnapshotsCreateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [***ApitrpcsnapshotsCreateJson**](apitrpcsnapshots.create_json.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

