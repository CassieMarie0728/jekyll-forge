# ApitrpcaiProvidersSaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Provider** | [***Object**](.md) |  | [default to null]
**Model** | **string** |  | [default to null]
**ApiKey** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

