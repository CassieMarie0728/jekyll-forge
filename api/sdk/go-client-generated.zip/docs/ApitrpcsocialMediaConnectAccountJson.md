# ApitrpcsocialMediaConnectAccountJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Platform** | **string** |  | [default to null]
**AccessToken** | **string** |  | [default to null]
**RefreshToken** | **string** |  | [optional] [default to null]
**ExpiresAt** | [***Object**](.md) |  | [optional] [default to null]
**AccountId** | **string** |  | [default to null]
**Username** | **string** |  | [optional] [default to null]
**DisplayName** | **string** |  | [optional] [default to null]
**ProfileImageUrl** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

