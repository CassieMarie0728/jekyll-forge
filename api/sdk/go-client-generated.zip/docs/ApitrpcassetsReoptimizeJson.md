# ApitrpcassetsReoptimizeJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **float64** |  | [default to null]
**MaxWidth** | **float64** |  | [optional] [default to null]
**OutputFormat** | **string** |  | [optional] [default to null]
**Quality** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

