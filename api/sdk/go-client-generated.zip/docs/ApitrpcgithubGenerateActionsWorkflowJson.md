# ApitrpcgithubGenerateActionsWorkflowJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | [default to null]
**Repo** | **string** |  | [default to null]
**Branch** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

