# ApitrpcabTestingGenerateVariationsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **float64** |  | [default to null]
**Count** | **float64** |  | [optional] [default to null]
**Tones** | **[]string** |  | [optional] [default to null]
**Angles** | **[]string** |  | [optional] [default to null]
**Headline** | **string** |  | [default to null]
**Content** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

