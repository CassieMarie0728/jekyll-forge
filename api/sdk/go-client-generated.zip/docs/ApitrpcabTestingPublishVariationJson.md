# ApitrpcabTestingPublishVariationJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **float64** |  | [default to null]
**VariationIndex** | **float64** |  | [default to null]
**Platforms** | **[]string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

