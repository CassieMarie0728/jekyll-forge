# TrpcAssetsReoptimizeBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [***ApitrpcassetsReoptimizeJson**](apitrpcassets.reoptimize_json.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

