# IO.Swagger.Model.TrpcSchedulerCancelAllBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcschedulerCancelAllJson**](ApitrpcschedulerCancelAllJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

