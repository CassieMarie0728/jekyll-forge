# IO.Swagger.Api.SocialMediaApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SocialMediaCancelScheduledPost**](SocialMediaApi.md#socialmediacancelscheduledpost) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**SocialMediaConnectAccount**](SocialMediaApi.md#socialmediaconnectaccount) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
[**SocialMediaDisconnectAccount**](SocialMediaApi.md#socialmediadisconnectaccount) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**SocialMediaGetAccountDetails**](SocialMediaApi.md#socialmediagetaccountdetails) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**SocialMediaGetAccounts**](SocialMediaApi.md#socialmediagetaccounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
[**SocialMediaGetAnalyticsByPlatform**](SocialMediaApi.md#socialmediagetanalyticsbyplatform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**SocialMediaGetAnalyticsSummary**](SocialMediaApi.md#socialmediagetanalyticssummary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**SocialMediaGetContentAnalytics**](SocialMediaApi.md#socialmediagetcontentanalytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**SocialMediaGetScheduledPosts**](SocialMediaApi.md#socialmediagetscheduledposts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**SocialMediaPublishContent**](SocialMediaApi.md#socialmediapublishcontent) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
[**SocialMediaReschedulePost**](SocialMediaApi.md#socialmediareschedulepost) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**SocialMediaSchedulePost**](SocialMediaApi.md#socialmediaschedulepost) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
[**SocialMediaSyncAnalytics**](SocialMediaApi.md#socialmediasyncanalytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

<a name="socialmediacancelscheduledpost"></a>
# **SocialMediaCancelScheduledPost**
> TRPCResponse SocialMediaCancelScheduledPost (TrpcSocialMediaCancelScheduledPostBody body)

Cancel Scheduled Post

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaCancelScheduledPostExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaCancelScheduledPostBody(); // TrpcSocialMediaCancelScheduledPostBody | 

            try
            {
                // Cancel Scheduled Post
                TRPCResponse result = apiInstance.SocialMediaCancelScheduledPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaCancelScheduledPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaCancelScheduledPostBody**](TrpcSocialMediaCancelScheduledPostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediaconnectaccount"></a>
# **SocialMediaConnectAccount**
> TRPCResponse SocialMediaConnectAccount (TrpcSocialMediaConnectAccountBody body)

Connect Account

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaConnectAccountExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaConnectAccountBody(); // TrpcSocialMediaConnectAccountBody | 

            try
            {
                // Connect Account
                TRPCResponse result = apiInstance.SocialMediaConnectAccount(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaConnectAccount: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaConnectAccountBody**](TrpcSocialMediaConnectAccountBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediadisconnectaccount"></a>
# **SocialMediaDisconnectAccount**
> TRPCResponse SocialMediaDisconnectAccount (TrpcSocialMediaDisconnectAccountBody body)

Disconnect Account

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaDisconnectAccountExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaDisconnectAccountBody(); // TrpcSocialMediaDisconnectAccountBody | 

            try
            {
                // Disconnect Account
                TRPCResponse result = apiInstance.SocialMediaDisconnectAccount(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaDisconnectAccount: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaDisconnectAccountBody**](TrpcSocialMediaDisconnectAccountBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediagetaccountdetails"></a>
# **SocialMediaGetAccountDetails**
> TRPCResponse SocialMediaGetAccountDetails (string input)

Get Account Details

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaGetAccountDetailsExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Account Details
                TRPCResponse result = apiInstance.SocialMediaGetAccountDetails(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaGetAccountDetails: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediagetaccounts"></a>
# **SocialMediaGetAccounts**
> TRPCResponse SocialMediaGetAccounts ()

Get Accounts

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaGetAccountsExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();

            try
            {
                // Get Accounts
                TRPCResponse result = apiInstance.SocialMediaGetAccounts();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaGetAccounts: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediagetanalyticsbyplatform"></a>
# **SocialMediaGetAnalyticsByPlatform**
> TRPCResponse SocialMediaGetAnalyticsByPlatform (string input)

Get Analytics By Platform

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaGetAnalyticsByPlatformExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Analytics By Platform
                TRPCResponse result = apiInstance.SocialMediaGetAnalyticsByPlatform(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaGetAnalyticsByPlatform: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediagetanalyticssummary"></a>
# **SocialMediaGetAnalyticsSummary**
> TRPCResponse SocialMediaGetAnalyticsSummary ()

Get Analytics Summary

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaGetAnalyticsSummaryExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();

            try
            {
                // Get Analytics Summary
                TRPCResponse result = apiInstance.SocialMediaGetAnalyticsSummary();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaGetAnalyticsSummary: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediagetcontentanalytics"></a>
# **SocialMediaGetContentAnalytics**
> TRPCResponse SocialMediaGetContentAnalytics (string input)

Get Content Analytics

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaGetContentAnalyticsExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Content Analytics
                TRPCResponse result = apiInstance.SocialMediaGetContentAnalytics(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaGetContentAnalytics: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediagetscheduledposts"></a>
# **SocialMediaGetScheduledPosts**
> TRPCResponse SocialMediaGetScheduledPosts (string input)

Get Scheduled Posts

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaGetScheduledPostsExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Scheduled Posts
                TRPCResponse result = apiInstance.SocialMediaGetScheduledPosts(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaGetScheduledPosts: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediapublishcontent"></a>
# **SocialMediaPublishContent**
> TRPCResponse SocialMediaPublishContent (TrpcSocialMediaPublishContentBody body)

Publish Content

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaPublishContentExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaPublishContentBody(); // TrpcSocialMediaPublishContentBody | 

            try
            {
                // Publish Content
                TRPCResponse result = apiInstance.SocialMediaPublishContent(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaPublishContent: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaPublishContentBody**](TrpcSocialMediaPublishContentBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediareschedulepost"></a>
# **SocialMediaReschedulePost**
> TRPCResponse SocialMediaReschedulePost (TrpcSocialMediaReschedulePostBody body)

Reschedule Post

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaReschedulePostExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaReschedulePostBody(); // TrpcSocialMediaReschedulePostBody | 

            try
            {
                // Reschedule Post
                TRPCResponse result = apiInstance.SocialMediaReschedulePost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaReschedulePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaReschedulePostBody**](TrpcSocialMediaReschedulePostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediaschedulepost"></a>
# **SocialMediaSchedulePost**
> TRPCResponse SocialMediaSchedulePost (TrpcSocialMediaSchedulePostBody body)

Schedule Post

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaSchedulePostExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaSchedulePostBody(); // TrpcSocialMediaSchedulePostBody | 

            try
            {
                // Schedule Post
                TRPCResponse result = apiInstance.SocialMediaSchedulePost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaSchedulePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSchedulePostBody**](TrpcSocialMediaSchedulePostBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="socialmediasyncanalytics"></a>
# **SocialMediaSyncAnalytics**
> TRPCResponse SocialMediaSyncAnalytics (TrpcSocialMediaSyncAnalyticsBody body)

Sync Analytics

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SocialMediaSyncAnalyticsExample
    {
        public void main()
        {

            var apiInstance = new SocialMediaApi();
            var body = new TrpcSocialMediaSyncAnalyticsBody(); // TrpcSocialMediaSyncAnalyticsBody | 

            try
            {
                // Sync Analytics
                TRPCResponse result = apiInstance.SocialMediaSyncAnalytics(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SocialMediaApi.SocialMediaSyncAnalytics: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSyncAnalyticsBody**](TrpcSocialMediaSyncAnalyticsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
