# IO.Swagger.Model.ApitrpcgithubDeleteFileJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | 
**Repo** | **string** |  | 
**Path** | **string** |  | 
**Branch** | **string** |  | 
**Sha** | **string** |  | 
**Message** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

