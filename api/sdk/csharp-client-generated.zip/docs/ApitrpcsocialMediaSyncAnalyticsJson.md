# IO.Swagger.Model.ApitrpcsocialMediaSyncAnalyticsJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AnalyticsId** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

