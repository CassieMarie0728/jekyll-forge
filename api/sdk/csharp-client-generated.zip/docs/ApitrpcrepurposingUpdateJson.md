# IO.Swagger.Model.ApitrpcrepurposingUpdateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**Content** | **string** |  | [optional] 
**Status** | **Object** |  | [optional] 
**IsCustomized** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

