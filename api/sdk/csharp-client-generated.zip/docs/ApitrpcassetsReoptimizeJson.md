# IO.Swagger.Model.ApitrpcassetsReoptimizeJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**MaxWidth** | **decimal?** |  | [optional] 
**OutputFormat** | **string** |  | [optional] 
**Quality** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

