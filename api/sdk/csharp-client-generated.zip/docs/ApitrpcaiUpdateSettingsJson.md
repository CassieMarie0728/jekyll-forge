# IO.Swagger.Model.ApitrpcaiUpdateSettingsJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool?** |  | [optional] 
**Temperature** | **decimal?** |  | [optional] 
**MaxTokens** | **decimal?** |  | [optional] 
**SystemPrompt** | **string** |  | [optional] 
**BrandVoicePrompt** | **string** |  | [optional] 
**SafetyPrompt** | **string** |  | [optional] 
**Streaming** | **bool?** |  | [optional] 
**DefaultLanguage** | **string** |  | [optional] 
**DefaultTone** | **string** |  | [optional] 
**BudgetLimitCents** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

