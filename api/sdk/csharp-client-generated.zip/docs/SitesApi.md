# IO.Swagger.Api.SitesApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SitesDelete**](SitesApi.md#sitesdelete) | **POST** /api/trpc/sites.delete | Delete
[**SitesGet**](SitesApi.md#sitesget) | **GET** /api/trpc/sites.get | Get
[**SitesList**](SitesApi.md#siteslist) | **GET** /api/trpc/sites.list | List
[**SitesUpdate**](SitesApi.md#sitesupdate) | **POST** /api/trpc/sites.update | Update
[**SitesUpsert**](SitesApi.md#sitesupsert) | **POST** /api/trpc/sites.upsert | Upsert

<a name="sitesdelete"></a>
# **SitesDelete**
> TRPCResponse SitesDelete (TrpcSitesDeleteBody body)

Delete

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SitesDeleteExample
    {
        public void main()
        {

            var apiInstance = new SitesApi();
            var body = new TrpcSitesDeleteBody(); // TrpcSitesDeleteBody | 

            try
            {
                // Delete
                TRPCResponse result = apiInstance.SitesDelete(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SitesApi.SitesDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesDeleteBody**](TrpcSitesDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="sitesget"></a>
# **SitesGet**
> TRPCResponse SitesGet (string input)

Get

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SitesGetExample
    {
        public void main()
        {

            var apiInstance = new SitesApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get
                TRPCResponse result = apiInstance.SitesGet(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SitesApi.SitesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="siteslist"></a>
# **SitesList**
> TRPCResponse SitesList ()

List

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SitesListExample
    {
        public void main()
        {

            var apiInstance = new SitesApi();

            try
            {
                // List
                TRPCResponse result = apiInstance.SitesList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SitesApi.SitesList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="sitesupdate"></a>
# **SitesUpdate**
> TRPCResponse SitesUpdate (TrpcSitesUpdateBody body)

Update

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SitesUpdateExample
    {
        public void main()
        {

            var apiInstance = new SitesApi();
            var body = new TrpcSitesUpdateBody(); // TrpcSitesUpdateBody | 

            try
            {
                // Update
                TRPCResponse result = apiInstance.SitesUpdate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SitesApi.SitesUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpdateBody**](TrpcSitesUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="sitesupsert"></a>
# **SitesUpsert**
> TRPCResponse SitesUpsert (TrpcSitesUpsertBody body)

Upsert

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SitesUpsertExample
    {
        public void main()
        {

            var apiInstance = new SitesApi();
            var body = new TrpcSitesUpsertBody(); // TrpcSitesUpsertBody | 

            try
            {
                // Upsert
                TRPCResponse result = apiInstance.SitesUpsert(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SitesApi.SitesUpsert: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpsertBody**](TrpcSitesUpsertBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
