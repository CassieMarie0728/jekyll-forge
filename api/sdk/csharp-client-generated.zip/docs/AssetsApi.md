# IO.Swagger.Api.AssetsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AssetsDelete**](AssetsApi.md#assetsdelete) | **POST** /api/trpc/assets.delete | Delete
[**AssetsGenerateAltText**](AssetsApi.md#assetsgeneratealttext) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
[**AssetsList**](AssetsApi.md#assetslist) | **GET** /api/trpc/assets.list | List
[**AssetsReoptimize**](AssetsApi.md#assetsreoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
[**AssetsUpdate**](AssetsApi.md#assetsupdate) | **POST** /api/trpc/assets.update | Update
[**AssetsUpload**](AssetsApi.md#assetsupload) | **POST** /api/trpc/assets.upload | Upload

<a name="assetsdelete"></a>
# **AssetsDelete**
> TRPCResponse AssetsDelete (TrpcAssetsDeleteBody body)

Delete

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssetsDeleteExample
    {
        public void main()
        {

            var apiInstance = new AssetsApi();
            var body = new TrpcAssetsDeleteBody(); // TrpcAssetsDeleteBody | 

            try
            {
                // Delete
                TRPCResponse result = apiInstance.AssetsDelete(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetsApi.AssetsDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsDeleteBody**](TrpcAssetsDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="assetsgeneratealttext"></a>
# **AssetsGenerateAltText**
> TRPCResponse AssetsGenerateAltText (TrpcAssetsGenerateAltTextBody body)

Generate Alt Text

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssetsGenerateAltTextExample
    {
        public void main()
        {

            var apiInstance = new AssetsApi();
            var body = new TrpcAssetsGenerateAltTextBody(); // TrpcAssetsGenerateAltTextBody | 

            try
            {
                // Generate Alt Text
                TRPCResponse result = apiInstance.AssetsGenerateAltText(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetsApi.AssetsGenerateAltText: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsGenerateAltTextBody**](TrpcAssetsGenerateAltTextBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="assetslist"></a>
# **AssetsList**
> TRPCResponse AssetsList (string input)

List

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssetsListExample
    {
        public void main()
        {

            var apiInstance = new AssetsApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List
                TRPCResponse result = apiInstance.AssetsList(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetsApi.AssetsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="assetsreoptimize"></a>
# **AssetsReoptimize**
> TRPCResponse AssetsReoptimize (TrpcAssetsReoptimizeBody body)

Reoptimize

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssetsReoptimizeExample
    {
        public void main()
        {

            var apiInstance = new AssetsApi();
            var body = new TrpcAssetsReoptimizeBody(); // TrpcAssetsReoptimizeBody | 

            try
            {
                // Reoptimize
                TRPCResponse result = apiInstance.AssetsReoptimize(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetsApi.AssetsReoptimize: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsReoptimizeBody**](TrpcAssetsReoptimizeBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="assetsupdate"></a>
# **AssetsUpdate**
> TRPCResponse AssetsUpdate (TrpcAssetsUpdateBody body)

Update

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssetsUpdateExample
    {
        public void main()
        {

            var apiInstance = new AssetsApi();
            var body = new TrpcAssetsUpdateBody(); // TrpcAssetsUpdateBody | 

            try
            {
                // Update
                TRPCResponse result = apiInstance.AssetsUpdate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetsApi.AssetsUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUpdateBody**](TrpcAssetsUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="assetsupload"></a>
# **AssetsUpload**
> TRPCResponse AssetsUpload (TrpcAssetsUploadBody body)

Upload

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssetsUploadExample
    {
        public void main()
        {

            var apiInstance = new AssetsApi();
            var body = new TrpcAssetsUploadBody(); // TrpcAssetsUploadBody | 

            try
            {
                // Upload
                TRPCResponse result = apiInstance.AssetsUpload(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetsApi.AssetsUpload: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUploadBody**](TrpcAssetsUploadBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
