# IO.Swagger.Model.ApitrpcschedulerScheduleJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **decimal?** |  | 
**PostId** | **decimal?** |  | [optional] 
**DraftPath** | **string** |  | 
**TargetPath** | **string** |  | 
**ScheduledAt** | **Object** |  | 
**Timezone** | **string** |  | 
**CommitMessage** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

