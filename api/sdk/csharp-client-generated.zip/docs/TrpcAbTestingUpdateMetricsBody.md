# IO.Swagger.Model.TrpcAbTestingUpdateMetricsBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcabTestingUpdateMetricsJson**](ApitrpcabTestingUpdateMetricsJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

