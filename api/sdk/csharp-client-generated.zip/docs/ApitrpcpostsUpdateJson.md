# IO.Swagger.Model.ApitrpcpostsUpdateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**Path** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Slug** | **string** |  | [optional] 
**Status** | **Object** |  | [optional] 
**FrontMatter** | **Object** |  | [optional] 
**Markdown** | **string** |  | [optional] 
**Sha** | **string** |  | [optional] 
**ScheduledAt** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

