# IO.Swagger.Model.ApitrpcaiGenerateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Task** | **string** |  | 
**UserPrompt** | **string** |  | [optional] 
**SelectedText** | **string** |  | [optional] 
**PostMarkdown** | **string** |  | [optional] 
**FrontMatter** | **Object** |  | [optional] 
**Tone** | **string** |  | [optional] 
**VoiceProfileId** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

