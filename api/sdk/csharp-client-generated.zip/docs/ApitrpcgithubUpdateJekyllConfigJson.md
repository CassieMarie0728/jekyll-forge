# IO.Swagger.Model.ApitrpcgithubUpdateJekyllConfigJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | 
**Repo** | **string** |  | 
**RootPath** | **string** |  | 
**Branch** | **string** |  | 
**CommitMessage** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

