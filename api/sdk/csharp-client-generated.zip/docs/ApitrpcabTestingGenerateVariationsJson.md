# IO.Swagger.Model.ApitrpcabTestingGenerateVariationsJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **decimal?** |  | 
**Count** | **decimal?** |  | [optional] 
**Tones** | **List&lt;string&gt;** |  | [optional] 
**Angles** | **List&lt;string&gt;** |  | [optional] 
**Headline** | **string** |  | 
**Content** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

