# IO.Swagger.Model.ApitrpcabTestingApplyWinnerJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **decimal?** |  | 
**WinningVariationIndex** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

