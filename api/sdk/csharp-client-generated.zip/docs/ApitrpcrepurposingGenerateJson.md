# IO.Swagger.Model.ApitrpcrepurposingGenerateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **decimal?** |  | 
**SiteId** | **decimal?** |  | 
**Format** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

