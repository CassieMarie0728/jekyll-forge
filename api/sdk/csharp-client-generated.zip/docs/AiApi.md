# IO.Swagger.Api.AiApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AiGenerate**](AiApi.md#aigenerate) | **POST** /api/trpc/ai.generate | Generate
[**AiGetSettings**](AiApi.md#aigetsettings) | **GET** /api/trpc/ai.getSettings | Get Settings
[**AiGetUsageStats**](AiApi.md#aigetusagestats) | **GET** /api/trpc/ai.getUsageStats | Get Usage Stats
[**AiUpdateSettings**](AiApi.md#aiupdatesettings) | **POST** /api/trpc/ai.updateSettings | Update Settings

<a name="aigenerate"></a>
# **AiGenerate**
> TRPCResponse AiGenerate (TrpcAiGenerateBody body)

Generate

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiGenerateExample
    {
        public void main()
        {

            var apiInstance = new AiApi();
            var body = new TrpcAiGenerateBody(); // TrpcAiGenerateBody | 

            try
            {
                // Generate
                TRPCResponse result = apiInstance.AiGenerate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiApi.AiGenerate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiGenerateBody**](TrpcAiGenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aigetsettings"></a>
# **AiGetSettings**
> TRPCResponse AiGetSettings ()

Get Settings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiGetSettingsExample
    {
        public void main()
        {

            var apiInstance = new AiApi();

            try
            {
                // Get Settings
                TRPCResponse result = apiInstance.AiGetSettings();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiApi.AiGetSettings: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aigetusagestats"></a>
# **AiGetUsageStats**
> TRPCResponse AiGetUsageStats ()

Get Usage Stats

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiGetUsageStatsExample
    {
        public void main()
        {

            var apiInstance = new AiApi();

            try
            {
                // Get Usage Stats
                TRPCResponse result = apiInstance.AiGetUsageStats();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiApi.AiGetUsageStats: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aiupdatesettings"></a>
# **AiUpdateSettings**
> TRPCResponse AiUpdateSettings (TrpcAiUpdateSettingsBody body)

Update Settings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiUpdateSettingsExample
    {
        public void main()
        {

            var apiInstance = new AiApi();
            var body = new TrpcAiUpdateSettingsBody(); // TrpcAiUpdateSettingsBody | 

            try
            {
                // Update Settings
                TRPCResponse result = apiInstance.AiUpdateSettings(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiApi.AiUpdateSettings: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiUpdateSettingsBody**](TrpcAiUpdateSettingsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
