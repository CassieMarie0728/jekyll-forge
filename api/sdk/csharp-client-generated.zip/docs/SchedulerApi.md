# IO.Swagger.Api.SchedulerApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SchedulerCancel**](SchedulerApi.md#schedulercancel) | **POST** /api/trpc/scheduler.cancel | Cancel
[**SchedulerCancelAll**](SchedulerApi.md#schedulercancelall) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
[**SchedulerList**](SchedulerApi.md#schedulerlist) | **GET** /api/trpc/scheduler.list | List
[**SchedulerListHeartbeatJobs**](SchedulerApi.md#schedulerlistheartbeatjobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**SchedulerMarkFailed**](SchedulerApi.md#schedulermarkfailed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
[**SchedulerMarkPublished**](SchedulerApi.md#schedulermarkpublished) | **POST** /api/trpc/scheduler.markPublished | Mark Published
[**SchedulerReschedule**](SchedulerApi.md#schedulerreschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
[**SchedulerSchedule**](SchedulerApi.md#schedulerschedule) | **POST** /api/trpc/scheduler.schedule | Schedule

<a name="schedulercancel"></a>
# **SchedulerCancel**
> TRPCResponse SchedulerCancel (TrpcSchedulerCancelBody body)

Cancel

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerCancelExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var body = new TrpcSchedulerCancelBody(); // TrpcSchedulerCancelBody | 

            try
            {
                // Cancel
                TRPCResponse result = apiInstance.SchedulerCancel(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerCancel: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelBody**](TrpcSchedulerCancelBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulercancelall"></a>
# **SchedulerCancelAll**
> TRPCResponse SchedulerCancelAll (TrpcSchedulerCancelAllBody body)

Cancel All

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerCancelAllExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var body = new TrpcSchedulerCancelAllBody(); // TrpcSchedulerCancelAllBody | 

            try
            {
                // Cancel All
                TRPCResponse result = apiInstance.SchedulerCancelAll(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerCancelAll: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelAllBody**](TrpcSchedulerCancelAllBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulerlist"></a>
# **SchedulerList**
> TRPCResponse SchedulerList (string input)

List

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerListExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List
                TRPCResponse result = apiInstance.SchedulerList(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulerlistheartbeatjobs"></a>
# **SchedulerListHeartbeatJobs**
> TRPCResponse SchedulerListHeartbeatJobs (string input)

List Heartbeat Jobs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerListHeartbeatJobsExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List Heartbeat Jobs
                TRPCResponse result = apiInstance.SchedulerListHeartbeatJobs(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerListHeartbeatJobs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulermarkfailed"></a>
# **SchedulerMarkFailed**
> TRPCResponse SchedulerMarkFailed (TrpcSchedulerMarkFailedBody body)

Mark Failed

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerMarkFailedExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var body = new TrpcSchedulerMarkFailedBody(); // TrpcSchedulerMarkFailedBody | 

            try
            {
                // Mark Failed
                TRPCResponse result = apiInstance.SchedulerMarkFailed(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerMarkFailed: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkFailedBody**](TrpcSchedulerMarkFailedBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulermarkpublished"></a>
# **SchedulerMarkPublished**
> TRPCResponse SchedulerMarkPublished (TrpcSchedulerMarkPublishedBody body)

Mark Published

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerMarkPublishedExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var body = new TrpcSchedulerMarkPublishedBody(); // TrpcSchedulerMarkPublishedBody | 

            try
            {
                // Mark Published
                TRPCResponse result = apiInstance.SchedulerMarkPublished(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerMarkPublished: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkPublishedBody**](TrpcSchedulerMarkPublishedBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulerreschedule"></a>
# **SchedulerReschedule**
> TRPCResponse SchedulerReschedule (TrpcSchedulerRescheduleBody body)

Reschedule

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerRescheduleExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var body = new TrpcSchedulerRescheduleBody(); // TrpcSchedulerRescheduleBody | 

            try
            {
                // Reschedule
                TRPCResponse result = apiInstance.SchedulerReschedule(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerReschedule: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerRescheduleBody**](TrpcSchedulerRescheduleBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="schedulerschedule"></a>
# **SchedulerSchedule**
> TRPCResponse SchedulerSchedule (TrpcSchedulerScheduleBody body)

Schedule

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SchedulerScheduleExample
    {
        public void main()
        {

            var apiInstance = new SchedulerApi();
            var body = new TrpcSchedulerScheduleBody(); // TrpcSchedulerScheduleBody | 

            try
            {
                // Schedule
                TRPCResponse result = apiInstance.SchedulerSchedule(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SchedulerApi.SchedulerSchedule: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerScheduleBody**](TrpcSchedulerScheduleBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
