# IO.Swagger.Model.TrpcGithubCreateBranchBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcgithubCreateBranchJson**](ApitrpcgithubCreateBranchJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

