# IO.Swagger.Api.PostsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PostsAutosave**](PostsApi.md#postsautosave) | **POST** /api/trpc/posts.autosave | Autosave
[**PostsDelete**](PostsApi.md#postsdelete) | **POST** /api/trpc/posts.delete | Delete
[**PostsGet**](PostsApi.md#postsget) | **GET** /api/trpc/posts.get | Get
[**PostsGetFrontMatterTemplates**](PostsApi.md#postsgetfrontmattertemplates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
[**PostsList**](PostsApi.md#postslist) | **GET** /api/trpc/posts.list | List
[**PostsUpdate**](PostsApi.md#postsupdate) | **POST** /api/trpc/posts.update | Update
[**PostsUpsert**](PostsApi.md#postsupsert) | **POST** /api/trpc/posts.upsert | Upsert

<a name="postsautosave"></a>
# **PostsAutosave**
> TRPCResponse PostsAutosave (TrpcPostsAutosaveBody body)

Autosave

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsAutosaveExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var body = new TrpcPostsAutosaveBody(); // TrpcPostsAutosaveBody | 

            try
            {
                // Autosave
                TRPCResponse result = apiInstance.PostsAutosave(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsAutosave: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsAutosaveBody**](TrpcPostsAutosaveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="postsdelete"></a>
# **PostsDelete**
> TRPCResponse PostsDelete (TrpcPostsDeleteBody body)

Delete

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsDeleteExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var body = new TrpcPostsDeleteBody(); // TrpcPostsDeleteBody | 

            try
            {
                // Delete
                TRPCResponse result = apiInstance.PostsDelete(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsDeleteBody**](TrpcPostsDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="postsget"></a>
# **PostsGet**
> TRPCResponse PostsGet (string input)

Get

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsGetExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get
                TRPCResponse result = apiInstance.PostsGet(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="postsgetfrontmattertemplates"></a>
# **PostsGetFrontMatterTemplates**
> TRPCResponse PostsGetFrontMatterTemplates (string input)

Get Front Matter Templates

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsGetFrontMatterTemplatesExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Front Matter Templates
                TRPCResponse result = apiInstance.PostsGetFrontMatterTemplates(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsGetFrontMatterTemplates: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="postslist"></a>
# **PostsList**
> TRPCResponse PostsList (string input)

List

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsListExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List
                TRPCResponse result = apiInstance.PostsList(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsList: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="postsupdate"></a>
# **PostsUpdate**
> TRPCResponse PostsUpdate (TrpcPostsUpdateBody body)

Update

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsUpdateExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var body = new TrpcPostsUpdateBody(); // TrpcPostsUpdateBody | 

            try
            {
                // Update
                TRPCResponse result = apiInstance.PostsUpdate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpdateBody**](TrpcPostsUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="postsupsert"></a>
# **PostsUpsert**
> TRPCResponse PostsUpsert (TrpcPostsUpsertBody body)

Upsert

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostsUpsertExample
    {
        public void main()
        {

            var apiInstance = new PostsApi();
            var body = new TrpcPostsUpsertBody(); // TrpcPostsUpsertBody | 

            try
            {
                // Upsert
                TRPCResponse result = apiInstance.PostsUpsert(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PostsApi.PostsUpsert: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpsertBody**](TrpcPostsUpsertBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
