# IO.Swagger.Model.ApitrpcabTestingUpdateMetricsJsonMetrics
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Impressions** | **decimal?** |  | [optional] 
**Engagements** | **decimal?** |  | [optional] 
**Clicks** | **decimal?** |  | [optional] 
**Shares** | **decimal?** |  | [optional] 
**Likes** | **decimal?** |  | [optional] 
**Replies** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

