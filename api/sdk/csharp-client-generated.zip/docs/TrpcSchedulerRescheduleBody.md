# IO.Swagger.Model.TrpcSchedulerRescheduleBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcschedulerRescheduleJson**](ApitrpcschedulerRescheduleJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

