# IO.Swagger.Api.SnapshotsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SnapshotsCreate**](SnapshotsApi.md#snapshotscreate) | **POST** /api/trpc/snapshots.create | Create
[**SnapshotsGet**](SnapshotsApi.md#snapshotsget) | **GET** /api/trpc/snapshots.get | Get
[**SnapshotsListByPost**](SnapshotsApi.md#snapshotslistbypost) | **GET** /api/trpc/snapshots.listByPost | List By Post

<a name="snapshotscreate"></a>
# **SnapshotsCreate**
> TRPCResponse SnapshotsCreate (TrpcSnapshotsCreateBody body)

Create

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SnapshotsCreateExample
    {
        public void main()
        {

            var apiInstance = new SnapshotsApi();
            var body = new TrpcSnapshotsCreateBody(); // TrpcSnapshotsCreateBody | 

            try
            {
                // Create
                TRPCResponse result = apiInstance.SnapshotsCreate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SnapshotsApi.SnapshotsCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSnapshotsCreateBody**](TrpcSnapshotsCreateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="snapshotsget"></a>
# **SnapshotsGet**
> TRPCResponse SnapshotsGet (string input)

Get

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SnapshotsGetExample
    {
        public void main()
        {

            var apiInstance = new SnapshotsApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get
                TRPCResponse result = apiInstance.SnapshotsGet(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SnapshotsApi.SnapshotsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="snapshotslistbypost"></a>
# **SnapshotsListByPost**
> TRPCResponse SnapshotsListByPost (string input)

List By Post

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SnapshotsListByPostExample
    {
        public void main()
        {

            var apiInstance = new SnapshotsApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List By Post
                TRPCResponse result = apiInstance.SnapshotsListByPost(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SnapshotsApi.SnapshotsListByPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
