# IO.Swagger.Model.ApitrpcassetsUpdateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**Name** | **string** |  | [optional] 
**Path** | **string** |  | [optional] 
**Alt** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

