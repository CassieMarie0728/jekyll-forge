# IO.Swagger.Model.TrpcNotificationsUnregisterDeviceBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcnotificationsUnregisterDeviceJson**](ApitrpcnotificationsUnregisterDeviceJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

