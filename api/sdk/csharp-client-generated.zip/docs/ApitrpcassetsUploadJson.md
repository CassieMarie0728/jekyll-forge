# IO.Swagger.Model.ApitrpcassetsUploadJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **decimal?** |  | 
**Name** | **string** |  | 
**Path** | **string** |  | 
**Base64Content** | **string** |  | 
**MimeType** | **string** |  | 
**Size** | **decimal?** |  | 
**Width** | **decimal?** |  | [optional] 
**Height** | **decimal?** |  | [optional] 
**Optimize** | **bool?** |  | 
**MaxWidth** | **decimal?** |  | [optional] 
**OutputFormat** | **string** |  | [optional] 
**Quality** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

