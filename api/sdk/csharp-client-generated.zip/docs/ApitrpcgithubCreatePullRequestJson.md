# IO.Swagger.Model.ApitrpcgithubCreatePullRequestJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | 
**Repo** | **string** |  | 
**Title** | **string** |  | 
**Head** | **string** |  | 
**_Base** | **string** |  | 
**Body** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

