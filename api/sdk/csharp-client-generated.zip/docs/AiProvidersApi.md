# IO.Swagger.Api.AiProvidersApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AiProvidersActivate**](AiProvidersApi.md#aiprovidersactivate) | **POST** /api/trpc/aiProviders.activate | Activate
[**AiProvidersGetSettings**](AiProvidersApi.md#aiprovidersgetsettings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
[**AiProvidersRemove**](AiProvidersApi.md#aiprovidersremove) | **POST** /api/trpc/aiProviders.remove | Remove
[**AiProvidersSave**](AiProvidersApi.md#aiproviderssave) | **POST** /api/trpc/aiProviders.save | Save
[**AiProvidersTest**](AiProvidersApi.md#aiproviderstest) | **POST** /api/trpc/aiProviders.test | Test

<a name="aiprovidersactivate"></a>
# **AiProvidersActivate**
> TRPCResponse AiProvidersActivate (TrpcAiProvidersActivateBody body)

Activate

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiProvidersActivateExample
    {
        public void main()
        {

            var apiInstance = new AiProvidersApi();
            var body = new TrpcAiProvidersActivateBody(); // TrpcAiProvidersActivateBody | 

            try
            {
                // Activate
                TRPCResponse result = apiInstance.AiProvidersActivate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiProvidersApi.AiProvidersActivate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersActivateBody**](TrpcAiProvidersActivateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aiprovidersgetsettings"></a>
# **AiProvidersGetSettings**
> TRPCResponse AiProvidersGetSettings ()

Get Settings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiProvidersGetSettingsExample
    {
        public void main()
        {

            var apiInstance = new AiProvidersApi();

            try
            {
                // Get Settings
                TRPCResponse result = apiInstance.AiProvidersGetSettings();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiProvidersApi.AiProvidersGetSettings: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aiprovidersremove"></a>
# **AiProvidersRemove**
> TRPCResponse AiProvidersRemove (TrpcAiProvidersRemoveBody body)

Remove

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiProvidersRemoveExample
    {
        public void main()
        {

            var apiInstance = new AiProvidersApi();
            var body = new TrpcAiProvidersRemoveBody(); // TrpcAiProvidersRemoveBody | 

            try
            {
                // Remove
                TRPCResponse result = apiInstance.AiProvidersRemove(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiProvidersApi.AiProvidersRemove: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersRemoveBody**](TrpcAiProvidersRemoveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aiproviderssave"></a>
# **AiProvidersSave**
> TRPCResponse AiProvidersSave (TrpcAiProvidersSaveBody body)

Save

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiProvidersSaveExample
    {
        public void main()
        {

            var apiInstance = new AiProvidersApi();
            var body = new TrpcAiProvidersSaveBody(); // TrpcAiProvidersSaveBody | 

            try
            {
                // Save
                TRPCResponse result = apiInstance.AiProvidersSave(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiProvidersApi.AiProvidersSave: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersSaveBody**](TrpcAiProvidersSaveBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="aiproviderstest"></a>
# **AiProvidersTest**
> TRPCResponse AiProvidersTest (TrpcAiProvidersTestBody body)

Test

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AiProvidersTestExample
    {
        public void main()
        {

            var apiInstance = new AiProvidersApi();
            var body = new TrpcAiProvidersTestBody(); // TrpcAiProvidersTestBody | 

            try
            {
                // Test
                TRPCResponse result = apiInstance.AiProvidersTest(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AiProvidersApi.AiProvidersTest: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersTestBody**](TrpcAiProvidersTestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
