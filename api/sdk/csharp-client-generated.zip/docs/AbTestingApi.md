# IO.Swagger.Api.AbTestingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AbTestingApplyWinner**](AbTestingApi.md#abtestingapplywinner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
[**AbTestingCompleteTest**](AbTestingApi.md#abtestingcompletetest) | **POST** /api/trpc/abTesting.completeTest | Complete Test
[**AbTestingGenerateVariations**](AbTestingApi.md#abtestinggeneratevariations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
[**AbTestingGetResults**](AbTestingApi.md#abtestinggetresults) | **GET** /api/trpc/abTesting.getResults | Get Results
[**AbTestingGetVariations**](AbTestingApi.md#abtestinggetvariations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
[**AbTestingPublishVariation**](AbTestingApi.md#abtestingpublishvariation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
[**AbTestingUpdateMetrics**](AbTestingApi.md#abtestingupdatemetrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics

<a name="abtestingapplywinner"></a>
# **AbTestingApplyWinner**
> TRPCResponse AbTestingApplyWinner (TrpcAbTestingApplyWinnerBody body)

Apply Winner

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingApplyWinnerExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var body = new TrpcAbTestingApplyWinnerBody(); // TrpcAbTestingApplyWinnerBody | 

            try
            {
                // Apply Winner
                TRPCResponse result = apiInstance.AbTestingApplyWinner(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingApplyWinner: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingApplyWinnerBody**](TrpcAbTestingApplyWinnerBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="abtestingcompletetest"></a>
# **AbTestingCompleteTest**
> TRPCResponse AbTestingCompleteTest (TrpcAbTestingCompleteTestBody body)

Complete Test

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingCompleteTestExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var body = new TrpcAbTestingCompleteTestBody(); // TrpcAbTestingCompleteTestBody | 

            try
            {
                // Complete Test
                TRPCResponse result = apiInstance.AbTestingCompleteTest(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingCompleteTest: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingCompleteTestBody**](TrpcAbTestingCompleteTestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="abtestinggeneratevariations"></a>
# **AbTestingGenerateVariations**
> TRPCResponse AbTestingGenerateVariations (TrpcAbTestingGenerateVariationsBody body)

Generate Variations

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingGenerateVariationsExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var body = new TrpcAbTestingGenerateVariationsBody(); // TrpcAbTestingGenerateVariationsBody | 

            try
            {
                // Generate Variations
                TRPCResponse result = apiInstance.AbTestingGenerateVariations(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingGenerateVariations: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingGenerateVariationsBody**](TrpcAbTestingGenerateVariationsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="abtestinggetresults"></a>
# **AbTestingGetResults**
> TRPCResponse AbTestingGetResults (string input)

Get Results

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingGetResultsExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Results
                TRPCResponse result = apiInstance.AbTestingGetResults(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingGetResults: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="abtestinggetvariations"></a>
# **AbTestingGetVariations**
> TRPCResponse AbTestingGetVariations (string input)

Get Variations

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingGetVariationsExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Variations
                TRPCResponse result = apiInstance.AbTestingGetVariations(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingGetVariations: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="abtestingpublishvariation"></a>
# **AbTestingPublishVariation**
> TRPCResponse AbTestingPublishVariation (TrpcAbTestingPublishVariationBody body)

Publish Variation

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingPublishVariationExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var body = new TrpcAbTestingPublishVariationBody(); // TrpcAbTestingPublishVariationBody | 

            try
            {
                // Publish Variation
                TRPCResponse result = apiInstance.AbTestingPublishVariation(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingPublishVariation: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingPublishVariationBody**](TrpcAbTestingPublishVariationBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="abtestingupdatemetrics"></a>
# **AbTestingUpdateMetrics**
> TRPCResponse AbTestingUpdateMetrics (TrpcAbTestingUpdateMetricsBody body)

Update Metrics

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AbTestingUpdateMetricsExample
    {
        public void main()
        {

            var apiInstance = new AbTestingApi();
            var body = new TrpcAbTestingUpdateMetricsBody(); // TrpcAbTestingUpdateMetricsBody | 

            try
            {
                // Update Metrics
                TRPCResponse result = apiInstance.AbTestingUpdateMetrics(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AbTestingApi.AbTestingUpdateMetrics: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingUpdateMetricsBody**](TrpcAbTestingUpdateMetricsBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
