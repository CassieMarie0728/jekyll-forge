# IO.Swagger.Api.RepurposingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**RepurposingDelete**](RepurposingApi.md#repurposingdelete) | **POST** /api/trpc/repurposing.delete | Delete
[**RepurposingGenerate**](RepurposingApi.md#repurposinggenerate) | **POST** /api/trpc/repurposing.generate | Generate
[**RepurposingGetById**](RepurposingApi.md#repurposinggetbyid) | **GET** /api/trpc/repurposing.getById | Get By Id
[**RepurposingGetByPost**](RepurposingApi.md#repurposinggetbypost) | **GET** /api/trpc/repurposing.getByPost | Get By Post
[**RepurposingRegenerate**](RepurposingApi.md#repurposingregenerate) | **POST** /api/trpc/repurposing.regenerate | Regenerate
[**RepurposingUpdate**](RepurposingApi.md#repurposingupdate) | **POST** /api/trpc/repurposing.update | Update

<a name="repurposingdelete"></a>
# **RepurposingDelete**
> TRPCResponse RepurposingDelete (TrpcRepurposingDeleteBody body)

Delete

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RepurposingDeleteExample
    {
        public void main()
        {

            var apiInstance = new RepurposingApi();
            var body = new TrpcRepurposingDeleteBody(); // TrpcRepurposingDeleteBody | 

            try
            {
                // Delete
                TRPCResponse result = apiInstance.RepurposingDelete(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RepurposingApi.RepurposingDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingDeleteBody**](TrpcRepurposingDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="repurposinggenerate"></a>
# **RepurposingGenerate**
> TRPCResponse RepurposingGenerate (TrpcRepurposingGenerateBody body)

Generate

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RepurposingGenerateExample
    {
        public void main()
        {

            var apiInstance = new RepurposingApi();
            var body = new TrpcRepurposingGenerateBody(); // TrpcRepurposingGenerateBody | 

            try
            {
                // Generate
                TRPCResponse result = apiInstance.RepurposingGenerate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RepurposingApi.RepurposingGenerate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingGenerateBody**](TrpcRepurposingGenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="repurposinggetbyid"></a>
# **RepurposingGetById**
> TRPCResponse RepurposingGetById (string input)

Get By Id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RepurposingGetByIdExample
    {
        public void main()
        {

            var apiInstance = new RepurposingApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get By Id
                TRPCResponse result = apiInstance.RepurposingGetById(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RepurposingApi.RepurposingGetById: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="repurposinggetbypost"></a>
# **RepurposingGetByPost**
> TRPCResponse RepurposingGetByPost (string input)

Get By Post

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RepurposingGetByPostExample
    {
        public void main()
        {

            var apiInstance = new RepurposingApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get By Post
                TRPCResponse result = apiInstance.RepurposingGetByPost(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RepurposingApi.RepurposingGetByPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="repurposingregenerate"></a>
# **RepurposingRegenerate**
> TRPCResponse RepurposingRegenerate (TrpcRepurposingRegenerateBody body)

Regenerate

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RepurposingRegenerateExample
    {
        public void main()
        {

            var apiInstance = new RepurposingApi();
            var body = new TrpcRepurposingRegenerateBody(); // TrpcRepurposingRegenerateBody | 

            try
            {
                // Regenerate
                TRPCResponse result = apiInstance.RepurposingRegenerate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RepurposingApi.RepurposingRegenerate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingRegenerateBody**](TrpcRepurposingRegenerateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="repurposingupdate"></a>
# **RepurposingUpdate**
> TRPCResponse RepurposingUpdate (TrpcRepurposingUpdateBody body)

Update

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RepurposingUpdateExample
    {
        public void main()
        {

            var apiInstance = new RepurposingApi();
            var body = new TrpcRepurposingUpdateBody(); // TrpcRepurposingUpdateBody | 

            try
            {
                // Update
                TRPCResponse result = apiInstance.RepurposingUpdate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RepurposingApi.RepurposingUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingUpdateBody**](TrpcRepurposingUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
