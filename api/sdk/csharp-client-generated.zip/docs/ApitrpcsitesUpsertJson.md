# IO.Swagger.Model.ApitrpcsitesUpsertJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | 
**Repo** | **string** |  | 
**DefaultBranch** | **string** |  | [optional] 
**SelectedBranch** | **string** |  | [optional] 
**RootPath** | **string** |  | [optional] 
**IsJekyll** | **bool?** |  | [optional] 
**IsFavorite** | **bool?** |  | [optional] 
**Timezone** | **string** |  | [optional] 
**DefaultLayout** | **string** |  | [optional] 
**DefaultAssetPath** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

