# IO.Swagger.Model.ApitrpcblocksCreateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | 
**Category** | **string** |  | [optional] 
**Content** | **string** |  | 
**ContentType** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

