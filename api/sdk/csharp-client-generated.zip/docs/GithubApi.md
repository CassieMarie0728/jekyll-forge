# IO.Swagger.Api.GithubApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GithubCheckPluginCompatibility**](GithubApi.md#githubcheckplugincompatibility) | **GET** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
[**GithubCommitFile**](GithubApi.md#githubcommitfile) | **POST** /api/trpc/github.commitFile | Commit File
[**GithubConnect**](GithubApi.md#githubconnect) | **POST** /api/trpc/github.connect | Connect
[**GithubCreateBranch**](GithubApi.md#githubcreatebranch) | **POST** /api/trpc/github.createBranch | Create Branch
[**GithubCreatePullRequest**](GithubApi.md#githubcreatepullrequest) | **POST** /api/trpc/github.createPullRequest | Create Pull Request
[**GithubDeleteFile**](GithubApi.md#githubdeletefile) | **POST** /api/trpc/github.deleteFile | Delete File
[**GithubDetectJekyll**](GithubApi.md#githubdetectjekyll) | **GET** /api/trpc/github.detectJekyll | Detect Jekyll
[**GithubDisconnect**](GithubApi.md#githubdisconnect) | **POST** /api/trpc/github.disconnect | Disconnect
[**GithubGenerateActionsWorkflow**](GithubApi.md#githubgenerateactionsworkflow) | **POST** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
[**GithubGetFile**](GithubApi.md#githubgetfile) | **GET** /api/trpc/github.getFile | Get File
[**GithubGetJekyllConfig**](GithubApi.md#githubgetjekyllconfig) | **GET** /api/trpc/github.getJekyllConfig | Get Jekyll Config
[**GithubGetPagesStatus**](GithubApi.md#githubgetpagesstatus) | **GET** /api/trpc/github.getPagesStatus | Get Pages Status
[**GithubGetRateLimit**](GithubApi.md#githubgetratelimit) | **GET** /api/trpc/github.getRateLimit | Get Rate Limit
[**GithubInventory**](GithubApi.md#githubinventory) | **GET** /api/trpc/github.inventory | Inventory
[**GithubListBranches**](GithubApi.md#githublistbranches) | **GET** /api/trpc/github.listBranches | List Branches
[**GithubListFiles**](GithubApi.md#githublistfiles) | **GET** /api/trpc/github.listFiles | List Files
[**GithubListRepos**](GithubApi.md#githublistrepos) | **GET** /api/trpc/github.listRepos | List Repos
[**GithubRepositories**](GithubApi.md#githubrepositories) | **GET** /api/trpc/github.repositories | Repositories
[**GithubReviewFile**](GithubApi.md#githubreviewfile) | **GET** /api/trpc/github.reviewFile | Review File
[**GithubStatus**](GithubApi.md#githubstatus) | **GET** /api/trpc/github.status | Status
[**GithubUpdateJekyllConfig**](GithubApi.md#githubupdatejekyllconfig) | **POST** /api/trpc/github.updateJekyllConfig | Update Jekyll Config

<a name="githubcheckplugincompatibility"></a>
# **GithubCheckPluginCompatibility**
> TRPCResponse GithubCheckPluginCompatibility (string input)

Check Plugin Compatibility

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubCheckPluginCompatibilityExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Check Plugin Compatibility
                TRPCResponse result = apiInstance.GithubCheckPluginCompatibility(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubCheckPluginCompatibility: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubcommitfile"></a>
# **GithubCommitFile**
> TRPCResponse GithubCommitFile (TrpcGithubCommitFileBody body)

Commit File

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubCommitFileExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubCommitFileBody(); // TrpcGithubCommitFileBody | 

            try
            {
                // Commit File
                TRPCResponse result = apiInstance.GithubCommitFile(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubCommitFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCommitFileBody**](TrpcGithubCommitFileBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubconnect"></a>
# **GithubConnect**
> TRPCResponse GithubConnect (TrpcGithubConnectBody body)

Connect

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubConnectExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubConnectBody(); // TrpcGithubConnectBody | 

            try
            {
                // Connect
                TRPCResponse result = apiInstance.GithubConnect(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubConnect: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubConnectBody**](TrpcGithubConnectBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubcreatebranch"></a>
# **GithubCreateBranch**
> TRPCResponse GithubCreateBranch (TrpcGithubCreateBranchBody body)

Create Branch

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubCreateBranchExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubCreateBranchBody(); // TrpcGithubCreateBranchBody | 

            try
            {
                // Create Branch
                TRPCResponse result = apiInstance.GithubCreateBranch(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubCreateBranch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreateBranchBody**](TrpcGithubCreateBranchBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubcreatepullrequest"></a>
# **GithubCreatePullRequest**
> TRPCResponse GithubCreatePullRequest (TrpcGithubCreatePullRequestBody body)

Create Pull Request

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubCreatePullRequestExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubCreatePullRequestBody(); // TrpcGithubCreatePullRequestBody | 

            try
            {
                // Create Pull Request
                TRPCResponse result = apiInstance.GithubCreatePullRequest(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubCreatePullRequest: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreatePullRequestBody**](TrpcGithubCreatePullRequestBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubdeletefile"></a>
# **GithubDeleteFile**
> TRPCResponse GithubDeleteFile (TrpcGithubDeleteFileBody body)

Delete File

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubDeleteFileExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubDeleteFileBody(); // TrpcGithubDeleteFileBody | 

            try
            {
                // Delete File
                TRPCResponse result = apiInstance.GithubDeleteFile(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubDeleteFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDeleteFileBody**](TrpcGithubDeleteFileBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubdetectjekyll"></a>
# **GithubDetectJekyll**
> TRPCResponse GithubDetectJekyll (string input)

Detect Jekyll

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubDetectJekyllExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Detect Jekyll
                TRPCResponse result = apiInstance.GithubDetectJekyll(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubDetectJekyll: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubdisconnect"></a>
# **GithubDisconnect**
> TRPCResponse GithubDisconnect (TrpcGithubDisconnectBody body = null)

Disconnect

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubDisconnectExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubDisconnectBody(); // TrpcGithubDisconnectBody |  (optional) 

            try
            {
                // Disconnect
                TRPCResponse result = apiInstance.GithubDisconnect(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubDisconnect: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDisconnectBody**](TrpcGithubDisconnectBody.md)|  | [optional] 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubgenerateactionsworkflow"></a>
# **GithubGenerateActionsWorkflow**
> TRPCResponse GithubGenerateActionsWorkflow (TrpcGithubGenerateActionsWorkflowBody body)

Generate Actions Workflow

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubGenerateActionsWorkflowExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubGenerateActionsWorkflowBody(); // TrpcGithubGenerateActionsWorkflowBody | 

            try
            {
                // Generate Actions Workflow
                TRPCResponse result = apiInstance.GithubGenerateActionsWorkflow(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubGenerateActionsWorkflow: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubGenerateActionsWorkflowBody**](TrpcGithubGenerateActionsWorkflowBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubgetfile"></a>
# **GithubGetFile**
> TRPCResponse GithubGetFile (string input)

Get File

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubGetFileExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get File
                TRPCResponse result = apiInstance.GithubGetFile(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubGetFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubgetjekyllconfig"></a>
# **GithubGetJekyllConfig**
> TRPCResponse GithubGetJekyllConfig (string input)

Get Jekyll Config

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubGetJekyllConfigExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Jekyll Config
                TRPCResponse result = apiInstance.GithubGetJekyllConfig(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubGetJekyllConfig: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubgetpagesstatus"></a>
# **GithubGetPagesStatus**
> TRPCResponse GithubGetPagesStatus (string input)

Get Pages Status

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubGetPagesStatusExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Get Pages Status
                TRPCResponse result = apiInstance.GithubGetPagesStatus(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubGetPagesStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubgetratelimit"></a>
# **GithubGetRateLimit**
> TRPCResponse GithubGetRateLimit ()

Get Rate Limit

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubGetRateLimitExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();

            try
            {
                // Get Rate Limit
                TRPCResponse result = apiInstance.GithubGetRateLimit();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubGetRateLimit: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubinventory"></a>
# **GithubInventory**
> TRPCResponse GithubInventory (string input)

Inventory

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubInventoryExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Inventory
                TRPCResponse result = apiInstance.GithubInventory(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubInventory: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githublistbranches"></a>
# **GithubListBranches**
> TRPCResponse GithubListBranches (string input)

List Branches

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubListBranchesExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List Branches
                TRPCResponse result = apiInstance.GithubListBranches(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubListBranches: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githublistfiles"></a>
# **GithubListFiles**
> TRPCResponse GithubListFiles (string input)

List Files

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubListFilesExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List Files
                TRPCResponse result = apiInstance.GithubListFiles(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubListFiles: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githublistrepos"></a>
# **GithubListRepos**
> TRPCResponse GithubListRepos (string input)

List Repos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubListReposExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // List Repos
                TRPCResponse result = apiInstance.GithubListRepos(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubListRepos: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubrepositories"></a>
# **GithubRepositories**
> TRPCResponse GithubRepositories (string input)

Repositories

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubRepositoriesExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Repositories
                TRPCResponse result = apiInstance.GithubRepositories(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubRepositories: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubreviewfile"></a>
# **GithubReviewFile**
> TRPCResponse GithubReviewFile (string input)

Review File

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubReviewFileExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var input = input_example;  // string | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}

            try
            {
                // Review File
                TRPCResponse result = apiInstance.GithubReviewFile(input);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubReviewFile: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **string**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubstatus"></a>
# **GithubStatus**
> TRPCResponse GithubStatus ()

Status

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubStatusExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();

            try
            {
                // Status
                TRPCResponse result = apiInstance.GithubStatus();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="githubupdatejekyllconfig"></a>
# **GithubUpdateJekyllConfig**
> TRPCResponse GithubUpdateJekyllConfig (TrpcGithubUpdateJekyllConfigBody body)

Update Jekyll Config

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GithubUpdateJekyllConfigExample
    {
        public void main()
        {

            var apiInstance = new GithubApi();
            var body = new TrpcGithubUpdateJekyllConfigBody(); // TrpcGithubUpdateJekyllConfigBody | 

            try
            {
                // Update Jekyll Config
                TRPCResponse result = apiInstance.GithubUpdateJekyllConfig(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GithubApi.GithubUpdateJekyllConfig: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubUpdateJekyllConfigBody**](TrpcGithubUpdateJekyllConfigBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
