# IO.Swagger.Model.ApitrpcsnapshotsCreateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **decimal?** |  | 
**PostId** | **decimal?** |  | [optional] 
**PostPath** | **string** |  | [optional] 
**Label** | **string** |  | 
**Reason** | **Object** |  | 
**Markdown** | **string** |  | [optional] 
**FrontMatter** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

