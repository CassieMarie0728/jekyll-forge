# IO.Swagger.Model.TrpcSitesUpdateBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcsitesUpdateJson**](ApitrpcsitesUpdateJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

