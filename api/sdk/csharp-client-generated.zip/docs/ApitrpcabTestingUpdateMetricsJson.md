# IO.Swagger.Model.ApitrpcabTestingUpdateMetricsJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **decimal?** |  | 
**VariationIndex** | **decimal?** |  | 
**Platform** | **string** |  | 
**Metrics** | [**ApitrpcabTestingUpdateMetricsJsonMetrics**](ApitrpcabTestingUpdateMetricsJsonMetrics.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

