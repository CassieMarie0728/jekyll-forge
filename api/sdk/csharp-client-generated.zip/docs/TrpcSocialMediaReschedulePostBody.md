# IO.Swagger.Model.TrpcSocialMediaReschedulePostBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcsocialMediaReschedulePostJson**](ApitrpcsocialMediaReschedulePostJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

