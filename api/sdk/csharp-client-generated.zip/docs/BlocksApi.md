# IO.Swagger.Api.BlocksApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BlocksCreate**](BlocksApi.md#blockscreate) | **POST** /api/trpc/blocks.create | Create
[**BlocksDelete**](BlocksApi.md#blocksdelete) | **POST** /api/trpc/blocks.delete | Delete
[**BlocksList**](BlocksApi.md#blockslist) | **GET** /api/trpc/blocks.list | List
[**BlocksUpdate**](BlocksApi.md#blocksupdate) | **POST** /api/trpc/blocks.update | Update

<a name="blockscreate"></a>
# **BlocksCreate**
> TRPCResponse BlocksCreate (TrpcBlocksCreateBody body)

Create

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BlocksCreateExample
    {
        public void main()
        {

            var apiInstance = new BlocksApi();
            var body = new TrpcBlocksCreateBody(); // TrpcBlocksCreateBody | 

            try
            {
                // Create
                TRPCResponse result = apiInstance.BlocksCreate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BlocksApi.BlocksCreate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksCreateBody**](TrpcBlocksCreateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="blocksdelete"></a>
# **BlocksDelete**
> TRPCResponse BlocksDelete (TrpcBlocksDeleteBody body)

Delete

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BlocksDeleteExample
    {
        public void main()
        {

            var apiInstance = new BlocksApi();
            var body = new TrpcBlocksDeleteBody(); // TrpcBlocksDeleteBody | 

            try
            {
                // Delete
                TRPCResponse result = apiInstance.BlocksDelete(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BlocksApi.BlocksDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksDeleteBody**](TrpcBlocksDeleteBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="blockslist"></a>
# **BlocksList**
> TRPCResponse BlocksList ()

List

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BlocksListExample
    {
        public void main()
        {

            var apiInstance = new BlocksApi();

            try
            {
                // List
                TRPCResponse result = apiInstance.BlocksList();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BlocksApi.BlocksList: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="blocksupdate"></a>
# **BlocksUpdate**
> TRPCResponse BlocksUpdate (TrpcBlocksUpdateBody body)

Update

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BlocksUpdateExample
    {
        public void main()
        {

            var apiInstance = new BlocksApi();
            var body = new TrpcBlocksUpdateBody(); // TrpcBlocksUpdateBody | 

            try
            {
                // Update
                TRPCResponse result = apiInstance.BlocksUpdate(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BlocksApi.BlocksUpdate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksUpdateBody**](TrpcBlocksUpdateBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
