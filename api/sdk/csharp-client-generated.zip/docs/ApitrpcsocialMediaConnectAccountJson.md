# IO.Swagger.Model.ApitrpcsocialMediaConnectAccountJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Platform** | **string** |  | 
**AccessToken** | **string** |  | 
**RefreshToken** | **string** |  | [optional] 
**ExpiresAt** | **Object** |  | [optional] 
**AccountId** | **string** |  | 
**Username** | **string** |  | [optional] 
**DisplayName** | **string** |  | [optional] 
**ProfileImageUrl** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

