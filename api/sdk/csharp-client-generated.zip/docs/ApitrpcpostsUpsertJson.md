# IO.Swagger.Model.ApitrpcpostsUpsertJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SiteId** | **decimal?** |  | 
**Path** | **string** |  | 
**Filename** | **string** |  | [optional] 
**Slug** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Status** | **Object** |  | [optional] 
**FrontMatter** | **Object** |  | [optional] 
**Markdown** | **string** |  | [optional] 
**Sha** | **string** |  | [optional] 
**ScheduledAt** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

