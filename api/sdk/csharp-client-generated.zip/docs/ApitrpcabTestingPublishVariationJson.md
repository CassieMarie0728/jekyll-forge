# IO.Swagger.Model.ApitrpcabTestingPublishVariationJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PostId** | **decimal?** |  | 
**VariationIndex** | **decimal?** |  | 
**Platforms** | **List&lt;string&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

