# IO.Swagger.Model.ApitrpcsocialMediaPublishContentJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RepurposedContentId** | **decimal?** |  | 
**AccountId** | **decimal?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

