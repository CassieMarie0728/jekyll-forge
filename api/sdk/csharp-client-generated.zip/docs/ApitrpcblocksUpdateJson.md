# IO.Swagger.Model.ApitrpcblocksUpdateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**Name** | **string** |  | [optional] 
**Category** | **string** |  | [optional] 
**Content** | **string** |  | [optional] 
**ContentType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

