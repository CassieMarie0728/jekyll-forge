# IO.Swagger.Model.ApitrpcsocialMediaSchedulePostJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RepurposedContentId** | **decimal?** |  | 
**SocialMediaAccountId** | **decimal?** |  | 
**ScheduledAt** | **Object** |  | 
**Timezone** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

