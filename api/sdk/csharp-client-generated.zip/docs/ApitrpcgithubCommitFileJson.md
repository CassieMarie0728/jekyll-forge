# IO.Swagger.Model.ApitrpcgithubCommitFileJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | 
**Repo** | **string** |  | 
**Path** | **string** |  | 
**Branch** | **string** |  | 
**Content** | **string** |  | 
**Message** | **string** |  | 
**Sha** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

