# IO.Swagger.Model.ApitrpcsitesUpdateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **decimal?** |  | 
**IsFavorite** | **bool?** |  | [optional] 
**SelectedBranch** | **string** |  | [optional] 
**RootPath** | **string** |  | [optional] 
**Timezone** | **string** |  | [optional] 
**DefaultLayout** | **string** |  | [optional] 
**DefaultAssetPath** | **string** |  | [optional] 
**AiVoiceProfile** | **string** |  | [optional] 
**Settings** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

