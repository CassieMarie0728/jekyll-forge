# IO.Swagger.Model.TrpcSocialMediaSyncAnalyticsBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcsocialMediaSyncAnalyticsJson**](ApitrpcsocialMediaSyncAnalyticsJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

