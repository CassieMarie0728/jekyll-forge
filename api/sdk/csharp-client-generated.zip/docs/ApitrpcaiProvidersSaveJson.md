# IO.Swagger.Model.ApitrpcaiProvidersSaveJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Provider** | **Object** |  | 
**Model** | **string** |  | 
**ApiKey** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

