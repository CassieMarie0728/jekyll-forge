# IO.Swagger.Model.TrpcSchedulerMarkFailedBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**ApitrpcschedulerMarkFailedJson**](ApitrpcschedulerMarkFailedJson.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

