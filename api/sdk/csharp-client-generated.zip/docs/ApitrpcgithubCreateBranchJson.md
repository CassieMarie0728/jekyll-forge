# IO.Swagger.Model.ApitrpcgithubCreateBranchJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Owner** | **string** |  | 
**Repo** | **string** |  | 
**BranchName** | **string** |  | 
**FromBranch** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

