# IO.Swagger.Api.NotificationsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**NotificationsRegisterDevice**](NotificationsApi.md#notificationsregisterdevice) | **POST** /api/trpc/notifications.registerDevice | Register Device
[**NotificationsUnregisterDevice**](NotificationsApi.md#notificationsunregisterdevice) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device

<a name="notificationsregisterdevice"></a>
# **NotificationsRegisterDevice**
> TRPCResponse NotificationsRegisterDevice (TrpcNotificationsRegisterDeviceBody body)

Register Device

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NotificationsRegisterDeviceExample
    {
        public void main()
        {

            var apiInstance = new NotificationsApi();
            var body = new TrpcNotificationsRegisterDeviceBody(); // TrpcNotificationsRegisterDeviceBody | 

            try
            {
                // Register Device
                TRPCResponse result = apiInstance.NotificationsRegisterDevice(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NotificationsApi.NotificationsRegisterDevice: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsRegisterDeviceBody**](TrpcNotificationsRegisterDeviceBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="notificationsunregisterdevice"></a>
# **NotificationsUnregisterDevice**
> TRPCResponse NotificationsUnregisterDevice (TrpcNotificationsUnregisterDeviceBody body)

Unregister Device

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class NotificationsUnregisterDeviceExample
    {
        public void main()
        {

            var apiInstance = new NotificationsApi();
            var body = new TrpcNotificationsUnregisterDeviceBody(); // TrpcNotificationsUnregisterDeviceBody | 

            try
            {
                // Unregister Device
                TRPCResponse result = apiInstance.NotificationsUnregisterDevice(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NotificationsApi.NotificationsUnregisterDevice: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsUnregisterDeviceBody**](TrpcNotificationsUnregisterDeviceBody.md)|  | 

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
