# IO.Swagger.Model.ApitrpcaiProvidersActivateJson
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Provider** | **Object** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

