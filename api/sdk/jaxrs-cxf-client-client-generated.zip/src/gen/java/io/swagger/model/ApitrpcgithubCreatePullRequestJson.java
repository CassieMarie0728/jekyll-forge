package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcgithubCreatePullRequestJson   {
  
  @Schema(required = true, description = "")
  private String owner = null;
  
  @Schema(required = true, description = "")
  private String repo = null;
  
  @Schema(required = true, description = "")
  private String title = null;
  
  @Schema(required = true, description = "")
  private String head = null;
  
  @Schema(required = true, description = "")
  private String base = null;
  
  @Schema(description = "")
  private String body = null;
 /**
   * Get owner
   * @return owner
  **/
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public ApitrpcgithubCreatePullRequestJson owner(String owner) {
    this.owner = owner;
    return this;
  }

 /**
   * Get repo
   * @return repo
  **/
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }

  public void setRepo(String repo) {
    this.repo = repo;
  }

  public ApitrpcgithubCreatePullRequestJson repo(String repo) {
    this.repo = repo;
    return this;
  }

 /**
   * Get title
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ApitrpcgithubCreatePullRequestJson title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Get head
   * @return head
  **/
  @JsonProperty("head")
  public String getHead() {
    return head;
  }

  public void setHead(String head) {
    this.head = head;
  }

  public ApitrpcgithubCreatePullRequestJson head(String head) {
    this.head = head;
    return this;
  }

 /**
   * Get base
   * @return base
  **/
  @JsonProperty("base")
  public String getBase() {
    return base;
  }

  public void setBase(String base) {
    this.base = base;
  }

  public ApitrpcgithubCreatePullRequestJson base(String base) {
    this.base = base;
    return this;
  }

 /**
   * Get body
   * @return body
  **/
  @JsonProperty("body")
  public String getBody() {
    return body;
  }

  public void setBody(String body) {
    this.body = body;
  }

  public ApitrpcgithubCreatePullRequestJson body(String body) {
    this.body = body;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreatePullRequestJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    head: ").append(toIndentedString(head)).append("\n");
    sb.append("    base: ").append(toIndentedString(base)).append("\n");
    sb.append("    body: ").append(toIndentedString(body)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
