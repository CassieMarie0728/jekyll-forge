package io.swagger.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcabTestingGenerateVariationsJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(description = "")
  private BigDecimal count = null;
  
  @Schema(description = "")
  private List<String> tones = null;
  
  @Schema(description = "")
  private List<String> angles = null;
  
  @Schema(required = true, description = "")
  private String headline = null;
  
  @Schema(required = true, description = "")
  private String content = null;
 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcabTestingGenerateVariationsJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get count
   * @return count
  **/
  @JsonProperty("count")
  public BigDecimal getCount() {
    return count;
  }

  public void setCount(BigDecimal count) {
    this.count = count;
  }

  public ApitrpcabTestingGenerateVariationsJson count(BigDecimal count) {
    this.count = count;
    return this;
  }

 /**
   * Get tones
   * @return tones
  **/
  @JsonProperty("tones")
  public List<String> getTones() {
    return tones;
  }

  public void setTones(List<String> tones) {
    this.tones = tones;
  }

  public ApitrpcabTestingGenerateVariationsJson tones(List<String> tones) {
    this.tones = tones;
    return this;
  }

  public ApitrpcabTestingGenerateVariationsJson addTonesItem(String tonesItem) {
    this.tones.add(tonesItem);
    return this;
  }

 /**
   * Get angles
   * @return angles
  **/
  @JsonProperty("angles")
  public List<String> getAngles() {
    return angles;
  }

  public void setAngles(List<String> angles) {
    this.angles = angles;
  }

  public ApitrpcabTestingGenerateVariationsJson angles(List<String> angles) {
    this.angles = angles;
    return this;
  }

  public ApitrpcabTestingGenerateVariationsJson addAnglesItem(String anglesItem) {
    this.angles.add(anglesItem);
    return this;
  }

 /**
   * Get headline
   * @return headline
  **/
  @JsonProperty("headline")
  public String getHeadline() {
    return headline;
  }

  public void setHeadline(String headline) {
    this.headline = headline;
  }

  public ApitrpcabTestingGenerateVariationsJson headline(String headline) {
    this.headline = headline;
    return this;
  }

 /**
   * Get content
   * @return content
  **/
  @JsonProperty("content")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ApitrpcabTestingGenerateVariationsJson content(String content) {
    this.content = content;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingGenerateVariationsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    tones: ").append(toIndentedString(tones)).append("\n");
    sb.append("    angles: ").append(toIndentedString(angles)).append("\n");
    sb.append("    headline: ").append(toIndentedString(headline)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
