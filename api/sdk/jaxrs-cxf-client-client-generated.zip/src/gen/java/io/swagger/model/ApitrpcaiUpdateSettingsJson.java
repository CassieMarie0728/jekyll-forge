package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcaiUpdateSettingsJson   {
  
  @Schema(description = "")
  private Boolean enabled = null;
  
  @Schema(description = "")
  private BigDecimal temperature = null;
  
  @Schema(description = "")
  private BigDecimal maxTokens = null;
  
  @Schema(description = "")
  private String systemPrompt = null;
  
  @Schema(description = "")
  private String brandVoicePrompt = null;
  
  @Schema(description = "")
  private String safetyPrompt = null;
  
  @Schema(description = "")
  private Boolean streaming = null;
  
  @Schema(description = "")
  private String defaultLanguage = null;
  
  @Schema(description = "")
  private String defaultTone = null;
  
  @Schema(description = "")
  private BigDecimal budgetLimitCents = null;
 /**
   * Get enabled
   * @return enabled
  **/
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public ApitrpcaiUpdateSettingsJson enabled(Boolean enabled) {
    this.enabled = enabled;
    return this;
  }

 /**
   * Get temperature
   * @return temperature
  **/
  @JsonProperty("temperature")
  public BigDecimal getTemperature() {
    return temperature;
  }

  public void setTemperature(BigDecimal temperature) {
    this.temperature = temperature;
  }

  public ApitrpcaiUpdateSettingsJson temperature(BigDecimal temperature) {
    this.temperature = temperature;
    return this;
  }

 /**
   * Get maxTokens
   * @return maxTokens
  **/
  @JsonProperty("maxTokens")
  public BigDecimal getMaxTokens() {
    return maxTokens;
  }

  public void setMaxTokens(BigDecimal maxTokens) {
    this.maxTokens = maxTokens;
  }

  public ApitrpcaiUpdateSettingsJson maxTokens(BigDecimal maxTokens) {
    this.maxTokens = maxTokens;
    return this;
  }

 /**
   * Get systemPrompt
   * @return systemPrompt
  **/
  @JsonProperty("systemPrompt")
  public String getSystemPrompt() {
    return systemPrompt;
  }

  public void setSystemPrompt(String systemPrompt) {
    this.systemPrompt = systemPrompt;
  }

  public ApitrpcaiUpdateSettingsJson systemPrompt(String systemPrompt) {
    this.systemPrompt = systemPrompt;
    return this;
  }

 /**
   * Get brandVoicePrompt
   * @return brandVoicePrompt
  **/
  @JsonProperty("brandVoicePrompt")
  public String getBrandVoicePrompt() {
    return brandVoicePrompt;
  }

  public void setBrandVoicePrompt(String brandVoicePrompt) {
    this.brandVoicePrompt = brandVoicePrompt;
  }

  public ApitrpcaiUpdateSettingsJson brandVoicePrompt(String brandVoicePrompt) {
    this.brandVoicePrompt = brandVoicePrompt;
    return this;
  }

 /**
   * Get safetyPrompt
   * @return safetyPrompt
  **/
  @JsonProperty("safetyPrompt")
  public String getSafetyPrompt() {
    return safetyPrompt;
  }

  public void setSafetyPrompt(String safetyPrompt) {
    this.safetyPrompt = safetyPrompt;
  }

  public ApitrpcaiUpdateSettingsJson safetyPrompt(String safetyPrompt) {
    this.safetyPrompt = safetyPrompt;
    return this;
  }

 /**
   * Get streaming
   * @return streaming
  **/
  @JsonProperty("streaming")
  public Boolean isStreaming() {
    return streaming;
  }

  public void setStreaming(Boolean streaming) {
    this.streaming = streaming;
  }

  public ApitrpcaiUpdateSettingsJson streaming(Boolean streaming) {
    this.streaming = streaming;
    return this;
  }

 /**
   * Get defaultLanguage
   * @return defaultLanguage
  **/
  @JsonProperty("defaultLanguage")
  public String getDefaultLanguage() {
    return defaultLanguage;
  }

  public void setDefaultLanguage(String defaultLanguage) {
    this.defaultLanguage = defaultLanguage;
  }

  public ApitrpcaiUpdateSettingsJson defaultLanguage(String defaultLanguage) {
    this.defaultLanguage = defaultLanguage;
    return this;
  }

 /**
   * Get defaultTone
   * @return defaultTone
  **/
  @JsonProperty("defaultTone")
  public String getDefaultTone() {
    return defaultTone;
  }

  public void setDefaultTone(String defaultTone) {
    this.defaultTone = defaultTone;
  }

  public ApitrpcaiUpdateSettingsJson defaultTone(String defaultTone) {
    this.defaultTone = defaultTone;
    return this;
  }

 /**
   * Get budgetLimitCents
   * @return budgetLimitCents
  **/
  @JsonProperty("budgetLimitCents")
  public BigDecimal getBudgetLimitCents() {
    return budgetLimitCents;
  }

  public void setBudgetLimitCents(BigDecimal budgetLimitCents) {
    this.budgetLimitCents = budgetLimitCents;
  }

  public ApitrpcaiUpdateSettingsJson budgetLimitCents(BigDecimal budgetLimitCents) {
    this.budgetLimitCents = budgetLimitCents;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiUpdateSettingsJson {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    temperature: ").append(toIndentedString(temperature)).append("\n");
    sb.append("    maxTokens: ").append(toIndentedString(maxTokens)).append("\n");
    sb.append("    systemPrompt: ").append(toIndentedString(systemPrompt)).append("\n");
    sb.append("    brandVoicePrompt: ").append(toIndentedString(brandVoicePrompt)).append("\n");
    sb.append("    safetyPrompt: ").append(toIndentedString(safetyPrompt)).append("\n");
    sb.append("    streaming: ").append(toIndentedString(streaming)).append("\n");
    sb.append("    defaultLanguage: ").append(toIndentedString(defaultLanguage)).append("\n");
    sb.append("    defaultTone: ").append(toIndentedString(defaultTone)).append("\n");
    sb.append("    budgetLimitCents: ").append(toIndentedString(budgetLimitCents)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
