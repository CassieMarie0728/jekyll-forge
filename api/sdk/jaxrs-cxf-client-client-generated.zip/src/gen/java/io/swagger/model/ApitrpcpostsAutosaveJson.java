package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcpostsAutosaveJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal id = null;
  
  @Schema(required = true, description = "")
  private String markdown = null;
  
  @Schema(required = true, description = "")
  private Object frontMatter = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }

  public void setId(BigDecimal id) {
    this.id = id;
  }

  public ApitrpcpostsAutosaveJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

 /**
   * Get markdown
   * @return markdown
  **/
  @JsonProperty("markdown")
  public String getMarkdown() {
    return markdown;
  }

  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  public ApitrpcpostsAutosaveJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

 /**
   * Get frontMatter
   * @return frontMatter
  **/
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }

  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  public ApitrpcpostsAutosaveJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsAutosaveJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
