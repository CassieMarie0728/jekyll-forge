package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcrepurposingGenerateJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal siteId = null;
  public enum FormatEnum {
    TWITTER("twitter"),
    LINKEDIN("linkedin"),
    TIKTOK("tiktok"),
    YOUTUBE("youtube"),
    NEWSLETTER("newsletter"),
    EMAIL("email"),
    PODCAST("podcast"),
    SLIDES("slides");

    private String value;

    FormatEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static FormatEnum fromValue(String text) {
      for (FormatEnum b : FormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(required = true, description = "")
  private FormatEnum format = null;
 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcrepurposingGenerateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get siteId
   * @return siteId
  **/
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public ApitrpcrepurposingGenerateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

 /**
   * Get format
   * @return format
  **/
  @JsonProperty("format")
  public String getFormat() {
    if (format == null) {
      return null;
    }
    return format.getValue();
  }

  public void setFormat(FormatEnum format) {
    this.format = format;
  }

  public ApitrpcrepurposingGenerateJson format(FormatEnum format) {
    this.format = format;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingGenerateJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
