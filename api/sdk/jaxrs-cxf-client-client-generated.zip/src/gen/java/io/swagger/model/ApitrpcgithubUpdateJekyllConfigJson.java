package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcgithubUpdateJekyllConfigJson   {
  
  @Schema(required = true, description = "")
  private String owner = null;
  
  @Schema(required = true, description = "")
  private String repo = null;
  
  @Schema(required = true, description = "")
  private String rootPath = null;
  
  @Schema(required = true, description = "")
  private String branch = null;
  
  @Schema(description = "")
  private String commitMessage = null;
 /**
   * Get owner
   * @return owner
  **/
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public ApitrpcgithubUpdateJekyllConfigJson owner(String owner) {
    this.owner = owner;
    return this;
  }

 /**
   * Get repo
   * @return repo
  **/
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }

  public void setRepo(String repo) {
    this.repo = repo;
  }

  public ApitrpcgithubUpdateJekyllConfigJson repo(String repo) {
    this.repo = repo;
    return this;
  }

 /**
   * Get rootPath
   * @return rootPath
  **/
  @JsonProperty("rootPath")
  public String getRootPath() {
    return rootPath;
  }

  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  public ApitrpcgithubUpdateJekyllConfigJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

 /**
   * Get branch
   * @return branch
  **/
  @JsonProperty("branch")
  public String getBranch() {
    return branch;
  }

  public void setBranch(String branch) {
    this.branch = branch;
  }

  public ApitrpcgithubUpdateJekyllConfigJson branch(String branch) {
    this.branch = branch;
    return this;
  }

 /**
   * Get commitMessage
   * @return commitMessage
  **/
  @JsonProperty("commitMessage")
  public String getCommitMessage() {
    return commitMessage;
  }

  public void setCommitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
  }

  public ApitrpcgithubUpdateJekyllConfigJson commitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubUpdateJekyllConfigJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
