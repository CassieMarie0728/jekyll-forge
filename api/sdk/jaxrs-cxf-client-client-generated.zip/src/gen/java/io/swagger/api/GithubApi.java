package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
@Path("/")
public interface GithubApi  {

    /**
     * Check Plugin Compatibility
     *
     */
    @GET
    @Path("/api/trpc/github.checkPluginCompatibility")
    @Produces({ "application/json" })
    @Operation(summary = "Check Plugin Compatibility", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubCheckPluginCompatibility(@QueryParam("input")String input);

    /**
     * Commit File
     *
     */
    @POST
    @Path("/api/trpc/github.commitFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Commit File", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubCommitFile(TrpcGithubCommitFileBody body);

    /**
     * Connect
     *
     */
    @POST
    @Path("/api/trpc/github.connect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubConnect(TrpcGithubConnectBody body);

    /**
     * Create Branch
     *
     */
    @POST
    @Path("/api/trpc/github.createBranch")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Branch", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubCreateBranch(TrpcGithubCreateBranchBody body);

    /**
     * Create Pull Request
     *
     */
    @POST
    @Path("/api/trpc/github.createPullRequest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Pull Request", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubCreatePullRequest(TrpcGithubCreatePullRequestBody body);

    /**
     * Delete File
     *
     */
    @POST
    @Path("/api/trpc/github.deleteFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete File", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubDeleteFile(TrpcGithubDeleteFileBody body);

    /**
     * Detect Jekyll
     *
     */
    @GET
    @Path("/api/trpc/github.detectJekyll")
    @Produces({ "application/json" })
    @Operation(summary = "Detect Jekyll", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubDetectJekyll(@QueryParam("input")String input);

    /**
     * Disconnect
     *
     */
    @POST
    @Path("/api/trpc/github.disconnect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubDisconnect(TrpcGithubDisconnectBody body);

    /**
     * Generate Actions Workflow
     *
     */
    @POST
    @Path("/api/trpc/github.generateActionsWorkflow")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Actions Workflow", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubGenerateActionsWorkflow(TrpcGithubGenerateActionsWorkflowBody body);

    /**
     * Get File
     *
     */
    @GET
    @Path("/api/trpc/github.getFile")
    @Produces({ "application/json" })
    @Operation(summary = "Get File", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubGetFile(@QueryParam("input")String input);

    /**
     * Get Jekyll Config
     *
     */
    @GET
    @Path("/api/trpc/github.getJekyllConfig")
    @Produces({ "application/json" })
    @Operation(summary = "Get Jekyll Config", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubGetJekyllConfig(@QueryParam("input")String input);

    /**
     * Get Pages Status
     *
     */
    @GET
    @Path("/api/trpc/github.getPagesStatus")
    @Produces({ "application/json" })
    @Operation(summary = "Get Pages Status", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubGetPagesStatus(@QueryParam("input")String input);

    /**
     * Get Rate Limit
     *
     */
    @GET
    @Path("/api/trpc/github.getRateLimit")
    @Produces({ "application/json" })
    @Operation(summary = "Get Rate Limit", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubGetRateLimit();

    /**
     * Inventory
     *
     */
    @GET
    @Path("/api/trpc/github.inventory")
    @Produces({ "application/json" })
    @Operation(summary = "Inventory", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubInventory(@QueryParam("input")String input);

    /**
     * List Branches
     *
     */
    @GET
    @Path("/api/trpc/github.listBranches")
    @Produces({ "application/json" })
    @Operation(summary = "List Branches", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubListBranches(@QueryParam("input")String input);

    /**
     * List Files
     *
     */
    @GET
    @Path("/api/trpc/github.listFiles")
    @Produces({ "application/json" })
    @Operation(summary = "List Files", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubListFiles(@QueryParam("input")String input);

    /**
     * List Repos
     *
     */
    @GET
    @Path("/api/trpc/github.listRepos")
    @Produces({ "application/json" })
    @Operation(summary = "List Repos", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubListRepos(@QueryParam("input")String input);

    /**
     * Repositories
     *
     */
    @GET
    @Path("/api/trpc/github.repositories")
    @Produces({ "application/json" })
    @Operation(summary = "Repositories", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubRepositories(@QueryParam("input")String input);

    /**
     * Review File
     *
     */
    @GET
    @Path("/api/trpc/github.reviewFile")
    @Produces({ "application/json" })
    @Operation(summary = "Review File", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubReviewFile(@QueryParam("input")String input);

    /**
     * Status
     *
     */
    @GET
    @Path("/api/trpc/github.status")
    @Produces({ "application/json" })
    @Operation(summary = "Status", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubStatus();

    /**
     * Update Jekyll Config
     *
     */
    @POST
    @Path("/api/trpc/github.updateJekyllConfig")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Jekyll Config", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse githubUpdateJekyllConfig(TrpcGithubUpdateJekyllConfigBody body);
}
