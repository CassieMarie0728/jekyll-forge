package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcassetsReoptimizeJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal id = null;
  
  @Schema(description = "")
  private BigDecimal maxWidth = null;
  public enum OutputFormatEnum {
    WEBP("webp"),
    JPEG("jpeg"),
    PNG("png");

    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static OutputFormatEnum fromValue(String text) {
      for (OutputFormatEnum b : OutputFormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(description = "")
  private OutputFormatEnum outputFormat = null;
  
  @Schema(description = "")
  private BigDecimal quality = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }

  public void setId(BigDecimal id) {
    this.id = id;
  }

  public ApitrpcassetsReoptimizeJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

 /**
   * Get maxWidth
   * @return maxWidth
  **/
  @JsonProperty("maxWidth")
  public BigDecimal getMaxWidth() {
    return maxWidth;
  }

  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  public ApitrpcassetsReoptimizeJson maxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
    return this;
  }

 /**
   * Get outputFormat
   * @return outputFormat
  **/
  @JsonProperty("outputFormat")
  public String getOutputFormat() {
    if (outputFormat == null) {
      return null;
    }
    return outputFormat.getValue();
  }

  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  public ApitrpcassetsReoptimizeJson outputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
    return this;
  }

 /**
   * Get quality
   * @return quality
  **/
  @JsonProperty("quality")
  public BigDecimal getQuality() {
    return quality;
  }

  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }

  public ApitrpcassetsReoptimizeJson quality(BigDecimal quality) {
    this.quality = quality;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsReoptimizeJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
