package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
@Path("/")
public interface SchedulerApi  {

    /**
     * Cancel
     *
     */
    @POST
    @Path("/api/trpc/scheduler.cancel")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerCancel(TrpcSchedulerCancelBody body);

    /**
     * Cancel All
     *
     */
    @POST
    @Path("/api/trpc/scheduler.cancelAll")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel All", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerCancelAll(TrpcSchedulerCancelAllBody body);

    /**
     * List
     *
     */
    @GET
    @Path("/api/trpc/scheduler.list")
    @Produces({ "application/json" })
    @Operation(summary = "List", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerList(@QueryParam("input")String input);

    /**
     * List Heartbeat Jobs
     *
     */
    @GET
    @Path("/api/trpc/scheduler.listHeartbeatJobs")
    @Produces({ "application/json" })
    @Operation(summary = "List Heartbeat Jobs", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerListHeartbeatJobs(@QueryParam("input")String input);

    /**
     * Mark Failed
     *
     */
    @POST
    @Path("/api/trpc/scheduler.markFailed")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Failed", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerMarkFailed(TrpcSchedulerMarkFailedBody body);

    /**
     * Mark Published
     *
     */
    @POST
    @Path("/api/trpc/scheduler.markPublished")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Published", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerMarkPublished(TrpcSchedulerMarkPublishedBody body);

    /**
     * Reschedule
     *
     */
    @POST
    @Path("/api/trpc/scheduler.reschedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerReschedule(TrpcSchedulerRescheduleBody body);

    /**
     * Schedule
     *
     */
    @POST
    @Path("/api/trpc/scheduler.schedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse schedulerSchedule(TrpcSchedulerScheduleBody body);
}
