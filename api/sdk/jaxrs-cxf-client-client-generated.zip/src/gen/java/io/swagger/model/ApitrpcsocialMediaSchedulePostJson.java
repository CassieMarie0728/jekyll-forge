package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsocialMediaSchedulePostJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal repurposedContentId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal socialMediaAccountId = null;
  
  @Schema(required = true, description = "")
  private Object scheduledAt = null;
  
  @Schema(description = "")
  private String timezone = null;
 /**
   * Get repurposedContentId
   * @return repurposedContentId
  **/
  @JsonProperty("repurposedContentId")
  public BigDecimal getRepurposedContentId() {
    return repurposedContentId;
  }

  public void setRepurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
  }

  public ApitrpcsocialMediaSchedulePostJson repurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
    return this;
  }

 /**
   * Get socialMediaAccountId
   * @return socialMediaAccountId
  **/
  @JsonProperty("socialMediaAccountId")
  public BigDecimal getSocialMediaAccountId() {
    return socialMediaAccountId;
  }

  public void setSocialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
  }

  public ApitrpcsocialMediaSchedulePostJson socialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
    return this;
  }

 /**
   * Get scheduledAt
   * @return scheduledAt
  **/
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }

  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  public ApitrpcsocialMediaSchedulePostJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

 /**
   * Get timezone
   * @return timezone
  **/
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public ApitrpcsocialMediaSchedulePostJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSchedulePostJson {\n");
    
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    socialMediaAccountId: ").append(toIndentedString(socialMediaAccountId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
