package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsocialMediaReschedulePostJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private Object scheduledAt = null;
  
  @Schema(description = "")
  private String timezone = null;
 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcsocialMediaReschedulePostJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get scheduledAt
   * @return scheduledAt
  **/
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }

  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  public ApitrpcsocialMediaReschedulePostJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

 /**
   * Get timezone
   * @return timezone
  **/
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public ApitrpcsocialMediaReschedulePostJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaReschedulePostJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
