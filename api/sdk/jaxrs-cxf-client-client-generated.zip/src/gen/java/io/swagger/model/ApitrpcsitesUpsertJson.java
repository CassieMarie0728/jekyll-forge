package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsitesUpsertJson   {
  
  @Schema(required = true, description = "")
  private String owner = null;
  
  @Schema(required = true, description = "")
  private String repo = null;
  
  @Schema(description = "")
  private String defaultBranch = null;
  
  @Schema(description = "")
  private String selectedBranch = null;
  
  @Schema(description = "")
  private String rootPath = null;
  
  @Schema(description = "")
  private Boolean isJekyll = null;
  
  @Schema(description = "")
  private Boolean isFavorite = null;
  
  @Schema(description = "")
  private String timezone = null;
  
  @Schema(description = "")
  private String defaultLayout = null;
  
  @Schema(description = "")
  private String defaultAssetPath = null;
 /**
   * Get owner
   * @return owner
  **/
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public ApitrpcsitesUpsertJson owner(String owner) {
    this.owner = owner;
    return this;
  }

 /**
   * Get repo
   * @return repo
  **/
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }

  public void setRepo(String repo) {
    this.repo = repo;
  }

  public ApitrpcsitesUpsertJson repo(String repo) {
    this.repo = repo;
    return this;
  }

 /**
   * Get defaultBranch
   * @return defaultBranch
  **/
  @JsonProperty("defaultBranch")
  public String getDefaultBranch() {
    return defaultBranch;
  }

  public void setDefaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
  }

  public ApitrpcsitesUpsertJson defaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
    return this;
  }

 /**
   * Get selectedBranch
   * @return selectedBranch
  **/
  @JsonProperty("selectedBranch")
  public String getSelectedBranch() {
    return selectedBranch;
  }

  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  public ApitrpcsitesUpsertJson selectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
    return this;
  }

 /**
   * Get rootPath
   * @return rootPath
  **/
  @JsonProperty("rootPath")
  public String getRootPath() {
    return rootPath;
  }

  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  public ApitrpcsitesUpsertJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

 /**
   * Get isJekyll
   * @return isJekyll
  **/
  @JsonProperty("isJekyll")
  public Boolean isIsJekyll() {
    return isJekyll;
  }

  public void setIsJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
  }

  public ApitrpcsitesUpsertJson isJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
    return this;
  }

 /**
   * Get isFavorite
   * @return isFavorite
  **/
  @JsonProperty("isFavorite")
  public Boolean isIsFavorite() {
    return isFavorite;
  }

  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  public ApitrpcsitesUpsertJson isFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
    return this;
  }

 /**
   * Get timezone
   * @return timezone
  **/
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public ApitrpcsitesUpsertJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

 /**
   * Get defaultLayout
   * @return defaultLayout
  **/
  @JsonProperty("defaultLayout")
  public String getDefaultLayout() {
    return defaultLayout;
  }

  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  public ApitrpcsitesUpsertJson defaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
    return this;
  }

 /**
   * Get defaultAssetPath
   * @return defaultAssetPath
  **/
  @JsonProperty("defaultAssetPath")
  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }

  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }

  public ApitrpcsitesUpsertJson defaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpsertJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    defaultBranch: ").append(toIndentedString(defaultBranch)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    isJekyll: ").append(toIndentedString(isJekyll)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
