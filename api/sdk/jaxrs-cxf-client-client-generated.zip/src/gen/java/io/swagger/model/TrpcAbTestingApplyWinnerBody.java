package io.swagger.model;

import io.swagger.model.ApitrpcabTestingApplyWinnerJson;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class TrpcAbTestingApplyWinnerBody   {
  
  @Schema(required = true, description = "")
  private ApitrpcabTestingApplyWinnerJson json = null;
 /**
   * Get json
   * @return json
  **/
  @JsonProperty("json")
  public ApitrpcabTestingApplyWinnerJson getJson() {
    return json;
  }

  public void setJson(ApitrpcabTestingApplyWinnerJson json) {
    this.json = json;
  }

  public TrpcAbTestingApplyWinnerBody json(ApitrpcabTestingApplyWinnerJson json) {
    this.json = json;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcAbTestingApplyWinnerBody {\n");
    
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
