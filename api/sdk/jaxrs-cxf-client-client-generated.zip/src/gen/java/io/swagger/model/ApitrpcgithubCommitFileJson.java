package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcgithubCommitFileJson   {
  
  @Schema(required = true, description = "")
  private String owner = null;
  
  @Schema(required = true, description = "")
  private String repo = null;
  
  @Schema(required = true, description = "")
  private String path = null;
  
  @Schema(required = true, description = "")
  private String branch = null;
  
  @Schema(required = true, description = "")
  private String content = null;
  
  @Schema(required = true, description = "")
  private String message = null;
  
  @Schema(description = "")
  private String sha = null;
 /**
   * Get owner
   * @return owner
  **/
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public ApitrpcgithubCommitFileJson owner(String owner) {
    this.owner = owner;
    return this;
  }

 /**
   * Get repo
   * @return repo
  **/
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }

  public void setRepo(String repo) {
    this.repo = repo;
  }

  public ApitrpcgithubCommitFileJson repo(String repo) {
    this.repo = repo;
    return this;
  }

 /**
   * Get path
   * @return path
  **/
  @JsonProperty("path")
  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public ApitrpcgithubCommitFileJson path(String path) {
    this.path = path;
    return this;
  }

 /**
   * Get branch
   * @return branch
  **/
  @JsonProperty("branch")
  public String getBranch() {
    return branch;
  }

  public void setBranch(String branch) {
    this.branch = branch;
  }

  public ApitrpcgithubCommitFileJson branch(String branch) {
    this.branch = branch;
    return this;
  }

 /**
   * Get content
   * @return content
  **/
  @JsonProperty("content")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ApitrpcgithubCommitFileJson content(String content) {
    this.content = content;
    return this;
  }

 /**
   * Get message
   * @return message
  **/
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public ApitrpcgithubCommitFileJson message(String message) {
    this.message = message;
    return this;
  }

 /**
   * Get sha
   * @return sha
  **/
  @JsonProperty("sha")
  public String getSha() {
    return sha;
  }

  public void setSha(String sha) {
    this.sha = sha;
  }

  public ApitrpcgithubCommitFileJson sha(String sha) {
    this.sha = sha;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCommitFileJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
