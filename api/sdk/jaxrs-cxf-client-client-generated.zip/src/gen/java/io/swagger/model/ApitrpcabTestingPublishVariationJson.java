package io.swagger.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcabTestingPublishVariationJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal variationIndex = null;
  public enum PlatformsEnum {
    TWITTER("twitter"),
    LINKEDIN("linkedin"),
    FACEBOOK("facebook"),
    INSTAGRAM("instagram"),
    EMAIL("email"),
    DIRECT("direct");

    private String value;

    PlatformsEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static PlatformsEnum fromValue(String text) {
      for (PlatformsEnum b : PlatformsEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(required = true, description = "")
  private List<PlatformsEnum> platforms = new ArrayList<PlatformsEnum>();
 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcabTestingPublishVariationJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get variationIndex
   * @return variationIndex
  **/
  @JsonProperty("variationIndex")
  public BigDecimal getVariationIndex() {
    return variationIndex;
  }

  public void setVariationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
  }

  public ApitrpcabTestingPublishVariationJson variationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
    return this;
  }

 /**
   * Get platforms
   * @return platforms
  **/
  @JsonProperty("platforms")
  public List<PlatformsEnum> getPlatforms() {
    return platforms;
  }

  public void setPlatforms(List<PlatformsEnum> platforms) {
    this.platforms = platforms;
  }

  public ApitrpcabTestingPublishVariationJson platforms(List<PlatformsEnum> platforms) {
    this.platforms = platforms;
    return this;
  }

  public ApitrpcabTestingPublishVariationJson addPlatformsItem(PlatformsEnum platformsItem) {
    this.platforms.add(platformsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingPublishVariationJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platforms: ").append(toIndentedString(platforms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
