package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcabTestingUpdateMetricsJsonMetrics   {
  
  @Schema(description = "")
  private BigDecimal impressions = null;
  
  @Schema(description = "")
  private BigDecimal engagements = null;
  
  @Schema(description = "")
  private BigDecimal clicks = null;
  
  @Schema(description = "")
  private BigDecimal shares = null;
  
  @Schema(description = "")
  private BigDecimal likes = null;
  
  @Schema(description = "")
  private BigDecimal replies = null;
 /**
   * Get impressions
   * @return impressions
  **/
  @JsonProperty("impressions")
  public BigDecimal getImpressions() {
    return impressions;
  }

  public void setImpressions(BigDecimal impressions) {
    this.impressions = impressions;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics impressions(BigDecimal impressions) {
    this.impressions = impressions;
    return this;
  }

 /**
   * Get engagements
   * @return engagements
  **/
  @JsonProperty("engagements")
  public BigDecimal getEngagements() {
    return engagements;
  }

  public void setEngagements(BigDecimal engagements) {
    this.engagements = engagements;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics engagements(BigDecimal engagements) {
    this.engagements = engagements;
    return this;
  }

 /**
   * Get clicks
   * @return clicks
  **/
  @JsonProperty("clicks")
  public BigDecimal getClicks() {
    return clicks;
  }

  public void setClicks(BigDecimal clicks) {
    this.clicks = clicks;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics clicks(BigDecimal clicks) {
    this.clicks = clicks;
    return this;
  }

 /**
   * Get shares
   * @return shares
  **/
  @JsonProperty("shares")
  public BigDecimal getShares() {
    return shares;
  }

  public void setShares(BigDecimal shares) {
    this.shares = shares;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics shares(BigDecimal shares) {
    this.shares = shares;
    return this;
  }

 /**
   * Get likes
   * @return likes
  **/
  @JsonProperty("likes")
  public BigDecimal getLikes() {
    return likes;
  }

  public void setLikes(BigDecimal likes) {
    this.likes = likes;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics likes(BigDecimal likes) {
    this.likes = likes;
    return this;
  }

 /**
   * Get replies
   * @return replies
  **/
  @JsonProperty("replies")
  public BigDecimal getReplies() {
    return replies;
  }

  public void setReplies(BigDecimal replies) {
    this.replies = replies;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics replies(BigDecimal replies) {
    this.replies = replies;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJsonMetrics {\n");
    
    sb.append("    impressions: ").append(toIndentedString(impressions)).append("\n");
    sb.append("    engagements: ").append(toIndentedString(engagements)).append("\n");
    sb.append("    clicks: ").append(toIndentedString(clicks)).append("\n");
    sb.append("    shares: ").append(toIndentedString(shares)).append("\n");
    sb.append("    likes: ").append(toIndentedString(likes)).append("\n");
    sb.append("    replies: ").append(toIndentedString(replies)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
