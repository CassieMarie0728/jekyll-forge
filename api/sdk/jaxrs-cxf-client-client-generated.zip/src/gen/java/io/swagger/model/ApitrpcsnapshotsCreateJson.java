package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsnapshotsCreateJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal siteId = null;
  
  @Schema(description = "")
  private BigDecimal postId = null;
  
  @Schema(description = "")
  private String postPath = null;
  
  @Schema(required = true, description = "")
  private String label = null;
  
  @Schema(required = true, description = "")
  private Object reason = null;
  
  @Schema(description = "")
  private String markdown = null;
  
  @Schema(description = "")
  private Object frontMatter = null;
 /**
   * Get siteId
   * @return siteId
  **/
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public ApitrpcsnapshotsCreateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcsnapshotsCreateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get postPath
   * @return postPath
  **/
  @JsonProperty("postPath")
  public String getPostPath() {
    return postPath;
  }

  public void setPostPath(String postPath) {
    this.postPath = postPath;
  }

  public ApitrpcsnapshotsCreateJson postPath(String postPath) {
    this.postPath = postPath;
    return this;
  }

 /**
   * Get label
   * @return label
  **/
  @JsonProperty("label")
  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public ApitrpcsnapshotsCreateJson label(String label) {
    this.label = label;
    return this;
  }

 /**
   * Get reason
   * @return reason
  **/
  @JsonProperty("reason")
  public Object getReason() {
    return reason;
  }

  public void setReason(Object reason) {
    this.reason = reason;
  }

  public ApitrpcsnapshotsCreateJson reason(Object reason) {
    this.reason = reason;
    return this;
  }

 /**
   * Get markdown
   * @return markdown
  **/
  @JsonProperty("markdown")
  public String getMarkdown() {
    return markdown;
  }

  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  public ApitrpcsnapshotsCreateJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

 /**
   * Get frontMatter
   * @return frontMatter
  **/
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }

  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  public ApitrpcsnapshotsCreateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsnapshotsCreateJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    postPath: ").append(toIndentedString(postPath)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
