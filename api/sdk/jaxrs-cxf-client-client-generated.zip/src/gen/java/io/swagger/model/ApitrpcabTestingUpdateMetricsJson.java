package io.swagger.model;

import io.swagger.model.ApitrpcabTestingUpdateMetricsJsonMetrics;
import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcabTestingUpdateMetricsJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal variationIndex = null;
  
  @Schema(required = true, description = "")
  private String platform = null;
  
  @Schema(description = "")
  private ApitrpcabTestingUpdateMetricsJsonMetrics metrics = null;
 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcabTestingUpdateMetricsJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get variationIndex
   * @return variationIndex
  **/
  @JsonProperty("variationIndex")
  public BigDecimal getVariationIndex() {
    return variationIndex;
  }

  public void setVariationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
  }

  public ApitrpcabTestingUpdateMetricsJson variationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
    return this;
  }

 /**
   * Get platform
   * @return platform
  **/
  @JsonProperty("platform")
  public String getPlatform() {
    return platform;
  }

  public void setPlatform(String platform) {
    this.platform = platform;
  }

  public ApitrpcabTestingUpdateMetricsJson platform(String platform) {
    this.platform = platform;
    return this;
  }

 /**
   * Get metrics
   * @return metrics
  **/
  @JsonProperty("metrics")
  public ApitrpcabTestingUpdateMetricsJsonMetrics getMetrics() {
    return metrics;
  }

  public void setMetrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) {
    this.metrics = metrics;
  }

  public ApitrpcabTestingUpdateMetricsJson metrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) {
    this.metrics = metrics;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    metrics: ").append(toIndentedString(metrics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
