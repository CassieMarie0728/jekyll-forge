package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcassetsUploadJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal siteId = null;
  
  @Schema(required = true, description = "")
  private String name = null;
  
  @Schema(required = true, description = "")
  private String path = null;
  
  @Schema(required = true, description = "")
  private String base64Content = null;
  
  @Schema(required = true, description = "")
  private String mimeType = null;
  
  @Schema(required = true, description = "")
  private BigDecimal size = null;
  
  @Schema(description = "")
  private BigDecimal width = null;
  
  @Schema(description = "")
  private BigDecimal height = null;
  
  @Schema(required = true, description = "")
  private Boolean optimize = null;
  
  @Schema(description = "")
  private BigDecimal maxWidth = null;
  public enum OutputFormatEnum {
    WEBP("webp"),
    JPEG("jpeg"),
    PNG("png"),
    ORIGINAL("original");

    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static OutputFormatEnum fromValue(String text) {
      for (OutputFormatEnum b : OutputFormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(description = "")
  private OutputFormatEnum outputFormat = null;
  
  @Schema(description = "")
  private BigDecimal quality = null;
 /**
   * Get siteId
   * @return siteId
  **/
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public ApitrpcassetsUploadJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

 /**
   * Get name
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ApitrpcassetsUploadJson name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get path
   * @return path
  **/
  @JsonProperty("path")
  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public ApitrpcassetsUploadJson path(String path) {
    this.path = path;
    return this;
  }

 /**
   * Get base64Content
   * @return base64Content
  **/
  @JsonProperty("base64Content")
  public String getBase64Content() {
    return base64Content;
  }

  public void setBase64Content(String base64Content) {
    this.base64Content = base64Content;
  }

  public ApitrpcassetsUploadJson base64Content(String base64Content) {
    this.base64Content = base64Content;
    return this;
  }

 /**
   * Get mimeType
   * @return mimeType
  **/
  @JsonProperty("mimeType")
  public String getMimeType() {
    return mimeType;
  }

  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  public ApitrpcassetsUploadJson mimeType(String mimeType) {
    this.mimeType = mimeType;
    return this;
  }

 /**
   * Get size
   * @return size
  **/
  @JsonProperty("size")
  public BigDecimal getSize() {
    return size;
  }

  public void setSize(BigDecimal size) {
    this.size = size;
  }

  public ApitrpcassetsUploadJson size(BigDecimal size) {
    this.size = size;
    return this;
  }

 /**
   * Get width
   * @return width
  **/
  @JsonProperty("width")
  public BigDecimal getWidth() {
    return width;
  }

  public void setWidth(BigDecimal width) {
    this.width = width;
  }

  public ApitrpcassetsUploadJson width(BigDecimal width) {
    this.width = width;
    return this;
  }

 /**
   * Get height
   * @return height
  **/
  @JsonProperty("height")
  public BigDecimal getHeight() {
    return height;
  }

  public void setHeight(BigDecimal height) {
    this.height = height;
  }

  public ApitrpcassetsUploadJson height(BigDecimal height) {
    this.height = height;
    return this;
  }

 /**
   * Get optimize
   * @return optimize
  **/
  @JsonProperty("optimize")
  public Boolean isOptimize() {
    return optimize;
  }

  public void setOptimize(Boolean optimize) {
    this.optimize = optimize;
  }

  public ApitrpcassetsUploadJson optimize(Boolean optimize) {
    this.optimize = optimize;
    return this;
  }

 /**
   * Get maxWidth
   * @return maxWidth
  **/
  @JsonProperty("maxWidth")
  public BigDecimal getMaxWidth() {
    return maxWidth;
  }

  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  public ApitrpcassetsUploadJson maxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
    return this;
  }

 /**
   * Get outputFormat
   * @return outputFormat
  **/
  @JsonProperty("outputFormat")
  public String getOutputFormat() {
    if (outputFormat == null) {
      return null;
    }
    return outputFormat.getValue();
  }

  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  public ApitrpcassetsUploadJson outputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
    return this;
  }

 /**
   * Get quality
   * @return quality
  **/
  @JsonProperty("quality")
  public BigDecimal getQuality() {
    return quality;
  }

  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }

  public ApitrpcassetsUploadJson quality(BigDecimal quality) {
    this.quality = quality;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsUploadJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    base64Content: ").append(toIndentedString(base64Content)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    optimize: ").append(toIndentedString(optimize)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
