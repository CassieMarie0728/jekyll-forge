# ApitrpcaiGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task** | **String** |  | 
**userPrompt** | **String** |  |  [optional]
**selectedText** | **String** |  |  [optional]
**postMarkdown** | **String** |  |  [optional]
**frontMatter** | **Object** |  |  [optional]
**tone** | **String** |  |  [optional]
**voiceProfileId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
