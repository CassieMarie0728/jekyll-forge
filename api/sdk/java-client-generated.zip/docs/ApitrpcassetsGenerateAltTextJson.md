# ApitrpcassetsGenerateAltTextJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assetId** | [**BigDecimal**](BigDecimal.md) |  | 
