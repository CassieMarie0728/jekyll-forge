# ApitrpcabTestingGenerateVariationsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**count** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**tones** | **List&lt;String&gt;** |  |  [optional]
**angles** | **List&lt;String&gt;** |  |  [optional]
**headline** | **String** |  | 
**content** | **String** |  | 
