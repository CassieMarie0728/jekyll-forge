# ApitrpcsocialMediaPublishContentJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposedContentId** | [**BigDecimal**](BigDecimal.md) |  | 
**accountId** | [**BigDecimal**](BigDecimal.md) |  | 
