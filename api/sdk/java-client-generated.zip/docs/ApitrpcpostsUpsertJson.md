# ApitrpcpostsUpsertJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
**path** | **String** |  | 
**filename** | **String** |  |  [optional]
**slug** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**status** | **Object** |  |  [optional]
**frontMatter** | **Object** |  |  [optional]
**markdown** | **String** |  |  [optional]
**sha** | **String** |  |  [optional]
**scheduledAt** | **Object** |  |  [optional]
