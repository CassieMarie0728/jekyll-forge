# TrpcPostsAutosaveBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcpostsAutosaveJson**](ApitrpcpostsAutosaveJson.md) |  | 
