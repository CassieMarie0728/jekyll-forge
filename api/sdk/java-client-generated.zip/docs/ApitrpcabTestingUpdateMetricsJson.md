# ApitrpcabTestingUpdateMetricsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**variationIndex** | [**BigDecimal**](BigDecimal.md) |  | 
**platform** | **String** |  | 
**metrics** | [**ApitrpcabTestingUpdateMetricsJsonMetrics**](ApitrpcabTestingUpdateMetricsJsonMetrics.md) |  |  [optional]
