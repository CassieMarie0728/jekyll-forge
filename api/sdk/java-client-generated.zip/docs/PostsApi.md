# PostsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**postsAutosave**](PostsApi.md#postsAutosave) | **POST** /api/trpc/posts.autosave | Autosave
[**postsDelete**](PostsApi.md#postsDelete) | **POST** /api/trpc/posts.delete | Delete
[**postsGet**](PostsApi.md#postsGet) | **GET** /api/trpc/posts.get | Get
[**postsGetFrontMatterTemplates**](PostsApi.md#postsGetFrontMatterTemplates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
[**postsList**](PostsApi.md#postsList) | **GET** /api/trpc/posts.list | List
[**postsUpdate**](PostsApi.md#postsUpdate) | **POST** /api/trpc/posts.update | Update
[**postsUpsert**](PostsApi.md#postsUpsert) | **POST** /api/trpc/posts.upsert | Upsert

<a name="postsAutosave"></a>
# **postsAutosave**
> TRPCResponse postsAutosave(body)

Autosave

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
TrpcPostsAutosaveBody body = new TrpcPostsAutosaveBody(); // TrpcPostsAutosaveBody | 
try {
    TRPCResponse result = apiInstance.postsAutosave(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsAutosave");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsAutosaveBody**](TrpcPostsAutosaveBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsDelete"></a>
# **postsDelete**
> TRPCResponse postsDelete(body)

Delete

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
TrpcPostsDeleteBody body = new TrpcPostsDeleteBody(); // TrpcPostsDeleteBody | 
try {
    TRPCResponse result = apiInstance.postsDelete(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsDeleteBody**](TrpcPostsDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsGet"></a>
# **postsGet**
> TRPCResponse postsGet(input)

Get

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.postsGet(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsGetFrontMatterTemplates"></a>
# **postsGetFrontMatterTemplates**
> TRPCResponse postsGetFrontMatterTemplates(input)

Get Front Matter Templates

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.postsGetFrontMatterTemplates(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsGetFrontMatterTemplates");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsList"></a>
# **postsList**
> TRPCResponse postsList(input)

List

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.postsList(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsList");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsUpdate"></a>
# **postsUpdate**
> TRPCResponse postsUpdate(body)

Update

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
TrpcPostsUpdateBody body = new TrpcPostsUpdateBody(); // TrpcPostsUpdateBody | 
try {
    TRPCResponse result = apiInstance.postsUpdate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsUpdate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpdateBody**](TrpcPostsUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsUpsert"></a>
# **postsUpsert**
> TRPCResponse postsUpsert(body)

Upsert

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PostsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


PostsApi apiInstance = new PostsApi();
TrpcPostsUpsertBody body = new TrpcPostsUpsertBody(); // TrpcPostsUpsertBody | 
try {
    TRPCResponse result = apiInstance.postsUpsert(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PostsApi#postsUpsert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpsertBody**](TrpcPostsUpsertBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

