# TrpcSchedulerCancelAllBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulerCancelAllJson**](ApitrpcschedulerCancelAllJson.md) |  | 
