# TrpcAbTestingGenerateVariationsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingGenerateVariationsJson**](ApitrpcabTestingGenerateVariationsJson.md) |  | 
