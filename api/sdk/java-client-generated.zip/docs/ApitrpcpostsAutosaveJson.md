# ApitrpcpostsAutosaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**markdown** | **String** |  | 
**frontMatter** | **Object** |  | 
