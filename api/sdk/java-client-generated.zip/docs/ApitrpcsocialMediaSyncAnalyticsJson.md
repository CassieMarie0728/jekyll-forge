# ApitrpcsocialMediaSyncAnalyticsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**analyticsId** | [**BigDecimal**](BigDecimal.md) |  | 
