# ApitrpcschedulerCancelAllJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
