# ApitrpcabTestingPublishVariationJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**variationIndex** | [**BigDecimal**](BigDecimal.md) |  | 
**platforms** | [**List&lt;PlatformsEnum&gt;**](#List&lt;PlatformsEnum&gt;) |  | 

<a name="List<PlatformsEnum>"></a>
## Enum: List&lt;PlatformsEnum&gt;
Name | Value
---- | -----
TWITTER | &quot;twitter&quot;
LINKEDIN | &quot;linkedin&quot;
FACEBOOK | &quot;facebook&quot;
INSTAGRAM | &quot;instagram&quot;
EMAIL | &quot;email&quot;
DIRECT | &quot;direct&quot;
