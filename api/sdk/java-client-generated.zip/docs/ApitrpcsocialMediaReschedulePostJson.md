# ApitrpcsocialMediaReschedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  |  [optional]
