# TrpcSitesUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsitesUpdateJson**](ApitrpcsitesUpdateJson.md) |  | 
