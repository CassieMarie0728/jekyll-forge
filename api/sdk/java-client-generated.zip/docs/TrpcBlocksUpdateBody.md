# TrpcBlocksUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcblocksUpdateJson**](ApitrpcblocksUpdateJson.md) |  | 
