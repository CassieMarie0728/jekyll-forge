# ApitrpcaiUpdateSettingsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **Boolean** |  |  [optional]
**temperature** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**maxTokens** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**systemPrompt** | **String** |  |  [optional]
**brandVoicePrompt** | **String** |  |  [optional]
**safetyPrompt** | **String** |  |  [optional]
**streaming** | **Boolean** |  |  [optional]
**defaultLanguage** | **String** |  |  [optional]
**defaultTone** | **String** |  |  [optional]
**budgetLimitCents** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
