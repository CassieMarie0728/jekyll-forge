# TrpcAiProvidersActivateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiProvidersActivateJson**](ApitrpcaiProvidersActivateJson.md) |  | 
