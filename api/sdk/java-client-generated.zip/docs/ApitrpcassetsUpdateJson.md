# ApitrpcassetsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**name** | **String** |  |  [optional]
**path** | **String** |  |  [optional]
**alt** | **String** |  |  [optional]
