# ApitrpcrepurposingRegenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
