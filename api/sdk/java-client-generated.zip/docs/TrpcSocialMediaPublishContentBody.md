# TrpcSocialMediaPublishContentBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaPublishContentJson**](ApitrpcsocialMediaPublishContentJson.md) |  | 
