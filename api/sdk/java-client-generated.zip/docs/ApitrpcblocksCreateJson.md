# ApitrpcblocksCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**category** | **String** |  |  [optional]
**content** | **String** |  | 
**contentType** | [**ContentTypeEnum**](#ContentTypeEnum) |  | 

<a name="ContentTypeEnum"></a>
## Enum: ContentTypeEnum
Name | Value
---- | -----
MARKDOWN | &quot;markdown&quot;
HTML | &quot;html&quot;
LIQUID | &quot;liquid&quot;
