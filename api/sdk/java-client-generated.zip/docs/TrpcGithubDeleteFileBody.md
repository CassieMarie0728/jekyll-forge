# TrpcGithubDeleteFileBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubDeleteFileJson**](ApitrpcgithubDeleteFileJson.md) |  | 
