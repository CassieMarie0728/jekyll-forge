# TrpcRepurposingUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcrepurposingUpdateJson**](ApitrpcrepurposingUpdateJson.md) |  | 
