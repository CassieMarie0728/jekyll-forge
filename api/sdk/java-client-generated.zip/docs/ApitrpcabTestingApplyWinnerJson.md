# ApitrpcabTestingApplyWinnerJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**winningVariationIndex** | [**BigDecimal**](BigDecimal.md) |  | 
