# ApitrpcpostsUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**path** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**slug** | **String** |  |  [optional]
**status** | **Object** |  |  [optional]
**frontMatter** | **Object** |  |  [optional]
**markdown** | **String** |  |  [optional]
**sha** | **String** |  |  [optional]
**scheduledAt** | **Object** |  |  [optional]
