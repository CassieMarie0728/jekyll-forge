# TrpcSnapshotsCreateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsnapshotsCreateJson**](ApitrpcsnapshotsCreateJson.md) |  | 
