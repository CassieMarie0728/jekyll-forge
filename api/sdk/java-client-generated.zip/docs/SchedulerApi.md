# SchedulerApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**schedulerCancel**](SchedulerApi.md#schedulerCancel) | **POST** /api/trpc/scheduler.cancel | Cancel
[**schedulerCancelAll**](SchedulerApi.md#schedulerCancelAll) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
[**schedulerList**](SchedulerApi.md#schedulerList) | **GET** /api/trpc/scheduler.list | List
[**schedulerListHeartbeatJobs**](SchedulerApi.md#schedulerListHeartbeatJobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**schedulerMarkFailed**](SchedulerApi.md#schedulerMarkFailed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
[**schedulerMarkPublished**](SchedulerApi.md#schedulerMarkPublished) | **POST** /api/trpc/scheduler.markPublished | Mark Published
[**schedulerReschedule**](SchedulerApi.md#schedulerReschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
[**schedulerSchedule**](SchedulerApi.md#schedulerSchedule) | **POST** /api/trpc/scheduler.schedule | Schedule

<a name="schedulerCancel"></a>
# **schedulerCancel**
> TRPCResponse schedulerCancel(body)

Cancel

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
TrpcSchedulerCancelBody body = new TrpcSchedulerCancelBody(); // TrpcSchedulerCancelBody | 
try {
    TRPCResponse result = apiInstance.schedulerCancel(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerCancel");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelBody**](TrpcSchedulerCancelBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerCancelAll"></a>
# **schedulerCancelAll**
> TRPCResponse schedulerCancelAll(body)

Cancel All

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
TrpcSchedulerCancelAllBody body = new TrpcSchedulerCancelAllBody(); // TrpcSchedulerCancelAllBody | 
try {
    TRPCResponse result = apiInstance.schedulerCancelAll(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerCancelAll");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelAllBody**](TrpcSchedulerCancelAllBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerList"></a>
# **schedulerList**
> TRPCResponse schedulerList(input)

List

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.schedulerList(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerList");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="schedulerListHeartbeatJobs"></a>
# **schedulerListHeartbeatJobs**
> TRPCResponse schedulerListHeartbeatJobs(input)

List Heartbeat Jobs

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.schedulerListHeartbeatJobs(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerListHeartbeatJobs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="schedulerMarkFailed"></a>
# **schedulerMarkFailed**
> TRPCResponse schedulerMarkFailed(body)

Mark Failed

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
TrpcSchedulerMarkFailedBody body = new TrpcSchedulerMarkFailedBody(); // TrpcSchedulerMarkFailedBody | 
try {
    TRPCResponse result = apiInstance.schedulerMarkFailed(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerMarkFailed");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkFailedBody**](TrpcSchedulerMarkFailedBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerMarkPublished"></a>
# **schedulerMarkPublished**
> TRPCResponse schedulerMarkPublished(body)

Mark Published

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
TrpcSchedulerMarkPublishedBody body = new TrpcSchedulerMarkPublishedBody(); // TrpcSchedulerMarkPublishedBody | 
try {
    TRPCResponse result = apiInstance.schedulerMarkPublished(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerMarkPublished");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkPublishedBody**](TrpcSchedulerMarkPublishedBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerReschedule"></a>
# **schedulerReschedule**
> TRPCResponse schedulerReschedule(body)

Reschedule

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
TrpcSchedulerRescheduleBody body = new TrpcSchedulerRescheduleBody(); // TrpcSchedulerRescheduleBody | 
try {
    TRPCResponse result = apiInstance.schedulerReschedule(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerReschedule");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerRescheduleBody**](TrpcSchedulerRescheduleBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerSchedule"></a>
# **schedulerSchedule**
> TRPCResponse schedulerSchedule(body)

Schedule

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SchedulerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SchedulerApi apiInstance = new SchedulerApi();
TrpcSchedulerScheduleBody body = new TrpcSchedulerScheduleBody(); // TrpcSchedulerScheduleBody | 
try {
    TRPCResponse result = apiInstance.schedulerSchedule(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SchedulerApi#schedulerSchedule");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerScheduleBody**](TrpcSchedulerScheduleBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

