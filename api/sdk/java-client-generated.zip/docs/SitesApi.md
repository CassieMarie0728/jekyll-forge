# SitesApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sitesDelete**](SitesApi.md#sitesDelete) | **POST** /api/trpc/sites.delete | Delete
[**sitesGet**](SitesApi.md#sitesGet) | **GET** /api/trpc/sites.get | Get
[**sitesList**](SitesApi.md#sitesList) | **GET** /api/trpc/sites.list | List
[**sitesUpdate**](SitesApi.md#sitesUpdate) | **POST** /api/trpc/sites.update | Update
[**sitesUpsert**](SitesApi.md#sitesUpsert) | **POST** /api/trpc/sites.upsert | Upsert

<a name="sitesDelete"></a>
# **sitesDelete**
> TRPCResponse sitesDelete(body)

Delete

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SitesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SitesApi apiInstance = new SitesApi();
TrpcSitesDeleteBody body = new TrpcSitesDeleteBody(); // TrpcSitesDeleteBody | 
try {
    TRPCResponse result = apiInstance.sitesDelete(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SitesApi#sitesDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesDeleteBody**](TrpcSitesDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sitesGet"></a>
# **sitesGet**
> TRPCResponse sitesGet(input)

Get

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SitesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SitesApi apiInstance = new SitesApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.sitesGet(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SitesApi#sitesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="sitesList"></a>
# **sitesList**
> TRPCResponse sitesList()

List

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SitesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SitesApi apiInstance = new SitesApi();
try {
    TRPCResponse result = apiInstance.sitesList();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SitesApi#sitesList");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="sitesUpdate"></a>
# **sitesUpdate**
> TRPCResponse sitesUpdate(body)

Update

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SitesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SitesApi apiInstance = new SitesApi();
TrpcSitesUpdateBody body = new TrpcSitesUpdateBody(); // TrpcSitesUpdateBody | 
try {
    TRPCResponse result = apiInstance.sitesUpdate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SitesApi#sitesUpdate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpdateBody**](TrpcSitesUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sitesUpsert"></a>
# **sitesUpsert**
> TRPCResponse sitesUpsert(body)

Upsert

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SitesApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SitesApi apiInstance = new SitesApi();
TrpcSitesUpsertBody body = new TrpcSitesUpsertBody(); // TrpcSitesUpsertBody | 
try {
    TRPCResponse result = apiInstance.sitesUpsert(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SitesApi#sitesUpsert");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpsertBody**](TrpcSitesUpsertBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

