# ApitrpcsitesUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**isFavorite** | **Boolean** |  |  [optional]
**selectedBranch** | **String** |  |  [optional]
**rootPath** | **String** |  |  [optional]
**timezone** | **String** |  |  [optional]
**defaultLayout** | **String** |  |  [optional]
**defaultAssetPath** | **String** |  |  [optional]
**aiVoiceProfile** | **String** |  |  [optional]
**settings** | **Object** |  |  [optional]
