# TrpcGithubCreatePullRequestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubCreatePullRequestJson**](ApitrpcgithubCreatePullRequestJson.md) |  | 
