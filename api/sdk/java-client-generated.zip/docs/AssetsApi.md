# AssetsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**assetsDelete**](AssetsApi.md#assetsDelete) | **POST** /api/trpc/assets.delete | Delete
[**assetsGenerateAltText**](AssetsApi.md#assetsGenerateAltText) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
[**assetsList**](AssetsApi.md#assetsList) | **GET** /api/trpc/assets.list | List
[**assetsReoptimize**](AssetsApi.md#assetsReoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
[**assetsUpdate**](AssetsApi.md#assetsUpdate) | **POST** /api/trpc/assets.update | Update
[**assetsUpload**](AssetsApi.md#assetsUpload) | **POST** /api/trpc/assets.upload | Upload

<a name="assetsDelete"></a>
# **assetsDelete**
> TRPCResponse assetsDelete(body)

Delete

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AssetsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AssetsApi apiInstance = new AssetsApi();
TrpcAssetsDeleteBody body = new TrpcAssetsDeleteBody(); // TrpcAssetsDeleteBody | 
try {
    TRPCResponse result = apiInstance.assetsDelete(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AssetsApi#assetsDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsDeleteBody**](TrpcAssetsDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsGenerateAltText"></a>
# **assetsGenerateAltText**
> TRPCResponse assetsGenerateAltText(body)

Generate Alt Text

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AssetsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AssetsApi apiInstance = new AssetsApi();
TrpcAssetsGenerateAltTextBody body = new TrpcAssetsGenerateAltTextBody(); // TrpcAssetsGenerateAltTextBody | 
try {
    TRPCResponse result = apiInstance.assetsGenerateAltText(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AssetsApi#assetsGenerateAltText");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsGenerateAltTextBody**](TrpcAssetsGenerateAltTextBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsList"></a>
# **assetsList**
> TRPCResponse assetsList(input)

List

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AssetsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AssetsApi apiInstance = new AssetsApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.assetsList(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AssetsApi#assetsList");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="assetsReoptimize"></a>
# **assetsReoptimize**
> TRPCResponse assetsReoptimize(body)

Reoptimize

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AssetsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AssetsApi apiInstance = new AssetsApi();
TrpcAssetsReoptimizeBody body = new TrpcAssetsReoptimizeBody(); // TrpcAssetsReoptimizeBody | 
try {
    TRPCResponse result = apiInstance.assetsReoptimize(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AssetsApi#assetsReoptimize");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsReoptimizeBody**](TrpcAssetsReoptimizeBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsUpdate"></a>
# **assetsUpdate**
> TRPCResponse assetsUpdate(body)

Update

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AssetsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AssetsApi apiInstance = new AssetsApi();
TrpcAssetsUpdateBody body = new TrpcAssetsUpdateBody(); // TrpcAssetsUpdateBody | 
try {
    TRPCResponse result = apiInstance.assetsUpdate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AssetsApi#assetsUpdate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUpdateBody**](TrpcAssetsUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsUpload"></a>
# **assetsUpload**
> TRPCResponse assetsUpload(body)

Upload

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AssetsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AssetsApi apiInstance = new AssetsApi();
TrpcAssetsUploadBody body = new TrpcAssetsUploadBody(); // TrpcAssetsUploadBody | 
try {
    TRPCResponse result = apiInstance.assetsUpload(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AssetsApi#assetsUpload");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUploadBody**](TrpcAssetsUploadBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

