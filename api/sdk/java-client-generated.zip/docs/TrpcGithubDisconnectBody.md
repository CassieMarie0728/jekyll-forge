# TrpcGithubDisconnectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | **Object** |  |  [optional]
