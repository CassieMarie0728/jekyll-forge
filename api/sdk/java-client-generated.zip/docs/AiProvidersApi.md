# AiProvidersApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiProvidersActivate**](AiProvidersApi.md#aiProvidersActivate) | **POST** /api/trpc/aiProviders.activate | Activate
[**aiProvidersGetSettings**](AiProvidersApi.md#aiProvidersGetSettings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
[**aiProvidersRemove**](AiProvidersApi.md#aiProvidersRemove) | **POST** /api/trpc/aiProviders.remove | Remove
[**aiProvidersSave**](AiProvidersApi.md#aiProvidersSave) | **POST** /api/trpc/aiProviders.save | Save
[**aiProvidersTest**](AiProvidersApi.md#aiProvidersTest) | **POST** /api/trpc/aiProviders.test | Test

<a name="aiProvidersActivate"></a>
# **aiProvidersActivate**
> TRPCResponse aiProvidersActivate(body)

Activate

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiProvidersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiProvidersApi apiInstance = new AiProvidersApi();
TrpcAiProvidersActivateBody body = new TrpcAiProvidersActivateBody(); // TrpcAiProvidersActivateBody | 
try {
    TRPCResponse result = apiInstance.aiProvidersActivate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiProvidersApi#aiProvidersActivate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersActivateBody**](TrpcAiProvidersActivateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersGetSettings"></a>
# **aiProvidersGetSettings**
> TRPCResponse aiProvidersGetSettings()

Get Settings

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiProvidersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiProvidersApi apiInstance = new AiProvidersApi();
try {
    TRPCResponse result = apiInstance.aiProvidersGetSettings();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiProvidersApi#aiProvidersGetSettings");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiProvidersRemove"></a>
# **aiProvidersRemove**
> TRPCResponse aiProvidersRemove(body)

Remove

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiProvidersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiProvidersApi apiInstance = new AiProvidersApi();
TrpcAiProvidersRemoveBody body = new TrpcAiProvidersRemoveBody(); // TrpcAiProvidersRemoveBody | 
try {
    TRPCResponse result = apiInstance.aiProvidersRemove(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiProvidersApi#aiProvidersRemove");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersRemoveBody**](TrpcAiProvidersRemoveBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersSave"></a>
# **aiProvidersSave**
> TRPCResponse aiProvidersSave(body)

Save

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiProvidersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiProvidersApi apiInstance = new AiProvidersApi();
TrpcAiProvidersSaveBody body = new TrpcAiProvidersSaveBody(); // TrpcAiProvidersSaveBody | 
try {
    TRPCResponse result = apiInstance.aiProvidersSave(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiProvidersApi#aiProvidersSave");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersSaveBody**](TrpcAiProvidersSaveBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersTest"></a>
# **aiProvidersTest**
> TRPCResponse aiProvidersTest(body)

Test

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiProvidersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiProvidersApi apiInstance = new AiProvidersApi();
TrpcAiProvidersTestBody body = new TrpcAiProvidersTestBody(); // TrpcAiProvidersTestBody | 
try {
    TRPCResponse result = apiInstance.aiProvidersTest(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiProvidersApi#aiProvidersTest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersTestBody**](TrpcAiProvidersTestBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

