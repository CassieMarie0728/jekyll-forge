# ApitrpcsnapshotsCreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
**postId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**postPath** | **String** |  |  [optional]
**label** | **String** |  | 
**reason** | **Object** |  | 
**markdown** | **String** |  |  [optional]
**frontMatter** | **Object** |  |  [optional]
