# AbTestingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**abTestingApplyWinner**](AbTestingApi.md#abTestingApplyWinner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
[**abTestingCompleteTest**](AbTestingApi.md#abTestingCompleteTest) | **POST** /api/trpc/abTesting.completeTest | Complete Test
[**abTestingGenerateVariations**](AbTestingApi.md#abTestingGenerateVariations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
[**abTestingGetResults**](AbTestingApi.md#abTestingGetResults) | **GET** /api/trpc/abTesting.getResults | Get Results
[**abTestingGetVariations**](AbTestingApi.md#abTestingGetVariations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
[**abTestingPublishVariation**](AbTestingApi.md#abTestingPublishVariation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
[**abTestingUpdateMetrics**](AbTestingApi.md#abTestingUpdateMetrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics

<a name="abTestingApplyWinner"></a>
# **abTestingApplyWinner**
> TRPCResponse abTestingApplyWinner(body)

Apply Winner

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
TrpcAbTestingApplyWinnerBody body = new TrpcAbTestingApplyWinnerBody(); // TrpcAbTestingApplyWinnerBody | 
try {
    TRPCResponse result = apiInstance.abTestingApplyWinner(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingApplyWinner");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingApplyWinnerBody**](TrpcAbTestingApplyWinnerBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingCompleteTest"></a>
# **abTestingCompleteTest**
> TRPCResponse abTestingCompleteTest(body)

Complete Test

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
TrpcAbTestingCompleteTestBody body = new TrpcAbTestingCompleteTestBody(); // TrpcAbTestingCompleteTestBody | 
try {
    TRPCResponse result = apiInstance.abTestingCompleteTest(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingCompleteTest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingCompleteTestBody**](TrpcAbTestingCompleteTestBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingGenerateVariations"></a>
# **abTestingGenerateVariations**
> TRPCResponse abTestingGenerateVariations(body)

Generate Variations

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
TrpcAbTestingGenerateVariationsBody body = new TrpcAbTestingGenerateVariationsBody(); // TrpcAbTestingGenerateVariationsBody | 
try {
    TRPCResponse result = apiInstance.abTestingGenerateVariations(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingGenerateVariations");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingGenerateVariationsBody**](TrpcAbTestingGenerateVariationsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingGetResults"></a>
# **abTestingGetResults**
> TRPCResponse abTestingGetResults(input)

Get Results

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.abTestingGetResults(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingGetResults");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="abTestingGetVariations"></a>
# **abTestingGetVariations**
> TRPCResponse abTestingGetVariations(input)

Get Variations

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.abTestingGetVariations(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingGetVariations");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="abTestingPublishVariation"></a>
# **abTestingPublishVariation**
> TRPCResponse abTestingPublishVariation(body)

Publish Variation

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
TrpcAbTestingPublishVariationBody body = new TrpcAbTestingPublishVariationBody(); // TrpcAbTestingPublishVariationBody | 
try {
    TRPCResponse result = apiInstance.abTestingPublishVariation(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingPublishVariation");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingPublishVariationBody**](TrpcAbTestingPublishVariationBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingUpdateMetrics"></a>
# **abTestingUpdateMetrics**
> TRPCResponse abTestingUpdateMetrics(body)

Update Metrics

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AbTestingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AbTestingApi apiInstance = new AbTestingApi();
TrpcAbTestingUpdateMetricsBody body = new TrpcAbTestingUpdateMetricsBody(); // TrpcAbTestingUpdateMetricsBody | 
try {
    TRPCResponse result = apiInstance.abTestingUpdateMetrics(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AbTestingApi#abTestingUpdateMetrics");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingUpdateMetricsBody**](TrpcAbTestingUpdateMetricsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

