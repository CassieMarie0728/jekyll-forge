# SnapshotsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**snapshotsCreate**](SnapshotsApi.md#snapshotsCreate) | **POST** /api/trpc/snapshots.create | Create
[**snapshotsGet**](SnapshotsApi.md#snapshotsGet) | **GET** /api/trpc/snapshots.get | Get
[**snapshotsListByPost**](SnapshotsApi.md#snapshotsListByPost) | **GET** /api/trpc/snapshots.listByPost | List By Post

<a name="snapshotsCreate"></a>
# **snapshotsCreate**
> TRPCResponse snapshotsCreate(body)

Create

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SnapshotsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SnapshotsApi apiInstance = new SnapshotsApi();
TrpcSnapshotsCreateBody body = new TrpcSnapshotsCreateBody(); // TrpcSnapshotsCreateBody | 
try {
    TRPCResponse result = apiInstance.snapshotsCreate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SnapshotsApi#snapshotsCreate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSnapshotsCreateBody**](TrpcSnapshotsCreateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="snapshotsGet"></a>
# **snapshotsGet**
> TRPCResponse snapshotsGet(input)

Get

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SnapshotsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SnapshotsApi apiInstance = new SnapshotsApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.snapshotsGet(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SnapshotsApi#snapshotsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="snapshotsListByPost"></a>
# **snapshotsListByPost**
> TRPCResponse snapshotsListByPost(input)

List By Post

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SnapshotsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SnapshotsApi apiInstance = new SnapshotsApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.snapshotsListByPost(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SnapshotsApi#snapshotsListByPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

