# ApitrpcassetsUploadJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
**name** | **String** |  | 
**path** | **String** |  | 
**base64Content** | **String** |  | 
**mimeType** | **String** |  | 
**size** | [**BigDecimal**](BigDecimal.md) |  | 
**width** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**height** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**optimize** | **Boolean** |  | 
**maxWidth** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**outputFormat** | [**OutputFormatEnum**](#OutputFormatEnum) |  |  [optional]
**quality** | [**BigDecimal**](BigDecimal.md) |  |  [optional]

<a name="OutputFormatEnum"></a>
## Enum: OutputFormatEnum
Name | Value
---- | -----
WEBP | &quot;webp&quot;
JPEG | &quot;jpeg&quot;
PNG | &quot;png&quot;
ORIGINAL | &quot;original&quot;
