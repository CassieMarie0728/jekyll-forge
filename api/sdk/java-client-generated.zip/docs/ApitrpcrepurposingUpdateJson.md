# ApitrpcrepurposingUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**content** | **String** |  |  [optional]
**status** | **Object** |  |  [optional]
**isCustomized** | **Boolean** |  |  [optional]
