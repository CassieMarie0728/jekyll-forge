# BlocksApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**blocksCreate**](BlocksApi.md#blocksCreate) | **POST** /api/trpc/blocks.create | Create
[**blocksDelete**](BlocksApi.md#blocksDelete) | **POST** /api/trpc/blocks.delete | Delete
[**blocksList**](BlocksApi.md#blocksList) | **GET** /api/trpc/blocks.list | List
[**blocksUpdate**](BlocksApi.md#blocksUpdate) | **POST** /api/trpc/blocks.update | Update

<a name="blocksCreate"></a>
# **blocksCreate**
> TRPCResponse blocksCreate(body)

Create

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BlocksApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


BlocksApi apiInstance = new BlocksApi();
TrpcBlocksCreateBody body = new TrpcBlocksCreateBody(); // TrpcBlocksCreateBody | 
try {
    TRPCResponse result = apiInstance.blocksCreate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BlocksApi#blocksCreate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksCreateBody**](TrpcBlocksCreateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="blocksDelete"></a>
# **blocksDelete**
> TRPCResponse blocksDelete(body)

Delete

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BlocksApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


BlocksApi apiInstance = new BlocksApi();
TrpcBlocksDeleteBody body = new TrpcBlocksDeleteBody(); // TrpcBlocksDeleteBody | 
try {
    TRPCResponse result = apiInstance.blocksDelete(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BlocksApi#blocksDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksDeleteBody**](TrpcBlocksDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="blocksList"></a>
# **blocksList**
> TRPCResponse blocksList()

List

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BlocksApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


BlocksApi apiInstance = new BlocksApi();
try {
    TRPCResponse result = apiInstance.blocksList();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BlocksApi#blocksList");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="blocksUpdate"></a>
# **blocksUpdate**
> TRPCResponse blocksUpdate(body)

Update

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BlocksApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


BlocksApi apiInstance = new BlocksApi();
TrpcBlocksUpdateBody body = new TrpcBlocksUpdateBody(); // TrpcBlocksUpdateBody | 
try {
    TRPCResponse result = apiInstance.blocksUpdate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BlocksApi#blocksUpdate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksUpdateBody**](TrpcBlocksUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

