# TrpcAiProvidersSaveBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiProvidersSaveJson**](ApitrpcaiProvidersSaveJson.md) |  | 
