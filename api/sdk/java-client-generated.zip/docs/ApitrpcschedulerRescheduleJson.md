# ApitrpcschedulerRescheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  |  [optional]
