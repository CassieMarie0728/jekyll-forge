# TrpcGithubConnectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubConnectJson**](ApitrpcgithubConnectJson.md) |  | 
