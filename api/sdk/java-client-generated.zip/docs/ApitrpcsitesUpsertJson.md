# ApitrpcsitesUpsertJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**defaultBranch** | **String** |  |  [optional]
**selectedBranch** | **String** |  |  [optional]
**rootPath** | **String** |  |  [optional]
**isJekyll** | **Boolean** |  |  [optional]
**isFavorite** | **Boolean** |  |  [optional]
**timezone** | **String** |  |  [optional]
**defaultLayout** | **String** |  |  [optional]
**defaultAssetPath** | **String** |  |  [optional]
