# ApitrpcsocialMediaConnectAccountJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | [**PlatformEnum**](#PlatformEnum) |  | 
**accessToken** | **String** |  | 
**refreshToken** | **String** |  |  [optional]
**expiresAt** | **Object** |  |  [optional]
**accountId** | **String** |  | 
**username** | **String** |  |  [optional]
**displayName** | **String** |  |  [optional]
**profileImageUrl** | **String** |  |  [optional]

<a name="PlatformEnum"></a>
## Enum: PlatformEnum
Name | Value
---- | -----
TWITTER | &quot;twitter&quot;
LINKEDIN | &quot;linkedin&quot;
FACEBOOK | &quot;facebook&quot;
INSTAGRAM | &quot;instagram&quot;
