# GithubApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**githubCheckPluginCompatibility**](GithubApi.md#githubCheckPluginCompatibility) | **GET** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
[**githubCommitFile**](GithubApi.md#githubCommitFile) | **POST** /api/trpc/github.commitFile | Commit File
[**githubConnect**](GithubApi.md#githubConnect) | **POST** /api/trpc/github.connect | Connect
[**githubCreateBranch**](GithubApi.md#githubCreateBranch) | **POST** /api/trpc/github.createBranch | Create Branch
[**githubCreatePullRequest**](GithubApi.md#githubCreatePullRequest) | **POST** /api/trpc/github.createPullRequest | Create Pull Request
[**githubDeleteFile**](GithubApi.md#githubDeleteFile) | **POST** /api/trpc/github.deleteFile | Delete File
[**githubDetectJekyll**](GithubApi.md#githubDetectJekyll) | **GET** /api/trpc/github.detectJekyll | Detect Jekyll
[**githubDisconnect**](GithubApi.md#githubDisconnect) | **POST** /api/trpc/github.disconnect | Disconnect
[**githubGenerateActionsWorkflow**](GithubApi.md#githubGenerateActionsWorkflow) | **POST** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
[**githubGetFile**](GithubApi.md#githubGetFile) | **GET** /api/trpc/github.getFile | Get File
[**githubGetJekyllConfig**](GithubApi.md#githubGetJekyllConfig) | **GET** /api/trpc/github.getJekyllConfig | Get Jekyll Config
[**githubGetPagesStatus**](GithubApi.md#githubGetPagesStatus) | **GET** /api/trpc/github.getPagesStatus | Get Pages Status
[**githubGetRateLimit**](GithubApi.md#githubGetRateLimit) | **GET** /api/trpc/github.getRateLimit | Get Rate Limit
[**githubInventory**](GithubApi.md#githubInventory) | **GET** /api/trpc/github.inventory | Inventory
[**githubListBranches**](GithubApi.md#githubListBranches) | **GET** /api/trpc/github.listBranches | List Branches
[**githubListFiles**](GithubApi.md#githubListFiles) | **GET** /api/trpc/github.listFiles | List Files
[**githubListRepos**](GithubApi.md#githubListRepos) | **GET** /api/trpc/github.listRepos | List Repos
[**githubRepositories**](GithubApi.md#githubRepositories) | **GET** /api/trpc/github.repositories | Repositories
[**githubReviewFile**](GithubApi.md#githubReviewFile) | **GET** /api/trpc/github.reviewFile | Review File
[**githubStatus**](GithubApi.md#githubStatus) | **GET** /api/trpc/github.status | Status
[**githubUpdateJekyllConfig**](GithubApi.md#githubUpdateJekyllConfig) | **POST** /api/trpc/github.updateJekyllConfig | Update Jekyll Config

<a name="githubCheckPluginCompatibility"></a>
# **githubCheckPluginCompatibility**
> TRPCResponse githubCheckPluginCompatibility(input)

Check Plugin Compatibility

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubCheckPluginCompatibility(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubCheckPluginCompatibility");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubCommitFile"></a>
# **githubCommitFile**
> TRPCResponse githubCommitFile(body)

Commit File

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubCommitFileBody body = new TrpcGithubCommitFileBody(); // TrpcGithubCommitFileBody | 
try {
    TRPCResponse result = apiInstance.githubCommitFile(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubCommitFile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCommitFileBody**](TrpcGithubCommitFileBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubConnect"></a>
# **githubConnect**
> TRPCResponse githubConnect(body)

Connect

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubConnectBody body = new TrpcGithubConnectBody(); // TrpcGithubConnectBody | 
try {
    TRPCResponse result = apiInstance.githubConnect(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubConnect");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubConnectBody**](TrpcGithubConnectBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubCreateBranch"></a>
# **githubCreateBranch**
> TRPCResponse githubCreateBranch(body)

Create Branch

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubCreateBranchBody body = new TrpcGithubCreateBranchBody(); // TrpcGithubCreateBranchBody | 
try {
    TRPCResponse result = apiInstance.githubCreateBranch(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubCreateBranch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreateBranchBody**](TrpcGithubCreateBranchBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubCreatePullRequest"></a>
# **githubCreatePullRequest**
> TRPCResponse githubCreatePullRequest(body)

Create Pull Request

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubCreatePullRequestBody body = new TrpcGithubCreatePullRequestBody(); // TrpcGithubCreatePullRequestBody | 
try {
    TRPCResponse result = apiInstance.githubCreatePullRequest(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubCreatePullRequest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreatePullRequestBody**](TrpcGithubCreatePullRequestBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubDeleteFile"></a>
# **githubDeleteFile**
> TRPCResponse githubDeleteFile(body)

Delete File

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubDeleteFileBody body = new TrpcGithubDeleteFileBody(); // TrpcGithubDeleteFileBody | 
try {
    TRPCResponse result = apiInstance.githubDeleteFile(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubDeleteFile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDeleteFileBody**](TrpcGithubDeleteFileBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubDetectJekyll"></a>
# **githubDetectJekyll**
> TRPCResponse githubDetectJekyll(input)

Detect Jekyll

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubDetectJekyll(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubDetectJekyll");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubDisconnect"></a>
# **githubDisconnect**
> TRPCResponse githubDisconnect(body)

Disconnect

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubDisconnectBody body = new TrpcGithubDisconnectBody(); // TrpcGithubDisconnectBody | 
try {
    TRPCResponse result = apiInstance.githubDisconnect(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubDisconnect");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDisconnectBody**](TrpcGithubDisconnectBody.md)|  | [optional]

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubGenerateActionsWorkflow"></a>
# **githubGenerateActionsWorkflow**
> TRPCResponse githubGenerateActionsWorkflow(body)

Generate Actions Workflow

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubGenerateActionsWorkflowBody body = new TrpcGithubGenerateActionsWorkflowBody(); // TrpcGithubGenerateActionsWorkflowBody | 
try {
    TRPCResponse result = apiInstance.githubGenerateActionsWorkflow(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubGenerateActionsWorkflow");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubGenerateActionsWorkflowBody**](TrpcGithubGenerateActionsWorkflowBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubGetFile"></a>
# **githubGetFile**
> TRPCResponse githubGetFile(input)

Get File

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubGetFile(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubGetFile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetJekyllConfig"></a>
# **githubGetJekyllConfig**
> TRPCResponse githubGetJekyllConfig(input)

Get Jekyll Config

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubGetJekyllConfig(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubGetJekyllConfig");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetPagesStatus"></a>
# **githubGetPagesStatus**
> TRPCResponse githubGetPagesStatus(input)

Get Pages Status

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubGetPagesStatus(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubGetPagesStatus");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetRateLimit"></a>
# **githubGetRateLimit**
> TRPCResponse githubGetRateLimit()

Get Rate Limit

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
try {
    TRPCResponse result = apiInstance.githubGetRateLimit();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubGetRateLimit");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubInventory"></a>
# **githubInventory**
> TRPCResponse githubInventory(input)

Inventory

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubInventory(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubInventory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListBranches"></a>
# **githubListBranches**
> TRPCResponse githubListBranches(input)

List Branches

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubListBranches(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubListBranches");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListFiles"></a>
# **githubListFiles**
> TRPCResponse githubListFiles(input)

List Files

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubListFiles(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubListFiles");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListRepos"></a>
# **githubListRepos**
> TRPCResponse githubListRepos(input)

List Repos

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubListRepos(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubListRepos");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubRepositories"></a>
# **githubRepositories**
> TRPCResponse githubRepositories(input)

Repositories

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubRepositories(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubRepositories");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubReviewFile"></a>
# **githubReviewFile**
> TRPCResponse githubReviewFile(input)

Review File

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.githubReviewFile(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubReviewFile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubStatus"></a>
# **githubStatus**
> TRPCResponse githubStatus()

Status

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
try {
    TRPCResponse result = apiInstance.githubStatus();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubStatus");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubUpdateJekyllConfig"></a>
# **githubUpdateJekyllConfig**
> TRPCResponse githubUpdateJekyllConfig(body)

Update Jekyll Config

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.GithubApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


GithubApi apiInstance = new GithubApi();
TrpcGithubUpdateJekyllConfigBody body = new TrpcGithubUpdateJekyllConfigBody(); // TrpcGithubUpdateJekyllConfigBody | 
try {
    TRPCResponse result = apiInstance.githubUpdateJekyllConfig(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling GithubApi#githubUpdateJekyllConfig");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubUpdateJekyllConfigBody**](TrpcGithubUpdateJekyllConfigBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

