# TrpcAbTestingUpdateMetricsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingUpdateMetricsJson**](ApitrpcabTestingUpdateMetricsJson.md) |  | 
