# TRPCResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
