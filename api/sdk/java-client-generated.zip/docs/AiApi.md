# AiApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiGenerate**](AiApi.md#aiGenerate) | **POST** /api/trpc/ai.generate | Generate
[**aiGetSettings**](AiApi.md#aiGetSettings) | **GET** /api/trpc/ai.getSettings | Get Settings
[**aiGetUsageStats**](AiApi.md#aiGetUsageStats) | **GET** /api/trpc/ai.getUsageStats | Get Usage Stats
[**aiUpdateSettings**](AiApi.md#aiUpdateSettings) | **POST** /api/trpc/ai.updateSettings | Update Settings

<a name="aiGenerate"></a>
# **aiGenerate**
> TRPCResponse aiGenerate(body)

Generate

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiApi apiInstance = new AiApi();
TrpcAiGenerateBody body = new TrpcAiGenerateBody(); // TrpcAiGenerateBody | 
try {
    TRPCResponse result = apiInstance.aiGenerate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiApi#aiGenerate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiGenerateBody**](TrpcAiGenerateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiGetSettings"></a>
# **aiGetSettings**
> TRPCResponse aiGetSettings()

Get Settings

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiApi apiInstance = new AiApi();
try {
    TRPCResponse result = apiInstance.aiGetSettings();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiApi#aiGetSettings");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiGetUsageStats"></a>
# **aiGetUsageStats**
> TRPCResponse aiGetUsageStats()

Get Usage Stats

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiApi apiInstance = new AiApi();
try {
    TRPCResponse result = apiInstance.aiGetUsageStats();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiApi#aiGetUsageStats");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiUpdateSettings"></a>
# **aiUpdateSettings**
> TRPCResponse aiUpdateSettings(body)

Update Settings

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AiApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AiApi apiInstance = new AiApi();
TrpcAiUpdateSettingsBody body = new TrpcAiUpdateSettingsBody(); // TrpcAiUpdateSettingsBody | 
try {
    TRPCResponse result = apiInstance.aiUpdateSettings(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AiApi#aiUpdateSettings");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiUpdateSettingsBody**](TrpcAiUpdateSettingsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

