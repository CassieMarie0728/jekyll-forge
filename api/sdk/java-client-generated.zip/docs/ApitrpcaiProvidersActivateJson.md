# ApitrpcaiProvidersActivateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | **Object** |  | 
