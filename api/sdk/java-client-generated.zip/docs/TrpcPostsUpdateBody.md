# TrpcPostsUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcpostsUpdateJson**](ApitrpcpostsUpdateJson.md) |  | 
