# ApitrpcabTestingCompleteTestJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
