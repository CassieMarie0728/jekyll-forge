# TrpcGithubUpdateJekyllConfigBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubUpdateJekyllConfigJson**](ApitrpcgithubUpdateJekyllConfigJson.md) |  | 
