# TrpcGithubGenerateActionsWorkflowBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubGenerateActionsWorkflowJson**](ApitrpcgithubGenerateActionsWorkflowJson.md) |  | 
