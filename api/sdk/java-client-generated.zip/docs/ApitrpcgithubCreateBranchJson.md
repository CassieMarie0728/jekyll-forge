# ApitrpcgithubCreateBranchJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | **String** |  | 
**repo** | **String** |  | 
**branchName** | **String** |  | 
**fromBranch** | **String** |  | 
