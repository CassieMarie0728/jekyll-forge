# ApitrpcassetsReoptimizeJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**maxWidth** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**outputFormat** | [**OutputFormatEnum**](#OutputFormatEnum) |  |  [optional]
**quality** | [**BigDecimal**](BigDecimal.md) |  |  [optional]

<a name="OutputFormatEnum"></a>
## Enum: OutputFormatEnum
Name | Value
---- | -----
WEBP | &quot;webp&quot;
JPEG | &quot;jpeg&quot;
PNG | &quot;png&quot;
