# TrpcRepurposingRegenerateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcrepurposingRegenerateJson**](ApitrpcrepurposingRegenerateJson.md) |  | 
