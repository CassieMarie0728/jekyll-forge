# ApitrpcrepurposingGenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**BigDecimal**](BigDecimal.md) |  | 
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
**format** | [**FormatEnum**](#FormatEnum) |  | 

<a name="FormatEnum"></a>
## Enum: FormatEnum
Name | Value
---- | -----
TWITTER | &quot;twitter&quot;
LINKEDIN | &quot;linkedin&quot;
TIKTOK | &quot;tiktok&quot;
YOUTUBE | &quot;youtube&quot;
NEWSLETTER | &quot;newsletter&quot;
EMAIL | &quot;email&quot;
PODCAST | &quot;podcast&quot;
SLIDES | &quot;slides&quot;
