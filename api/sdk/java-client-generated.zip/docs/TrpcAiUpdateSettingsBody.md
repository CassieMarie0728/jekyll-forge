# TrpcAiUpdateSettingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiUpdateSettingsJson**](ApitrpcaiUpdateSettingsJson.md) |  | 
