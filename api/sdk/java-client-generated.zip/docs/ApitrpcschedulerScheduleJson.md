# ApitrpcschedulerScheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**BigDecimal**](BigDecimal.md) |  | 
**postId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**draftPath** | **String** |  | 
**targetPath** | **String** |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  | 
**commitMessage** | **String** |  |  [optional]
