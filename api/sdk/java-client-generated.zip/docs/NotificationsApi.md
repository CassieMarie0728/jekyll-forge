# NotificationsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**notificationsRegisterDevice**](NotificationsApi.md#notificationsRegisterDevice) | **POST** /api/trpc/notifications.registerDevice | Register Device
[**notificationsUnregisterDevice**](NotificationsApi.md#notificationsUnregisterDevice) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device

<a name="notificationsRegisterDevice"></a>
# **notificationsRegisterDevice**
> TRPCResponse notificationsRegisterDevice(body)

Register Device

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.NotificationsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


NotificationsApi apiInstance = new NotificationsApi();
TrpcNotificationsRegisterDeviceBody body = new TrpcNotificationsRegisterDeviceBody(); // TrpcNotificationsRegisterDeviceBody | 
try {
    TRPCResponse result = apiInstance.notificationsRegisterDevice(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling NotificationsApi#notificationsRegisterDevice");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsRegisterDeviceBody**](TrpcNotificationsRegisterDeviceBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="notificationsUnregisterDevice"></a>
# **notificationsUnregisterDevice**
> TRPCResponse notificationsUnregisterDevice(body)

Unregister Device

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.NotificationsApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


NotificationsApi apiInstance = new NotificationsApi();
TrpcNotificationsUnregisterDeviceBody body = new TrpcNotificationsUnregisterDeviceBody(); // TrpcNotificationsUnregisterDeviceBody | 
try {
    TRPCResponse result = apiInstance.notificationsUnregisterDevice(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling NotificationsApi#notificationsUnregisterDevice");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsUnregisterDeviceBody**](TrpcNotificationsUnregisterDeviceBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

