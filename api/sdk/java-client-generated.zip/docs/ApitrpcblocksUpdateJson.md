# ApitrpcblocksUpdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**name** | **String** |  |  [optional]
**category** | **String** |  |  [optional]
**content** | **String** |  |  [optional]
**contentType** | [**ContentTypeEnum**](#ContentTypeEnum) |  |  [optional]

<a name="ContentTypeEnum"></a>
## Enum: ContentTypeEnum
Name | Value
---- | -----
MARKDOWN | &quot;markdown&quot;
HTML | &quot;html&quot;
LIQUID | &quot;liquid&quot;
