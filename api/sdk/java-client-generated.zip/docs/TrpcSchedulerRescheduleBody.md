# TrpcSchedulerRescheduleBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulerRescheduleJson**](ApitrpcschedulerRescheduleJson.md) |  | 
