# RepurposingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**repurposingDelete**](RepurposingApi.md#repurposingDelete) | **POST** /api/trpc/repurposing.delete | Delete
[**repurposingGenerate**](RepurposingApi.md#repurposingGenerate) | **POST** /api/trpc/repurposing.generate | Generate
[**repurposingGetById**](RepurposingApi.md#repurposingGetById) | **GET** /api/trpc/repurposing.getById | Get By Id
[**repurposingGetByPost**](RepurposingApi.md#repurposingGetByPost) | **GET** /api/trpc/repurposing.getByPost | Get By Post
[**repurposingRegenerate**](RepurposingApi.md#repurposingRegenerate) | **POST** /api/trpc/repurposing.regenerate | Regenerate
[**repurposingUpdate**](RepurposingApi.md#repurposingUpdate) | **POST** /api/trpc/repurposing.update | Update

<a name="repurposingDelete"></a>
# **repurposingDelete**
> TRPCResponse repurposingDelete(body)

Delete

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RepurposingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


RepurposingApi apiInstance = new RepurposingApi();
TrpcRepurposingDeleteBody body = new TrpcRepurposingDeleteBody(); // TrpcRepurposingDeleteBody | 
try {
    TRPCResponse result = apiInstance.repurposingDelete(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RepurposingApi#repurposingDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingDeleteBody**](TrpcRepurposingDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingGenerate"></a>
# **repurposingGenerate**
> TRPCResponse repurposingGenerate(body)

Generate

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RepurposingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


RepurposingApi apiInstance = new RepurposingApi();
TrpcRepurposingGenerateBody body = new TrpcRepurposingGenerateBody(); // TrpcRepurposingGenerateBody | 
try {
    TRPCResponse result = apiInstance.repurposingGenerate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RepurposingApi#repurposingGenerate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingGenerateBody**](TrpcRepurposingGenerateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingGetById"></a>
# **repurposingGetById**
> TRPCResponse repurposingGetById(input)

Get By Id

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RepurposingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


RepurposingApi apiInstance = new RepurposingApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.repurposingGetById(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RepurposingApi#repurposingGetById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="repurposingGetByPost"></a>
# **repurposingGetByPost**
> TRPCResponse repurposingGetByPost(input)

Get By Post

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RepurposingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


RepurposingApi apiInstance = new RepurposingApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.repurposingGetByPost(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RepurposingApi#repurposingGetByPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="repurposingRegenerate"></a>
# **repurposingRegenerate**
> TRPCResponse repurposingRegenerate(body)

Regenerate

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RepurposingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


RepurposingApi apiInstance = new RepurposingApi();
TrpcRepurposingRegenerateBody body = new TrpcRepurposingRegenerateBody(); // TrpcRepurposingRegenerateBody | 
try {
    TRPCResponse result = apiInstance.repurposingRegenerate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RepurposingApi#repurposingRegenerate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingRegenerateBody**](TrpcRepurposingRegenerateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingUpdate"></a>
# **repurposingUpdate**
> TRPCResponse repurposingUpdate(body)

Update

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.RepurposingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


RepurposingApi apiInstance = new RepurposingApi();
TrpcRepurposingUpdateBody body = new TrpcRepurposingUpdateBody(); // TrpcRepurposingUpdateBody | 
try {
    TRPCResponse result = apiInstance.repurposingUpdate(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RepurposingApi#repurposingUpdate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingUpdateBody**](TrpcRepurposingUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

