# ApitrpcnotificationsRegisterDeviceJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | 
**platform** | [**PlatformEnum**](#PlatformEnum) |  | 

<a name="PlatformEnum"></a>
## Enum: PlatformEnum
Name | Value
---- | -----
ANDROID | &quot;android&quot;
