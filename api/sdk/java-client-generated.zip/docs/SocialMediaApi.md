# SocialMediaApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**socialMediaCancelScheduledPost**](SocialMediaApi.md#socialMediaCancelScheduledPost) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**socialMediaConnectAccount**](SocialMediaApi.md#socialMediaConnectAccount) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
[**socialMediaDisconnectAccount**](SocialMediaApi.md#socialMediaDisconnectAccount) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**socialMediaGetAccountDetails**](SocialMediaApi.md#socialMediaGetAccountDetails) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**socialMediaGetAccounts**](SocialMediaApi.md#socialMediaGetAccounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
[**socialMediaGetAnalyticsByPlatform**](SocialMediaApi.md#socialMediaGetAnalyticsByPlatform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**socialMediaGetAnalyticsSummary**](SocialMediaApi.md#socialMediaGetAnalyticsSummary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**socialMediaGetContentAnalytics**](SocialMediaApi.md#socialMediaGetContentAnalytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**socialMediaGetScheduledPosts**](SocialMediaApi.md#socialMediaGetScheduledPosts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**socialMediaPublishContent**](SocialMediaApi.md#socialMediaPublishContent) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
[**socialMediaReschedulePost**](SocialMediaApi.md#socialMediaReschedulePost) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**socialMediaSchedulePost**](SocialMediaApi.md#socialMediaSchedulePost) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
[**socialMediaSyncAnalytics**](SocialMediaApi.md#socialMediaSyncAnalytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

<a name="socialMediaCancelScheduledPost"></a>
# **socialMediaCancelScheduledPost**
> TRPCResponse socialMediaCancelScheduledPost(body)

Cancel Scheduled Post

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaCancelScheduledPostBody body = new TrpcSocialMediaCancelScheduledPostBody(); // TrpcSocialMediaCancelScheduledPostBody | 
try {
    TRPCResponse result = apiInstance.socialMediaCancelScheduledPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaCancelScheduledPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaCancelScheduledPostBody**](TrpcSocialMediaCancelScheduledPostBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaConnectAccount"></a>
# **socialMediaConnectAccount**
> TRPCResponse socialMediaConnectAccount(body)

Connect Account

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaConnectAccountBody body = new TrpcSocialMediaConnectAccountBody(); // TrpcSocialMediaConnectAccountBody | 
try {
    TRPCResponse result = apiInstance.socialMediaConnectAccount(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaConnectAccount");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaConnectAccountBody**](TrpcSocialMediaConnectAccountBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaDisconnectAccount"></a>
# **socialMediaDisconnectAccount**
> TRPCResponse socialMediaDisconnectAccount(body)

Disconnect Account

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaDisconnectAccountBody body = new TrpcSocialMediaDisconnectAccountBody(); // TrpcSocialMediaDisconnectAccountBody | 
try {
    TRPCResponse result = apiInstance.socialMediaDisconnectAccount(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaDisconnectAccount");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaDisconnectAccountBody**](TrpcSocialMediaDisconnectAccountBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaGetAccountDetails"></a>
# **socialMediaGetAccountDetails**
> TRPCResponse socialMediaGetAccountDetails(input)

Get Account Details

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.socialMediaGetAccountDetails(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaGetAccountDetails");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAccounts"></a>
# **socialMediaGetAccounts**
> TRPCResponse socialMediaGetAccounts()

Get Accounts

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
try {
    TRPCResponse result = apiInstance.socialMediaGetAccounts();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaGetAccounts");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAnalyticsByPlatform"></a>
# **socialMediaGetAnalyticsByPlatform**
> TRPCResponse socialMediaGetAnalyticsByPlatform(input)

Get Analytics By Platform

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.socialMediaGetAnalyticsByPlatform(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaGetAnalyticsByPlatform");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAnalyticsSummary"></a>
# **socialMediaGetAnalyticsSummary**
> TRPCResponse socialMediaGetAnalyticsSummary()

Get Analytics Summary

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
try {
    TRPCResponse result = apiInstance.socialMediaGetAnalyticsSummary();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaGetAnalyticsSummary");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetContentAnalytics"></a>
# **socialMediaGetContentAnalytics**
> TRPCResponse socialMediaGetContentAnalytics(input)

Get Content Analytics

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.socialMediaGetContentAnalytics(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaGetContentAnalytics");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetScheduledPosts"></a>
# **socialMediaGetScheduledPosts**
> TRPCResponse socialMediaGetScheduledPosts(input)

Get Scheduled Posts

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
String input = "input_example"; // String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    TRPCResponse result = apiInstance.socialMediaGetScheduledPosts(input);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaGetScheduledPosts");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaPublishContent"></a>
# **socialMediaPublishContent**
> TRPCResponse socialMediaPublishContent(body)

Publish Content

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaPublishContentBody body = new TrpcSocialMediaPublishContentBody(); // TrpcSocialMediaPublishContentBody | 
try {
    TRPCResponse result = apiInstance.socialMediaPublishContent(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaPublishContent");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaPublishContentBody**](TrpcSocialMediaPublishContentBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaReschedulePost"></a>
# **socialMediaReschedulePost**
> TRPCResponse socialMediaReschedulePost(body)

Reschedule Post

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaReschedulePostBody body = new TrpcSocialMediaReschedulePostBody(); // TrpcSocialMediaReschedulePostBody | 
try {
    TRPCResponse result = apiInstance.socialMediaReschedulePost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaReschedulePost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaReschedulePostBody**](TrpcSocialMediaReschedulePostBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaSchedulePost"></a>
# **socialMediaSchedulePost**
> TRPCResponse socialMediaSchedulePost(body)

Schedule Post

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaSchedulePostBody body = new TrpcSocialMediaSchedulePostBody(); // TrpcSocialMediaSchedulePostBody | 
try {
    TRPCResponse result = apiInstance.socialMediaSchedulePost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaSchedulePost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSchedulePostBody**](TrpcSocialMediaSchedulePostBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaSyncAnalytics"></a>
# **socialMediaSyncAnalytics**
> TRPCResponse socialMediaSyncAnalytics(body)

Sync Analytics

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SocialMediaApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SocialMediaApi apiInstance = new SocialMediaApi();
TrpcSocialMediaSyncAnalyticsBody body = new TrpcSocialMediaSyncAnalyticsBody(); // TrpcSocialMediaSyncAnalyticsBody | 
try {
    TRPCResponse result = apiInstance.socialMediaSyncAnalytics(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SocialMediaApi#socialMediaSyncAnalytics");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSyncAnalyticsBody**](TrpcSocialMediaSyncAnalyticsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

