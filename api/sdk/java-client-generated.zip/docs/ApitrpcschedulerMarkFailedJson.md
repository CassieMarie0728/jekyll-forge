# ApitrpcschedulerMarkFailedJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**errorMessage** | **String** |  | 
