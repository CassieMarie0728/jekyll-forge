# TrpcAssetsUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsUpdateJson**](ApitrpcassetsUpdateJson.md) |  | 
