# TrpcNotificationsUnregisterDeviceBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcnotificationsUnregisterDeviceJson**](ApitrpcnotificationsUnregisterDeviceJson.md) |  | 
