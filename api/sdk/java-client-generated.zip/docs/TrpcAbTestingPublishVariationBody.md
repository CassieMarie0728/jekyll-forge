# TrpcAbTestingPublishVariationBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingPublishVariationJson**](ApitrpcabTestingPublishVariationJson.md) |  | 
