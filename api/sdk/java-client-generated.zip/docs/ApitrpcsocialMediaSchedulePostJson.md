# ApitrpcsocialMediaSchedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposedContentId** | [**BigDecimal**](BigDecimal.md) |  | 
**socialMediaAccountId** | [**BigDecimal**](BigDecimal.md) |  | 
**scheduledAt** | **Object** |  | 
**timezone** | **String** |  |  [optional]
