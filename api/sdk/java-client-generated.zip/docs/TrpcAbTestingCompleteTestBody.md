# TrpcAbTestingCompleteTestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingCompleteTestJson**](ApitrpcabTestingCompleteTestJson.md) |  | 
