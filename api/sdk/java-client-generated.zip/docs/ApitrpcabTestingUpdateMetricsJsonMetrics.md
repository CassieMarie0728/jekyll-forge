# ApitrpcabTestingUpdateMetricsJsonMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**impressions** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**engagements** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**clicks** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**shares** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**likes** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**replies** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
