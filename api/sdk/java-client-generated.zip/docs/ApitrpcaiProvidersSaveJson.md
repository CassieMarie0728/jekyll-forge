# ApitrpcaiProvidersSaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | **Object** |  | 
**model** | **String** |  | 
**apiKey** | **String** |  | 
