# io.swagger.client - Kotlin client library for Jekyll Forge API

## Requires

* Kotlin 1.4.30
* Gradle 5.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *http://localhost:3000*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AbTestingApi* | [**abTestingApplyWinner**](docs/AbTestingApi.md#abtestingapplywinner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
*AbTestingApi* | [**abTestingCompleteTest**](docs/AbTestingApi.md#abtestingcompletetest) | **POST** /api/trpc/abTesting.completeTest | Complete Test
*AbTestingApi* | [**abTestingGenerateVariations**](docs/AbTestingApi.md#abtestinggeneratevariations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
*AbTestingApi* | [**abTestingGetResults**](docs/AbTestingApi.md#abtestinggetresults) | **GET** /api/trpc/abTesting.getResults | Get Results
*AbTestingApi* | [**abTestingGetVariations**](docs/AbTestingApi.md#abtestinggetvariations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
*AbTestingApi* | [**abTestingPublishVariation**](docs/AbTestingApi.md#abtestingpublishvariation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
*AbTestingApi* | [**abTestingUpdateMetrics**](docs/AbTestingApi.md#abtestingupdatemetrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics
*AiApi* | [**aiGenerate**](docs/AiApi.md#aigenerate) | **POST** /api/trpc/ai.generate | Generate
*AiApi* | [**aiGetSettings**](docs/AiApi.md#aigetsettings) | **GET** /api/trpc/ai.getSettings | Get Settings
*AiApi* | [**aiGetUsageStats**](docs/AiApi.md#aigetusagestats) | **GET** /api/trpc/ai.getUsageStats | Get Usage Stats
*AiApi* | [**aiUpdateSettings**](docs/AiApi.md#aiupdatesettings) | **POST** /api/trpc/ai.updateSettings | Update Settings
*AiProvidersApi* | [**aiProvidersActivate**](docs/AiProvidersApi.md#aiprovidersactivate) | **POST** /api/trpc/aiProviders.activate | Activate
*AiProvidersApi* | [**aiProvidersGetSettings**](docs/AiProvidersApi.md#aiprovidersgetsettings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
*AiProvidersApi* | [**aiProvidersRemove**](docs/AiProvidersApi.md#aiprovidersremove) | **POST** /api/trpc/aiProviders.remove | Remove
*AiProvidersApi* | [**aiProvidersSave**](docs/AiProvidersApi.md#aiproviderssave) | **POST** /api/trpc/aiProviders.save | Save
*AiProvidersApi* | [**aiProvidersTest**](docs/AiProvidersApi.md#aiproviderstest) | **POST** /api/trpc/aiProviders.test | Test
*AssetsApi* | [**assetsDelete**](docs/AssetsApi.md#assetsdelete) | **POST** /api/trpc/assets.delete | Delete
*AssetsApi* | [**assetsGenerateAltText**](docs/AssetsApi.md#assetsgeneratealttext) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
*AssetsApi* | [**assetsList**](docs/AssetsApi.md#assetslist) | **GET** /api/trpc/assets.list | List
*AssetsApi* | [**assetsReoptimize**](docs/AssetsApi.md#assetsreoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
*AssetsApi* | [**assetsUpdate**](docs/AssetsApi.md#assetsupdate) | **POST** /api/trpc/assets.update | Update
*AssetsApi* | [**assetsUpload**](docs/AssetsApi.md#assetsupload) | **POST** /api/trpc/assets.upload | Upload
*BlocksApi* | [**blocksCreate**](docs/BlocksApi.md#blockscreate) | **POST** /api/trpc/blocks.create | Create
*BlocksApi* | [**blocksDelete**](docs/BlocksApi.md#blocksdelete) | **POST** /api/trpc/blocks.delete | Delete
*BlocksApi* | [**blocksList**](docs/BlocksApi.md#blockslist) | **GET** /api/trpc/blocks.list | List
*BlocksApi* | [**blocksUpdate**](docs/BlocksApi.md#blocksupdate) | **POST** /api/trpc/blocks.update | Update
*GithubApi* | [**githubCheckPluginCompatibility**](docs/GithubApi.md#githubcheckplugincompatibility) | **GET** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
*GithubApi* | [**githubCommitFile**](docs/GithubApi.md#githubcommitfile) | **POST** /api/trpc/github.commitFile | Commit File
*GithubApi* | [**githubConnect**](docs/GithubApi.md#githubconnect) | **POST** /api/trpc/github.connect | Connect
*GithubApi* | [**githubCreateBranch**](docs/GithubApi.md#githubcreatebranch) | **POST** /api/trpc/github.createBranch | Create Branch
*GithubApi* | [**githubCreatePullRequest**](docs/GithubApi.md#githubcreatepullrequest) | **POST** /api/trpc/github.createPullRequest | Create Pull Request
*GithubApi* | [**githubDeleteFile**](docs/GithubApi.md#githubdeletefile) | **POST** /api/trpc/github.deleteFile | Delete File
*GithubApi* | [**githubDetectJekyll**](docs/GithubApi.md#githubdetectjekyll) | **GET** /api/trpc/github.detectJekyll | Detect Jekyll
*GithubApi* | [**githubDisconnect**](docs/GithubApi.md#githubdisconnect) | **POST** /api/trpc/github.disconnect | Disconnect
*GithubApi* | [**githubGenerateActionsWorkflow**](docs/GithubApi.md#githubgenerateactionsworkflow) | **POST** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
*GithubApi* | [**githubGetFile**](docs/GithubApi.md#githubgetfile) | **GET** /api/trpc/github.getFile | Get File
*GithubApi* | [**githubGetJekyllConfig**](docs/GithubApi.md#githubgetjekyllconfig) | **GET** /api/trpc/github.getJekyllConfig | Get Jekyll Config
*GithubApi* | [**githubGetPagesStatus**](docs/GithubApi.md#githubgetpagesstatus) | **GET** /api/trpc/github.getPagesStatus | Get Pages Status
*GithubApi* | [**githubGetRateLimit**](docs/GithubApi.md#githubgetratelimit) | **GET** /api/trpc/github.getRateLimit | Get Rate Limit
*GithubApi* | [**githubInventory**](docs/GithubApi.md#githubinventory) | **GET** /api/trpc/github.inventory | Inventory
*GithubApi* | [**githubListBranches**](docs/GithubApi.md#githublistbranches) | **GET** /api/trpc/github.listBranches | List Branches
*GithubApi* | [**githubListFiles**](docs/GithubApi.md#githublistfiles) | **GET** /api/trpc/github.listFiles | List Files
*GithubApi* | [**githubListRepos**](docs/GithubApi.md#githublistrepos) | **GET** /api/trpc/github.listRepos | List Repos
*GithubApi* | [**githubRepositories**](docs/GithubApi.md#githubrepositories) | **GET** /api/trpc/github.repositories | Repositories
*GithubApi* | [**githubReviewFile**](docs/GithubApi.md#githubreviewfile) | **GET** /api/trpc/github.reviewFile | Review File
*GithubApi* | [**githubStatus**](docs/GithubApi.md#githubstatus) | **GET** /api/trpc/github.status | Status
*GithubApi* | [**githubUpdateJekyllConfig**](docs/GithubApi.md#githubupdatejekyllconfig) | **POST** /api/trpc/github.updateJekyllConfig | Update Jekyll Config
*NotificationsApi* | [**notificationsRegisterDevice**](docs/NotificationsApi.md#notificationsregisterdevice) | **POST** /api/trpc/notifications.registerDevice | Register Device
*NotificationsApi* | [**notificationsUnregisterDevice**](docs/NotificationsApi.md#notificationsunregisterdevice) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device
*PostsApi* | [**postsAutosave**](docs/PostsApi.md#postsautosave) | **POST** /api/trpc/posts.autosave | Autosave
*PostsApi* | [**postsDelete**](docs/PostsApi.md#postsdelete) | **POST** /api/trpc/posts.delete | Delete
*PostsApi* | [**postsGet**](docs/PostsApi.md#postsget) | **GET** /api/trpc/posts.get | Get
*PostsApi* | [**postsGetFrontMatterTemplates**](docs/PostsApi.md#postsgetfrontmattertemplates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
*PostsApi* | [**postsList**](docs/PostsApi.md#postslist) | **GET** /api/trpc/posts.list | List
*PostsApi* | [**postsUpdate**](docs/PostsApi.md#postsupdate) | **POST** /api/trpc/posts.update | Update
*PostsApi* | [**postsUpsert**](docs/PostsApi.md#postsupsert) | **POST** /api/trpc/posts.upsert | Upsert
*RepurposingApi* | [**repurposingDelete**](docs/RepurposingApi.md#repurposingdelete) | **POST** /api/trpc/repurposing.delete | Delete
*RepurposingApi* | [**repurposingGenerate**](docs/RepurposingApi.md#repurposinggenerate) | **POST** /api/trpc/repurposing.generate | Generate
*RepurposingApi* | [**repurposingGetById**](docs/RepurposingApi.md#repurposinggetbyid) | **GET** /api/trpc/repurposing.getById | Get By Id
*RepurposingApi* | [**repurposingGetByPost**](docs/RepurposingApi.md#repurposinggetbypost) | **GET** /api/trpc/repurposing.getByPost | Get By Post
*RepurposingApi* | [**repurposingRegenerate**](docs/RepurposingApi.md#repurposingregenerate) | **POST** /api/trpc/repurposing.regenerate | Regenerate
*RepurposingApi* | [**repurposingUpdate**](docs/RepurposingApi.md#repurposingupdate) | **POST** /api/trpc/repurposing.update | Update
*SchedulerApi* | [**schedulerCancel**](docs/SchedulerApi.md#schedulercancel) | **POST** /api/trpc/scheduler.cancel | Cancel
*SchedulerApi* | [**schedulerCancelAll**](docs/SchedulerApi.md#schedulercancelall) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
*SchedulerApi* | [**schedulerList**](docs/SchedulerApi.md#schedulerlist) | **GET** /api/trpc/scheduler.list | List
*SchedulerApi* | [**schedulerListHeartbeatJobs**](docs/SchedulerApi.md#schedulerlistheartbeatjobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
*SchedulerApi* | [**schedulerMarkFailed**](docs/SchedulerApi.md#schedulermarkfailed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
*SchedulerApi* | [**schedulerMarkPublished**](docs/SchedulerApi.md#schedulermarkpublished) | **POST** /api/trpc/scheduler.markPublished | Mark Published
*SchedulerApi* | [**schedulerReschedule**](docs/SchedulerApi.md#schedulerreschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
*SchedulerApi* | [**schedulerSchedule**](docs/SchedulerApi.md#schedulerschedule) | **POST** /api/trpc/scheduler.schedule | Schedule
*SitesApi* | [**sitesDelete**](docs/SitesApi.md#sitesdelete) | **POST** /api/trpc/sites.delete | Delete
*SitesApi* | [**sitesGet**](docs/SitesApi.md#sitesget) | **GET** /api/trpc/sites.get | Get
*SitesApi* | [**sitesList**](docs/SitesApi.md#siteslist) | **GET** /api/trpc/sites.list | List
*SitesApi* | [**sitesUpdate**](docs/SitesApi.md#sitesupdate) | **POST** /api/trpc/sites.update | Update
*SitesApi* | [**sitesUpsert**](docs/SitesApi.md#sitesupsert) | **POST** /api/trpc/sites.upsert | Upsert
*SnapshotsApi* | [**snapshotsCreate**](docs/SnapshotsApi.md#snapshotscreate) | **POST** /api/trpc/snapshots.create | Create
*SnapshotsApi* | [**snapshotsGet**](docs/SnapshotsApi.md#snapshotsget) | **GET** /api/trpc/snapshots.get | Get
*SnapshotsApi* | [**snapshotsListByPost**](docs/SnapshotsApi.md#snapshotslistbypost) | **GET** /api/trpc/snapshots.listByPost | List By Post
*SocialMediaApi* | [**socialMediaCancelScheduledPost**](docs/SocialMediaApi.md#socialmediacancelscheduledpost) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
*SocialMediaApi* | [**socialMediaConnectAccount**](docs/SocialMediaApi.md#socialmediaconnectaccount) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
*SocialMediaApi* | [**socialMediaDisconnectAccount**](docs/SocialMediaApi.md#socialmediadisconnectaccount) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
*SocialMediaApi* | [**socialMediaGetAccountDetails**](docs/SocialMediaApi.md#socialmediagetaccountdetails) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
*SocialMediaApi* | [**socialMediaGetAccounts**](docs/SocialMediaApi.md#socialmediagetaccounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
*SocialMediaApi* | [**socialMediaGetAnalyticsByPlatform**](docs/SocialMediaApi.md#socialmediagetanalyticsbyplatform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
*SocialMediaApi* | [**socialMediaGetAnalyticsSummary**](docs/SocialMediaApi.md#socialmediagetanalyticssummary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
*SocialMediaApi* | [**socialMediaGetContentAnalytics**](docs/SocialMediaApi.md#socialmediagetcontentanalytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
*SocialMediaApi* | [**socialMediaGetScheduledPosts**](docs/SocialMediaApi.md#socialmediagetscheduledposts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
*SocialMediaApi* | [**socialMediaPublishContent**](docs/SocialMediaApi.md#socialmediapublishcontent) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
*SocialMediaApi* | [**socialMediaReschedulePost**](docs/SocialMediaApi.md#socialmediareschedulepost) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
*SocialMediaApi* | [**socialMediaSchedulePost**](docs/SocialMediaApi.md#socialmediaschedulepost) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
*SocialMediaApi* | [**socialMediaSyncAnalytics**](docs/SocialMediaApi.md#socialmediasyncanalytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.ApitrpcabTestingapplyWinnerJson](docs/ApitrpcabTestingapplyWinnerJson.md)
 - [io.swagger.client.models.ApitrpcabTestingcompleteTestJson](docs/ApitrpcabTestingcompleteTestJson.md)
 - [io.swagger.client.models.ApitrpcabTestinggenerateVariationsJson](docs/ApitrpcabTestinggenerateVariationsJson.md)
 - [io.swagger.client.models.ApitrpcabTestingpublishVariationJson](docs/ApitrpcabTestingpublishVariationJson.md)
 - [io.swagger.client.models.ApitrpcabTestingupdateMetricsJson](docs/ApitrpcabTestingupdateMetricsJson.md)
 - [io.swagger.client.models.ApitrpcabTestingupdateMetricsJsonMetrics](docs/ApitrpcabTestingupdateMetricsJsonMetrics.md)
 - [io.swagger.client.models.ApitrpcaiProvidersactivateJson](docs/ApitrpcaiProvidersactivateJson.md)
 - [io.swagger.client.models.ApitrpcaiProviderssaveJson](docs/ApitrpcaiProviderssaveJson.md)
 - [io.swagger.client.models.ApitrpcaigenerateJson](docs/ApitrpcaigenerateJson.md)
 - [io.swagger.client.models.ApitrpcaiupdateSettingsJson](docs/ApitrpcaiupdateSettingsJson.md)
 - [io.swagger.client.models.ApitrpcassetsdeleteJson](docs/ApitrpcassetsdeleteJson.md)
 - [io.swagger.client.models.ApitrpcassetsgenerateAltTextJson](docs/ApitrpcassetsgenerateAltTextJson.md)
 - [io.swagger.client.models.ApitrpcassetsreoptimizeJson](docs/ApitrpcassetsreoptimizeJson.md)
 - [io.swagger.client.models.ApitrpcassetsupdateJson](docs/ApitrpcassetsupdateJson.md)
 - [io.swagger.client.models.ApitrpcassetsuploadJson](docs/ApitrpcassetsuploadJson.md)
 - [io.swagger.client.models.ApitrpcblockscreateJson](docs/ApitrpcblockscreateJson.md)
 - [io.swagger.client.models.ApitrpcblocksupdateJson](docs/ApitrpcblocksupdateJson.md)
 - [io.swagger.client.models.ApitrpcgithubcommitFileJson](docs/ApitrpcgithubcommitFileJson.md)
 - [io.swagger.client.models.ApitrpcgithubconnectJson](docs/ApitrpcgithubconnectJson.md)
 - [io.swagger.client.models.ApitrpcgithubcreateBranchJson](docs/ApitrpcgithubcreateBranchJson.md)
 - [io.swagger.client.models.ApitrpcgithubcreatePullRequestJson](docs/ApitrpcgithubcreatePullRequestJson.md)
 - [io.swagger.client.models.ApitrpcgithubdeleteFileJson](docs/ApitrpcgithubdeleteFileJson.md)
 - [io.swagger.client.models.ApitrpcgithubgenerateActionsWorkflowJson](docs/ApitrpcgithubgenerateActionsWorkflowJson.md)
 - [io.swagger.client.models.ApitrpcgithubupdateJekyllConfigJson](docs/ApitrpcgithubupdateJekyllConfigJson.md)
 - [io.swagger.client.models.ApitrpcnotificationsregisterDeviceJson](docs/ApitrpcnotificationsregisterDeviceJson.md)
 - [io.swagger.client.models.ApitrpcnotificationsunregisterDeviceJson](docs/ApitrpcnotificationsunregisterDeviceJson.md)
 - [io.swagger.client.models.ApitrpcpostsautosaveJson](docs/ApitrpcpostsautosaveJson.md)
 - [io.swagger.client.models.ApitrpcpostsupdateJson](docs/ApitrpcpostsupdateJson.md)
 - [io.swagger.client.models.ApitrpcpostsupsertJson](docs/ApitrpcpostsupsertJson.md)
 - [io.swagger.client.models.ApitrpcrepurposinggenerateJson](docs/ApitrpcrepurposinggenerateJson.md)
 - [io.swagger.client.models.ApitrpcrepurposingregenerateJson](docs/ApitrpcrepurposingregenerateJson.md)
 - [io.swagger.client.models.ApitrpcrepurposingupdateJson](docs/ApitrpcrepurposingupdateJson.md)
 - [io.swagger.client.models.ApitrpcschedulercancelAllJson](docs/ApitrpcschedulercancelAllJson.md)
 - [io.swagger.client.models.ApitrpcschedulermarkFailedJson](docs/ApitrpcschedulermarkFailedJson.md)
 - [io.swagger.client.models.ApitrpcschedulerrescheduleJson](docs/ApitrpcschedulerrescheduleJson.md)
 - [io.swagger.client.models.ApitrpcschedulerscheduleJson](docs/ApitrpcschedulerscheduleJson.md)
 - [io.swagger.client.models.ApitrpcsitesupdateJson](docs/ApitrpcsitesupdateJson.md)
 - [io.swagger.client.models.ApitrpcsitesupsertJson](docs/ApitrpcsitesupsertJson.md)
 - [io.swagger.client.models.ApitrpcsnapshotscreateJson](docs/ApitrpcsnapshotscreateJson.md)
 - [io.swagger.client.models.ApitrpcsocialMediaconnectAccountJson](docs/ApitrpcsocialMediaconnectAccountJson.md)
 - [io.swagger.client.models.ApitrpcsocialMediapublishContentJson](docs/ApitrpcsocialMediapublishContentJson.md)
 - [io.swagger.client.models.ApitrpcsocialMediareschedulePostJson](docs/ApitrpcsocialMediareschedulePostJson.md)
 - [io.swagger.client.models.ApitrpcsocialMediaschedulePostJson](docs/ApitrpcsocialMediaschedulePostJson.md)
 - [io.swagger.client.models.ApitrpcsocialMediasyncAnalyticsJson](docs/ApitrpcsocialMediasyncAnalyticsJson.md)
 - [io.swagger.client.models.Error](docs/Error.md)
 - [io.swagger.client.models.TRPCResponse](docs/TRPCResponse.md)
 - [io.swagger.client.models.TrpcAbTestingApplyWinnerBody](docs/TrpcAbTestingApplyWinnerBody.md)
 - [io.swagger.client.models.TrpcAbTestingCompleteTestBody](docs/TrpcAbTestingCompleteTestBody.md)
 - [io.swagger.client.models.TrpcAbTestingGenerateVariationsBody](docs/TrpcAbTestingGenerateVariationsBody.md)
 - [io.swagger.client.models.TrpcAbTestingPublishVariationBody](docs/TrpcAbTestingPublishVariationBody.md)
 - [io.swagger.client.models.TrpcAbTestingUpdateMetricsBody](docs/TrpcAbTestingUpdateMetricsBody.md)
 - [io.swagger.client.models.TrpcAiGenerateBody](docs/TrpcAiGenerateBody.md)
 - [io.swagger.client.models.TrpcAiProvidersActivateBody](docs/TrpcAiProvidersActivateBody.md)
 - [io.swagger.client.models.TrpcAiProvidersRemoveBody](docs/TrpcAiProvidersRemoveBody.md)
 - [io.swagger.client.models.TrpcAiProvidersSaveBody](docs/TrpcAiProvidersSaveBody.md)
 - [io.swagger.client.models.TrpcAiProvidersTestBody](docs/TrpcAiProvidersTestBody.md)
 - [io.swagger.client.models.TrpcAiUpdateSettingsBody](docs/TrpcAiUpdateSettingsBody.md)
 - [io.swagger.client.models.TrpcAssetsDeleteBody](docs/TrpcAssetsDeleteBody.md)
 - [io.swagger.client.models.TrpcAssetsGenerateAltTextBody](docs/TrpcAssetsGenerateAltTextBody.md)
 - [io.swagger.client.models.TrpcAssetsReoptimizeBody](docs/TrpcAssetsReoptimizeBody.md)
 - [io.swagger.client.models.TrpcAssetsUpdateBody](docs/TrpcAssetsUpdateBody.md)
 - [io.swagger.client.models.TrpcAssetsUploadBody](docs/TrpcAssetsUploadBody.md)
 - [io.swagger.client.models.TrpcBlocksCreateBody](docs/TrpcBlocksCreateBody.md)
 - [io.swagger.client.models.TrpcBlocksDeleteBody](docs/TrpcBlocksDeleteBody.md)
 - [io.swagger.client.models.TrpcBlocksUpdateBody](docs/TrpcBlocksUpdateBody.md)
 - [io.swagger.client.models.TrpcGithubCommitFileBody](docs/TrpcGithubCommitFileBody.md)
 - [io.swagger.client.models.TrpcGithubConnectBody](docs/TrpcGithubConnectBody.md)
 - [io.swagger.client.models.TrpcGithubCreateBranchBody](docs/TrpcGithubCreateBranchBody.md)
 - [io.swagger.client.models.TrpcGithubCreatePullRequestBody](docs/TrpcGithubCreatePullRequestBody.md)
 - [io.swagger.client.models.TrpcGithubDeleteFileBody](docs/TrpcGithubDeleteFileBody.md)
 - [io.swagger.client.models.TrpcGithubDisconnectBody](docs/TrpcGithubDisconnectBody.md)
 - [io.swagger.client.models.TrpcGithubGenerateActionsWorkflowBody](docs/TrpcGithubGenerateActionsWorkflowBody.md)
 - [io.swagger.client.models.TrpcGithubUpdateJekyllConfigBody](docs/TrpcGithubUpdateJekyllConfigBody.md)
 - [io.swagger.client.models.TrpcNotificationsRegisterDeviceBody](docs/TrpcNotificationsRegisterDeviceBody.md)
 - [io.swagger.client.models.TrpcNotificationsUnregisterDeviceBody](docs/TrpcNotificationsUnregisterDeviceBody.md)
 - [io.swagger.client.models.TrpcPostsAutosaveBody](docs/TrpcPostsAutosaveBody.md)
 - [io.swagger.client.models.TrpcPostsDeleteBody](docs/TrpcPostsDeleteBody.md)
 - [io.swagger.client.models.TrpcPostsUpdateBody](docs/TrpcPostsUpdateBody.md)
 - [io.swagger.client.models.TrpcPostsUpsertBody](docs/TrpcPostsUpsertBody.md)
 - [io.swagger.client.models.TrpcRepurposingDeleteBody](docs/TrpcRepurposingDeleteBody.md)
 - [io.swagger.client.models.TrpcRepurposingGenerateBody](docs/TrpcRepurposingGenerateBody.md)
 - [io.swagger.client.models.TrpcRepurposingRegenerateBody](docs/TrpcRepurposingRegenerateBody.md)
 - [io.swagger.client.models.TrpcRepurposingUpdateBody](docs/TrpcRepurposingUpdateBody.md)
 - [io.swagger.client.models.TrpcSchedulerCancelAllBody](docs/TrpcSchedulerCancelAllBody.md)
 - [io.swagger.client.models.TrpcSchedulerCancelBody](docs/TrpcSchedulerCancelBody.md)
 - [io.swagger.client.models.TrpcSchedulerMarkFailedBody](docs/TrpcSchedulerMarkFailedBody.md)
 - [io.swagger.client.models.TrpcSchedulerMarkPublishedBody](docs/TrpcSchedulerMarkPublishedBody.md)
 - [io.swagger.client.models.TrpcSchedulerRescheduleBody](docs/TrpcSchedulerRescheduleBody.md)
 - [io.swagger.client.models.TrpcSchedulerScheduleBody](docs/TrpcSchedulerScheduleBody.md)
 - [io.swagger.client.models.TrpcSitesDeleteBody](docs/TrpcSitesDeleteBody.md)
 - [io.swagger.client.models.TrpcSitesUpdateBody](docs/TrpcSitesUpdateBody.md)
 - [io.swagger.client.models.TrpcSitesUpsertBody](docs/TrpcSitesUpsertBody.md)
 - [io.swagger.client.models.TrpcSnapshotsCreateBody](docs/TrpcSnapshotsCreateBody.md)
 - [io.swagger.client.models.TrpcSocialMediaCancelScheduledPostBody](docs/TrpcSocialMediaCancelScheduledPostBody.md)
 - [io.swagger.client.models.TrpcSocialMediaConnectAccountBody](docs/TrpcSocialMediaConnectAccountBody.md)
 - [io.swagger.client.models.TrpcSocialMediaDisconnectAccountBody](docs/TrpcSocialMediaDisconnectAccountBody.md)
 - [io.swagger.client.models.TrpcSocialMediaPublishContentBody](docs/TrpcSocialMediaPublishContentBody.md)
 - [io.swagger.client.models.TrpcSocialMediaReschedulePostBody](docs/TrpcSocialMediaReschedulePostBody.md)
 - [io.swagger.client.models.TrpcSocialMediaSchedulePostBody](docs/TrpcSocialMediaSchedulePostBody.md)
 - [io.swagger.client.models.TrpcSocialMediaSyncAnalyticsBody](docs/TrpcSocialMediaSyncAnalyticsBody.md)

<a name="documentation-for-authorization"></a>
## Documentation for Authorization

<a name="bearerAuth"></a>
### bearerAuth


