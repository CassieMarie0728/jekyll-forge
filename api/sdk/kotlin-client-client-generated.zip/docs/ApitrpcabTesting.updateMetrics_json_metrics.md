# ApitrpcabTestingupdateMetricsJsonMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**impressions** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**engagements** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**clicks** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**shares** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**likes** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**replies** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
