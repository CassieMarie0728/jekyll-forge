# ApitrpcsocialMediaschedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposedContentId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**socialMediaAccountId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**scheduledAt** | [**kotlin.Any**](.md) |  | 
**timezone** | [**kotlin.String**](.md) |  |  [optional]
