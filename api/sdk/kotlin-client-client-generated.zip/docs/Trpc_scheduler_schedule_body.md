# TrpcSchedulerScheduleBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulerscheduleJson**](ApitrpcschedulerscheduleJson.md) |  | 
