# TrpcBlocksCreateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcblockscreateJson**](ApitrpcblockscreateJson.md) |  | 
