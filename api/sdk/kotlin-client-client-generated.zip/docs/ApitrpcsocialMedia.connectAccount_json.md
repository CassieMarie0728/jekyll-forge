# ApitrpcsocialMediaconnectAccountJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | [**inline**](#Platform) |  | 
**accessToken** | [**kotlin.String**](.md) |  | 
**refreshToken** | [**kotlin.String**](.md) |  |  [optional]
**expiresAt** | [**kotlin.Any**](.md) |  |  [optional]
**accountId** | [**kotlin.String**](.md) |  | 
**username** | [**kotlin.String**](.md) |  |  [optional]
**displayName** | [**kotlin.String**](.md) |  |  [optional]
**profileImageUrl** | [**kotlin.String**](.md) |  |  [optional]

<a name="Platform"></a>
## Enum: platform
Name | Value
---- | -----
platform | twitter, linkedin, facebook, instagram
