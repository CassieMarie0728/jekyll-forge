# RepurposingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**repurposingDelete**](RepurposingApi.md#repurposingDelete) | **POST** /api/trpc/repurposing.delete | Delete
[**repurposingGenerate**](RepurposingApi.md#repurposingGenerate) | **POST** /api/trpc/repurposing.generate | Generate
[**repurposingGetById**](RepurposingApi.md#repurposingGetById) | **GET** /api/trpc/repurposing.getById | Get By Id
[**repurposingGetByPost**](RepurposingApi.md#repurposingGetByPost) | **GET** /api/trpc/repurposing.getByPost | Get By Post
[**repurposingRegenerate**](RepurposingApi.md#repurposingRegenerate) | **POST** /api/trpc/repurposing.regenerate | Regenerate
[**repurposingUpdate**](RepurposingApi.md#repurposingUpdate) | **POST** /api/trpc/repurposing.update | Update

<a name="repurposingDelete"></a>
# **repurposingDelete**
> TRPCResponse repurposingDelete(body)

Delete

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = RepurposingApi()
val body : TrpcRepurposingDeleteBody =  // TrpcRepurposingDeleteBody | 
try {
    val result : TRPCResponse = apiInstance.repurposingDelete(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling RepurposingApi#repurposingDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling RepurposingApi#repurposingDelete")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingDeleteBody**](TrpcRepurposingDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingGenerate"></a>
# **repurposingGenerate**
> TRPCResponse repurposingGenerate(body)

Generate

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = RepurposingApi()
val body : TrpcRepurposingGenerateBody =  // TrpcRepurposingGenerateBody | 
try {
    val result : TRPCResponse = apiInstance.repurposingGenerate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling RepurposingApi#repurposingGenerate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling RepurposingApi#repurposingGenerate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingGenerateBody**](TrpcRepurposingGenerateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingGetById"></a>
# **repurposingGetById**
> TRPCResponse repurposingGetById(input)

Get By Id

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = RepurposingApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.repurposingGetById(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling RepurposingApi#repurposingGetById")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling RepurposingApi#repurposingGetById")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="repurposingGetByPost"></a>
# **repurposingGetByPost**
> TRPCResponse repurposingGetByPost(input)

Get By Post

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = RepurposingApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.repurposingGetByPost(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling RepurposingApi#repurposingGetByPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling RepurposingApi#repurposingGetByPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="repurposingRegenerate"></a>
# **repurposingRegenerate**
> TRPCResponse repurposingRegenerate(body)

Regenerate

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = RepurposingApi()
val body : TrpcRepurposingRegenerateBody =  // TrpcRepurposingRegenerateBody | 
try {
    val result : TRPCResponse = apiInstance.repurposingRegenerate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling RepurposingApi#repurposingRegenerate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling RepurposingApi#repurposingRegenerate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingRegenerateBody**](TrpcRepurposingRegenerateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="repurposingUpdate"></a>
# **repurposingUpdate**
> TRPCResponse repurposingUpdate(body)

Update

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = RepurposingApi()
val body : TrpcRepurposingUpdateBody =  // TrpcRepurposingUpdateBody | 
try {
    val result : TRPCResponse = apiInstance.repurposingUpdate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling RepurposingApi#repurposingUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling RepurposingApi#repurposingUpdate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcRepurposingUpdateBody**](TrpcRepurposingUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

