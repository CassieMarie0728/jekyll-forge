# AiProvidersApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiProvidersActivate**](AiProvidersApi.md#aiProvidersActivate) | **POST** /api/trpc/aiProviders.activate | Activate
[**aiProvidersGetSettings**](AiProvidersApi.md#aiProvidersGetSettings) | **GET** /api/trpc/aiProviders.getSettings | Get Settings
[**aiProvidersRemove**](AiProvidersApi.md#aiProvidersRemove) | **POST** /api/trpc/aiProviders.remove | Remove
[**aiProvidersSave**](AiProvidersApi.md#aiProvidersSave) | **POST** /api/trpc/aiProviders.save | Save
[**aiProvidersTest**](AiProvidersApi.md#aiProvidersTest) | **POST** /api/trpc/aiProviders.test | Test

<a name="aiProvidersActivate"></a>
# **aiProvidersActivate**
> TRPCResponse aiProvidersActivate(body)

Activate

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiProvidersApi()
val body : TrpcAiProvidersActivateBody =  // TrpcAiProvidersActivateBody | 
try {
    val result : TRPCResponse = apiInstance.aiProvidersActivate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiProvidersApi#aiProvidersActivate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiProvidersApi#aiProvidersActivate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersActivateBody**](TrpcAiProvidersActivateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersGetSettings"></a>
# **aiProvidersGetSettings**
> TRPCResponse aiProvidersGetSettings()

Get Settings

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiProvidersApi()
try {
    val result : TRPCResponse = apiInstance.aiProvidersGetSettings()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiProvidersApi#aiProvidersGetSettings")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiProvidersApi#aiProvidersGetSettings")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiProvidersRemove"></a>
# **aiProvidersRemove**
> TRPCResponse aiProvidersRemove(body)

Remove

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiProvidersApi()
val body : TrpcAiProvidersRemoveBody =  // TrpcAiProvidersRemoveBody | 
try {
    val result : TRPCResponse = apiInstance.aiProvidersRemove(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiProvidersApi#aiProvidersRemove")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiProvidersApi#aiProvidersRemove")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersRemoveBody**](TrpcAiProvidersRemoveBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersSave"></a>
# **aiProvidersSave**
> TRPCResponse aiProvidersSave(body)

Save

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiProvidersApi()
val body : TrpcAiProvidersSaveBody =  // TrpcAiProvidersSaveBody | 
try {
    val result : TRPCResponse = apiInstance.aiProvidersSave(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiProvidersApi#aiProvidersSave")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiProvidersApi#aiProvidersSave")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersSaveBody**](TrpcAiProvidersSaveBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiProvidersTest"></a>
# **aiProvidersTest**
> TRPCResponse aiProvidersTest(body)

Test

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiProvidersApi()
val body : TrpcAiProvidersTestBody =  // TrpcAiProvidersTestBody | 
try {
    val result : TRPCResponse = apiInstance.aiProvidersTest(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiProvidersApi#aiProvidersTest")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiProvidersApi#aiProvidersTest")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiProvidersTestBody**](TrpcAiProvidersTestBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

