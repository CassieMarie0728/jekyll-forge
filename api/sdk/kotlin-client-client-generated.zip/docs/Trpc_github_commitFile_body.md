# TrpcGithubCommitFileBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubcommitFileJson**](ApitrpcgithubcommitFileJson.md) |  | 
