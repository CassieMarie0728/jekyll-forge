# ApitrpcaiProviderssaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | [**kotlin.Any**](.md) |  | 
**model** | [**kotlin.String**](.md) |  | 
**apiKey** | [**kotlin.String**](.md) |  | 
