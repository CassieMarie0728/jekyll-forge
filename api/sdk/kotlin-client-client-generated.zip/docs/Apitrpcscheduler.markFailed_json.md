# ApitrpcschedulermarkFailedJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**errorMessage** | [**kotlin.String**](.md) |  | 
