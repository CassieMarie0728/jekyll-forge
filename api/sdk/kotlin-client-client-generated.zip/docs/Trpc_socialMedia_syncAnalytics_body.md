# TrpcSocialMediaSyncAnalyticsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediasyncAnalyticsJson**](ApitrpcsocialMediasyncAnalyticsJson.md) |  | 
