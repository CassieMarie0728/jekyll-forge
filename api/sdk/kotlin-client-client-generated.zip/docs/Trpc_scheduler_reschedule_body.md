# TrpcSchedulerRescheduleBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulerrescheduleJson**](ApitrpcschedulerrescheduleJson.md) |  | 
