# TrpcAiUpdateSettingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiupdateSettingsJson**](ApitrpcaiupdateSettingsJson.md) |  | 
