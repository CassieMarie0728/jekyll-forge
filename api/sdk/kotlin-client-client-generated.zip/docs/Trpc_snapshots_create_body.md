# TrpcSnapshotsCreateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsnapshotscreateJson**](ApitrpcsnapshotscreateJson.md) |  | 
