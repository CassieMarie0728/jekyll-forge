# ApitrpcschedulerscheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**draftPath** | [**kotlin.String**](.md) |  | 
**targetPath** | [**kotlin.String**](.md) |  | 
**scheduledAt** | [**kotlin.Any**](.md) |  | 
**timezone** | [**kotlin.String**](.md) |  | 
**commitMessage** | [**kotlin.String**](.md) |  |  [optional]
