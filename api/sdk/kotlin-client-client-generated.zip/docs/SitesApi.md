# SitesApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sitesDelete**](SitesApi.md#sitesDelete) | **POST** /api/trpc/sites.delete | Delete
[**sitesGet**](SitesApi.md#sitesGet) | **GET** /api/trpc/sites.get | Get
[**sitesList**](SitesApi.md#sitesList) | **GET** /api/trpc/sites.list | List
[**sitesUpdate**](SitesApi.md#sitesUpdate) | **POST** /api/trpc/sites.update | Update
[**sitesUpsert**](SitesApi.md#sitesUpsert) | **POST** /api/trpc/sites.upsert | Upsert

<a name="sitesDelete"></a>
# **sitesDelete**
> TRPCResponse sitesDelete(body)

Delete

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SitesApi()
val body : TrpcSitesDeleteBody =  // TrpcSitesDeleteBody | 
try {
    val result : TRPCResponse = apiInstance.sitesDelete(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SitesApi#sitesDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SitesApi#sitesDelete")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesDeleteBody**](TrpcSitesDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sitesGet"></a>
# **sitesGet**
> TRPCResponse sitesGet(input)

Get

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SitesApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.sitesGet(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SitesApi#sitesGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SitesApi#sitesGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="sitesList"></a>
# **sitesList**
> TRPCResponse sitesList()

List

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SitesApi()
try {
    val result : TRPCResponse = apiInstance.sitesList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SitesApi#sitesList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SitesApi#sitesList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="sitesUpdate"></a>
# **sitesUpdate**
> TRPCResponse sitesUpdate(body)

Update

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SitesApi()
val body : TrpcSitesUpdateBody =  // TrpcSitesUpdateBody | 
try {
    val result : TRPCResponse = apiInstance.sitesUpdate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SitesApi#sitesUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SitesApi#sitesUpdate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpdateBody**](TrpcSitesUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sitesUpsert"></a>
# **sitesUpsert**
> TRPCResponse sitesUpsert(body)

Upsert

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SitesApi()
val body : TrpcSitesUpsertBody =  // TrpcSitesUpsertBody | 
try {
    val result : TRPCResponse = apiInstance.sitesUpsert(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SitesApi#sitesUpsert")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SitesApi#sitesUpsert")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSitesUpsertBody**](TrpcSitesUpsertBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

