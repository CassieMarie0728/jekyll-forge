# TrpcSchedulerCancelAllBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulercancelAllJson**](ApitrpcschedulercancelAllJson.md) |  | 
