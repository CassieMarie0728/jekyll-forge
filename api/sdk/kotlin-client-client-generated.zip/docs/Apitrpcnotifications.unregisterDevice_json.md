# ApitrpcnotificationsunregisterDeviceJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | [**kotlin.String**](.md) |  | 
