# TrpcAssetsUploadBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsuploadJson**](ApitrpcassetsuploadJson.md) |  | 
