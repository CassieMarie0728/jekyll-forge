# TrpcSocialMediaPublishContentBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediapublishContentJson**](ApitrpcsocialMediapublishContentJson.md) |  | 
