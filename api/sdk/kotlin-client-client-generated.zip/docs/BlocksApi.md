# BlocksApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**blocksCreate**](BlocksApi.md#blocksCreate) | **POST** /api/trpc/blocks.create | Create
[**blocksDelete**](BlocksApi.md#blocksDelete) | **POST** /api/trpc/blocks.delete | Delete
[**blocksList**](BlocksApi.md#blocksList) | **GET** /api/trpc/blocks.list | List
[**blocksUpdate**](BlocksApi.md#blocksUpdate) | **POST** /api/trpc/blocks.update | Update

<a name="blocksCreate"></a>
# **blocksCreate**
> TRPCResponse blocksCreate(body)

Create

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = BlocksApi()
val body : TrpcBlocksCreateBody =  // TrpcBlocksCreateBody | 
try {
    val result : TRPCResponse = apiInstance.blocksCreate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling BlocksApi#blocksCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BlocksApi#blocksCreate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksCreateBody**](TrpcBlocksCreateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="blocksDelete"></a>
# **blocksDelete**
> TRPCResponse blocksDelete(body)

Delete

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = BlocksApi()
val body : TrpcBlocksDeleteBody =  // TrpcBlocksDeleteBody | 
try {
    val result : TRPCResponse = apiInstance.blocksDelete(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling BlocksApi#blocksDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BlocksApi#blocksDelete")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksDeleteBody**](TrpcBlocksDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="blocksList"></a>
# **blocksList**
> TRPCResponse blocksList()

List

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = BlocksApi()
try {
    val result : TRPCResponse = apiInstance.blocksList()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling BlocksApi#blocksList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BlocksApi#blocksList")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="blocksUpdate"></a>
# **blocksUpdate**
> TRPCResponse blocksUpdate(body)

Update

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = BlocksApi()
val body : TrpcBlocksUpdateBody =  // TrpcBlocksUpdateBody | 
try {
    val result : TRPCResponse = apiInstance.blocksUpdate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling BlocksApi#blocksUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BlocksApi#blocksUpdate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcBlocksUpdateBody**](TrpcBlocksUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

