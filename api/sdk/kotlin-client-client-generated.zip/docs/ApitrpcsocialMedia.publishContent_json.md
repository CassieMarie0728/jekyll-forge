# ApitrpcsocialMediapublishContentJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repurposedContentId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**accountId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
