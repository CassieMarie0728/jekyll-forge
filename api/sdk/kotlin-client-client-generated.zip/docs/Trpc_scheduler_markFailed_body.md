# TrpcSchedulerMarkFailedBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcschedulermarkFailedJson**](ApitrpcschedulermarkFailedJson.md) |  | 
