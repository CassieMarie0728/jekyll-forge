# TrpcAbTestingGenerateVariationsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestinggenerateVariationsJson**](ApitrpcabTestinggenerateVariationsJson.md) |  | 
