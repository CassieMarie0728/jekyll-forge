# AssetsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**assetsDelete**](AssetsApi.md#assetsDelete) | **POST** /api/trpc/assets.delete | Delete
[**assetsGenerateAltText**](AssetsApi.md#assetsGenerateAltText) | **POST** /api/trpc/assets.generateAltText | Generate Alt Text
[**assetsList**](AssetsApi.md#assetsList) | **GET** /api/trpc/assets.list | List
[**assetsReoptimize**](AssetsApi.md#assetsReoptimize) | **POST** /api/trpc/assets.reoptimize | Reoptimize
[**assetsUpdate**](AssetsApi.md#assetsUpdate) | **POST** /api/trpc/assets.update | Update
[**assetsUpload**](AssetsApi.md#assetsUpload) | **POST** /api/trpc/assets.upload | Upload

<a name="assetsDelete"></a>
# **assetsDelete**
> TRPCResponse assetsDelete(body)

Delete

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AssetsApi()
val body : TrpcAssetsDeleteBody =  // TrpcAssetsDeleteBody | 
try {
    val result : TRPCResponse = apiInstance.assetsDelete(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AssetsApi#assetsDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AssetsApi#assetsDelete")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsDeleteBody**](TrpcAssetsDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsGenerateAltText"></a>
# **assetsGenerateAltText**
> TRPCResponse assetsGenerateAltText(body)

Generate Alt Text

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AssetsApi()
val body : TrpcAssetsGenerateAltTextBody =  // TrpcAssetsGenerateAltTextBody | 
try {
    val result : TRPCResponse = apiInstance.assetsGenerateAltText(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AssetsApi#assetsGenerateAltText")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AssetsApi#assetsGenerateAltText")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsGenerateAltTextBody**](TrpcAssetsGenerateAltTextBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsList"></a>
# **assetsList**
> TRPCResponse assetsList(input)

List

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AssetsApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.assetsList(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AssetsApi#assetsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AssetsApi#assetsList")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="assetsReoptimize"></a>
# **assetsReoptimize**
> TRPCResponse assetsReoptimize(body)

Reoptimize

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AssetsApi()
val body : TrpcAssetsReoptimizeBody =  // TrpcAssetsReoptimizeBody | 
try {
    val result : TRPCResponse = apiInstance.assetsReoptimize(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AssetsApi#assetsReoptimize")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AssetsApi#assetsReoptimize")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsReoptimizeBody**](TrpcAssetsReoptimizeBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsUpdate"></a>
# **assetsUpdate**
> TRPCResponse assetsUpdate(body)

Update

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AssetsApi()
val body : TrpcAssetsUpdateBody =  // TrpcAssetsUpdateBody | 
try {
    val result : TRPCResponse = apiInstance.assetsUpdate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AssetsApi#assetsUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AssetsApi#assetsUpdate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUpdateBody**](TrpcAssetsUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="assetsUpload"></a>
# **assetsUpload**
> TRPCResponse assetsUpload(body)

Upload

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AssetsApi()
val body : TrpcAssetsUploadBody =  // TrpcAssetsUploadBody | 
try {
    val result : TRPCResponse = apiInstance.assetsUpload(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AssetsApi#assetsUpload")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AssetsApi#assetsUpload")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAssetsUploadBody**](TrpcAssetsUploadBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

