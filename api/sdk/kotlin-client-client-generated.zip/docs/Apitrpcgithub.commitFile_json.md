# ApitrpcgithubcommitFileJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**kotlin.String**](.md) |  | 
**repo** | [**kotlin.String**](.md) |  | 
**path** | [**kotlin.String**](.md) |  | 
**branch** | [**kotlin.String**](.md) |  | 
**content** | [**kotlin.String**](.md) |  | 
**message** | [**kotlin.String**](.md) |  | 
**sha** | [**kotlin.String**](.md) |  |  [optional]
