# TrpcGithubCreatePullRequestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubcreatePullRequestJson**](ApitrpcgithubcreatePullRequestJson.md) |  | 
