# ApitrpcsnapshotscreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**postPath** | [**kotlin.String**](.md) |  |  [optional]
**label** | [**kotlin.String**](.md) |  | 
**reason** | [**kotlin.Any**](.md) |  | 
**markdown** | [**kotlin.String**](.md) |  |  [optional]
**frontMatter** | [**kotlin.Any**](.md) |  |  [optional]
