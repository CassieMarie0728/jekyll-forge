# TrpcPostsAutosaveBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcpostsautosaveJson**](ApitrpcpostsautosaveJson.md) |  | 
