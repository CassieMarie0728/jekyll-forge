# ApitrpcaigenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task** | [**kotlin.String**](.md) |  | 
**userPrompt** | [**kotlin.String**](.md) |  |  [optional]
**selectedText** | [**kotlin.String**](.md) |  |  [optional]
**postMarkdown** | [**kotlin.String**](.md) |  |  [optional]
**frontMatter** | [**kotlin.Any**](.md) |  |  [optional]
**tone** | [**kotlin.String**](.md) |  |  [optional]
**voiceProfileId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
