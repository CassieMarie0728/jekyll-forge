# TrpcAbTestingPublishVariationBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingpublishVariationJson**](ApitrpcabTestingpublishVariationJson.md) |  | 
