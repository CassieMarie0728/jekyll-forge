# TrpcNotificationsUnregisterDeviceBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcnotificationsunregisterDeviceJson**](ApitrpcnotificationsunregisterDeviceJson.md) |  | 
