# AiApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**aiGenerate**](AiApi.md#aiGenerate) | **POST** /api/trpc/ai.generate | Generate
[**aiGetSettings**](AiApi.md#aiGetSettings) | **GET** /api/trpc/ai.getSettings | Get Settings
[**aiGetUsageStats**](AiApi.md#aiGetUsageStats) | **GET** /api/trpc/ai.getUsageStats | Get Usage Stats
[**aiUpdateSettings**](AiApi.md#aiUpdateSettings) | **POST** /api/trpc/ai.updateSettings | Update Settings

<a name="aiGenerate"></a>
# **aiGenerate**
> TRPCResponse aiGenerate(body)

Generate

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiApi()
val body : TrpcAiGenerateBody =  // TrpcAiGenerateBody | 
try {
    val result : TRPCResponse = apiInstance.aiGenerate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiApi#aiGenerate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiApi#aiGenerate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiGenerateBody**](TrpcAiGenerateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="aiGetSettings"></a>
# **aiGetSettings**
> TRPCResponse aiGetSettings()

Get Settings

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiApi()
try {
    val result : TRPCResponse = apiInstance.aiGetSettings()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiApi#aiGetSettings")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiApi#aiGetSettings")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiGetUsageStats"></a>
# **aiGetUsageStats**
> TRPCResponse aiGetUsageStats()

Get Usage Stats

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiApi()
try {
    val result : TRPCResponse = apiInstance.aiGetUsageStats()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiApi#aiGetUsageStats")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiApi#aiGetUsageStats")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="aiUpdateSettings"></a>
# **aiUpdateSettings**
> TRPCResponse aiUpdateSettings(body)

Update Settings

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AiApi()
val body : TrpcAiUpdateSettingsBody =  // TrpcAiUpdateSettingsBody | 
try {
    val result : TRPCResponse = apiInstance.aiUpdateSettings(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AiApi#aiUpdateSettings")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AiApi#aiUpdateSettings")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAiUpdateSettingsBody**](TrpcAiUpdateSettingsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

