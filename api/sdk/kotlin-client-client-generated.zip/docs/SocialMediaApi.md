# SocialMediaApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**socialMediaCancelScheduledPost**](SocialMediaApi.md#socialMediaCancelScheduledPost) | **POST** /api/trpc/socialMedia.cancelScheduledPost | Cancel Scheduled Post
[**socialMediaConnectAccount**](SocialMediaApi.md#socialMediaConnectAccount) | **POST** /api/trpc/socialMedia.connectAccount | Connect Account
[**socialMediaDisconnectAccount**](SocialMediaApi.md#socialMediaDisconnectAccount) | **POST** /api/trpc/socialMedia.disconnectAccount | Disconnect Account
[**socialMediaGetAccountDetails**](SocialMediaApi.md#socialMediaGetAccountDetails) | **GET** /api/trpc/socialMedia.getAccountDetails | Get Account Details
[**socialMediaGetAccounts**](SocialMediaApi.md#socialMediaGetAccounts) | **GET** /api/trpc/socialMedia.getAccounts | Get Accounts
[**socialMediaGetAnalyticsByPlatform**](SocialMediaApi.md#socialMediaGetAnalyticsByPlatform) | **GET** /api/trpc/socialMedia.getAnalyticsByPlatform | Get Analytics By Platform
[**socialMediaGetAnalyticsSummary**](SocialMediaApi.md#socialMediaGetAnalyticsSummary) | **GET** /api/trpc/socialMedia.getAnalyticsSummary | Get Analytics Summary
[**socialMediaGetContentAnalytics**](SocialMediaApi.md#socialMediaGetContentAnalytics) | **GET** /api/trpc/socialMedia.getContentAnalytics | Get Content Analytics
[**socialMediaGetScheduledPosts**](SocialMediaApi.md#socialMediaGetScheduledPosts) | **GET** /api/trpc/socialMedia.getScheduledPosts | Get Scheduled Posts
[**socialMediaPublishContent**](SocialMediaApi.md#socialMediaPublishContent) | **POST** /api/trpc/socialMedia.publishContent | Publish Content
[**socialMediaReschedulePost**](SocialMediaApi.md#socialMediaReschedulePost) | **POST** /api/trpc/socialMedia.reschedulePost | Reschedule Post
[**socialMediaSchedulePost**](SocialMediaApi.md#socialMediaSchedulePost) | **POST** /api/trpc/socialMedia.schedulePost | Schedule Post
[**socialMediaSyncAnalytics**](SocialMediaApi.md#socialMediaSyncAnalytics) | **POST** /api/trpc/socialMedia.syncAnalytics | Sync Analytics

<a name="socialMediaCancelScheduledPost"></a>
# **socialMediaCancelScheduledPost**
> TRPCResponse socialMediaCancelScheduledPost(body)

Cancel Scheduled Post

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaCancelScheduledPostBody =  // TrpcSocialMediaCancelScheduledPostBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaCancelScheduledPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaCancelScheduledPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaCancelScheduledPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaCancelScheduledPostBody**](TrpcSocialMediaCancelScheduledPostBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaConnectAccount"></a>
# **socialMediaConnectAccount**
> TRPCResponse socialMediaConnectAccount(body)

Connect Account

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaConnectAccountBody =  // TrpcSocialMediaConnectAccountBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaConnectAccount(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaConnectAccount")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaConnectAccount")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaConnectAccountBody**](TrpcSocialMediaConnectAccountBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaDisconnectAccount"></a>
# **socialMediaDisconnectAccount**
> TRPCResponse socialMediaDisconnectAccount(body)

Disconnect Account

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaDisconnectAccountBody =  // TrpcSocialMediaDisconnectAccountBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaDisconnectAccount(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaDisconnectAccount")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaDisconnectAccount")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaDisconnectAccountBody**](TrpcSocialMediaDisconnectAccountBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaGetAccountDetails"></a>
# **socialMediaGetAccountDetails**
> TRPCResponse socialMediaGetAccountDetails(input)

Get Account Details

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.socialMediaGetAccountDetails(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaGetAccountDetails")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaGetAccountDetails")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAccounts"></a>
# **socialMediaGetAccounts**
> TRPCResponse socialMediaGetAccounts()

Get Accounts

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
try {
    val result : TRPCResponse = apiInstance.socialMediaGetAccounts()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaGetAccounts")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaGetAccounts")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAnalyticsByPlatform"></a>
# **socialMediaGetAnalyticsByPlatform**
> TRPCResponse socialMediaGetAnalyticsByPlatform(input)

Get Analytics By Platform

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.socialMediaGetAnalyticsByPlatform(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaGetAnalyticsByPlatform")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaGetAnalyticsByPlatform")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetAnalyticsSummary"></a>
# **socialMediaGetAnalyticsSummary**
> TRPCResponse socialMediaGetAnalyticsSummary()

Get Analytics Summary

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
try {
    val result : TRPCResponse = apiInstance.socialMediaGetAnalyticsSummary()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaGetAnalyticsSummary")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaGetAnalyticsSummary")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetContentAnalytics"></a>
# **socialMediaGetContentAnalytics**
> TRPCResponse socialMediaGetContentAnalytics(input)

Get Content Analytics

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.socialMediaGetContentAnalytics(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaGetContentAnalytics")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaGetContentAnalytics")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaGetScheduledPosts"></a>
# **socialMediaGetScheduledPosts**
> TRPCResponse socialMediaGetScheduledPosts(input)

Get Scheduled Posts

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.socialMediaGetScheduledPosts(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaGetScheduledPosts")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaGetScheduledPosts")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="socialMediaPublishContent"></a>
# **socialMediaPublishContent**
> TRPCResponse socialMediaPublishContent(body)

Publish Content

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaPublishContentBody =  // TrpcSocialMediaPublishContentBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaPublishContent(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaPublishContent")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaPublishContent")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaPublishContentBody**](TrpcSocialMediaPublishContentBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaReschedulePost"></a>
# **socialMediaReschedulePost**
> TRPCResponse socialMediaReschedulePost(body)

Reschedule Post

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaReschedulePostBody =  // TrpcSocialMediaReschedulePostBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaReschedulePost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaReschedulePost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaReschedulePost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaReschedulePostBody**](TrpcSocialMediaReschedulePostBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaSchedulePost"></a>
# **socialMediaSchedulePost**
> TRPCResponse socialMediaSchedulePost(body)

Schedule Post

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaSchedulePostBody =  // TrpcSocialMediaSchedulePostBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaSchedulePost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaSchedulePost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaSchedulePost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSchedulePostBody**](TrpcSocialMediaSchedulePostBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="socialMediaSyncAnalytics"></a>
# **socialMediaSyncAnalytics**
> TRPCResponse socialMediaSyncAnalytics(body)

Sync Analytics

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SocialMediaApi()
val body : TrpcSocialMediaSyncAnalyticsBody =  // TrpcSocialMediaSyncAnalyticsBody | 
try {
    val result : TRPCResponse = apiInstance.socialMediaSyncAnalytics(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SocialMediaApi#socialMediaSyncAnalytics")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SocialMediaApi#socialMediaSyncAnalytics")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSocialMediaSyncAnalyticsBody**](TrpcSocialMediaSyncAnalyticsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

