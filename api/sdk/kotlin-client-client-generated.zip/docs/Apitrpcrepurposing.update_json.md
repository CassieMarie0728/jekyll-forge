# ApitrpcrepurposingupdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**content** | [**kotlin.String**](.md) |  |  [optional]
**status** | [**kotlin.Any**](.md) |  |  [optional]
**isCustomized** | [**kotlin.Boolean**](.md) |  |  [optional]
