# TrpcAssetsUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsupdateJson**](ApitrpcassetsupdateJson.md) |  | 
