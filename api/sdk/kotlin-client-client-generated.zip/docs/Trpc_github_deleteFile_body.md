# TrpcGithubDeleteFileBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubdeleteFileJson**](ApitrpcgithubdeleteFileJson.md) |  | 
