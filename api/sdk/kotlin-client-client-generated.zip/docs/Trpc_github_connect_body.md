# TrpcGithubConnectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubconnectJson**](ApitrpcgithubconnectJson.md) |  | 
