# ApitrpcabTestingapplyWinnerJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**winningVariationIndex** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
