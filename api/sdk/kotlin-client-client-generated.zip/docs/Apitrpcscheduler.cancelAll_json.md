# ApitrpcschedulercancelAllJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
