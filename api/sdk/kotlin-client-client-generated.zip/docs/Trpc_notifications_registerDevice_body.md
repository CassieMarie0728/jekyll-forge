# TrpcNotificationsRegisterDeviceBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcnotificationsregisterDeviceJson**](ApitrpcnotificationsregisterDeviceJson.md) |  | 
