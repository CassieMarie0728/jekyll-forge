# ApitrpcnotificationsregisterDeviceJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | [**kotlin.String**](.md) |  | 
**platform** | [**inline**](#Platform) |  | 

<a name="Platform"></a>
## Enum: platform
Name | Value
---- | -----
platform | android
