# TrpcSitesUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsitesupdateJson**](ApitrpcsitesupdateJson.md) |  | 
