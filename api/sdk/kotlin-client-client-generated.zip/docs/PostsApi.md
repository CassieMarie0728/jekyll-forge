# PostsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**postsAutosave**](PostsApi.md#postsAutosave) | **POST** /api/trpc/posts.autosave | Autosave
[**postsDelete**](PostsApi.md#postsDelete) | **POST** /api/trpc/posts.delete | Delete
[**postsGet**](PostsApi.md#postsGet) | **GET** /api/trpc/posts.get | Get
[**postsGetFrontMatterTemplates**](PostsApi.md#postsGetFrontMatterTemplates) | **GET** /api/trpc/posts.getFrontMatterTemplates | Get Front Matter Templates
[**postsList**](PostsApi.md#postsList) | **GET** /api/trpc/posts.list | List
[**postsUpdate**](PostsApi.md#postsUpdate) | **POST** /api/trpc/posts.update | Update
[**postsUpsert**](PostsApi.md#postsUpsert) | **POST** /api/trpc/posts.upsert | Upsert

<a name="postsAutosave"></a>
# **postsAutosave**
> TRPCResponse postsAutosave(body)

Autosave

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val body : TrpcPostsAutosaveBody =  // TrpcPostsAutosaveBody | 
try {
    val result : TRPCResponse = apiInstance.postsAutosave(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsAutosave")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsAutosave")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsAutosaveBody**](TrpcPostsAutosaveBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsDelete"></a>
# **postsDelete**
> TRPCResponse postsDelete(body)

Delete

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val body : TrpcPostsDeleteBody =  // TrpcPostsDeleteBody | 
try {
    val result : TRPCResponse = apiInstance.postsDelete(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsDelete")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsDelete")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsDeleteBody**](TrpcPostsDeleteBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsGet"></a>
# **postsGet**
> TRPCResponse postsGet(input)

Get

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.postsGet(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsGetFrontMatterTemplates"></a>
# **postsGetFrontMatterTemplates**
> TRPCResponse postsGetFrontMatterTemplates(input)

Get Front Matter Templates

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.postsGetFrontMatterTemplates(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsGetFrontMatterTemplates")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsGetFrontMatterTemplates")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsList"></a>
# **postsList**
> TRPCResponse postsList(input)

List

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.postsList(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsList")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="postsUpdate"></a>
# **postsUpdate**
> TRPCResponse postsUpdate(body)

Update

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val body : TrpcPostsUpdateBody =  // TrpcPostsUpdateBody | 
try {
    val result : TRPCResponse = apiInstance.postsUpdate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsUpdate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsUpdate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpdateBody**](TrpcPostsUpdateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="postsUpsert"></a>
# **postsUpsert**
> TRPCResponse postsUpsert(body)

Upsert

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PostsApi()
val body : TrpcPostsUpsertBody =  // TrpcPostsUpsertBody | 
try {
    val result : TRPCResponse = apiInstance.postsUpsert(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PostsApi#postsUpsert")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PostsApi#postsUpsert")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcPostsUpsertBody**](TrpcPostsUpsertBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

