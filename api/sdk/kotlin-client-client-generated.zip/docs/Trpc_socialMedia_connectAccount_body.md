# TrpcSocialMediaConnectAccountBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaconnectAccountJson**](ApitrpcsocialMediaconnectAccountJson.md) |  | 
