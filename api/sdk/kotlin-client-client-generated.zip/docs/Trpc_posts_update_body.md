# TrpcPostsUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcpostsupdateJson**](ApitrpcpostsupdateJson.md) |  | 
