# SchedulerApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**schedulerCancel**](SchedulerApi.md#schedulerCancel) | **POST** /api/trpc/scheduler.cancel | Cancel
[**schedulerCancelAll**](SchedulerApi.md#schedulerCancelAll) | **POST** /api/trpc/scheduler.cancelAll | Cancel All
[**schedulerList**](SchedulerApi.md#schedulerList) | **GET** /api/trpc/scheduler.list | List
[**schedulerListHeartbeatJobs**](SchedulerApi.md#schedulerListHeartbeatJobs) | **GET** /api/trpc/scheduler.listHeartbeatJobs | List Heartbeat Jobs
[**schedulerMarkFailed**](SchedulerApi.md#schedulerMarkFailed) | **POST** /api/trpc/scheduler.markFailed | Mark Failed
[**schedulerMarkPublished**](SchedulerApi.md#schedulerMarkPublished) | **POST** /api/trpc/scheduler.markPublished | Mark Published
[**schedulerReschedule**](SchedulerApi.md#schedulerReschedule) | **POST** /api/trpc/scheduler.reschedule | Reschedule
[**schedulerSchedule**](SchedulerApi.md#schedulerSchedule) | **POST** /api/trpc/scheduler.schedule | Schedule

<a name="schedulerCancel"></a>
# **schedulerCancel**
> TRPCResponse schedulerCancel(body)

Cancel

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val body : TrpcSchedulerCancelBody =  // TrpcSchedulerCancelBody | 
try {
    val result : TRPCResponse = apiInstance.schedulerCancel(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerCancel")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerCancel")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelBody**](TrpcSchedulerCancelBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerCancelAll"></a>
# **schedulerCancelAll**
> TRPCResponse schedulerCancelAll(body)

Cancel All

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val body : TrpcSchedulerCancelAllBody =  // TrpcSchedulerCancelAllBody | 
try {
    val result : TRPCResponse = apiInstance.schedulerCancelAll(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerCancelAll")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerCancelAll")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerCancelAllBody**](TrpcSchedulerCancelAllBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerList"></a>
# **schedulerList**
> TRPCResponse schedulerList(input)

List

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.schedulerList(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerList")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerList")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="schedulerListHeartbeatJobs"></a>
# **schedulerListHeartbeatJobs**
> TRPCResponse schedulerListHeartbeatJobs(input)

List Heartbeat Jobs

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.schedulerListHeartbeatJobs(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerListHeartbeatJobs")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerListHeartbeatJobs")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="schedulerMarkFailed"></a>
# **schedulerMarkFailed**
> TRPCResponse schedulerMarkFailed(body)

Mark Failed

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val body : TrpcSchedulerMarkFailedBody =  // TrpcSchedulerMarkFailedBody | 
try {
    val result : TRPCResponse = apiInstance.schedulerMarkFailed(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerMarkFailed")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerMarkFailed")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkFailedBody**](TrpcSchedulerMarkFailedBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerMarkPublished"></a>
# **schedulerMarkPublished**
> TRPCResponse schedulerMarkPublished(body)

Mark Published

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val body : TrpcSchedulerMarkPublishedBody =  // TrpcSchedulerMarkPublishedBody | 
try {
    val result : TRPCResponse = apiInstance.schedulerMarkPublished(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerMarkPublished")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerMarkPublished")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerMarkPublishedBody**](TrpcSchedulerMarkPublishedBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerReschedule"></a>
# **schedulerReschedule**
> TRPCResponse schedulerReschedule(body)

Reschedule

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val body : TrpcSchedulerRescheduleBody =  // TrpcSchedulerRescheduleBody | 
try {
    val result : TRPCResponse = apiInstance.schedulerReschedule(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerReschedule")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerReschedule")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerRescheduleBody**](TrpcSchedulerRescheduleBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="schedulerSchedule"></a>
# **schedulerSchedule**
> TRPCResponse schedulerSchedule(body)

Schedule

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SchedulerApi()
val body : TrpcSchedulerScheduleBody =  // TrpcSchedulerScheduleBody | 
try {
    val result : TRPCResponse = apiInstance.schedulerSchedule(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SchedulerApi#schedulerSchedule")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SchedulerApi#schedulerSchedule")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSchedulerScheduleBody**](TrpcSchedulerScheduleBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

