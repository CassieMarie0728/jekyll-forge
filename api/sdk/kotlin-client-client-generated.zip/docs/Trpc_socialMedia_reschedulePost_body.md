# TrpcSocialMediaReschedulePostBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediareschedulePostJson**](ApitrpcsocialMediareschedulePostJson.md) |  | 
