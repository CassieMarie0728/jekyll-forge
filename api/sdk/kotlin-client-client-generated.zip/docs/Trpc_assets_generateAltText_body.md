# TrpcAssetsGenerateAltTextBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsgenerateAltTextJson**](ApitrpcassetsgenerateAltTextJson.md) |  | 
