# TrpcRepurposingUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcrepurposingupdateJson**](ApitrpcrepurposingupdateJson.md) |  | 
