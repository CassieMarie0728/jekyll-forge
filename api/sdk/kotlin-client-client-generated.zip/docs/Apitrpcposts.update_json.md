# ApitrpcpostsupdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**path** | [**kotlin.String**](.md) |  |  [optional]
**title** | [**kotlin.String**](.md) |  |  [optional]
**slug** | [**kotlin.String**](.md) |  |  [optional]
**status** | [**kotlin.Any**](.md) |  |  [optional]
**frontMatter** | [**kotlin.Any**](.md) |  |  [optional]
**markdown** | [**kotlin.String**](.md) |  |  [optional]
**sha** | [**kotlin.String**](.md) |  |  [optional]
**scheduledAt** | [**kotlin.Any**](.md) |  |  [optional]
