# ApitrpcabTestingpublishVariationJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**variationIndex** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**platforms** | [**inline**](#kotlin.Array&lt;Platforms&gt;) |  | 

<a name="kotlin.Array<Platforms>"></a>
## Enum: platforms
Name | Value
---- | -----
platforms | twitter, linkedin, facebook, instagram, email, direct
