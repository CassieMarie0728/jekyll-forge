# TrpcPostsUpsertBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcpostsupsertJson**](ApitrpcpostsupsertJson.md) |  | 
