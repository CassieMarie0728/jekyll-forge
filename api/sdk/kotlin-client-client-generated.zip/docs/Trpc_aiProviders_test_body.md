# TrpcAiProvidersTestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiProviderssaveJson**](ApitrpcaiProviderssaveJson.md) |  | 
