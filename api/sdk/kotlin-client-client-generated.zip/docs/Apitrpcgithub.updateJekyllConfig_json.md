# ApitrpcgithubupdateJekyllConfigJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**kotlin.String**](.md) |  | 
**repo** | [**kotlin.String**](.md) |  | 
**rootPath** | [**kotlin.String**](.md) |  | 
**branch** | [**kotlin.String**](.md) |  | 
**commitMessage** | [**kotlin.String**](.md) |  |  [optional]
