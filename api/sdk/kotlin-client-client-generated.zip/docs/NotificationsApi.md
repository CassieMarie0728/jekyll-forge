# NotificationsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**notificationsRegisterDevice**](NotificationsApi.md#notificationsRegisterDevice) | **POST** /api/trpc/notifications.registerDevice | Register Device
[**notificationsUnregisterDevice**](NotificationsApi.md#notificationsUnregisterDevice) | **POST** /api/trpc/notifications.unregisterDevice | Unregister Device

<a name="notificationsRegisterDevice"></a>
# **notificationsRegisterDevice**
> TRPCResponse notificationsRegisterDevice(body)

Register Device

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = NotificationsApi()
val body : TrpcNotificationsRegisterDeviceBody =  // TrpcNotificationsRegisterDeviceBody | 
try {
    val result : TRPCResponse = apiInstance.notificationsRegisterDevice(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling NotificationsApi#notificationsRegisterDevice")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling NotificationsApi#notificationsRegisterDevice")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsRegisterDeviceBody**](TrpcNotificationsRegisterDeviceBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="notificationsUnregisterDevice"></a>
# **notificationsUnregisterDevice**
> TRPCResponse notificationsUnregisterDevice(body)

Unregister Device

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = NotificationsApi()
val body : TrpcNotificationsUnregisterDeviceBody =  // TrpcNotificationsUnregisterDeviceBody | 
try {
    val result : TRPCResponse = apiInstance.notificationsUnregisterDevice(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling NotificationsApi#notificationsUnregisterDevice")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling NotificationsApi#notificationsUnregisterDevice")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcNotificationsUnregisterDeviceBody**](TrpcNotificationsUnregisterDeviceBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

