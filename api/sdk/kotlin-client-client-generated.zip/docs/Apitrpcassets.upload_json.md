# ApitrpcassetsuploadJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**siteId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**name** | [**kotlin.String**](.md) |  | 
**path** | [**kotlin.String**](.md) |  | 
**base64Content** | [**kotlin.String**](.md) |  | 
**mimeType** | [**kotlin.String**](.md) |  | 
**size** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**width** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**height** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**optimize** | [**kotlin.Boolean**](.md) |  | 
**maxWidth** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**outputFormat** | [**inline**](#OutputFormat) |  |  [optional]
**quality** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]

<a name="OutputFormat"></a>
## Enum: outputFormat
Name | Value
---- | -----
outputFormat | webp, jpeg, png, original
