# TrpcGithubCreateBranchBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubcreateBranchJson**](ApitrpcgithubcreateBranchJson.md) |  | 
