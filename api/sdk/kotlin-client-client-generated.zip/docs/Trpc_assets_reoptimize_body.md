# TrpcAssetsReoptimizeBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsreoptimizeJson**](ApitrpcassetsreoptimizeJson.md) |  | 
