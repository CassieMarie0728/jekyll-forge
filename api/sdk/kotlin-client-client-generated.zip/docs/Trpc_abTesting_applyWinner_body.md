# TrpcAbTestingApplyWinnerBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingapplyWinnerJson**](ApitrpcabTestingapplyWinnerJson.md) |  | 
