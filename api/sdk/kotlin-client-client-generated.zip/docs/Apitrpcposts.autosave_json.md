# ApitrpcpostsautosaveJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**markdown** | [**kotlin.String**](.md) |  | 
**frontMatter** | [**kotlin.Any**](.md) |  | 
