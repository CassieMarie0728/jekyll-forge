# ApitrpcassetsgenerateAltTextJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assetId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
