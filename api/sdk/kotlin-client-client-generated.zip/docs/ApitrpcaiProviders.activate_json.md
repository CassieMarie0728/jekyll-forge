# ApitrpcaiProvidersactivateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | [**kotlin.Any**](.md) |  | 
