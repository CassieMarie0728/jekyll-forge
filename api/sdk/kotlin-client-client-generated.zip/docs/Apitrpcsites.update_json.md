# ApitrpcsitesupdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**isFavorite** | [**kotlin.Boolean**](.md) |  |  [optional]
**selectedBranch** | [**kotlin.String**](.md) |  |  [optional]
**rootPath** | [**kotlin.String**](.md) |  |  [optional]
**timezone** | [**kotlin.String**](.md) |  |  [optional]
**defaultLayout** | [**kotlin.String**](.md) |  |  [optional]
**defaultAssetPath** | [**kotlin.String**](.md) |  |  [optional]
**aiVoiceProfile** | [**kotlin.String**](.md) |  |  [optional]
**settings** | [**kotlin.Any**](.md) |  |  [optional]
