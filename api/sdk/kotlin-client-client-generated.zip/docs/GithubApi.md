# GithubApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**githubCheckPluginCompatibility**](GithubApi.md#githubCheckPluginCompatibility) | **GET** /api/trpc/github.checkPluginCompatibility | Check Plugin Compatibility
[**githubCommitFile**](GithubApi.md#githubCommitFile) | **POST** /api/trpc/github.commitFile | Commit File
[**githubConnect**](GithubApi.md#githubConnect) | **POST** /api/trpc/github.connect | Connect
[**githubCreateBranch**](GithubApi.md#githubCreateBranch) | **POST** /api/trpc/github.createBranch | Create Branch
[**githubCreatePullRequest**](GithubApi.md#githubCreatePullRequest) | **POST** /api/trpc/github.createPullRequest | Create Pull Request
[**githubDeleteFile**](GithubApi.md#githubDeleteFile) | **POST** /api/trpc/github.deleteFile | Delete File
[**githubDetectJekyll**](GithubApi.md#githubDetectJekyll) | **GET** /api/trpc/github.detectJekyll | Detect Jekyll
[**githubDisconnect**](GithubApi.md#githubDisconnect) | **POST** /api/trpc/github.disconnect | Disconnect
[**githubGenerateActionsWorkflow**](GithubApi.md#githubGenerateActionsWorkflow) | **POST** /api/trpc/github.generateActionsWorkflow | Generate Actions Workflow
[**githubGetFile**](GithubApi.md#githubGetFile) | **GET** /api/trpc/github.getFile | Get File
[**githubGetJekyllConfig**](GithubApi.md#githubGetJekyllConfig) | **GET** /api/trpc/github.getJekyllConfig | Get Jekyll Config
[**githubGetPagesStatus**](GithubApi.md#githubGetPagesStatus) | **GET** /api/trpc/github.getPagesStatus | Get Pages Status
[**githubGetRateLimit**](GithubApi.md#githubGetRateLimit) | **GET** /api/trpc/github.getRateLimit | Get Rate Limit
[**githubInventory**](GithubApi.md#githubInventory) | **GET** /api/trpc/github.inventory | Inventory
[**githubListBranches**](GithubApi.md#githubListBranches) | **GET** /api/trpc/github.listBranches | List Branches
[**githubListFiles**](GithubApi.md#githubListFiles) | **GET** /api/trpc/github.listFiles | List Files
[**githubListRepos**](GithubApi.md#githubListRepos) | **GET** /api/trpc/github.listRepos | List Repos
[**githubRepositories**](GithubApi.md#githubRepositories) | **GET** /api/trpc/github.repositories | Repositories
[**githubReviewFile**](GithubApi.md#githubReviewFile) | **GET** /api/trpc/github.reviewFile | Review File
[**githubStatus**](GithubApi.md#githubStatus) | **GET** /api/trpc/github.status | Status
[**githubUpdateJekyllConfig**](GithubApi.md#githubUpdateJekyllConfig) | **POST** /api/trpc/github.updateJekyllConfig | Update Jekyll Config

<a name="githubCheckPluginCompatibility"></a>
# **githubCheckPluginCompatibility**
> TRPCResponse githubCheckPluginCompatibility(input)

Check Plugin Compatibility

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubCheckPluginCompatibility(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubCheckPluginCompatibility")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubCheckPluginCompatibility")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubCommitFile"></a>
# **githubCommitFile**
> TRPCResponse githubCommitFile(body)

Commit File

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubCommitFileBody =  // TrpcGithubCommitFileBody | 
try {
    val result : TRPCResponse = apiInstance.githubCommitFile(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubCommitFile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubCommitFile")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCommitFileBody**](TrpcGithubCommitFileBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubConnect"></a>
# **githubConnect**
> TRPCResponse githubConnect(body)

Connect

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubConnectBody =  // TrpcGithubConnectBody | 
try {
    val result : TRPCResponse = apiInstance.githubConnect(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubConnect")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubConnect")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubConnectBody**](TrpcGithubConnectBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubCreateBranch"></a>
# **githubCreateBranch**
> TRPCResponse githubCreateBranch(body)

Create Branch

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubCreateBranchBody =  // TrpcGithubCreateBranchBody | 
try {
    val result : TRPCResponse = apiInstance.githubCreateBranch(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubCreateBranch")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubCreateBranch")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreateBranchBody**](TrpcGithubCreateBranchBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubCreatePullRequest"></a>
# **githubCreatePullRequest**
> TRPCResponse githubCreatePullRequest(body)

Create Pull Request

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubCreatePullRequestBody =  // TrpcGithubCreatePullRequestBody | 
try {
    val result : TRPCResponse = apiInstance.githubCreatePullRequest(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubCreatePullRequest")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubCreatePullRequest")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubCreatePullRequestBody**](TrpcGithubCreatePullRequestBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubDeleteFile"></a>
# **githubDeleteFile**
> TRPCResponse githubDeleteFile(body)

Delete File

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubDeleteFileBody =  // TrpcGithubDeleteFileBody | 
try {
    val result : TRPCResponse = apiInstance.githubDeleteFile(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubDeleteFile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubDeleteFile")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDeleteFileBody**](TrpcGithubDeleteFileBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubDetectJekyll"></a>
# **githubDetectJekyll**
> TRPCResponse githubDetectJekyll(input)

Detect Jekyll

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubDetectJekyll(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubDetectJekyll")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubDetectJekyll")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubDisconnect"></a>
# **githubDisconnect**
> TRPCResponse githubDisconnect(body)

Disconnect

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubDisconnectBody =  // TrpcGithubDisconnectBody | 
try {
    val result : TRPCResponse = apiInstance.githubDisconnect(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubDisconnect")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubDisconnect")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubDisconnectBody**](TrpcGithubDisconnectBody.md)|  | [optional]

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubGenerateActionsWorkflow"></a>
# **githubGenerateActionsWorkflow**
> TRPCResponse githubGenerateActionsWorkflow(body)

Generate Actions Workflow

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubGenerateActionsWorkflowBody =  // TrpcGithubGenerateActionsWorkflowBody | 
try {
    val result : TRPCResponse = apiInstance.githubGenerateActionsWorkflow(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubGenerateActionsWorkflow")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubGenerateActionsWorkflow")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubGenerateActionsWorkflowBody**](TrpcGithubGenerateActionsWorkflowBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="githubGetFile"></a>
# **githubGetFile**
> TRPCResponse githubGetFile(input)

Get File

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubGetFile(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubGetFile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubGetFile")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetJekyllConfig"></a>
# **githubGetJekyllConfig**
> TRPCResponse githubGetJekyllConfig(input)

Get Jekyll Config

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubGetJekyllConfig(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubGetJekyllConfig")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubGetJekyllConfig")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetPagesStatus"></a>
# **githubGetPagesStatus**
> TRPCResponse githubGetPagesStatus(input)

Get Pages Status

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubGetPagesStatus(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubGetPagesStatus")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubGetPagesStatus")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubGetRateLimit"></a>
# **githubGetRateLimit**
> TRPCResponse githubGetRateLimit()

Get Rate Limit

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
try {
    val result : TRPCResponse = apiInstance.githubGetRateLimit()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubGetRateLimit")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubGetRateLimit")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubInventory"></a>
# **githubInventory**
> TRPCResponse githubInventory(input)

Inventory

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubInventory(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubInventory")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubInventory")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListBranches"></a>
# **githubListBranches**
> TRPCResponse githubListBranches(input)

List Branches

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubListBranches(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubListBranches")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubListBranches")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListFiles"></a>
# **githubListFiles**
> TRPCResponse githubListFiles(input)

List Files

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubListFiles(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubListFiles")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubListFiles")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubListRepos"></a>
# **githubListRepos**
> TRPCResponse githubListRepos(input)

List Repos

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubListRepos(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubListRepos")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubListRepos")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubRepositories"></a>
# **githubRepositories**
> TRPCResponse githubRepositories(input)

Repositories

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubRepositories(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubRepositories")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubRepositories")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubReviewFile"></a>
# **githubReviewFile**
> TRPCResponse githubReviewFile(input)

Review File

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.githubReviewFile(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubReviewFile")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubReviewFile")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubStatus"></a>
# **githubStatus**
> TRPCResponse githubStatus()

Status

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
try {
    val result : TRPCResponse = apiInstance.githubStatus()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubStatus")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubStatus")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="githubUpdateJekyllConfig"></a>
# **githubUpdateJekyllConfig**
> TRPCResponse githubUpdateJekyllConfig(body)

Update Jekyll Config

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = GithubApi()
val body : TrpcGithubUpdateJekyllConfigBody =  // TrpcGithubUpdateJekyllConfigBody | 
try {
    val result : TRPCResponse = apiInstance.githubUpdateJekyllConfig(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling GithubApi#githubUpdateJekyllConfig")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling GithubApi#githubUpdateJekyllConfig")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcGithubUpdateJekyllConfigBody**](TrpcGithubUpdateJekyllConfigBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

