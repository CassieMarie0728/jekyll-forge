# TrpcAiGenerateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaigenerateJson**](ApitrpcaigenerateJson.md) |  | 
