# ApitrpcsitesupsertJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**kotlin.String**](.md) |  | 
**repo** | [**kotlin.String**](.md) |  | 
**defaultBranch** | [**kotlin.String**](.md) |  |  [optional]
**selectedBranch** | [**kotlin.String**](.md) |  |  [optional]
**rootPath** | [**kotlin.String**](.md) |  |  [optional]
**isJekyll** | [**kotlin.Boolean**](.md) |  |  [optional]
**isFavorite** | [**kotlin.Boolean**](.md) |  |  [optional]
**timezone** | [**kotlin.String**](.md) |  |  [optional]
**defaultLayout** | [**kotlin.String**](.md) |  |  [optional]
**defaultAssetPath** | [**kotlin.String**](.md) |  |  [optional]
