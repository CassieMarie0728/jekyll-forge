# ApitrpcgithubgenerateActionsWorkflowJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**kotlin.String**](.md) |  | 
**repo** | [**kotlin.String**](.md) |  | 
**branch** | [**kotlin.String**](.md) |  | 
