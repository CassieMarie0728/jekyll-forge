# ApitrpcrepurposinggenerateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**siteId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**format** | [**inline**](#Format) |  | 

<a name="Format"></a>
## Enum: format
Name | Value
---- | -----
format | twitter, linkedin, tiktok, youtube, newsletter, email, podcast, slides
