# TrpcAiProvidersActivateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcaiProvidersactivateJson**](ApitrpcaiProvidersactivateJson.md) |  | 
