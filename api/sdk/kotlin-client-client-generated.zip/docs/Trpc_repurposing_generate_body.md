# TrpcRepurposingGenerateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcrepurposinggenerateJson**](ApitrpcrepurposinggenerateJson.md) |  | 
