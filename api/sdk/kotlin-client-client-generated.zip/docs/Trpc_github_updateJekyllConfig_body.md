# TrpcGithubUpdateJekyllConfigBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubupdateJekyllConfigJson**](ApitrpcgithubupdateJekyllConfigJson.md) |  | 
