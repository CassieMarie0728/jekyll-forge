# SnapshotsApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**snapshotsCreate**](SnapshotsApi.md#snapshotsCreate) | **POST** /api/trpc/snapshots.create | Create
[**snapshotsGet**](SnapshotsApi.md#snapshotsGet) | **GET** /api/trpc/snapshots.get | Get
[**snapshotsListByPost**](SnapshotsApi.md#snapshotsListByPost) | **GET** /api/trpc/snapshots.listByPost | List By Post

<a name="snapshotsCreate"></a>
# **snapshotsCreate**
> TRPCResponse snapshotsCreate(body)

Create

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SnapshotsApi()
val body : TrpcSnapshotsCreateBody =  // TrpcSnapshotsCreateBody | 
try {
    val result : TRPCResponse = apiInstance.snapshotsCreate(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SnapshotsApi#snapshotsCreate")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SnapshotsApi#snapshotsCreate")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcSnapshotsCreateBody**](TrpcSnapshotsCreateBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="snapshotsGet"></a>
# **snapshotsGet**
> TRPCResponse snapshotsGet(input)

Get

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SnapshotsApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.snapshotsGet(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SnapshotsApi#snapshotsGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SnapshotsApi#snapshotsGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="snapshotsListByPost"></a>
# **snapshotsListByPost**
> TRPCResponse snapshotsListByPost(input)

List By Post

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SnapshotsApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.snapshotsListByPost(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SnapshotsApi#snapshotsListByPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SnapshotsApi#snapshotsListByPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

