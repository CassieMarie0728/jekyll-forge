# ApitrpcsocialMediareschedulePostJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**scheduledAt** | [**kotlin.Any**](.md) |  | 
**timezone** | [**kotlin.String**](.md) |  |  [optional]
