# TrpcAbTestingCompleteTestBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingcompleteTestJson**](ApitrpcabTestingcompleteTestJson.md) |  | 
