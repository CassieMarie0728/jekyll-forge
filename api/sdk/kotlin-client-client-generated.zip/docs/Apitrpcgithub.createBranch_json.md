# ApitrpcgithubcreateBranchJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**kotlin.String**](.md) |  | 
**repo** | [**kotlin.String**](.md) |  | 
**branchName** | [**kotlin.String**](.md) |  | 
**fromBranch** | [**kotlin.String**](.md) |  | 
