# AbTestingApi

All URIs are relative to *http://localhost:3000*

Method | HTTP request | Description
------------- | ------------- | -------------
[**abTestingApplyWinner**](AbTestingApi.md#abTestingApplyWinner) | **POST** /api/trpc/abTesting.applyWinner | Apply Winner
[**abTestingCompleteTest**](AbTestingApi.md#abTestingCompleteTest) | **POST** /api/trpc/abTesting.completeTest | Complete Test
[**abTestingGenerateVariations**](AbTestingApi.md#abTestingGenerateVariations) | **POST** /api/trpc/abTesting.generateVariations | Generate Variations
[**abTestingGetResults**](AbTestingApi.md#abTestingGetResults) | **GET** /api/trpc/abTesting.getResults | Get Results
[**abTestingGetVariations**](AbTestingApi.md#abTestingGetVariations) | **GET** /api/trpc/abTesting.getVariations | Get Variations
[**abTestingPublishVariation**](AbTestingApi.md#abTestingPublishVariation) | **POST** /api/trpc/abTesting.publishVariation | Publish Variation
[**abTestingUpdateMetrics**](AbTestingApi.md#abTestingUpdateMetrics) | **POST** /api/trpc/abTesting.updateMetrics | Update Metrics

<a name="abTestingApplyWinner"></a>
# **abTestingApplyWinner**
> TRPCResponse abTestingApplyWinner(body)

Apply Winner

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val body : TrpcAbTestingApplyWinnerBody =  // TrpcAbTestingApplyWinnerBody | 
try {
    val result : TRPCResponse = apiInstance.abTestingApplyWinner(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingApplyWinner")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingApplyWinner")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingApplyWinnerBody**](TrpcAbTestingApplyWinnerBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingCompleteTest"></a>
# **abTestingCompleteTest**
> TRPCResponse abTestingCompleteTest(body)

Complete Test

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val body : TrpcAbTestingCompleteTestBody =  // TrpcAbTestingCompleteTestBody | 
try {
    val result : TRPCResponse = apiInstance.abTestingCompleteTest(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingCompleteTest")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingCompleteTest")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingCompleteTestBody**](TrpcAbTestingCompleteTestBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingGenerateVariations"></a>
# **abTestingGenerateVariations**
> TRPCResponse abTestingGenerateVariations(body)

Generate Variations

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val body : TrpcAbTestingGenerateVariationsBody =  // TrpcAbTestingGenerateVariationsBody | 
try {
    val result : TRPCResponse = apiInstance.abTestingGenerateVariations(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingGenerateVariations")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingGenerateVariations")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingGenerateVariationsBody**](TrpcAbTestingGenerateVariationsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingGetResults"></a>
# **abTestingGetResults**
> TRPCResponse abTestingGetResults(input)

Get Results

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.abTestingGetResults(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingGetResults")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingGetResults")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="abTestingGetVariations"></a>
# **abTestingGetVariations**
> TRPCResponse abTestingGetVariations(input)

Get Variations

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val input : kotlin.String = input_example // kotlin.String | URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
try {
    val result : TRPCResponse = apiInstance.abTestingGetVariations(input)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingGetVariations")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingGetVariations")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **input** | **kotlin.String**| URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}} |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="abTestingPublishVariation"></a>
# **abTestingPublishVariation**
> TRPCResponse abTestingPublishVariation(body)

Publish Variation

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val body : TrpcAbTestingPublishVariationBody =  // TrpcAbTestingPublishVariationBody | 
try {
    val result : TRPCResponse = apiInstance.abTestingPublishVariation(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingPublishVariation")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingPublishVariation")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingPublishVariationBody**](TrpcAbTestingPublishVariationBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="abTestingUpdateMetrics"></a>
# **abTestingUpdateMetrics**
> TRPCResponse abTestingUpdateMetrics(body)

Update Metrics

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AbTestingApi()
val body : TrpcAbTestingUpdateMetricsBody =  // TrpcAbTestingUpdateMetricsBody | 
try {
    val result : TRPCResponse = apiInstance.abTestingUpdateMetrics(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AbTestingApi#abTestingUpdateMetrics")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AbTestingApi#abTestingUpdateMetrics")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TrpcAbTestingUpdateMetricsBody**](TrpcAbTestingUpdateMetricsBody.md)|  |

### Return type

[**TRPCResponse**](TRPCResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

