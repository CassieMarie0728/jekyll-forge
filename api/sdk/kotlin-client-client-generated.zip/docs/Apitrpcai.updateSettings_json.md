# ApitrpcaiupdateSettingsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | [**kotlin.Boolean**](.md) |  |  [optional]
**temperature** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**maxTokens** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**systemPrompt** | [**kotlin.String**](.md) |  |  [optional]
**brandVoicePrompt** | [**kotlin.String**](.md) |  |  [optional]
**safetyPrompt** | [**kotlin.String**](.md) |  |  [optional]
**streaming** | [**kotlin.Boolean**](.md) |  |  [optional]
**defaultLanguage** | [**kotlin.String**](.md) |  |  [optional]
**defaultTone** | [**kotlin.String**](.md) |  |  [optional]
**budgetLimitCents** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
