# ApitrpcassetsupdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**name** | [**kotlin.String**](.md) |  |  [optional]
**path** | [**kotlin.String**](.md) |  |  [optional]
**alt** | [**kotlin.String**](.md) |  |  [optional]
