# ApitrpcsocialMediasyncAnalyticsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**analyticsId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
