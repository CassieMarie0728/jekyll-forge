# ApitrpcschedulerrescheduleJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**scheduledAt** | [**kotlin.Any**](.md) |  | 
**timezone** | [**kotlin.String**](.md) |  |  [optional]
