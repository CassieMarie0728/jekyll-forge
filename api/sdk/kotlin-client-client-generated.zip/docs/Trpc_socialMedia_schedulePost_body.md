# TrpcSocialMediaSchedulePostBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsocialMediaschedulePostJson**](ApitrpcsocialMediaschedulePostJson.md) |  | 
