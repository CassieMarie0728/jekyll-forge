# ApitrpcblocksupdateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**name** | [**kotlin.String**](.md) |  |  [optional]
**category** | [**kotlin.String**](.md) |  |  [optional]
**content** | [**kotlin.String**](.md) |  |  [optional]
**contentType** | [**inline**](#ContentType) |  |  [optional]

<a name="ContentType"></a>
## Enum: contentType
Name | Value
---- | -----
contentType | markdown, html, liquid
