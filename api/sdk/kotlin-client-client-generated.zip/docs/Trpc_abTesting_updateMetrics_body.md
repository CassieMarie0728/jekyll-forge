# TrpcAbTestingUpdateMetricsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcabTestingupdateMetricsJson**](ApitrpcabTestingupdateMetricsJson.md) |  | 
