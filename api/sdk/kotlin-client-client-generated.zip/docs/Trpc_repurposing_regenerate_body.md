# TrpcRepurposingRegenerateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcrepurposingregenerateJson**](ApitrpcrepurposingregenerateJson.md) |  | 
