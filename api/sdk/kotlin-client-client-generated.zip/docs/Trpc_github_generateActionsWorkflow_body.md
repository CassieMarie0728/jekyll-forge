# TrpcGithubGenerateActionsWorkflowBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcgithubgenerateActionsWorkflowJson**](ApitrpcgithubgenerateActionsWorkflowJson.md) |  | 
