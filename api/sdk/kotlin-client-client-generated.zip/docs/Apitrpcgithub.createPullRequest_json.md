# ApitrpcgithubcreatePullRequestJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**kotlin.String**](.md) |  | 
**repo** | [**kotlin.String**](.md) |  | 
**title** | [**kotlin.String**](.md) |  | 
**head** | [**kotlin.String**](.md) |  | 
**base** | [**kotlin.String**](.md) |  | 
**body** | [**kotlin.String**](.md) |  |  [optional]
