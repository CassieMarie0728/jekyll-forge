# ApitrpcabTestinggenerateVariationsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**count** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**tones** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
**angles** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
**headline** | [**kotlin.String**](.md) |  | 
**content** | [**kotlin.String**](.md) |  | 
