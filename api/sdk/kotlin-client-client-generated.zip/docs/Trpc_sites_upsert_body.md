# TrpcSitesUpsertBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcsitesupsertJson**](ApitrpcsitesupsertJson.md) |  | 
