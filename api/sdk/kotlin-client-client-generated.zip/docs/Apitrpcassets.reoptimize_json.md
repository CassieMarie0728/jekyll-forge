# ApitrpcassetsreoptimizeJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**maxWidth** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**outputFormat** | [**inline**](#OutputFormat) |  |  [optional]
**quality** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]

<a name="OutputFormat"></a>
## Enum: outputFormat
Name | Value
---- | -----
outputFormat | webp, jpeg, png
