# TrpcAssetsDeleteBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcassetsdeleteJson**](ApitrpcassetsdeleteJson.md) |  | 
