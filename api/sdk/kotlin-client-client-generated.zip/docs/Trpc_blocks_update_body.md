# TrpcBlocksUpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**json** | [**ApitrpcblocksupdateJson**](ApitrpcblocksupdateJson.md) |  | 
