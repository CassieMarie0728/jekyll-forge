# ApitrpcblockscreateJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**kotlin.String**](.md) |  | 
**category** | [**kotlin.String**](.md) |  |  [optional]
**content** | [**kotlin.String**](.md) |  | 
**contentType** | [**inline**](#ContentType) |  | 

<a name="ContentType"></a>
## Enum: contentType
Name | Value
---- | -----
contentType | markdown, html, liquid
