# ApitrpcabTestingupdateMetricsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**postId** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**variationIndex** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**platform** | [**kotlin.String**](.md) |  | 
**metrics** | [**ApitrpcabTestingupdateMetricsJsonMetrics**](ApitrpcabTestingupdateMetricsJsonMetrics.md) |  |  [optional]
