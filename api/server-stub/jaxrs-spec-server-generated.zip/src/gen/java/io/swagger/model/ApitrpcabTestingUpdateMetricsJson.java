package io.swagger.model;

import io.swagger.model.ApitrpcabTestingUpdateMetricsJsonMetrics;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcabTestingUpdateMetricsJson   {

  private @Valid BigDecimal postId = null;

  private @Valid BigDecimal variationIndex = null;

  private @Valid String platform = null;

  private @Valid ApitrpcabTestingUpdateMetricsJsonMetrics metrics = null;

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJson variationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("variationIndex")
  @NotNull

  public BigDecimal getVariationIndex() {
    return variationIndex;
  }
  public void setVariationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJson platform(String platform) {
    this.platform = platform;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("platform")
  @NotNull

  public String getPlatform() {
    return platform;
  }
  public void setPlatform(String platform) {
    this.platform = platform;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJson metrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) {
    this.metrics = metrics;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("metrics")
  @NotNull

  public ApitrpcabTestingUpdateMetricsJsonMetrics getMetrics() {
    return metrics;
  }
  public void setMetrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) {
    this.metrics = metrics;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJson apitrpcabTestingUpdateMetricsJson = (ApitrpcabTestingUpdateMetricsJson) o;
    return Objects.equals(postId, apitrpcabTestingUpdateMetricsJson.postId) &&
        Objects.equals(variationIndex, apitrpcabTestingUpdateMetricsJson.variationIndex) &&
        Objects.equals(platform, apitrpcabTestingUpdateMetricsJson.platform) &&
        Objects.equals(metrics, apitrpcabTestingUpdateMetricsJson.metrics);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, variationIndex, platform, metrics);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    metrics: ").append(toIndentedString(metrics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
