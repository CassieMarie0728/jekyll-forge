package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsocialMediaConnectAccountJson   {

public enum PlatformEnum {

    TWITTER(String.valueOf("twitter")), LINKEDIN(String.valueOf("linkedin")), FACEBOOK(String.valueOf("facebook")), INSTAGRAM(String.valueOf("instagram"));


    private String value;

    PlatformEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static PlatformEnum fromValue(String v) {
        for (PlatformEnum b : PlatformEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}
  private @Valid PlatformEnum platform = null;

  private @Valid String accessToken = null;

  private @Valid String refreshToken = null;

  private @Valid Object expiresAt = null;

  private @Valid String accountId = null;

  private @Valid String username = null;

  private @Valid String displayName = null;

  private @Valid String profileImageUrl = null;

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson platform(PlatformEnum platform) {
    this.platform = platform;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("platform")
  @NotNull

  public PlatformEnum getPlatform() {
    return platform;
  }
  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson accessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("accessToken")
  @NotNull

  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson refreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("refreshToken")
  @NotNull

  public String getRefreshToken() {
    return refreshToken;
  }
  public void setRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson expiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("expiresAt")
  @NotNull

  public Object getExpiresAt() {
    return expiresAt;
  }
  public void setExpiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("accountId")
  @NotNull

  public String getAccountId() {
    return accountId;
  }
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson username(String username) {
    this.username = username;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("username")
  @NotNull

  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("displayName")
  @NotNull

  public String getDisplayName() {
    return displayName;
  }
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson profileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("profileImageUrl")
  @NotNull

  public String getProfileImageUrl() {
    return profileImageUrl;
  }
  public void setProfileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaConnectAccountJson apitrpcsocialMediaConnectAccountJson = (ApitrpcsocialMediaConnectAccountJson) o;
    return Objects.equals(platform, apitrpcsocialMediaConnectAccountJson.platform) &&
        Objects.equals(accessToken, apitrpcsocialMediaConnectAccountJson.accessToken) &&
        Objects.equals(refreshToken, apitrpcsocialMediaConnectAccountJson.refreshToken) &&
        Objects.equals(expiresAt, apitrpcsocialMediaConnectAccountJson.expiresAt) &&
        Objects.equals(accountId, apitrpcsocialMediaConnectAccountJson.accountId) &&
        Objects.equals(username, apitrpcsocialMediaConnectAccountJson.username) &&
        Objects.equals(displayName, apitrpcsocialMediaConnectAccountJson.displayName) &&
        Objects.equals(profileImageUrl, apitrpcsocialMediaConnectAccountJson.profileImageUrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(platform, accessToken, refreshToken, expiresAt, accountId, username, displayName, profileImageUrl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaConnectAccountJson {\n");
    
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    accessToken: ").append(toIndentedString(accessToken)).append("\n");
    sb.append("    refreshToken: ").append(toIndentedString(refreshToken)).append("\n");
    sb.append("    expiresAt: ").append(toIndentedString(expiresAt)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    profileImageUrl: ").append(toIndentedString(profileImageUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
