package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcabTestingUpdateMetricsJsonMetrics   {

  private @Valid BigDecimal impressions = null;

  private @Valid BigDecimal engagements = null;

  private @Valid BigDecimal clicks = null;

  private @Valid BigDecimal shares = null;

  private @Valid BigDecimal likes = null;

  private @Valid BigDecimal replies = null;

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics impressions(BigDecimal impressions) {
    this.impressions = impressions;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("impressions")
  @NotNull

  public BigDecimal getImpressions() {
    return impressions;
  }
  public void setImpressions(BigDecimal impressions) {
    this.impressions = impressions;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics engagements(BigDecimal engagements) {
    this.engagements = engagements;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("engagements")
  @NotNull

  public BigDecimal getEngagements() {
    return engagements;
  }
  public void setEngagements(BigDecimal engagements) {
    this.engagements = engagements;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics clicks(BigDecimal clicks) {
    this.clicks = clicks;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("clicks")
  @NotNull

  public BigDecimal getClicks() {
    return clicks;
  }
  public void setClicks(BigDecimal clicks) {
    this.clicks = clicks;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics shares(BigDecimal shares) {
    this.shares = shares;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("shares")
  @NotNull

  public BigDecimal getShares() {
    return shares;
  }
  public void setShares(BigDecimal shares) {
    this.shares = shares;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics likes(BigDecimal likes) {
    this.likes = likes;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("likes")
  @NotNull

  public BigDecimal getLikes() {
    return likes;
  }
  public void setLikes(BigDecimal likes) {
    this.likes = likes;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics replies(BigDecimal replies) {
    this.replies = replies;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("replies")
  @NotNull

  public BigDecimal getReplies() {
    return replies;
  }
  public void setReplies(BigDecimal replies) {
    this.replies = replies;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJsonMetrics apitrpcabTestingUpdateMetricsJsonMetrics = (ApitrpcabTestingUpdateMetricsJsonMetrics) o;
    return Objects.equals(impressions, apitrpcabTestingUpdateMetricsJsonMetrics.impressions) &&
        Objects.equals(engagements, apitrpcabTestingUpdateMetricsJsonMetrics.engagements) &&
        Objects.equals(clicks, apitrpcabTestingUpdateMetricsJsonMetrics.clicks) &&
        Objects.equals(shares, apitrpcabTestingUpdateMetricsJsonMetrics.shares) &&
        Objects.equals(likes, apitrpcabTestingUpdateMetricsJsonMetrics.likes) &&
        Objects.equals(replies, apitrpcabTestingUpdateMetricsJsonMetrics.replies);
  }

  @Override
  public int hashCode() {
    return Objects.hash(impressions, engagements, clicks, shares, likes, replies);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJsonMetrics {\n");
    
    sb.append("    impressions: ").append(toIndentedString(impressions)).append("\n");
    sb.append("    engagements: ").append(toIndentedString(engagements)).append("\n");
    sb.append("    clicks: ").append(toIndentedString(clicks)).append("\n");
    sb.append("    shares: ").append(toIndentedString(shares)).append("\n");
    sb.append("    likes: ").append(toIndentedString(likes)).append("\n");
    sb.append("    replies: ").append(toIndentedString(replies)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
