package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcrepurposingUpdateJson   {

  private @Valid BigDecimal id = null;

  private @Valid String content = null;

  private @Valid Object status = null;

  private @Valid Boolean isCustomized = null;

  /**
   **/
  public ApitrpcrepurposingUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("id")
  @NotNull

  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcrepurposingUpdateJson content(String content) {
    this.content = content;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("content")
  @NotNull

  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  public ApitrpcrepurposingUpdateJson status(Object status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("status")
  @NotNull

  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  public ApitrpcrepurposingUpdateJson isCustomized(Boolean isCustomized) {
    this.isCustomized = isCustomized;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("isCustomized")
  @NotNull

  public Boolean isIsCustomized() {
    return isCustomized;
  }
  public void setIsCustomized(Boolean isCustomized) {
    this.isCustomized = isCustomized;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingUpdateJson apitrpcrepurposingUpdateJson = (ApitrpcrepurposingUpdateJson) o;
    return Objects.equals(id, apitrpcrepurposingUpdateJson.id) &&
        Objects.equals(content, apitrpcrepurposingUpdateJson.content) &&
        Objects.equals(status, apitrpcrepurposingUpdateJson.status) &&
        Objects.equals(isCustomized, apitrpcrepurposingUpdateJson.isCustomized);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, content, status, isCustomized);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isCustomized: ").append(toIndentedString(isCustomized)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
