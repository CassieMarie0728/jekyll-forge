package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcpostsUpsertJson   {

  private @Valid BigDecimal siteId = null;

  private @Valid String path = null;

  private @Valid String filename = null;

  private @Valid String slug = null;

  private @Valid String title = null;

  private @Valid Object status = null;

  private @Valid Object frontMatter = null;

  private @Valid String markdown = null;

  private @Valid String sha = null;

  private @Valid Object scheduledAt = null;

  /**
   **/
  public ApitrpcpostsUpsertJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("siteId")
  @NotNull

  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson path(String path) {
    this.path = path;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("path")
  @NotNull

  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson filename(String filename) {
    this.filename = filename;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("filename")
  @NotNull

  public String getFilename() {
    return filename;
  }
  public void setFilename(String filename) {
    this.filename = filename;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson slug(String slug) {
    this.slug = slug;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("slug")
  @NotNull

  public String getSlug() {
    return slug;
  }
  public void setSlug(String slug) {
    this.slug = slug;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson title(String title) {
    this.title = title;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("title")
  @NotNull

  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson status(Object status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("status")
  @NotNull

  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("frontMatter")
  @NotNull

  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("markdown")
  @NotNull

  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("sha")
  @NotNull

  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("scheduledAt")
  @NotNull

  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpsertJson apitrpcpostsUpsertJson = (ApitrpcpostsUpsertJson) o;
    return Objects.equals(siteId, apitrpcpostsUpsertJson.siteId) &&
        Objects.equals(path, apitrpcpostsUpsertJson.path) &&
        Objects.equals(filename, apitrpcpostsUpsertJson.filename) &&
        Objects.equals(slug, apitrpcpostsUpsertJson.slug) &&
        Objects.equals(title, apitrpcpostsUpsertJson.title) &&
        Objects.equals(status, apitrpcpostsUpsertJson.status) &&
        Objects.equals(frontMatter, apitrpcpostsUpsertJson.frontMatter) &&
        Objects.equals(markdown, apitrpcpostsUpsertJson.markdown) &&
        Objects.equals(sha, apitrpcpostsUpsertJson.sha) &&
        Objects.equals(scheduledAt, apitrpcpostsUpsertJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, path, filename, slug, title, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpsertJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
