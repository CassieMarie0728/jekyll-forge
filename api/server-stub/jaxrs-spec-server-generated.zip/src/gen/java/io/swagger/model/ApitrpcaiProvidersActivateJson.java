package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcaiProvidersActivateJson   {

  private @Valid Object provider = null;

  /**
   **/
  public ApitrpcaiProvidersActivateJson provider(Object provider) {
    this.provider = provider;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("provider")
  @NotNull

  public Object getProvider() {
    return provider;
  }
  public void setProvider(Object provider) {
    this.provider = provider;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiProvidersActivateJson apitrpcaiProvidersActivateJson = (ApitrpcaiProvidersActivateJson) o;
    return Objects.equals(provider, apitrpcaiProvidersActivateJson.provider);
  }

  @Override
  public int hashCode() {
    return Objects.hash(provider);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiProvidersActivateJson {\n");
    
    sb.append("    provider: ").append(toIndentedString(provider)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
