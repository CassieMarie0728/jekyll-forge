package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcassetsReoptimizeJson   {

  private @Valid BigDecimal id = null;

  private @Valid BigDecimal maxWidth = null;

public enum OutputFormatEnum {

    WEBP(String.valueOf("webp")), JPEG(String.valueOf("jpeg")), PNG(String.valueOf("png"));


    private String value;

    OutputFormatEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static OutputFormatEnum fromValue(String v) {
        for (OutputFormatEnum b : OutputFormatEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}
  private @Valid OutputFormatEnum outputFormat = null;

  private @Valid BigDecimal quality = null;

  /**
   **/
  public ApitrpcassetsReoptimizeJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("id")
  @NotNull

  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcassetsReoptimizeJson maxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("maxWidth")
  @NotNull

  public BigDecimal getMaxWidth() {
    return maxWidth;
  }
  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  /**
   **/
  public ApitrpcassetsReoptimizeJson outputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("outputFormat")
  @NotNull

  public OutputFormatEnum getOutputFormat() {
    return outputFormat;
  }
  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  /**
   **/
  public ApitrpcassetsReoptimizeJson quality(BigDecimal quality) {
    this.quality = quality;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("quality")
  @NotNull

  public BigDecimal getQuality() {
    return quality;
  }
  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsReoptimizeJson apitrpcassetsReoptimizeJson = (ApitrpcassetsReoptimizeJson) o;
    return Objects.equals(id, apitrpcassetsReoptimizeJson.id) &&
        Objects.equals(maxWidth, apitrpcassetsReoptimizeJson.maxWidth) &&
        Objects.equals(outputFormat, apitrpcassetsReoptimizeJson.outputFormat) &&
        Objects.equals(quality, apitrpcassetsReoptimizeJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsReoptimizeJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
