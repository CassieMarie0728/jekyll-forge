package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcgithubCreateBranchJson   {

  private @Valid String owner = null;

  private @Valid String repo = null;

  private @Valid String branchName = null;

  private @Valid String fromBranch = null;

  /**
   **/
  public ApitrpcgithubCreateBranchJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("owner")
  @NotNull

  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubCreateBranchJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("repo")
  @NotNull

  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubCreateBranchJson branchName(String branchName) {
    this.branchName = branchName;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("branchName")
  @NotNull

  public String getBranchName() {
    return branchName;
  }
  public void setBranchName(String branchName) {
    this.branchName = branchName;
  }

  /**
   **/
  public ApitrpcgithubCreateBranchJson fromBranch(String fromBranch) {
    this.fromBranch = fromBranch;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("fromBranch")
  @NotNull

  public String getFromBranch() {
    return fromBranch;
  }
  public void setFromBranch(String fromBranch) {
    this.fromBranch = fromBranch;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCreateBranchJson apitrpcgithubCreateBranchJson = (ApitrpcgithubCreateBranchJson) o;
    return Objects.equals(owner, apitrpcgithubCreateBranchJson.owner) &&
        Objects.equals(repo, apitrpcgithubCreateBranchJson.repo) &&
        Objects.equals(branchName, apitrpcgithubCreateBranchJson.branchName) &&
        Objects.equals(fromBranch, apitrpcgithubCreateBranchJson.fromBranch);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, branchName, fromBranch);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreateBranchJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    branchName: ").append(toIndentedString(branchName)).append("\n");
    sb.append("    fromBranch: ").append(toIndentedString(fromBranch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
