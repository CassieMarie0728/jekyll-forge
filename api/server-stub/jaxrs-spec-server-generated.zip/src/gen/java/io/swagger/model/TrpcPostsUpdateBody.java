package io.swagger.model;

import io.swagger.model.ApitrpcpostsUpdateJson;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class TrpcPostsUpdateBody   {

  private @Valid ApitrpcpostsUpdateJson json = null;

  /**
   **/
  public TrpcPostsUpdateBody json(ApitrpcpostsUpdateJson json) {
    this.json = json;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("json")
  @NotNull

  public ApitrpcpostsUpdateJson getJson() {
    return json;
  }
  public void setJson(ApitrpcpostsUpdateJson json) {
    this.json = json;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrpcPostsUpdateBody trpcPostsUpdateBody = (TrpcPostsUpdateBody) o;
    return Objects.equals(json, trpcPostsUpdateBody.json);
  }

  @Override
  public int hashCode() {
    return Objects.hash(json);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcPostsUpdateBody {\n");
    
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
