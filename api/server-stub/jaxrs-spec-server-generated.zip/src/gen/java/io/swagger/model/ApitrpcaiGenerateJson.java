package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcaiGenerateJson   {

  private @Valid String task = null;

  private @Valid String userPrompt = null;

  private @Valid String selectedText = null;

  private @Valid String postMarkdown = null;

  private @Valid Object frontMatter = null;

  private @Valid String tone = null;

  private @Valid BigDecimal voiceProfileId = null;

  /**
   **/
  public ApitrpcaiGenerateJson task(String task) {
    this.task = task;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("task")
  @NotNull

  public String getTask() {
    return task;
  }
  public void setTask(String task) {
    this.task = task;
  }

  /**
   **/
  public ApitrpcaiGenerateJson userPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("userPrompt")
  @NotNull

  public String getUserPrompt() {
    return userPrompt;
  }
  public void setUserPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
  }

  /**
   **/
  public ApitrpcaiGenerateJson selectedText(String selectedText) {
    this.selectedText = selectedText;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("selectedText")
  @NotNull

  public String getSelectedText() {
    return selectedText;
  }
  public void setSelectedText(String selectedText) {
    this.selectedText = selectedText;
  }

  /**
   **/
  public ApitrpcaiGenerateJson postMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("postMarkdown")
  @NotNull

  public String getPostMarkdown() {
    return postMarkdown;
  }
  public void setPostMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
  }

  /**
   **/
  public ApitrpcaiGenerateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("frontMatter")
  @NotNull

  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  public ApitrpcaiGenerateJson tone(String tone) {
    this.tone = tone;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("tone")
  @NotNull

  public String getTone() {
    return tone;
  }
  public void setTone(String tone) {
    this.tone = tone;
  }

  /**
   **/
  public ApitrpcaiGenerateJson voiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("voiceProfileId")
  @NotNull

  public BigDecimal getVoiceProfileId() {
    return voiceProfileId;
  }
  public void setVoiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiGenerateJson apitrpcaiGenerateJson = (ApitrpcaiGenerateJson) o;
    return Objects.equals(task, apitrpcaiGenerateJson.task) &&
        Objects.equals(userPrompt, apitrpcaiGenerateJson.userPrompt) &&
        Objects.equals(selectedText, apitrpcaiGenerateJson.selectedText) &&
        Objects.equals(postMarkdown, apitrpcaiGenerateJson.postMarkdown) &&
        Objects.equals(frontMatter, apitrpcaiGenerateJson.frontMatter) &&
        Objects.equals(tone, apitrpcaiGenerateJson.tone) &&
        Objects.equals(voiceProfileId, apitrpcaiGenerateJson.voiceProfileId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(task, userPrompt, selectedText, postMarkdown, frontMatter, tone, voiceProfileId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiGenerateJson {\n");
    
    sb.append("    task: ").append(toIndentedString(task)).append("\n");
    sb.append("    userPrompt: ").append(toIndentedString(userPrompt)).append("\n");
    sb.append("    selectedText: ").append(toIndentedString(selectedText)).append("\n");
    sb.append("    postMarkdown: ").append(toIndentedString(postMarkdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    tone: ").append(toIndentedString(tone)).append("\n");
    sb.append("    voiceProfileId: ").append(toIndentedString(voiceProfileId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
