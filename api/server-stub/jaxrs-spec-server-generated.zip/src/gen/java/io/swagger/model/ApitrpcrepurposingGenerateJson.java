package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcrepurposingGenerateJson   {

  private @Valid BigDecimal postId = null;

  private @Valid BigDecimal siteId = null;

public enum FormatEnum {

    TWITTER(String.valueOf("twitter")), LINKEDIN(String.valueOf("linkedin")), TIKTOK(String.valueOf("tiktok")), YOUTUBE(String.valueOf("youtube")), NEWSLETTER(String.valueOf("newsletter")), EMAIL(String.valueOf("email")), PODCAST(String.valueOf("podcast")), SLIDES(String.valueOf("slides"));


    private String value;

    FormatEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static FormatEnum fromValue(String v) {
        for (FormatEnum b : FormatEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}
  private @Valid FormatEnum format = null;

  /**
   **/
  public ApitrpcrepurposingGenerateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcrepurposingGenerateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("siteId")
  @NotNull

  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcrepurposingGenerateJson format(FormatEnum format) {
    this.format = format;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("format")
  @NotNull

  public FormatEnum getFormat() {
    return format;
  }
  public void setFormat(FormatEnum format) {
    this.format = format;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingGenerateJson apitrpcrepurposingGenerateJson = (ApitrpcrepurposingGenerateJson) o;
    return Objects.equals(postId, apitrpcrepurposingGenerateJson.postId) &&
        Objects.equals(siteId, apitrpcrepurposingGenerateJson.siteId) &&
        Objects.equals(format, apitrpcrepurposingGenerateJson.format);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, siteId, format);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingGenerateJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
