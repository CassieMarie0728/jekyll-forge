package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsocialMediaReschedulePostJson   {

  private @Valid BigDecimal postId = null;

  private @Valid Object scheduledAt = null;

  private @Valid String timezone = null;

  /**
   **/
  public ApitrpcsocialMediaReschedulePostJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcsocialMediaReschedulePostJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("scheduledAt")
  @NotNull

  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  public ApitrpcsocialMediaReschedulePostJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("timezone")
  @NotNull

  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaReschedulePostJson apitrpcsocialMediaReschedulePostJson = (ApitrpcsocialMediaReschedulePostJson) o;
    return Objects.equals(postId, apitrpcsocialMediaReschedulePostJson.postId) &&
        Objects.equals(scheduledAt, apitrpcsocialMediaReschedulePostJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcsocialMediaReschedulePostJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaReschedulePostJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
