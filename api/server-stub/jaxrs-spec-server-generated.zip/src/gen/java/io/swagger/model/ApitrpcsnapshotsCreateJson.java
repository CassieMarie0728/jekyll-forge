package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsnapshotsCreateJson   {

  private @Valid BigDecimal siteId = null;

  private @Valid BigDecimal postId = null;

  private @Valid String postPath = null;

  private @Valid String label = null;

  private @Valid Object reason = null;

  private @Valid String markdown = null;

  private @Valid Object frontMatter = null;

  /**
   **/
  public ApitrpcsnapshotsCreateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("siteId")
  @NotNull

  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson postPath(String postPath) {
    this.postPath = postPath;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("postPath")
  @NotNull

  public String getPostPath() {
    return postPath;
  }
  public void setPostPath(String postPath) {
    this.postPath = postPath;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson label(String label) {
    this.label = label;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("label")
  @NotNull

  public String getLabel() {
    return label;
  }
  public void setLabel(String label) {
    this.label = label;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson reason(Object reason) {
    this.reason = reason;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("reason")
  @NotNull

  public Object getReason() {
    return reason;
  }
  public void setReason(Object reason) {
    this.reason = reason;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("markdown")
  @NotNull

  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("frontMatter")
  @NotNull

  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsnapshotsCreateJson apitrpcsnapshotsCreateJson = (ApitrpcsnapshotsCreateJson) o;
    return Objects.equals(siteId, apitrpcsnapshotsCreateJson.siteId) &&
        Objects.equals(postId, apitrpcsnapshotsCreateJson.postId) &&
        Objects.equals(postPath, apitrpcsnapshotsCreateJson.postPath) &&
        Objects.equals(label, apitrpcsnapshotsCreateJson.label) &&
        Objects.equals(reason, apitrpcsnapshotsCreateJson.reason) &&
        Objects.equals(markdown, apitrpcsnapshotsCreateJson.markdown) &&
        Objects.equals(frontMatter, apitrpcsnapshotsCreateJson.frontMatter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, postPath, label, reason, markdown, frontMatter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsnapshotsCreateJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    postPath: ").append(toIndentedString(postPath)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
