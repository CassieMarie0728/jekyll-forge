package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcpostsUpdateJson   {

  private @Valid BigDecimal id = null;

  private @Valid String path = null;

  private @Valid String title = null;

  private @Valid String slug = null;

  private @Valid Object status = null;

  private @Valid Object frontMatter = null;

  private @Valid String markdown = null;

  private @Valid String sha = null;

  private @Valid Object scheduledAt = null;

  /**
   **/
  public ApitrpcpostsUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("id")
  @NotNull

  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson path(String path) {
    this.path = path;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("path")
  @NotNull

  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson title(String title) {
    this.title = title;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("title")
  @NotNull

  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson slug(String slug) {
    this.slug = slug;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("slug")
  @NotNull

  public String getSlug() {
    return slug;
  }
  public void setSlug(String slug) {
    this.slug = slug;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson status(Object status) {
    this.status = status;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("status")
  @NotNull

  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("frontMatter")
  @NotNull

  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("markdown")
  @NotNull

  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("sha")
  @NotNull

  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("scheduledAt")

  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpdateJson apitrpcpostsUpdateJson = (ApitrpcpostsUpdateJson) o;
    return Objects.equals(id, apitrpcpostsUpdateJson.id) &&
        Objects.equals(path, apitrpcpostsUpdateJson.path) &&
        Objects.equals(title, apitrpcpostsUpdateJson.title) &&
        Objects.equals(slug, apitrpcpostsUpdateJson.slug) &&
        Objects.equals(status, apitrpcpostsUpdateJson.status) &&
        Objects.equals(frontMatter, apitrpcpostsUpdateJson.frontMatter) &&
        Objects.equals(markdown, apitrpcpostsUpdateJson.markdown) &&
        Objects.equals(sha, apitrpcpostsUpdateJson.sha) &&
        Objects.equals(scheduledAt, apitrpcpostsUpdateJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, path, title, slug, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
