package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcaiUpdateSettingsJson   {

  private @Valid Boolean enabled = null;

  private @Valid BigDecimal temperature = null;

  private @Valid BigDecimal maxTokens = null;

  private @Valid String systemPrompt = null;

  private @Valid String brandVoicePrompt = null;

  private @Valid String safetyPrompt = null;

  private @Valid Boolean streaming = null;

  private @Valid String defaultLanguage = null;

  private @Valid String defaultTone = null;

  private @Valid BigDecimal budgetLimitCents = null;

  /**
   **/
  public ApitrpcaiUpdateSettingsJson enabled(Boolean enabled) {
    this.enabled = enabled;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("enabled")
  @NotNull

  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson temperature(BigDecimal temperature) {
    this.temperature = temperature;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("temperature")
  @NotNull

  public BigDecimal getTemperature() {
    return temperature;
  }
  public void setTemperature(BigDecimal temperature) {
    this.temperature = temperature;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson maxTokens(BigDecimal maxTokens) {
    this.maxTokens = maxTokens;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("maxTokens")
  @NotNull

  public BigDecimal getMaxTokens() {
    return maxTokens;
  }
  public void setMaxTokens(BigDecimal maxTokens) {
    this.maxTokens = maxTokens;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson systemPrompt(String systemPrompt) {
    this.systemPrompt = systemPrompt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("systemPrompt")
  @NotNull

  public String getSystemPrompt() {
    return systemPrompt;
  }
  public void setSystemPrompt(String systemPrompt) {
    this.systemPrompt = systemPrompt;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson brandVoicePrompt(String brandVoicePrompt) {
    this.brandVoicePrompt = brandVoicePrompt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("brandVoicePrompt")
  @NotNull

  public String getBrandVoicePrompt() {
    return brandVoicePrompt;
  }
  public void setBrandVoicePrompt(String brandVoicePrompt) {
    this.brandVoicePrompt = brandVoicePrompt;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson safetyPrompt(String safetyPrompt) {
    this.safetyPrompt = safetyPrompt;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("safetyPrompt")
  @NotNull

  public String getSafetyPrompt() {
    return safetyPrompt;
  }
  public void setSafetyPrompt(String safetyPrompt) {
    this.safetyPrompt = safetyPrompt;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson streaming(Boolean streaming) {
    this.streaming = streaming;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("streaming")
  @NotNull

  public Boolean isStreaming() {
    return streaming;
  }
  public void setStreaming(Boolean streaming) {
    this.streaming = streaming;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson defaultLanguage(String defaultLanguage) {
    this.defaultLanguage = defaultLanguage;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultLanguage")
  @NotNull

  public String getDefaultLanguage() {
    return defaultLanguage;
  }
  public void setDefaultLanguage(String defaultLanguage) {
    this.defaultLanguage = defaultLanguage;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson defaultTone(String defaultTone) {
    this.defaultTone = defaultTone;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultTone")
  @NotNull

  public String getDefaultTone() {
    return defaultTone;
  }
  public void setDefaultTone(String defaultTone) {
    this.defaultTone = defaultTone;
  }

  /**
   **/
  public ApitrpcaiUpdateSettingsJson budgetLimitCents(BigDecimal budgetLimitCents) {
    this.budgetLimitCents = budgetLimitCents;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("budgetLimitCents")

  public BigDecimal getBudgetLimitCents() {
    return budgetLimitCents;
  }
  public void setBudgetLimitCents(BigDecimal budgetLimitCents) {
    this.budgetLimitCents = budgetLimitCents;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiUpdateSettingsJson apitrpcaiUpdateSettingsJson = (ApitrpcaiUpdateSettingsJson) o;
    return Objects.equals(enabled, apitrpcaiUpdateSettingsJson.enabled) &&
        Objects.equals(temperature, apitrpcaiUpdateSettingsJson.temperature) &&
        Objects.equals(maxTokens, apitrpcaiUpdateSettingsJson.maxTokens) &&
        Objects.equals(systemPrompt, apitrpcaiUpdateSettingsJson.systemPrompt) &&
        Objects.equals(brandVoicePrompt, apitrpcaiUpdateSettingsJson.brandVoicePrompt) &&
        Objects.equals(safetyPrompt, apitrpcaiUpdateSettingsJson.safetyPrompt) &&
        Objects.equals(streaming, apitrpcaiUpdateSettingsJson.streaming) &&
        Objects.equals(defaultLanguage, apitrpcaiUpdateSettingsJson.defaultLanguage) &&
        Objects.equals(defaultTone, apitrpcaiUpdateSettingsJson.defaultTone) &&
        Objects.equals(budgetLimitCents, apitrpcaiUpdateSettingsJson.budgetLimitCents);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enabled, temperature, maxTokens, systemPrompt, brandVoicePrompt, safetyPrompt, streaming, defaultLanguage, defaultTone, budgetLimitCents);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiUpdateSettingsJson {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    temperature: ").append(toIndentedString(temperature)).append("\n");
    sb.append("    maxTokens: ").append(toIndentedString(maxTokens)).append("\n");
    sb.append("    systemPrompt: ").append(toIndentedString(systemPrompt)).append("\n");
    sb.append("    brandVoicePrompt: ").append(toIndentedString(brandVoicePrompt)).append("\n");
    sb.append("    safetyPrompt: ").append(toIndentedString(safetyPrompt)).append("\n");
    sb.append("    streaming: ").append(toIndentedString(streaming)).append("\n");
    sb.append("    defaultLanguage: ").append(toIndentedString(defaultLanguage)).append("\n");
    sb.append("    defaultTone: ").append(toIndentedString(defaultTone)).append("\n");
    sb.append("    budgetLimitCents: ").append(toIndentedString(budgetLimitCents)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
