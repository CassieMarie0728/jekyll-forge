package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcaiProvidersSaveJson   {

  private @Valid Object provider = null;

  private @Valid String model = null;

  private @Valid String apiKey = null;

  /**
   **/
  public ApitrpcaiProvidersSaveJson provider(Object provider) {
    this.provider = provider;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("provider")
  @NotNull

  public Object getProvider() {
    return provider;
  }
  public void setProvider(Object provider) {
    this.provider = provider;
  }

  /**
   **/
  public ApitrpcaiProvidersSaveJson model(String model) {
    this.model = model;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("model")
  @NotNull
 @Size(min=1,max=160)
  public String getModel() {
    return model;
  }
  public void setModel(String model) {
    this.model = model;
  }

  /**
   **/
  public ApitrpcaiProvidersSaveJson apiKey(String apiKey) {
    this.apiKey = apiKey;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("apiKey")
  @NotNull
 @Size(min=8,max=1024)
  public String getApiKey() {
    return apiKey;
  }
  public void setApiKey(String apiKey) {
    this.apiKey = apiKey;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiProvidersSaveJson apitrpcaiProvidersSaveJson = (ApitrpcaiProvidersSaveJson) o;
    return Objects.equals(provider, apitrpcaiProvidersSaveJson.provider) &&
        Objects.equals(model, apitrpcaiProvidersSaveJson.model) &&
        Objects.equals(apiKey, apitrpcaiProvidersSaveJson.apiKey);
  }

  @Override
  public int hashCode() {
    return Objects.hash(provider, model, apiKey);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiProvidersSaveJson {\n");
    
    sb.append("    provider: ").append(toIndentedString(provider)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    apiKey: ").append(toIndentedString(apiKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
