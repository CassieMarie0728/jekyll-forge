package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcgithubCommitFileJson   {

  private @Valid String owner = null;

  private @Valid String repo = null;

  private @Valid String path = null;

  private @Valid String branch = null;

  private @Valid String content = null;

  private @Valid String message = null;

  private @Valid String sha = null;

  /**
   **/
  public ApitrpcgithubCommitFileJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("owner")
  @NotNull

  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("repo")
  @NotNull

  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson path(String path) {
    this.path = path;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("path")
  @NotNull

  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson branch(String branch) {
    this.branch = branch;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("branch")
  @NotNull

  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson content(String content) {
    this.content = content;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("content")
  @NotNull

  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson message(String message) {
    this.message = message;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("message")
  @NotNull

  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("sha")
  @NotNull

  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCommitFileJson apitrpcgithubCommitFileJson = (ApitrpcgithubCommitFileJson) o;
    return Objects.equals(owner, apitrpcgithubCommitFileJson.owner) &&
        Objects.equals(repo, apitrpcgithubCommitFileJson.repo) &&
        Objects.equals(path, apitrpcgithubCommitFileJson.path) &&
        Objects.equals(branch, apitrpcgithubCommitFileJson.branch) &&
        Objects.equals(content, apitrpcgithubCommitFileJson.content) &&
        Objects.equals(message, apitrpcgithubCommitFileJson.message) &&
        Objects.equals(sha, apitrpcgithubCommitFileJson.sha);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, path, branch, content, message, sha);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCommitFileJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
