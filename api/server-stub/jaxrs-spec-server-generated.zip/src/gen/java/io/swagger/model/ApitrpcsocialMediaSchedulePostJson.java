package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsocialMediaSchedulePostJson   {

  private @Valid BigDecimal repurposedContentId = null;

  private @Valid BigDecimal socialMediaAccountId = null;

  private @Valid Object scheduledAt = null;

  private @Valid String timezone = null;

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson repurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("repurposedContentId")
  @NotNull

  public BigDecimal getRepurposedContentId() {
    return repurposedContentId;
  }
  public void setRepurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
  }

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson socialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("socialMediaAccountId")
  @NotNull

  public BigDecimal getSocialMediaAccountId() {
    return socialMediaAccountId;
  }
  public void setSocialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
  }

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("scheduledAt")
  @NotNull

  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("timezone")
  @NotNull

  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSchedulePostJson apitrpcsocialMediaSchedulePostJson = (ApitrpcsocialMediaSchedulePostJson) o;
    return Objects.equals(repurposedContentId, apitrpcsocialMediaSchedulePostJson.repurposedContentId) &&
        Objects.equals(socialMediaAccountId, apitrpcsocialMediaSchedulePostJson.socialMediaAccountId) &&
        Objects.equals(scheduledAt, apitrpcsocialMediaSchedulePostJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcsocialMediaSchedulePostJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repurposedContentId, socialMediaAccountId, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSchedulePostJson {\n");
    
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    socialMediaAccountId: ").append(toIndentedString(socialMediaAccountId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
