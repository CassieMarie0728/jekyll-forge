package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsitesUpdateJson   {

  private @Valid BigDecimal id = null;

  private @Valid Boolean isFavorite = null;

  private @Valid String selectedBranch = null;

  private @Valid String rootPath = null;

  private @Valid String timezone = null;

  private @Valid String defaultLayout = null;

  private @Valid String defaultAssetPath = null;

  private @Valid String aiVoiceProfile = null;

  private @Valid Object settings = null;

  /**
   **/
  public ApitrpcsitesUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("id")
  @NotNull

  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson isFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("isFavorite")
  @NotNull

  public Boolean isIsFavorite() {
    return isFavorite;
  }
  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson selectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("selectedBranch")
  @NotNull

  public String getSelectedBranch() {
    return selectedBranch;
  }
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("rootPath")
  @NotNull

  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("timezone")
  @NotNull

  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson defaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultLayout")
  @NotNull

  public String getDefaultLayout() {
    return defaultLayout;
  }
  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson defaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultAssetPath")
  @NotNull

  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }
  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson aiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("aiVoiceProfile")
  @NotNull

  public String getAiVoiceProfile() {
    return aiVoiceProfile;
  }
  public void setAiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson settings(Object settings) {
    this.settings = settings;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("settings")
  @NotNull

  public Object getSettings() {
    return settings;
  }
  public void setSettings(Object settings) {
    this.settings = settings;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpdateJson apitrpcsitesUpdateJson = (ApitrpcsitesUpdateJson) o;
    return Objects.equals(id, apitrpcsitesUpdateJson.id) &&
        Objects.equals(isFavorite, apitrpcsitesUpdateJson.isFavorite) &&
        Objects.equals(selectedBranch, apitrpcsitesUpdateJson.selectedBranch) &&
        Objects.equals(rootPath, apitrpcsitesUpdateJson.rootPath) &&
        Objects.equals(timezone, apitrpcsitesUpdateJson.timezone) &&
        Objects.equals(defaultLayout, apitrpcsitesUpdateJson.defaultLayout) &&
        Objects.equals(defaultAssetPath, apitrpcsitesUpdateJson.defaultAssetPath) &&
        Objects.equals(aiVoiceProfile, apitrpcsitesUpdateJson.aiVoiceProfile) &&
        Objects.equals(settings, apitrpcsitesUpdateJson.settings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, isFavorite, selectedBranch, rootPath, timezone, defaultLayout, defaultAssetPath, aiVoiceProfile, settings);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("    aiVoiceProfile: ").append(toIndentedString(aiVoiceProfile)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
