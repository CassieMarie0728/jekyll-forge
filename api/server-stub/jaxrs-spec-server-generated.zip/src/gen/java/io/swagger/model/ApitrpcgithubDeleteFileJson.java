package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcgithubDeleteFileJson   {

  private @Valid String owner = null;

  private @Valid String repo = null;

  private @Valid String path = null;

  private @Valid String branch = null;

  private @Valid String sha = null;

  private @Valid String message = null;

  /**
   **/
  public ApitrpcgithubDeleteFileJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("owner")
  @NotNull

  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("repo")
  @NotNull

  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson path(String path) {
    this.path = path;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("path")
  @NotNull

  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson branch(String branch) {
    this.branch = branch;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("branch")
  @NotNull

  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("sha")
  @NotNull

  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson message(String message) {
    this.message = message;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("message")
  @NotNull

  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubDeleteFileJson apitrpcgithubDeleteFileJson = (ApitrpcgithubDeleteFileJson) o;
    return Objects.equals(owner, apitrpcgithubDeleteFileJson.owner) &&
        Objects.equals(repo, apitrpcgithubDeleteFileJson.repo) &&
        Objects.equals(path, apitrpcgithubDeleteFileJson.path) &&
        Objects.equals(branch, apitrpcgithubDeleteFileJson.branch) &&
        Objects.equals(sha, apitrpcgithubDeleteFileJson.sha) &&
        Objects.equals(message, apitrpcgithubDeleteFileJson.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, path, branch, sha, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubDeleteFileJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
