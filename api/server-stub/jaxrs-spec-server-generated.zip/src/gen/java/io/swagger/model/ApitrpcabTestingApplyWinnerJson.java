package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcabTestingApplyWinnerJson   {

  private @Valid BigDecimal postId = null;

  private @Valid BigDecimal winningVariationIndex = null;

  /**
   **/
  public ApitrpcabTestingApplyWinnerJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcabTestingApplyWinnerJson winningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("winningVariationIndex")
  @NotNull

  public BigDecimal getWinningVariationIndex() {
    return winningVariationIndex;
  }
  public void setWinningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingApplyWinnerJson apitrpcabTestingApplyWinnerJson = (ApitrpcabTestingApplyWinnerJson) o;
    return Objects.equals(postId, apitrpcabTestingApplyWinnerJson.postId) &&
        Objects.equals(winningVariationIndex, apitrpcabTestingApplyWinnerJson.winningVariationIndex);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, winningVariationIndex);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingApplyWinnerJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    winningVariationIndex: ").append(toIndentedString(winningVariationIndex)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
