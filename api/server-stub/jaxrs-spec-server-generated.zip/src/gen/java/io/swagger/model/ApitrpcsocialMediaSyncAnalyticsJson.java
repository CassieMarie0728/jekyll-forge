package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsocialMediaSyncAnalyticsJson   {

  private @Valid BigDecimal analyticsId = null;

  /**
   **/
  public ApitrpcsocialMediaSyncAnalyticsJson analyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("analyticsId")
  @NotNull

  public BigDecimal getAnalyticsId() {
    return analyticsId;
  }
  public void setAnalyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSyncAnalyticsJson apitrpcsocialMediaSyncAnalyticsJson = (ApitrpcsocialMediaSyncAnalyticsJson) o;
    return Objects.equals(analyticsId, apitrpcsocialMediaSyncAnalyticsJson.analyticsId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(analyticsId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSyncAnalyticsJson {\n");
    
    sb.append("    analyticsId: ").append(toIndentedString(analyticsId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
