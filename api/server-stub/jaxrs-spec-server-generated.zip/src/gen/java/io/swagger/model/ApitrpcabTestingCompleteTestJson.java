package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcabTestingCompleteTestJson   {

  private @Valid BigDecimal postId = null;

  /**
   **/
  public ApitrpcabTestingCompleteTestJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingCompleteTestJson apitrpcabTestingCompleteTestJson = (ApitrpcabTestingCompleteTestJson) o;
    return Objects.equals(postId, apitrpcabTestingCompleteTestJson.postId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingCompleteTestJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
