package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcassetsUploadJson   {

  private @Valid BigDecimal siteId = null;

  private @Valid String name = null;

  private @Valid String path = null;

  private @Valid String base64Content = null;

  private @Valid String mimeType = null;

  private @Valid BigDecimal size = null;

  private @Valid BigDecimal width = null;

  private @Valid BigDecimal height = null;

  private @Valid Boolean optimize = null;

  private @Valid BigDecimal maxWidth = null;

public enum OutputFormatEnum {

    WEBP(String.valueOf("webp")), JPEG(String.valueOf("jpeg")), PNG(String.valueOf("png")), ORIGINAL(String.valueOf("original"));


    private String value;

    OutputFormatEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static OutputFormatEnum fromValue(String v) {
        for (OutputFormatEnum b : OutputFormatEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}
  private @Valid OutputFormatEnum outputFormat = null;

  private @Valid BigDecimal quality = null;

  /**
   **/
  public ApitrpcassetsUploadJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("siteId")
  @NotNull

  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcassetsUploadJson name(String name) {
    this.name = name;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("name")
  @NotNull
 @Size(min=1,max=256)
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  public ApitrpcassetsUploadJson path(String path) {
    this.path = path;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("path")
  @NotNull

  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcassetsUploadJson base64Content(String base64Content) {
    this.base64Content = base64Content;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("base64Content")
  @NotNull

  public String getBase64Content() {
    return base64Content;
  }
  public void setBase64Content(String base64Content) {
    this.base64Content = base64Content;
  }

  /**
   **/
  public ApitrpcassetsUploadJson mimeType(String mimeType) {
    this.mimeType = mimeType;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("mimeType")
  @NotNull

  public String getMimeType() {
    return mimeType;
  }
  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  /**
   **/
  public ApitrpcassetsUploadJson size(BigDecimal size) {
    this.size = size;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("size")
  @NotNull

  public BigDecimal getSize() {
    return size;
  }
  public void setSize(BigDecimal size) {
    this.size = size;
  }

  /**
   **/
  public ApitrpcassetsUploadJson width(BigDecimal width) {
    this.width = width;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("width")
  @NotNull

  public BigDecimal getWidth() {
    return width;
  }
  public void setWidth(BigDecimal width) {
    this.width = width;
  }

  /**
   **/
  public ApitrpcassetsUploadJson height(BigDecimal height) {
    this.height = height;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("height")
  @NotNull

  public BigDecimal getHeight() {
    return height;
  }
  public void setHeight(BigDecimal height) {
    this.height = height;
  }

  /**
   **/
  public ApitrpcassetsUploadJson optimize(Boolean optimize) {
    this.optimize = optimize;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("optimize")
  @NotNull

  public Boolean isOptimize() {
    return optimize;
  }
  public void setOptimize(Boolean optimize) {
    this.optimize = optimize;
  }

  /**
   **/
  public ApitrpcassetsUploadJson maxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("maxWidth")
  @NotNull

  public BigDecimal getMaxWidth() {
    return maxWidth;
  }
  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  /**
   **/
  public ApitrpcassetsUploadJson outputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("outputFormat")
  @NotNull

  public OutputFormatEnum getOutputFormat() {
    return outputFormat;
  }
  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  /**
   **/
  public ApitrpcassetsUploadJson quality(BigDecimal quality) {
    this.quality = quality;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("quality")
  @NotNull

  public BigDecimal getQuality() {
    return quality;
  }
  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsUploadJson apitrpcassetsUploadJson = (ApitrpcassetsUploadJson) o;
    return Objects.equals(siteId, apitrpcassetsUploadJson.siteId) &&
        Objects.equals(name, apitrpcassetsUploadJson.name) &&
        Objects.equals(path, apitrpcassetsUploadJson.path) &&
        Objects.equals(base64Content, apitrpcassetsUploadJson.base64Content) &&
        Objects.equals(mimeType, apitrpcassetsUploadJson.mimeType) &&
        Objects.equals(size, apitrpcassetsUploadJson.size) &&
        Objects.equals(width, apitrpcassetsUploadJson.width) &&
        Objects.equals(height, apitrpcassetsUploadJson.height) &&
        Objects.equals(optimize, apitrpcassetsUploadJson.optimize) &&
        Objects.equals(maxWidth, apitrpcassetsUploadJson.maxWidth) &&
        Objects.equals(outputFormat, apitrpcassetsUploadJson.outputFormat) &&
        Objects.equals(quality, apitrpcassetsUploadJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, name, path, base64Content, mimeType, size, width, height, optimize, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsUploadJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    base64Content: ").append(toIndentedString(base64Content)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    optimize: ").append(toIndentedString(optimize)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
