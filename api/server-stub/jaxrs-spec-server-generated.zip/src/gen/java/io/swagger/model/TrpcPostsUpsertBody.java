package io.swagger.model;

import io.swagger.model.ApitrpcpostsUpsertJson;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class TrpcPostsUpsertBody   {

  private @Valid ApitrpcpostsUpsertJson json = null;

  /**
   **/
  public TrpcPostsUpsertBody json(ApitrpcpostsUpsertJson json) {
    this.json = json;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("json")
  @NotNull

  public ApitrpcpostsUpsertJson getJson() {
    return json;
  }
  public void setJson(ApitrpcpostsUpsertJson json) {
    this.json = json;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrpcPostsUpsertBody trpcPostsUpsertBody = (TrpcPostsUpsertBody) o;
    return Objects.equals(json, trpcPostsUpsertBody.json);
  }

  @Override
  public int hashCode() {
    return Objects.hash(json);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcPostsUpsertBody {\n");
    
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
