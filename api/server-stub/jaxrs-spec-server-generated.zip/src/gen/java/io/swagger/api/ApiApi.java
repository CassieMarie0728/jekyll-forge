package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;
import io.swagger.model.TrpcAiGenerateBody;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;
import io.swagger.model.TrpcAiUpdateSettingsBody;
import io.swagger.model.TrpcAssetsDeleteBody;
import io.swagger.model.TrpcAssetsGenerateAltTextBody;
import io.swagger.model.TrpcAssetsReoptimizeBody;
import io.swagger.model.TrpcAssetsUpdateBody;
import io.swagger.model.TrpcAssetsUploadBody;
import io.swagger.model.TrpcBlocksCreateBody;
import io.swagger.model.TrpcBlocksDeleteBody;
import io.swagger.model.TrpcBlocksUpdateBody;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;
import io.swagger.model.TrpcNotificationsRegisterDeviceBody;
import io.swagger.model.TrpcNotificationsUnregisterDeviceBody;
import io.swagger.model.TrpcPostsAutosaveBody;
import io.swagger.model.TrpcPostsDeleteBody;
import io.swagger.model.TrpcPostsUpdateBody;
import io.swagger.model.TrpcPostsUpsertBody;
import io.swagger.model.TrpcRepurposingDeleteBody;
import io.swagger.model.TrpcRepurposingGenerateBody;
import io.swagger.model.TrpcRepurposingRegenerateBody;
import io.swagger.model.TrpcRepurposingUpdateBody;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;
import io.swagger.model.TrpcSitesDeleteBody;
import io.swagger.model.TrpcSitesUpdateBody;
import io.swagger.model.TrpcSitesUpsertBody;
import io.swagger.model.TrpcSnapshotsCreateBody;
import io.swagger.model.TrpcSocialMediaCancelScheduledPostBody;
import io.swagger.model.TrpcSocialMediaConnectAccountBody;
import io.swagger.model.TrpcSocialMediaDisconnectAccountBody;
import io.swagger.model.TrpcSocialMediaPublishContentBody;
import io.swagger.model.TrpcSocialMediaReschedulePostBody;
import io.swagger.model.TrpcSocialMediaSchedulePostBody;
import io.swagger.model.TrpcSocialMediaSyncAnalyticsBody;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import java.util.Map;
import java.util.List;
import javax.validation.constraints.*;
import javax.validation.Valid;

@Path("/api")

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJAXRSSpecServerCodegen", date = "2026-09-27T19:37:33.020490393Z[GMT]")
public class ApiApi {

    @POST
    @Path("/trpc/abTesting.applyWinner")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Apply Winner", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingApplyWinner(@Valid TrpcAbTestingApplyWinnerBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/abTesting.completeTest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Complete Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingCompleteTest(@Valid TrpcAbTestingCompleteTestBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/abTesting.generateVariations")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingGenerateVariations(@Valid TrpcAbTestingGenerateVariationsBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/abTesting.getResults")
    @Produces({ "application/json" })
    @Operation(summary = "Get Results", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingGetResults( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/abTesting.getVariations")
    @Produces({ "application/json" })
    @Operation(summary = "Get Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingGetVariations( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/abTesting.publishVariation")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Variation", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingPublishVariation(@Valid TrpcAbTestingPublishVariationBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/abTesting.updateMetrics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Metrics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response abTestingUpdateMetrics(@Valid TrpcAbTestingUpdateMetricsBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/ai.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiGenerate(@Valid TrpcAiGenerateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/ai.getSettings")
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiGetSettings() {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/ai.getUsageStats")
    @Produces({ "application/json" })
    @Operation(summary = "Get Usage Stats", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiGetUsageStats() {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/aiProviders.activate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Activate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiProvidersActivate(@Valid TrpcAiProvidersActivateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/aiProviders.getSettings")
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiProvidersGetSettings() {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/aiProviders.remove")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Remove", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiProvidersRemove(@Valid TrpcAiProvidersRemoveBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/aiProviders.save")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Save", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiProvidersSave(@Valid TrpcAiProvidersSaveBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/aiProviders.test")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiProvidersTest(@Valid TrpcAiProvidersTestBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/ai.updateSettings")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response aiUpdateSettings(@Valid TrpcAiUpdateSettingsBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/assets.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response assetsDelete(@Valid TrpcAssetsDeleteBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/assets.generateAltText")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Alt Text", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response assetsGenerateAltText(@Valid TrpcAssetsGenerateAltTextBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/assets.list")
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response assetsList( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/assets.reoptimize")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reoptimize", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response assetsReoptimize(@Valid TrpcAssetsReoptimizeBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/assets.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response assetsUpdate(@Valid TrpcAssetsUpdateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/assets.upload")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upload", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response assetsUpload(@Valid TrpcAssetsUploadBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/blocks.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response blocksCreate(@Valid TrpcBlocksCreateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/blocks.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response blocksDelete(@Valid TrpcBlocksDeleteBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/blocks.list")
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response blocksList() {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/blocks.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response blocksUpdate(@Valid TrpcBlocksUpdateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.checkPluginCompatibility")
    @Produces({ "application/json" })
    @Operation(summary = "Check Plugin Compatibility", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubCheckPluginCompatibility( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.commitFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Commit File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubCommitFile(@Valid TrpcGithubCommitFileBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.connect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubConnect(@Valid TrpcGithubConnectBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.createBranch")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Branch", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubCreateBranch(@Valid TrpcGithubCreateBranchBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.createPullRequest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Pull Request", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubCreatePullRequest(@Valid TrpcGithubCreatePullRequestBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.deleteFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubDeleteFile(@Valid TrpcGithubDeleteFileBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.detectJekyll")
    @Produces({ "application/json" })
    @Operation(summary = "Detect Jekyll", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubDetectJekyll( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.disconnect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubDisconnect(@Valid TrpcGithubDisconnectBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.generateActionsWorkflow")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Actions Workflow", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubGenerateActionsWorkflow(@Valid TrpcGithubGenerateActionsWorkflowBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.getFile")
    @Produces({ "application/json" })
    @Operation(summary = "Get File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubGetFile( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.getJekyllConfig")
    @Produces({ "application/json" })
    @Operation(summary = "Get Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubGetJekyllConfig( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.getPagesStatus")
    @Produces({ "application/json" })
    @Operation(summary = "Get Pages Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubGetPagesStatus( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.getRateLimit")
    @Produces({ "application/json" })
    @Operation(summary = "Get Rate Limit", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubGetRateLimit() {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.inventory")
    @Produces({ "application/json" })
    @Operation(summary = "Inventory", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubInventory( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.listBranches")
    @Produces({ "application/json" })
    @Operation(summary = "List Branches", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubListBranches( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.listFiles")
    @Produces({ "application/json" })
    @Operation(summary = "List Files", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubListFiles( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.listRepos")
    @Produces({ "application/json" })
    @Operation(summary = "List Repos", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubListRepos( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.repositories")
    @Produces({ "application/json" })
    @Operation(summary = "Repositories", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubRepositories( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.reviewFile")
    @Produces({ "application/json" })
    @Operation(summary = "Review File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubReviewFile( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/github.status")
    @Produces({ "application/json" })
    @Operation(summary = "Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubStatus() {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/github.updateJekyllConfig")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response githubUpdateJekyllConfig(@Valid TrpcGithubUpdateJekyllConfigBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/notifications.registerDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Register Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Notifications" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response notificationsRegisterDevice(@Valid TrpcNotificationsRegisterDeviceBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/notifications.unregisterDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Unregister Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Notifications" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response notificationsUnregisterDevice(@Valid TrpcNotificationsUnregisterDeviceBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/posts.autosave")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Autosave", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsAutosave(@Valid TrpcPostsAutosaveBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/posts.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsDelete(@Valid TrpcPostsDeleteBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/posts.get")
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsGet( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/posts.getFrontMatterTemplates")
    @Produces({ "application/json" })
    @Operation(summary = "Get Front Matter Templates", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsGetFrontMatterTemplates( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/posts.list")
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsList( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/posts.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsUpdate(@Valid TrpcPostsUpdateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/posts.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response postsUpsert(@Valid TrpcPostsUpsertBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/repurposing.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response repurposingDelete(@Valid TrpcRepurposingDeleteBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/repurposing.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response repurposingGenerate(@Valid TrpcRepurposingGenerateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/repurposing.getById")
    @Produces({ "application/json" })
    @Operation(summary = "Get By Id", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response repurposingGetById( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/repurposing.getByPost")
    @Produces({ "application/json" })
    @Operation(summary = "Get By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response repurposingGetByPost( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/repurposing.regenerate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Regenerate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response repurposingRegenerate(@Valid TrpcRepurposingRegenerateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/repurposing.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response repurposingUpdate(@Valid TrpcRepurposingUpdateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/scheduler.cancel")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerCancel(@Valid TrpcSchedulerCancelBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/scheduler.cancelAll")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel All", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerCancelAll(@Valid TrpcSchedulerCancelAllBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/scheduler.list")
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerList( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/scheduler.listHeartbeatJobs")
    @Produces({ "application/json" })
    @Operation(summary = "List Heartbeat Jobs", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerListHeartbeatJobs( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/scheduler.markFailed")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Failed", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerMarkFailed(@Valid TrpcSchedulerMarkFailedBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/scheduler.markPublished")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Published", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerMarkPublished(@Valid TrpcSchedulerMarkPublishedBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/scheduler.reschedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerReschedule(@Valid TrpcSchedulerRescheduleBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/scheduler.schedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response schedulerSchedule(@Valid TrpcSchedulerScheduleBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/sites.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response sitesDelete(@Valid TrpcSitesDeleteBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/sites.get")
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response sitesGet( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/sites.list")
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response sitesList() {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/sites.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response sitesUpdate(@Valid TrpcSitesUpdateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/sites.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response sitesUpsert(@Valid TrpcSitesUpsertBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/snapshots.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response snapshotsCreate(@Valid TrpcSnapshotsCreateBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/snapshots.get")
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response snapshotsGet( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/snapshots.listByPost")
    @Produces({ "application/json" })
    @Operation(summary = "List By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response snapshotsListByPost( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.cancelScheduledPost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel Scheduled Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaCancelScheduledPost(@Valid TrpcSocialMediaCancelScheduledPostBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.connectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaConnectAccount(@Valid TrpcSocialMediaConnectAccountBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.disconnectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaDisconnectAccount(@Valid TrpcSocialMediaDisconnectAccountBody body) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/socialMedia.getAccountDetails")
    @Produces({ "application/json" })
    @Operation(summary = "Get Account Details", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaGetAccountDetails( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/socialMedia.getAccounts")
    @Produces({ "application/json" })
    @Operation(summary = "Get Accounts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaGetAccounts() {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/socialMedia.getAnalyticsByPlatform")
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics By Platform", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaGetAnalyticsByPlatform( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/socialMedia.getAnalyticsSummary")
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics Summary", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaGetAnalyticsSummary() {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/socialMedia.getContentAnalytics")
    @Produces({ "application/json" })
    @Operation(summary = "Get Content Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaGetContentAnalytics( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @GET
    @Path("/trpc/socialMedia.getScheduledPosts")
    @Produces({ "application/json" })
    @Operation(summary = "Get Scheduled Posts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaGetScheduledPosts( @NotNull  @QueryParam("input") 

 @Parameter(description = "URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}")  String input
) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.publishContent")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Content", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaPublishContent(@Valid TrpcSocialMediaPublishContentBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.reschedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaReschedulePost(@Valid TrpcSocialMediaReschedulePostBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.schedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaSchedulePost(@Valid TrpcSocialMediaSchedulePostBody body) {
        return Response.ok().entity("magic!").build();
    }
    @POST
    @Path("/trpc/socialMedia.syncAnalytics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Sync Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
    })
    public Response socialMediaSyncAnalytics(@Valid TrpcSocialMediaSyncAnalyticsBody body) {
        return Response.ok().entity("magic!").build();
    }}
