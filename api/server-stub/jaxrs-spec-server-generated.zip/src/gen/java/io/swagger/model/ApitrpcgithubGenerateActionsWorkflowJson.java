package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcgithubGenerateActionsWorkflowJson   {

  private @Valid String owner = null;

  private @Valid String repo = null;

  private @Valid String branch = null;

  /**
   **/
  public ApitrpcgithubGenerateActionsWorkflowJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("owner")
  @NotNull

  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubGenerateActionsWorkflowJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("repo")
  @NotNull

  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubGenerateActionsWorkflowJson branch(String branch) {
    this.branch = branch;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("branch")
  @NotNull

  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubGenerateActionsWorkflowJson apitrpcgithubGenerateActionsWorkflowJson = (ApitrpcgithubGenerateActionsWorkflowJson) o;
    return Objects.equals(owner, apitrpcgithubGenerateActionsWorkflowJson.owner) &&
        Objects.equals(repo, apitrpcgithubGenerateActionsWorkflowJson.repo) &&
        Objects.equals(branch, apitrpcgithubGenerateActionsWorkflowJson.branch);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, branch);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubGenerateActionsWorkflowJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
