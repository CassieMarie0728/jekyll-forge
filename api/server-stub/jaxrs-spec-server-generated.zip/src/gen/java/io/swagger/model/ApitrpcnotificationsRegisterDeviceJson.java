package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcnotificationsRegisterDeviceJson   {

  private @Valid String token = null;

public enum PlatformEnum {

    ANDROID(String.valueOf("android"));


    private String value;

    PlatformEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static PlatformEnum fromValue(String v) {
        for (PlatformEnum b : PlatformEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}
  private @Valid PlatformEnum platform = null;

  /**
   **/
  public ApitrpcnotificationsRegisterDeviceJson token(String token) {
    this.token = token;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("token")
  @NotNull
 @Size(min=1,max=512)
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  public ApitrpcnotificationsRegisterDeviceJson platform(PlatformEnum platform) {
    this.platform = platform;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("platform")
  @NotNull

  public PlatformEnum getPlatform() {
    return platform;
  }
  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcnotificationsRegisterDeviceJson apitrpcnotificationsRegisterDeviceJson = (ApitrpcnotificationsRegisterDeviceJson) o;
    return Objects.equals(token, apitrpcnotificationsRegisterDeviceJson.token) &&
        Objects.equals(platform, apitrpcnotificationsRegisterDeviceJson.platform);
  }

  @Override
  public int hashCode() {
    return Objects.hash(token, platform);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcnotificationsRegisterDeviceJson {\n");
    
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
