package io.swagger.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcabTestingPublishVariationJson   {

  private @Valid BigDecimal postId = null;

  private @Valid BigDecimal variationIndex = null;

public enum PlatformsEnum {

    TWITTER(String.valueOf("twitter")), LINKEDIN(String.valueOf("linkedin")), FACEBOOK(String.valueOf("facebook")), INSTAGRAM(String.valueOf("instagram")), EMAIL(String.valueOf("email")), DIRECT(String.valueOf("direct"));


    private String value;

    PlatformsEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static PlatformsEnum fromValue(String v) {
        for (PlatformsEnum b : PlatformsEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}
  private @Valid List<PlatformsEnum> platforms = new ArrayList<PlatformsEnum>();

  /**
   **/
  public ApitrpcabTestingPublishVariationJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcabTestingPublishVariationJson variationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("variationIndex")
  @NotNull

  public BigDecimal getVariationIndex() {
    return variationIndex;
  }
  public void setVariationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
  }

  /**
   **/
  public ApitrpcabTestingPublishVariationJson platforms(List<PlatformsEnum> platforms) {
    this.platforms = platforms;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("platforms")
  @NotNull

  public List<PlatformsEnum> getPlatforms() {
    return platforms;
  }
  public void setPlatforms(List<PlatformsEnum> platforms) {
    this.platforms = platforms;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingPublishVariationJson apitrpcabTestingPublishVariationJson = (ApitrpcabTestingPublishVariationJson) o;
    return Objects.equals(postId, apitrpcabTestingPublishVariationJson.postId) &&
        Objects.equals(variationIndex, apitrpcabTestingPublishVariationJson.variationIndex) &&
        Objects.equals(platforms, apitrpcabTestingPublishVariationJson.platforms);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, variationIndex, platforms);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingPublishVariationJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platforms: ").append(toIndentedString(platforms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
