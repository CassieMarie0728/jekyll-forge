package io.swagger.model;

import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcsitesUpsertJson   {

  private @Valid String owner = null;

  private @Valid String repo = null;

  private @Valid String defaultBranch = null;

  private @Valid String selectedBranch = null;

  private @Valid String rootPath = null;

  private @Valid Boolean isJekyll = null;

  private @Valid Boolean isFavorite = null;

  private @Valid String timezone = null;

  private @Valid String defaultLayout = null;

  private @Valid String defaultAssetPath = null;

  /**
   **/
  public ApitrpcsitesUpsertJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("owner")
  @NotNull

  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("repo")
  @NotNull

  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson defaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultBranch")
  @NotNull

  public String getDefaultBranch() {
    return defaultBranch;
  }
  public void setDefaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson selectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("selectedBranch")
  @NotNull

  public String getSelectedBranch() {
    return selectedBranch;
  }
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("rootPath")
  @NotNull

  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson isJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("isJekyll")
  @NotNull

  public Boolean isIsJekyll() {
    return isJekyll;
  }
  public void setIsJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson isFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("isFavorite")
  @NotNull

  public Boolean isIsFavorite() {
    return isFavorite;
  }
  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("timezone")
  @NotNull

  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson defaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultLayout")
  @NotNull

  public String getDefaultLayout() {
    return defaultLayout;
  }
  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson defaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("defaultAssetPath")
  @NotNull

  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }
  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpsertJson apitrpcsitesUpsertJson = (ApitrpcsitesUpsertJson) o;
    return Objects.equals(owner, apitrpcsitesUpsertJson.owner) &&
        Objects.equals(repo, apitrpcsitesUpsertJson.repo) &&
        Objects.equals(defaultBranch, apitrpcsitesUpsertJson.defaultBranch) &&
        Objects.equals(selectedBranch, apitrpcsitesUpsertJson.selectedBranch) &&
        Objects.equals(rootPath, apitrpcsitesUpsertJson.rootPath) &&
        Objects.equals(isJekyll, apitrpcsitesUpsertJson.isJekyll) &&
        Objects.equals(isFavorite, apitrpcsitesUpsertJson.isFavorite) &&
        Objects.equals(timezone, apitrpcsitesUpsertJson.timezone) &&
        Objects.equals(defaultLayout, apitrpcsitesUpsertJson.defaultLayout) &&
        Objects.equals(defaultAssetPath, apitrpcsitesUpsertJson.defaultAssetPath);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, defaultBranch, selectedBranch, rootPath, isJekyll, isFavorite, timezone, defaultLayout, defaultAssetPath);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpsertJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    defaultBranch: ").append(toIndentedString(defaultBranch)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    isJekyll: ").append(toIndentedString(isJekyll)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
