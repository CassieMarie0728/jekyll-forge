package io.swagger.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.*;
import javax.validation.Valid;


import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ApitrpcabTestingGenerateVariationsJson   {

  private @Valid BigDecimal postId = null;

  private @Valid BigDecimal count = null;

  private @Valid List<String> tones = new ArrayList<String>();

  private @Valid List<String> angles = new ArrayList<String>();

  private @Valid String headline = null;

  private @Valid String content = null;

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("postId")
  @NotNull

  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson count(BigDecimal count) {
    this.count = count;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("count")
  @NotNull

  public BigDecimal getCount() {
    return count;
  }
  public void setCount(BigDecimal count) {
    this.count = count;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson tones(List<String> tones) {
    this.tones = tones;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("tones")
  @NotNull

  public List<String> getTones() {
    return tones;
  }
  public void setTones(List<String> tones) {
    this.tones = tones;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson angles(List<String> angles) {
    this.angles = angles;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("angles")
  @NotNull

  public List<String> getAngles() {
    return angles;
  }
  public void setAngles(List<String> angles) {
    this.angles = angles;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson headline(String headline) {
    this.headline = headline;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("headline")
  @NotNull

  public String getHeadline() {
    return headline;
  }
  public void setHeadline(String headline) {
    this.headline = headline;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson content(String content) {
    this.content = content;
    return this;
  }

  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("content")
  @NotNull

  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingGenerateVariationsJson apitrpcabTestingGenerateVariationsJson = (ApitrpcabTestingGenerateVariationsJson) o;
    return Objects.equals(postId, apitrpcabTestingGenerateVariationsJson.postId) &&
        Objects.equals(count, apitrpcabTestingGenerateVariationsJson.count) &&
        Objects.equals(tones, apitrpcabTestingGenerateVariationsJson.tones) &&
        Objects.equals(angles, apitrpcabTestingGenerateVariationsJson.angles) &&
        Objects.equals(headline, apitrpcabTestingGenerateVariationsJson.headline) &&
        Objects.equals(content, apitrpcabTestingGenerateVariationsJson.content);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, count, tones, angles, headline, content);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingGenerateVariationsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    tones: ").append(toIndentedString(tones)).append("\n");
    sb.append("    angles: ").append(toIndentedString(angles)).append("\n");
    sb.append("    headline: ").append(toIndentedString(headline)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
