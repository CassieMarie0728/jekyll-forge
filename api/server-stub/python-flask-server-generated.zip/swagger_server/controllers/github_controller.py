import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_github_commit_file_body import TrpcGithubCommitFileBody  # noqa: E501
from swagger_server.models.trpc_github_connect_body import TrpcGithubConnectBody  # noqa: E501
from swagger_server.models.trpc_github_create_branch_body import TrpcGithubCreateBranchBody  # noqa: E501
from swagger_server.models.trpc_github_create_pull_request_body import TrpcGithubCreatePullRequestBody  # noqa: E501
from swagger_server.models.trpc_github_delete_file_body import TrpcGithubDeleteFileBody  # noqa: E501
from swagger_server.models.trpc_github_disconnect_body import TrpcGithubDisconnectBody  # noqa: E501
from swagger_server.models.trpc_github_generate_actions_workflow_body import TrpcGithubGenerateActionsWorkflowBody  # noqa: E501
from swagger_server.models.trpc_github_update_jekyll_config_body import TrpcGithubUpdateJekyllConfigBody  # noqa: E501
from swagger_server import util


def github_check_plugin_compatibility(input):  # noqa: E501
    """Check Plugin Compatibility

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_commit_file(body):  # noqa: E501
    """Commit File

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubCommitFileBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_connect(body):  # noqa: E501
    """Connect

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubConnectBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_create_branch(body):  # noqa: E501
    """Create Branch

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubCreateBranchBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_create_pull_request(body):  # noqa: E501
    """Create Pull Request

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubCreatePullRequestBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_delete_file(body):  # noqa: E501
    """Delete File

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubDeleteFileBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_detect_jekyll(input):  # noqa: E501
    """Detect Jekyll

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_disconnect(body=None):  # noqa: E501
    """Disconnect

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubDisconnectBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_generate_actions_workflow(body):  # noqa: E501
    """Generate Actions Workflow

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubGenerateActionsWorkflowBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def github_get_file(input):  # noqa: E501
    """Get File

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_get_jekyll_config(input):  # noqa: E501
    """Get Jekyll Config

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_get_pages_status(input):  # noqa: E501
    """Get Pages Status

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_get_rate_limit():  # noqa: E501
    """Get Rate Limit

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_inventory(input):  # noqa: E501
    """Inventory

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_list_branches(input):  # noqa: E501
    """List Branches

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_list_files(input):  # noqa: E501
    """List Files

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_list_repos(input):  # noqa: E501
    """List Repos

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_repositories(input):  # noqa: E501
    """Repositories

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_review_file(input):  # noqa: E501
    """Review File

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_status():  # noqa: E501
    """Status

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def github_update_jekyll_config(body):  # noqa: E501
    """Update Jekyll Config

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcGithubUpdateJekyllConfigBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
