import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_blocks_create_body import TrpcBlocksCreateBody  # noqa: E501
from swagger_server.models.trpc_blocks_delete_body import TrpcBlocksDeleteBody  # noqa: E501
from swagger_server.models.trpc_blocks_update_body import TrpcBlocksUpdateBody  # noqa: E501
from swagger_server import util


def blocks_create(body):  # noqa: E501
    """Create

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcBlocksCreateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def blocks_delete(body):  # noqa: E501
    """Delete

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcBlocksDeleteBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def blocks_list():  # noqa: E501
    """List

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def blocks_update(body):  # noqa: E501
    """Update

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcBlocksUpdateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
