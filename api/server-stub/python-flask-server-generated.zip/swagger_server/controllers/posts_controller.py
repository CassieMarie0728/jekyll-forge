import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_posts_autosave_body import TrpcPostsAutosaveBody  # noqa: E501
from swagger_server.models.trpc_posts_delete_body import TrpcPostsDeleteBody  # noqa: E501
from swagger_server.models.trpc_posts_update_body import TrpcPostsUpdateBody  # noqa: E501
from swagger_server.models.trpc_posts_upsert_body import TrpcPostsUpsertBody  # noqa: E501
from swagger_server import util


def posts_autosave(body):  # noqa: E501
    """Autosave

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcPostsAutosaveBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def posts_delete(body):  # noqa: E501
    """Delete

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcPostsDeleteBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def posts_get(input):  # noqa: E501
    """Get

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def posts_get_front_matter_templates(input):  # noqa: E501
    """Get Front Matter Templates

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def posts_list(input):  # noqa: E501
    """List

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def posts_update(body):  # noqa: E501
    """Update

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcPostsUpdateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def posts_upsert(body):  # noqa: E501
    """Upsert

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcPostsUpsertBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
