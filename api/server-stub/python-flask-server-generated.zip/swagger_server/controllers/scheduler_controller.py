import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_scheduler_cancel_all_body import TrpcSchedulerCancelAllBody  # noqa: E501
from swagger_server.models.trpc_scheduler_cancel_body import TrpcSchedulerCancelBody  # noqa: E501
from swagger_server.models.trpc_scheduler_mark_failed_body import TrpcSchedulerMarkFailedBody  # noqa: E501
from swagger_server.models.trpc_scheduler_mark_published_body import TrpcSchedulerMarkPublishedBody  # noqa: E501
from swagger_server.models.trpc_scheduler_reschedule_body import TrpcSchedulerRescheduleBody  # noqa: E501
from swagger_server.models.trpc_scheduler_schedule_body import TrpcSchedulerScheduleBody  # noqa: E501
from swagger_server import util


def scheduler_cancel(body):  # noqa: E501
    """Cancel

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSchedulerCancelBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def scheduler_cancel_all(body):  # noqa: E501
    """Cancel All

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSchedulerCancelAllBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def scheduler_list(input):  # noqa: E501
    """List

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def scheduler_list_heartbeat_jobs(input):  # noqa: E501
    """List Heartbeat Jobs

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def scheduler_mark_failed(body):  # noqa: E501
    """Mark Failed

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSchedulerMarkFailedBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def scheduler_mark_published(body):  # noqa: E501
    """Mark Published

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSchedulerMarkPublishedBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def scheduler_reschedule(body):  # noqa: E501
    """Reschedule

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSchedulerRescheduleBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def scheduler_schedule(body):  # noqa: E501
    """Schedule

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSchedulerScheduleBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
