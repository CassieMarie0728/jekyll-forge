import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_ai_providers_activate_body import TrpcAiProvidersActivateBody  # noqa: E501
from swagger_server.models.trpc_ai_providers_remove_body import TrpcAiProvidersRemoveBody  # noqa: E501
from swagger_server.models.trpc_ai_providers_save_body import TrpcAiProvidersSaveBody  # noqa: E501
from swagger_server.models.trpc_ai_providers_test_body import TrpcAiProvidersTestBody  # noqa: E501
from swagger_server import util


def ai_providers_activate(body):  # noqa: E501
    """Activate

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAiProvidersActivateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ai_providers_get_settings():  # noqa: E501
    """Get Settings

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def ai_providers_remove(body):  # noqa: E501
    """Remove

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAiProvidersRemoveBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ai_providers_save(body):  # noqa: E501
    """Save

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAiProvidersSaveBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ai_providers_test(body):  # noqa: E501
    """Test

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAiProvidersTestBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
