import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_ai_generate_body import TrpcAiGenerateBody  # noqa: E501
from swagger_server.models.trpc_ai_update_settings_body import TrpcAiUpdateSettingsBody  # noqa: E501
from swagger_server import util


def ai_generate(body):  # noqa: E501
    """Generate

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAiGenerateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ai_get_settings():  # noqa: E501
    """Get Settings

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def ai_get_usage_stats():  # noqa: E501
    """Get Usage Stats

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def ai_update_settings(body):  # noqa: E501
    """Update Settings

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAiUpdateSettingsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
