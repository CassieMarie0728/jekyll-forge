import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_assets_delete_body import TrpcAssetsDeleteBody  # noqa: E501
from swagger_server.models.trpc_assets_generate_alt_text_body import TrpcAssetsGenerateAltTextBody  # noqa: E501
from swagger_server.models.trpc_assets_reoptimize_body import TrpcAssetsReoptimizeBody  # noqa: E501
from swagger_server.models.trpc_assets_update_body import TrpcAssetsUpdateBody  # noqa: E501
from swagger_server.models.trpc_assets_upload_body import TrpcAssetsUploadBody  # noqa: E501
from swagger_server import util


def assets_delete(body):  # noqa: E501
    """Delete

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAssetsDeleteBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def assets_generate_alt_text(body):  # noqa: E501
    """Generate Alt Text

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAssetsGenerateAltTextBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def assets_list(input):  # noqa: E501
    """List

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def assets_reoptimize(body):  # noqa: E501
    """Reoptimize

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAssetsReoptimizeBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def assets_update(body):  # noqa: E501
    """Update

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAssetsUpdateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def assets_upload(body):  # noqa: E501
    """Upload

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAssetsUploadBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
