import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_snapshots_create_body import TrpcSnapshotsCreateBody  # noqa: E501
from swagger_server import util


def snapshots_create(body):  # noqa: E501
    """Create

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSnapshotsCreateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def snapshots_get(input):  # noqa: E501
    """Get

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def snapshots_list_by_post(input):  # noqa: E501
    """List By Post

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'
