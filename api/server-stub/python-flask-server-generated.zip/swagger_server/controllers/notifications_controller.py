import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_notifications_register_device_body import TrpcNotificationsRegisterDeviceBody  # noqa: E501
from swagger_server.models.trpc_notifications_unregister_device_body import TrpcNotificationsUnregisterDeviceBody  # noqa: E501
from swagger_server import util


def notifications_register_device(body):  # noqa: E501
    """Register Device

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcNotificationsRegisterDeviceBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def notifications_unregister_device(body):  # noqa: E501
    """Unregister Device

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcNotificationsUnregisterDeviceBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
