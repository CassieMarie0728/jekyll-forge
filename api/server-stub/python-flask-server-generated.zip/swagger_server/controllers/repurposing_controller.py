import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_repurposing_delete_body import TrpcRepurposingDeleteBody  # noqa: E501
from swagger_server.models.trpc_repurposing_generate_body import TrpcRepurposingGenerateBody  # noqa: E501
from swagger_server.models.trpc_repurposing_regenerate_body import TrpcRepurposingRegenerateBody  # noqa: E501
from swagger_server.models.trpc_repurposing_update_body import TrpcRepurposingUpdateBody  # noqa: E501
from swagger_server import util


def repurposing_delete(body):  # noqa: E501
    """Delete

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcRepurposingDeleteBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def repurposing_generate(body):  # noqa: E501
    """Generate

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcRepurposingGenerateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def repurposing_get_by_id(input):  # noqa: E501
    """Get By Id

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def repurposing_get_by_post(input):  # noqa: E501
    """Get By Post

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def repurposing_regenerate(body):  # noqa: E501
    """Regenerate

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcRepurposingRegenerateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def repurposing_update(body):  # noqa: E501
    """Update

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcRepurposingUpdateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
