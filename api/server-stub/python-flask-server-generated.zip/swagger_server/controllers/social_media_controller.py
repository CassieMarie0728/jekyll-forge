import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_social_media_cancel_scheduled_post_body import TrpcSocialMediaCancelScheduledPostBody  # noqa: E501
from swagger_server.models.trpc_social_media_connect_account_body import TrpcSocialMediaConnectAccountBody  # noqa: E501
from swagger_server.models.trpc_social_media_disconnect_account_body import TrpcSocialMediaDisconnectAccountBody  # noqa: E501
from swagger_server.models.trpc_social_media_publish_content_body import TrpcSocialMediaPublishContentBody  # noqa: E501
from swagger_server.models.trpc_social_media_reschedule_post_body import TrpcSocialMediaReschedulePostBody  # noqa: E501
from swagger_server.models.trpc_social_media_schedule_post_body import TrpcSocialMediaSchedulePostBody  # noqa: E501
from swagger_server.models.trpc_social_media_sync_analytics_body import TrpcSocialMediaSyncAnalyticsBody  # noqa: E501
from swagger_server import util


def social_media_cancel_scheduled_post(body):  # noqa: E501
    """Cancel Scheduled Post

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaCancelScheduledPostBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def social_media_connect_account(body):  # noqa: E501
    """Connect Account

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaConnectAccountBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def social_media_disconnect_account(body):  # noqa: E501
    """Disconnect Account

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaDisconnectAccountBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def social_media_get_account_details(input):  # noqa: E501
    """Get Account Details

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def social_media_get_accounts():  # noqa: E501
    """Get Accounts

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def social_media_get_analytics_by_platform(input):  # noqa: E501
    """Get Analytics By Platform

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def social_media_get_analytics_summary():  # noqa: E501
    """Get Analytics Summary

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def social_media_get_content_analytics(input):  # noqa: E501
    """Get Content Analytics

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def social_media_get_scheduled_posts(input):  # noqa: E501
    """Get Scheduled Posts

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def social_media_publish_content(body):  # noqa: E501
    """Publish Content

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaPublishContentBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def social_media_reschedule_post(body):  # noqa: E501
    """Reschedule Post

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaReschedulePostBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def social_media_schedule_post(body):  # noqa: E501
    """Schedule Post

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaSchedulePostBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def social_media_sync_analytics(body):  # noqa: E501
    """Sync Analytics

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSocialMediaSyncAnalyticsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
