import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_ab_testing_apply_winner_body import TrpcAbTestingApplyWinnerBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_complete_test_body import TrpcAbTestingCompleteTestBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_generate_variations_body import TrpcAbTestingGenerateVariationsBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_publish_variation_body import TrpcAbTestingPublishVariationBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_update_metrics_body import TrpcAbTestingUpdateMetricsBody  # noqa: E501
from swagger_server import util


def ab_testing_apply_winner(body):  # noqa: E501
    """Apply Winner

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAbTestingApplyWinnerBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ab_testing_complete_test(body):  # noqa: E501
    """Complete Test

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAbTestingCompleteTestBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ab_testing_generate_variations(body):  # noqa: E501
    """Generate Variations

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAbTestingGenerateVariationsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ab_testing_get_results(input):  # noqa: E501
    """Get Results

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def ab_testing_get_variations(input):  # noqa: E501
    """Get Variations

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def ab_testing_publish_variation(body):  # noqa: E501
    """Publish Variation

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAbTestingPublishVariationBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def ab_testing_update_metrics(body):  # noqa: E501
    """Update Metrics

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcAbTestingUpdateMetricsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
