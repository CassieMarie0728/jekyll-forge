import connexion
import six

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_sites_delete_body import TrpcSitesDeleteBody  # noqa: E501
from swagger_server.models.trpc_sites_update_body import TrpcSitesUpdateBody  # noqa: E501
from swagger_server.models.trpc_sites_upsert_body import TrpcSitesUpsertBody  # noqa: E501
from swagger_server import util


def sites_delete(body):  # noqa: E501
    """Delete

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSitesDeleteBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def sites_get(input):  # noqa: E501
    """Get

     # noqa: E501

    :param input: URL-encoded tRPC input envelope, e.g. {\&quot;json\&quot;:{...}}
    :type input: str

    :rtype: TRPCResponse
    """
    return 'do some magic!'


def sites_list():  # noqa: E501
    """List

     # noqa: E501


    :rtype: TRPCResponse
    """
    return 'do some magic!'


def sites_update(body):  # noqa: E501
    """Update

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSitesUpdateBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def sites_upsert(body):  # noqa: E501
    """Upsert

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: TRPCResponse
    """
    if connexion.request.is_json:
        body = TrpcSitesUpsertBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
