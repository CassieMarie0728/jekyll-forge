# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_repurposing_delete_body import TrpcRepurposingDeleteBody  # noqa: E501
from swagger_server.models.trpc_repurposing_generate_body import TrpcRepurposingGenerateBody  # noqa: E501
from swagger_server.models.trpc_repurposing_regenerate_body import TrpcRepurposingRegenerateBody  # noqa: E501
from swagger_server.models.trpc_repurposing_update_body import TrpcRepurposingUpdateBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestRepurposingController(BaseTestCase):
    """RepurposingController integration test stubs"""

    def test_repurposing_delete(self):
        """Test case for repurposing_delete

        Delete
        """
        body = TrpcRepurposingDeleteBody()
        response = self.client.open(
            '/api/trpc/repurposing.delete',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_repurposing_generate(self):
        """Test case for repurposing_generate

        Generate
        """
        body = TrpcRepurposingGenerateBody()
        response = self.client.open(
            '/api/trpc/repurposing.generate',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_repurposing_get_by_id(self):
        """Test case for repurposing_get_by_id

        Get By Id
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/repurposing.getById',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_repurposing_get_by_post(self):
        """Test case for repurposing_get_by_post

        Get By Post
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/repurposing.getByPost',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_repurposing_regenerate(self):
        """Test case for repurposing_regenerate

        Regenerate
        """
        body = TrpcRepurposingRegenerateBody()
        response = self.client.open(
            '/api/trpc/repurposing.regenerate',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_repurposing_update(self):
        """Test case for repurposing_update

        Update
        """
        body = TrpcRepurposingUpdateBody()
        response = self.client.open(
            '/api/trpc/repurposing.update',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
