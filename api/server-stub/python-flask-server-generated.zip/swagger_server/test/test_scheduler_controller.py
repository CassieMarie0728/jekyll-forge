# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_scheduler_cancel_all_body import TrpcSchedulerCancelAllBody  # noqa: E501
from swagger_server.models.trpc_scheduler_cancel_body import TrpcSchedulerCancelBody  # noqa: E501
from swagger_server.models.trpc_scheduler_mark_failed_body import TrpcSchedulerMarkFailedBody  # noqa: E501
from swagger_server.models.trpc_scheduler_mark_published_body import TrpcSchedulerMarkPublishedBody  # noqa: E501
from swagger_server.models.trpc_scheduler_reschedule_body import TrpcSchedulerRescheduleBody  # noqa: E501
from swagger_server.models.trpc_scheduler_schedule_body import TrpcSchedulerScheduleBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSchedulerController(BaseTestCase):
    """SchedulerController integration test stubs"""

    def test_scheduler_cancel(self):
        """Test case for scheduler_cancel

        Cancel
        """
        body = TrpcSchedulerCancelBody()
        response = self.client.open(
            '/api/trpc/scheduler.cancel',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_cancel_all(self):
        """Test case for scheduler_cancel_all

        Cancel All
        """
        body = TrpcSchedulerCancelAllBody()
        response = self.client.open(
            '/api/trpc/scheduler.cancelAll',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_list(self):
        """Test case for scheduler_list

        List
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/scheduler.list',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_list_heartbeat_jobs(self):
        """Test case for scheduler_list_heartbeat_jobs

        List Heartbeat Jobs
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/scheduler.listHeartbeatJobs',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_mark_failed(self):
        """Test case for scheduler_mark_failed

        Mark Failed
        """
        body = TrpcSchedulerMarkFailedBody()
        response = self.client.open(
            '/api/trpc/scheduler.markFailed',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_mark_published(self):
        """Test case for scheduler_mark_published

        Mark Published
        """
        body = TrpcSchedulerMarkPublishedBody()
        response = self.client.open(
            '/api/trpc/scheduler.markPublished',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_reschedule(self):
        """Test case for scheduler_reschedule

        Reschedule
        """
        body = TrpcSchedulerRescheduleBody()
        response = self.client.open(
            '/api/trpc/scheduler.reschedule',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_scheduler_schedule(self):
        """Test case for scheduler_schedule

        Schedule
        """
        body = TrpcSchedulerScheduleBody()
        response = self.client.open(
            '/api/trpc/scheduler.schedule',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
