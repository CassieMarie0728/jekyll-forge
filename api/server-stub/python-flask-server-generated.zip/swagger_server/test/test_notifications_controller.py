# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_notifications_register_device_body import TrpcNotificationsRegisterDeviceBody  # noqa: E501
from swagger_server.models.trpc_notifications_unregister_device_body import TrpcNotificationsUnregisterDeviceBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestNotificationsController(BaseTestCase):
    """NotificationsController integration test stubs"""

    def test_notifications_register_device(self):
        """Test case for notifications_register_device

        Register Device
        """
        body = TrpcNotificationsRegisterDeviceBody()
        response = self.client.open(
            '/api/trpc/notifications.registerDevice',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_notifications_unregister_device(self):
        """Test case for notifications_unregister_device

        Unregister Device
        """
        body = TrpcNotificationsUnregisterDeviceBody()
        response = self.client.open(
            '/api/trpc/notifications.unregisterDevice',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
