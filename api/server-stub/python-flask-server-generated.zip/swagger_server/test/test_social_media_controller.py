# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_social_media_cancel_scheduled_post_body import TrpcSocialMediaCancelScheduledPostBody  # noqa: E501
from swagger_server.models.trpc_social_media_connect_account_body import TrpcSocialMediaConnectAccountBody  # noqa: E501
from swagger_server.models.trpc_social_media_disconnect_account_body import TrpcSocialMediaDisconnectAccountBody  # noqa: E501
from swagger_server.models.trpc_social_media_publish_content_body import TrpcSocialMediaPublishContentBody  # noqa: E501
from swagger_server.models.trpc_social_media_reschedule_post_body import TrpcSocialMediaReschedulePostBody  # noqa: E501
from swagger_server.models.trpc_social_media_schedule_post_body import TrpcSocialMediaSchedulePostBody  # noqa: E501
from swagger_server.models.trpc_social_media_sync_analytics_body import TrpcSocialMediaSyncAnalyticsBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSocialMediaController(BaseTestCase):
    """SocialMediaController integration test stubs"""

    def test_social_media_cancel_scheduled_post(self):
        """Test case for social_media_cancel_scheduled_post

        Cancel Scheduled Post
        """
        body = TrpcSocialMediaCancelScheduledPostBody()
        response = self.client.open(
            '/api/trpc/socialMedia.cancelScheduledPost',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_connect_account(self):
        """Test case for social_media_connect_account

        Connect Account
        """
        body = TrpcSocialMediaConnectAccountBody()
        response = self.client.open(
            '/api/trpc/socialMedia.connectAccount',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_disconnect_account(self):
        """Test case for social_media_disconnect_account

        Disconnect Account
        """
        body = TrpcSocialMediaDisconnectAccountBody()
        response = self.client.open(
            '/api/trpc/socialMedia.disconnectAccount',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_get_account_details(self):
        """Test case for social_media_get_account_details

        Get Account Details
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/socialMedia.getAccountDetails',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_get_accounts(self):
        """Test case for social_media_get_accounts

        Get Accounts
        """
        response = self.client.open(
            '/api/trpc/socialMedia.getAccounts',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_get_analytics_by_platform(self):
        """Test case for social_media_get_analytics_by_platform

        Get Analytics By Platform
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/socialMedia.getAnalyticsByPlatform',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_get_analytics_summary(self):
        """Test case for social_media_get_analytics_summary

        Get Analytics Summary
        """
        response = self.client.open(
            '/api/trpc/socialMedia.getAnalyticsSummary',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_get_content_analytics(self):
        """Test case for social_media_get_content_analytics

        Get Content Analytics
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/socialMedia.getContentAnalytics',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_get_scheduled_posts(self):
        """Test case for social_media_get_scheduled_posts

        Get Scheduled Posts
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/socialMedia.getScheduledPosts',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_publish_content(self):
        """Test case for social_media_publish_content

        Publish Content
        """
        body = TrpcSocialMediaPublishContentBody()
        response = self.client.open(
            '/api/trpc/socialMedia.publishContent',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_reschedule_post(self):
        """Test case for social_media_reschedule_post

        Reschedule Post
        """
        body = TrpcSocialMediaReschedulePostBody()
        response = self.client.open(
            '/api/trpc/socialMedia.reschedulePost',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_schedule_post(self):
        """Test case for social_media_schedule_post

        Schedule Post
        """
        body = TrpcSocialMediaSchedulePostBody()
        response = self.client.open(
            '/api/trpc/socialMedia.schedulePost',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_social_media_sync_analytics(self):
        """Test case for social_media_sync_analytics

        Sync Analytics
        """
        body = TrpcSocialMediaSyncAnalyticsBody()
        response = self.client.open(
            '/api/trpc/socialMedia.syncAnalytics',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
