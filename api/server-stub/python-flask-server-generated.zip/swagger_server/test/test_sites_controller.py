# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_sites_delete_body import TrpcSitesDeleteBody  # noqa: E501
from swagger_server.models.trpc_sites_update_body import TrpcSitesUpdateBody  # noqa: E501
from swagger_server.models.trpc_sites_upsert_body import TrpcSitesUpsertBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSitesController(BaseTestCase):
    """SitesController integration test stubs"""

    def test_sites_delete(self):
        """Test case for sites_delete

        Delete
        """
        body = TrpcSitesDeleteBody()
        response = self.client.open(
            '/api/trpc/sites.delete',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_sites_get(self):
        """Test case for sites_get

        Get
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/sites.get',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_sites_list(self):
        """Test case for sites_list

        List
        """
        response = self.client.open(
            '/api/trpc/sites.list',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_sites_update(self):
        """Test case for sites_update

        Update
        """
        body = TrpcSitesUpdateBody()
        response = self.client.open(
            '/api/trpc/sites.update',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_sites_upsert(self):
        """Test case for sites_upsert

        Upsert
        """
        body = TrpcSitesUpsertBody()
        response = self.client.open(
            '/api/trpc/sites.upsert',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
