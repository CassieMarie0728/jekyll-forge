# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_ai_generate_body import TrpcAiGenerateBody  # noqa: E501
from swagger_server.models.trpc_ai_update_settings_body import TrpcAiUpdateSettingsBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAiController(BaseTestCase):
    """AiController integration test stubs"""

    def test_ai_generate(self):
        """Test case for ai_generate

        Generate
        """
        body = TrpcAiGenerateBody()
        response = self.client.open(
            '/api/trpc/ai.generate',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_get_settings(self):
        """Test case for ai_get_settings

        Get Settings
        """
        response = self.client.open(
            '/api/trpc/ai.getSettings',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_get_usage_stats(self):
        """Test case for ai_get_usage_stats

        Get Usage Stats
        """
        response = self.client.open(
            '/api/trpc/ai.getUsageStats',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_update_settings(self):
        """Test case for ai_update_settings

        Update Settings
        """
        body = TrpcAiUpdateSettingsBody()
        response = self.client.open(
            '/api/trpc/ai.updateSettings',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
