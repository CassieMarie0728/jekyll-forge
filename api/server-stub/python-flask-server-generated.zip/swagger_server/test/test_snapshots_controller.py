# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_snapshots_create_body import TrpcSnapshotsCreateBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSnapshotsController(BaseTestCase):
    """SnapshotsController integration test stubs"""

    def test_snapshots_create(self):
        """Test case for snapshots_create

        Create
        """
        body = TrpcSnapshotsCreateBody()
        response = self.client.open(
            '/api/trpc/snapshots.create',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_snapshots_get(self):
        """Test case for snapshots_get

        Get
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/snapshots.get',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_snapshots_list_by_post(self):
        """Test case for snapshots_list_by_post

        List By Post
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/snapshots.listByPost',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
