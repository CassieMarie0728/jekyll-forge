# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_posts_autosave_body import TrpcPostsAutosaveBody  # noqa: E501
from swagger_server.models.trpc_posts_delete_body import TrpcPostsDeleteBody  # noqa: E501
from swagger_server.models.trpc_posts_update_body import TrpcPostsUpdateBody  # noqa: E501
from swagger_server.models.trpc_posts_upsert_body import TrpcPostsUpsertBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestPostsController(BaseTestCase):
    """PostsController integration test stubs"""

    def test_posts_autosave(self):
        """Test case for posts_autosave

        Autosave
        """
        body = TrpcPostsAutosaveBody()
        response = self.client.open(
            '/api/trpc/posts.autosave',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_posts_delete(self):
        """Test case for posts_delete

        Delete
        """
        body = TrpcPostsDeleteBody()
        response = self.client.open(
            '/api/trpc/posts.delete',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_posts_get(self):
        """Test case for posts_get

        Get
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/posts.get',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_posts_get_front_matter_templates(self):
        """Test case for posts_get_front_matter_templates

        Get Front Matter Templates
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/posts.getFrontMatterTemplates',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_posts_list(self):
        """Test case for posts_list

        List
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/posts.list',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_posts_update(self):
        """Test case for posts_update

        Update
        """
        body = TrpcPostsUpdateBody()
        response = self.client.open(
            '/api/trpc/posts.update',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_posts_upsert(self):
        """Test case for posts_upsert

        Upsert
        """
        body = TrpcPostsUpsertBody()
        response = self.client.open(
            '/api/trpc/posts.upsert',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
