# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_ai_providers_activate_body import TrpcAiProvidersActivateBody  # noqa: E501
from swagger_server.models.trpc_ai_providers_remove_body import TrpcAiProvidersRemoveBody  # noqa: E501
from swagger_server.models.trpc_ai_providers_save_body import TrpcAiProvidersSaveBody  # noqa: E501
from swagger_server.models.trpc_ai_providers_test_body import TrpcAiProvidersTestBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAiProvidersController(BaseTestCase):
    """AiProvidersController integration test stubs"""

    def test_ai_providers_activate(self):
        """Test case for ai_providers_activate

        Activate
        """
        body = TrpcAiProvidersActivateBody()
        response = self.client.open(
            '/api/trpc/aiProviders.activate',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_providers_get_settings(self):
        """Test case for ai_providers_get_settings

        Get Settings
        """
        response = self.client.open(
            '/api/trpc/aiProviders.getSettings',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_providers_remove(self):
        """Test case for ai_providers_remove

        Remove
        """
        body = TrpcAiProvidersRemoveBody()
        response = self.client.open(
            '/api/trpc/aiProviders.remove',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_providers_save(self):
        """Test case for ai_providers_save

        Save
        """
        body = TrpcAiProvidersSaveBody()
        response = self.client.open(
            '/api/trpc/aiProviders.save',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ai_providers_test(self):
        """Test case for ai_providers_test

        Test
        """
        body = TrpcAiProvidersTestBody()
        response = self.client.open(
            '/api/trpc/aiProviders.test',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
