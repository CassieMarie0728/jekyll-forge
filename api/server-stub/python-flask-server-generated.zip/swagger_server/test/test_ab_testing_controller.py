# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_ab_testing_apply_winner_body import TrpcAbTestingApplyWinnerBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_complete_test_body import TrpcAbTestingCompleteTestBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_generate_variations_body import TrpcAbTestingGenerateVariationsBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_publish_variation_body import TrpcAbTestingPublishVariationBody  # noqa: E501
from swagger_server.models.trpc_ab_testing_update_metrics_body import TrpcAbTestingUpdateMetricsBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAbTestingController(BaseTestCase):
    """AbTestingController integration test stubs"""

    def test_ab_testing_apply_winner(self):
        """Test case for ab_testing_apply_winner

        Apply Winner
        """
        body = TrpcAbTestingApplyWinnerBody()
        response = self.client.open(
            '/api/trpc/abTesting.applyWinner',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ab_testing_complete_test(self):
        """Test case for ab_testing_complete_test

        Complete Test
        """
        body = TrpcAbTestingCompleteTestBody()
        response = self.client.open(
            '/api/trpc/abTesting.completeTest',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ab_testing_generate_variations(self):
        """Test case for ab_testing_generate_variations

        Generate Variations
        """
        body = TrpcAbTestingGenerateVariationsBody()
        response = self.client.open(
            '/api/trpc/abTesting.generateVariations',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ab_testing_get_results(self):
        """Test case for ab_testing_get_results

        Get Results
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/abTesting.getResults',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ab_testing_get_variations(self):
        """Test case for ab_testing_get_variations

        Get Variations
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/abTesting.getVariations',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ab_testing_publish_variation(self):
        """Test case for ab_testing_publish_variation

        Publish Variation
        """
        body = TrpcAbTestingPublishVariationBody()
        response = self.client.open(
            '/api/trpc/abTesting.publishVariation',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_ab_testing_update_metrics(self):
        """Test case for ab_testing_update_metrics

        Update Metrics
        """
        body = TrpcAbTestingUpdateMetricsBody()
        response = self.client.open(
            '/api/trpc/abTesting.updateMetrics',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
