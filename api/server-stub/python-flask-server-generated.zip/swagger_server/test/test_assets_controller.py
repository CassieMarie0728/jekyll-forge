# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_assets_delete_body import TrpcAssetsDeleteBody  # noqa: E501
from swagger_server.models.trpc_assets_generate_alt_text_body import TrpcAssetsGenerateAltTextBody  # noqa: E501
from swagger_server.models.trpc_assets_reoptimize_body import TrpcAssetsReoptimizeBody  # noqa: E501
from swagger_server.models.trpc_assets_update_body import TrpcAssetsUpdateBody  # noqa: E501
from swagger_server.models.trpc_assets_upload_body import TrpcAssetsUploadBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestAssetsController(BaseTestCase):
    """AssetsController integration test stubs"""

    def test_assets_delete(self):
        """Test case for assets_delete

        Delete
        """
        body = TrpcAssetsDeleteBody()
        response = self.client.open(
            '/api/trpc/assets.delete',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_assets_generate_alt_text(self):
        """Test case for assets_generate_alt_text

        Generate Alt Text
        """
        body = TrpcAssetsGenerateAltTextBody()
        response = self.client.open(
            '/api/trpc/assets.generateAltText',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_assets_list(self):
        """Test case for assets_list

        List
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/assets.list',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_assets_reoptimize(self):
        """Test case for assets_reoptimize

        Reoptimize
        """
        body = TrpcAssetsReoptimizeBody()
        response = self.client.open(
            '/api/trpc/assets.reoptimize',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_assets_update(self):
        """Test case for assets_update

        Update
        """
        body = TrpcAssetsUpdateBody()
        response = self.client.open(
            '/api/trpc/assets.update',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_assets_upload(self):
        """Test case for assets_upload

        Upload
        """
        body = TrpcAssetsUploadBody()
        response = self.client.open(
            '/api/trpc/assets.upload',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
