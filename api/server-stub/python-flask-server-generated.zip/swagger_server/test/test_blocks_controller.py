# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_blocks_create_body import TrpcBlocksCreateBody  # noqa: E501
from swagger_server.models.trpc_blocks_delete_body import TrpcBlocksDeleteBody  # noqa: E501
from swagger_server.models.trpc_blocks_update_body import TrpcBlocksUpdateBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestBlocksController(BaseTestCase):
    """BlocksController integration test stubs"""

    def test_blocks_create(self):
        """Test case for blocks_create

        Create
        """
        body = TrpcBlocksCreateBody()
        response = self.client.open(
            '/api/trpc/blocks.create',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_blocks_delete(self):
        """Test case for blocks_delete

        Delete
        """
        body = TrpcBlocksDeleteBody()
        response = self.client.open(
            '/api/trpc/blocks.delete',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_blocks_list(self):
        """Test case for blocks_list

        List
        """
        response = self.client.open(
            '/api/trpc/blocks.list',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_blocks_update(self):
        """Test case for blocks_update

        Update
        """
        body = TrpcBlocksUpdateBody()
        response = self.client.open(
            '/api/trpc/blocks.update',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
