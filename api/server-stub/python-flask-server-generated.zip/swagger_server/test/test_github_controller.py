# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error import Error  # noqa: E501
from swagger_server.models.trpc_response import TRPCResponse  # noqa: E501
from swagger_server.models.trpc_github_commit_file_body import TrpcGithubCommitFileBody  # noqa: E501
from swagger_server.models.trpc_github_connect_body import TrpcGithubConnectBody  # noqa: E501
from swagger_server.models.trpc_github_create_branch_body import TrpcGithubCreateBranchBody  # noqa: E501
from swagger_server.models.trpc_github_create_pull_request_body import TrpcGithubCreatePullRequestBody  # noqa: E501
from swagger_server.models.trpc_github_delete_file_body import TrpcGithubDeleteFileBody  # noqa: E501
from swagger_server.models.trpc_github_disconnect_body import TrpcGithubDisconnectBody  # noqa: E501
from swagger_server.models.trpc_github_generate_actions_workflow_body import TrpcGithubGenerateActionsWorkflowBody  # noqa: E501
from swagger_server.models.trpc_github_update_jekyll_config_body import TrpcGithubUpdateJekyllConfigBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestGithubController(BaseTestCase):
    """GithubController integration test stubs"""

    def test_github_check_plugin_compatibility(self):
        """Test case for github_check_plugin_compatibility

        Check Plugin Compatibility
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.checkPluginCompatibility',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_commit_file(self):
        """Test case for github_commit_file

        Commit File
        """
        body = TrpcGithubCommitFileBody()
        response = self.client.open(
            '/api/trpc/github.commitFile',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_connect(self):
        """Test case for github_connect

        Connect
        """
        body = TrpcGithubConnectBody()
        response = self.client.open(
            '/api/trpc/github.connect',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_create_branch(self):
        """Test case for github_create_branch

        Create Branch
        """
        body = TrpcGithubCreateBranchBody()
        response = self.client.open(
            '/api/trpc/github.createBranch',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_create_pull_request(self):
        """Test case for github_create_pull_request

        Create Pull Request
        """
        body = TrpcGithubCreatePullRequestBody()
        response = self.client.open(
            '/api/trpc/github.createPullRequest',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_delete_file(self):
        """Test case for github_delete_file

        Delete File
        """
        body = TrpcGithubDeleteFileBody()
        response = self.client.open(
            '/api/trpc/github.deleteFile',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_detect_jekyll(self):
        """Test case for github_detect_jekyll

        Detect Jekyll
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.detectJekyll',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_disconnect(self):
        """Test case for github_disconnect

        Disconnect
        """
        body = TrpcGithubDisconnectBody()
        response = self.client.open(
            '/api/trpc/github.disconnect',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_generate_actions_workflow(self):
        """Test case for github_generate_actions_workflow

        Generate Actions Workflow
        """
        body = TrpcGithubGenerateActionsWorkflowBody()
        response = self.client.open(
            '/api/trpc/github.generateActionsWorkflow',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_get_file(self):
        """Test case for github_get_file

        Get File
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.getFile',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_get_jekyll_config(self):
        """Test case for github_get_jekyll_config

        Get Jekyll Config
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.getJekyllConfig',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_get_pages_status(self):
        """Test case for github_get_pages_status

        Get Pages Status
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.getPagesStatus',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_get_rate_limit(self):
        """Test case for github_get_rate_limit

        Get Rate Limit
        """
        response = self.client.open(
            '/api/trpc/github.getRateLimit',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_inventory(self):
        """Test case for github_inventory

        Inventory
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.inventory',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_list_branches(self):
        """Test case for github_list_branches

        List Branches
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.listBranches',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_list_files(self):
        """Test case for github_list_files

        List Files
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.listFiles',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_list_repos(self):
        """Test case for github_list_repos

        List Repos
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.listRepos',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_repositories(self):
        """Test case for github_repositories

        Repositories
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.repositories',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_review_file(self):
        """Test case for github_review_file

        Review File
        """
        query_string = [('input', 'input_example')]
        response = self.client.open(
            '/api/trpc/github.reviewFile',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_status(self):
        """Test case for github_status

        Status
        """
        response = self.client.open(
            '/api/trpc/github.status',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_github_update_jekyll_config(self):
        """Test case for github_update_jekyll_config

        Update Jekyll Config
        """
        body = TrpcGithubUpdateJekyllConfigBody()
        response = self.client.open(
            '/api/trpc/github.updateJekyllConfig',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
