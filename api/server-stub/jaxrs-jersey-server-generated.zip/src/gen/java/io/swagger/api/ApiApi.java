package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.ApiApiService;
import io.swagger.api.factories.ApiApiServiceFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;
import io.swagger.model.TrpcAiGenerateBody;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;
import io.swagger.model.TrpcAiUpdateSettingsBody;
import io.swagger.model.TrpcAssetsDeleteBody;
import io.swagger.model.TrpcAssetsGenerateAltTextBody;
import io.swagger.model.TrpcAssetsReoptimizeBody;
import io.swagger.model.TrpcAssetsUpdateBody;
import io.swagger.model.TrpcAssetsUploadBody;
import io.swagger.model.TrpcBlocksCreateBody;
import io.swagger.model.TrpcBlocksDeleteBody;
import io.swagger.model.TrpcBlocksUpdateBody;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;
import io.swagger.model.TrpcNotificationsRegisterDeviceBody;
import io.swagger.model.TrpcNotificationsUnregisterDeviceBody;
import io.swagger.model.TrpcPostsAutosaveBody;
import io.swagger.model.TrpcPostsDeleteBody;
import io.swagger.model.TrpcPostsUpdateBody;
import io.swagger.model.TrpcPostsUpsertBody;
import io.swagger.model.TrpcRepurposingDeleteBody;
import io.swagger.model.TrpcRepurposingGenerateBody;
import io.swagger.model.TrpcRepurposingRegenerateBody;
import io.swagger.model.TrpcRepurposingUpdateBody;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;
import io.swagger.model.TrpcSitesDeleteBody;
import io.swagger.model.TrpcSitesUpdateBody;
import io.swagger.model.TrpcSitesUpsertBody;
import io.swagger.model.TrpcSnapshotsCreateBody;
import io.swagger.model.TrpcSocialMediaCancelScheduledPostBody;
import io.swagger.model.TrpcSocialMediaConnectAccountBody;
import io.swagger.model.TrpcSocialMediaDisconnectAccountBody;
import io.swagger.model.TrpcSocialMediaPublishContentBody;
import io.swagger.model.TrpcSocialMediaReschedulePostBody;
import io.swagger.model.TrpcSocialMediaSchedulePostBody;
import io.swagger.model.TrpcSocialMediaSyncAnalyticsBody;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;


@Path("/api")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2026-09-27T19:37:06.118222786Z[GMT]")
public class ApiApi  {
   private final ApiApiService delegate;

   public ApiApi(@Context ServletConfig servletContext) {
      ApiApiService delegate = null;

      if (servletContext != null) {
         String implClass = servletContext.getInitParameter("ApiApi.implementation");
         if (implClass != null && !"".equals(implClass.trim())) {
            try {
               delegate = (ApiApiService) Class.forName(implClass).newInstance();
            } catch (Exception e) {
               throw new RuntimeException(e);
            }
         } 
      }

      if (delegate == null) {
         delegate = ApiApiServiceFactory.getApiApi();
      }

      this.delegate = delegate;
   }

    @POST
    @Path("/trpc/abTesting.applyWinner")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Apply Winner", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingApplyWinner(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAbTestingApplyWinnerBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingApplyWinner(body,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.completeTest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Complete Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingCompleteTest(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAbTestingCompleteTestBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingCompleteTest(body,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.generateVariations")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingGenerateVariations(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAbTestingGenerateVariationsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingGenerateVariations(body,securityContext);
    }
    @GET
    @Path("/trpc/abTesting.getResults")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Results", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingGetResults(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingGetResults(input,securityContext);
    }
    @GET
    @Path("/trpc/abTesting.getVariations")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingGetVariations(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingGetVariations(input,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.publishVariation")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Variation", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingPublishVariation(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAbTestingPublishVariationBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingPublishVariation(body,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.updateMetrics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Metrics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingUpdateMetrics(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAbTestingUpdateMetricsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.abTestingUpdateMetrics(body,securityContext);
    }
    @POST
    @Path("/trpc/ai.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiGenerate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAiGenerateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiGenerate(body,securityContext);
    }
    @GET
    @Path("/trpc/ai.getSettings")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiGetSettings(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiGetSettings(securityContext);
    }
    @GET
    @Path("/trpc/ai.getUsageStats")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Usage Stats", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiGetUsageStats(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiGetUsageStats(securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.activate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Activate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersActivate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAiProvidersActivateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiProvidersActivate(body,securityContext);
    }
    @GET
    @Path("/trpc/aiProviders.getSettings")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersGetSettings(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiProvidersGetSettings(securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.remove")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Remove", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersRemove(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAiProvidersRemoveBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiProvidersRemove(body,securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.save")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Save", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersSave(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAiProvidersSaveBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiProvidersSave(body,securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.test")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersTest(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAiProvidersTestBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiProvidersTest(body,securityContext);
    }
    @POST
    @Path("/trpc/ai.updateSettings")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiUpdateSettings(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAiUpdateSettingsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.aiUpdateSettings(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsDelete(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAssetsDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.assetsDelete(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.generateAltText")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Alt Text", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsGenerateAltText(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAssetsGenerateAltTextBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.assetsGenerateAltText(body,securityContext);
    }
    @GET
    @Path("/trpc/assets.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsList(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.assetsList(input,securityContext);
    }
    @POST
    @Path("/trpc/assets.reoptimize")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reoptimize", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsReoptimize(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAssetsReoptimizeBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.assetsReoptimize(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAssetsUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.assetsUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.upload")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upload", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsUpload(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcAssetsUploadBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.assetsUpload(body,securityContext);
    }
    @POST
    @Path("/trpc/blocks.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksCreate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcBlocksCreateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.blocksCreate(body,securityContext);
    }
    @POST
    @Path("/trpc/blocks.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksDelete(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcBlocksDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.blocksDelete(body,securityContext);
    }
    @GET
    @Path("/trpc/blocks.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksList(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.blocksList(securityContext);
    }
    @POST
    @Path("/trpc/blocks.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcBlocksUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.blocksUpdate(body,securityContext);
    }
    @GET
    @Path("/trpc/github.checkPluginCompatibility")
    
    @Produces({ "application/json" })
    @Operation(summary = "Check Plugin Compatibility", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCheckPluginCompatibility(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubCheckPluginCompatibility(input,securityContext);
    }
    @POST
    @Path("/trpc/github.commitFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Commit File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCommitFile(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubCommitFileBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubCommitFile(body,securityContext);
    }
    @POST
    @Path("/trpc/github.connect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubConnect(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubConnectBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubConnect(body,securityContext);
    }
    @POST
    @Path("/trpc/github.createBranch")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Branch", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCreateBranch(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubCreateBranchBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubCreateBranch(body,securityContext);
    }
    @POST
    @Path("/trpc/github.createPullRequest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Pull Request", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCreatePullRequest(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubCreatePullRequestBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubCreatePullRequest(body,securityContext);
    }
    @POST
    @Path("/trpc/github.deleteFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubDeleteFile(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubDeleteFileBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubDeleteFile(body,securityContext);
    }
    @GET
    @Path("/trpc/github.detectJekyll")
    
    @Produces({ "application/json" })
    @Operation(summary = "Detect Jekyll", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubDetectJekyll(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubDetectJekyll(input,securityContext);
    }
    @POST
    @Path("/trpc/github.disconnect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubDisconnect(@Parameter(in = ParameterIn.DEFAULT, description = "" ) TrpcGithubDisconnectBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubDisconnect(body,securityContext);
    }
    @POST
    @Path("/trpc/github.generateActionsWorkflow")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Actions Workflow", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGenerateActionsWorkflow(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubGenerateActionsWorkflowBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubGenerateActionsWorkflow(body,securityContext);
    }
    @GET
    @Path("/trpc/github.getFile")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetFile(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubGetFile(input,securityContext);
    }
    @GET
    @Path("/trpc/github.getJekyllConfig")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetJekyllConfig(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubGetJekyllConfig(input,securityContext);
    }
    @GET
    @Path("/trpc/github.getPagesStatus")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Pages Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetPagesStatus(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubGetPagesStatus(input,securityContext);
    }
    @GET
    @Path("/trpc/github.getRateLimit")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Rate Limit", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetRateLimit(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubGetRateLimit(securityContext);
    }
    @GET
    @Path("/trpc/github.inventory")
    
    @Produces({ "application/json" })
    @Operation(summary = "Inventory", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubInventory(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubInventory(input,securityContext);
    }
    @GET
    @Path("/trpc/github.listBranches")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Branches", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubListBranches(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubListBranches(input,securityContext);
    }
    @GET
    @Path("/trpc/github.listFiles")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Files", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubListFiles(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubListFiles(input,securityContext);
    }
    @GET
    @Path("/trpc/github.listRepos")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Repos", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubListRepos(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubListRepos(input,securityContext);
    }
    @GET
    @Path("/trpc/github.repositories")
    
    @Produces({ "application/json" })
    @Operation(summary = "Repositories", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubRepositories(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubRepositories(input,securityContext);
    }
    @GET
    @Path("/trpc/github.reviewFile")
    
    @Produces({ "application/json" })
    @Operation(summary = "Review File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubReviewFile(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubReviewFile(input,securityContext);
    }
    @GET
    @Path("/trpc/github.status")
    
    @Produces({ "application/json" })
    @Operation(summary = "Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubStatus(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubStatus(securityContext);
    }
    @POST
    @Path("/trpc/github.updateJekyllConfig")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubUpdateJekyllConfig(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcGithubUpdateJekyllConfigBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.githubUpdateJekyllConfig(body,securityContext);
    }
    @POST
    @Path("/trpc/notifications.registerDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Register Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Notifications" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response notificationsRegisterDevice(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcNotificationsRegisterDeviceBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.notificationsRegisterDevice(body,securityContext);
    }
    @POST
    @Path("/trpc/notifications.unregisterDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Unregister Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Notifications" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response notificationsUnregisterDevice(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcNotificationsUnregisterDeviceBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.notificationsUnregisterDevice(body,securityContext);
    }
    @POST
    @Path("/trpc/posts.autosave")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Autosave", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsAutosave(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcPostsAutosaveBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsAutosave(body,securityContext);
    }
    @POST
    @Path("/trpc/posts.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsDelete(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcPostsDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsDelete(body,securityContext);
    }
    @GET
    @Path("/trpc/posts.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsGet(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsGet(input,securityContext);
    }
    @GET
    @Path("/trpc/posts.getFrontMatterTemplates")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Front Matter Templates", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsGetFrontMatterTemplates(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsGetFrontMatterTemplates(input,securityContext);
    }
    @GET
    @Path("/trpc/posts.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsList(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsList(input,securityContext);
    }
    @POST
    @Path("/trpc/posts.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcPostsUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/posts.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsUpsert(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcPostsUpsertBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.postsUpsert(body,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingDelete(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcRepurposingDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.repurposingDelete(body,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingGenerate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcRepurposingGenerateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.repurposingGenerate(body,securityContext);
    }
    @GET
    @Path("/trpc/repurposing.getById")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get By Id", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingGetById(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.repurposingGetById(input,securityContext);
    }
    @GET
    @Path("/trpc/repurposing.getByPost")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingGetByPost(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.repurposingGetByPost(input,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.regenerate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Regenerate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingRegenerate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcRepurposingRegenerateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.repurposingRegenerate(body,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcRepurposingUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.repurposingUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.cancel")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerCancel(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSchedulerCancelBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerCancel(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.cancelAll")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel All", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerCancelAll(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSchedulerCancelAllBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerCancelAll(body,securityContext);
    }
    @GET
    @Path("/trpc/scheduler.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerList(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerList(input,securityContext);
    }
    @GET
    @Path("/trpc/scheduler.listHeartbeatJobs")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Heartbeat Jobs", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerListHeartbeatJobs(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerListHeartbeatJobs(input,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.markFailed")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Failed", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerMarkFailed(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSchedulerMarkFailedBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerMarkFailed(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.markPublished")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Published", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerMarkPublished(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSchedulerMarkPublishedBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerMarkPublished(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.reschedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerReschedule(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSchedulerRescheduleBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerReschedule(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.schedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerSchedule(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSchedulerScheduleBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.schedulerSchedule(body,securityContext);
    }
    @POST
    @Path("/trpc/sites.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesDelete(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSitesDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.sitesDelete(body,securityContext);
    }
    @GET
    @Path("/trpc/sites.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesGet(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.sitesGet(input,securityContext);
    }
    @GET
    @Path("/trpc/sites.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesList(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.sitesList(securityContext);
    }
    @POST
    @Path("/trpc/sites.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSitesUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.sitesUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/sites.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesUpsert(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSitesUpsertBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.sitesUpsert(body,securityContext);
    }
    @POST
    @Path("/trpc/snapshots.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response snapshotsCreate(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSnapshotsCreateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.snapshotsCreate(body,securityContext);
    }
    @GET
    @Path("/trpc/snapshots.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response snapshotsGet(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.snapshotsGet(input,securityContext);
    }
    @GET
    @Path("/trpc/snapshots.listByPost")
    
    @Produces({ "application/json" })
    @Operation(summary = "List By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response snapshotsListByPost(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.snapshotsListByPost(input,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.cancelScheduledPost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel Scheduled Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaCancelScheduledPost(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaCancelScheduledPostBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaCancelScheduledPost(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.connectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaConnectAccount(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaConnectAccountBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaConnectAccount(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.disconnectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaDisconnectAccount(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaDisconnectAccountBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaDisconnectAccount(body,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAccountDetails")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Account Details", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAccountDetails(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaGetAccountDetails(input,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAccounts")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Accounts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAccounts(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaGetAccounts(securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAnalyticsByPlatform")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics By Platform", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAnalyticsByPlatform(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaGetAnalyticsByPlatform(input,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAnalyticsSummary")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics Summary", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAnalyticsSummary(@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaGetAnalyticsSummary(securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getContentAnalytics")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Content Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetContentAnalytics(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaGetContentAnalytics(input,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getScheduledPosts")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Scheduled Posts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetScheduledPosts(@Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}",required=true) @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaGetScheduledPosts(input,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.publishContent")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Content", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaPublishContent(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaPublishContentBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaPublishContent(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.reschedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaReschedulePost(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaReschedulePostBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaReschedulePost(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.schedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaSchedulePost(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaSchedulePostBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaSchedulePost(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.syncAnalytics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Sync Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaSyncAnalytics(@Parameter(in = ParameterIn.DEFAULT, description = "" ,required=true) TrpcSocialMediaSyncAnalyticsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.socialMediaSyncAnalytics(body,securityContext);
    }
}
