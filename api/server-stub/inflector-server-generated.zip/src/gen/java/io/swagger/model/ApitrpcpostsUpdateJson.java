package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcpostsUpdateJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("path")
  private String path = null;
  @JsonProperty("title")
  private String title = null;
  @JsonProperty("slug")
  private String slug = null;
  @JsonProperty("status")
  private Object status = null;
  @JsonProperty("frontMatter")
  private Object frontMatter = null;
  @JsonProperty("markdown")
  private String markdown = null;
  @JsonProperty("sha")
  private String sha = null;
  @JsonProperty("scheduledAt")
  private Object scheduledAt = null;
  /**
   **/
  public ApitrpcpostsUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson path(String path) {
    this.path = path;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson title(String title) {
    this.title = title;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson slug(String slug) {
    this.slug = slug;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("slug")
  public String getSlug() {
    return slug;
  }
  public void setSlug(String slug) {
    this.slug = slug;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson status(Object status) {
    this.status = status;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("status")
  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("markdown")
  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("sha")
  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  public ApitrpcpostsUpdateJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpdateJson apitrpcpostsUpdateJson = (ApitrpcpostsUpdateJson) o;
    return Objects.equals(id, apitrpcpostsUpdateJson.id) &&
        Objects.equals(path, apitrpcpostsUpdateJson.path) &&
        Objects.equals(title, apitrpcpostsUpdateJson.title) &&
        Objects.equals(slug, apitrpcpostsUpdateJson.slug) &&
        Objects.equals(status, apitrpcpostsUpdateJson.status) &&
        Objects.equals(frontMatter, apitrpcpostsUpdateJson.frontMatter) &&
        Objects.equals(markdown, apitrpcpostsUpdateJson.markdown) &&
        Objects.equals(sha, apitrpcpostsUpdateJson.sha) &&
        Objects.equals(scheduledAt, apitrpcpostsUpdateJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, path, title, slug, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpdateJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
