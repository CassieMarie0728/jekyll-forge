package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcgithubDeleteFileJson   {
  @JsonProperty("owner")
  private String owner = null;
  @JsonProperty("repo")
  private String repo = null;
  @JsonProperty("path")
  private String path = null;
  @JsonProperty("branch")
  private String branch = null;
  @JsonProperty("sha")
  private String sha = null;
  @JsonProperty("message")
  private String message = null;
  /**
   **/
  public ApitrpcgithubDeleteFileJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson path(String path) {
    this.path = path;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson branch(String branch) {
    this.branch = branch;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("branch")
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("sha")
  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  public ApitrpcgithubDeleteFileJson message(String message) {
    this.message = message;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubDeleteFileJson apitrpcgithubDeleteFileJson = (ApitrpcgithubDeleteFileJson) o;
    return Objects.equals(owner, apitrpcgithubDeleteFileJson.owner) &&
        Objects.equals(repo, apitrpcgithubDeleteFileJson.repo) &&
        Objects.equals(path, apitrpcgithubDeleteFileJson.path) &&
        Objects.equals(branch, apitrpcgithubDeleteFileJson.branch) &&
        Objects.equals(sha, apitrpcgithubDeleteFileJson.sha) &&
        Objects.equals(message, apitrpcgithubDeleteFileJson.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, path, branch, sha, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubDeleteFileJson {\n");
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
