package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcschedulerRescheduleJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("scheduledAt")
  private Object scheduledAt = null;
  @JsonProperty("timezone")
  private String timezone = null;
  /**
   **/
  public ApitrpcschedulerRescheduleJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcschedulerRescheduleJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  public ApitrpcschedulerRescheduleJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcschedulerRescheduleJson apitrpcschedulerRescheduleJson = (ApitrpcschedulerRescheduleJson) o;
    return Objects.equals(id, apitrpcschedulerRescheduleJson.id) &&
        Objects.equals(scheduledAt, apitrpcschedulerRescheduleJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcschedulerRescheduleJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcschedulerRescheduleJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
