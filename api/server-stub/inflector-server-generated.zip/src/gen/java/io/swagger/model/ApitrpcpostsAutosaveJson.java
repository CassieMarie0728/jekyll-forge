package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcpostsAutosaveJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("markdown")
  private String markdown = null;
  @JsonProperty("frontMatter")
  private Object frontMatter = null;
  /**
   **/
  public ApitrpcpostsAutosaveJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcpostsAutosaveJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("markdown")
  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcpostsAutosaveJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsAutosaveJson apitrpcpostsAutosaveJson = (ApitrpcpostsAutosaveJson) o;
    return Objects.equals(id, apitrpcpostsAutosaveJson.id) &&
        Objects.equals(markdown, apitrpcpostsAutosaveJson.markdown) &&
        Objects.equals(frontMatter, apitrpcpostsAutosaveJson.frontMatter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, markdown, frontMatter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsAutosaveJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
