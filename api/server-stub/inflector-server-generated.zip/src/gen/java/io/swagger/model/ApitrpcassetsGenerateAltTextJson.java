package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcassetsGenerateAltTextJson   {
  @JsonProperty("assetId")
  private BigDecimal assetId = null;
  /**
   **/
  public ApitrpcassetsGenerateAltTextJson assetId(BigDecimal assetId) {
    this.assetId = assetId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("assetId")
  public BigDecimal getAssetId() {
    return assetId;
  }
  public void setAssetId(BigDecimal assetId) {
    this.assetId = assetId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsGenerateAltTextJson apitrpcassetsGenerateAltTextJson = (ApitrpcassetsGenerateAltTextJson) o;
    return Objects.equals(assetId, apitrpcassetsGenerateAltTextJson.assetId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(assetId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsGenerateAltTextJson {\n");
    sb.append("    assetId: ").append(toIndentedString(assetId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
