package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcabTestingApplyWinnerJson   {
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("winningVariationIndex")
  private BigDecimal winningVariationIndex = null;
  /**
   **/
  public ApitrpcabTestingApplyWinnerJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcabTestingApplyWinnerJson winningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("winningVariationIndex")
  public BigDecimal getWinningVariationIndex() {
    return winningVariationIndex;
  }
  public void setWinningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingApplyWinnerJson apitrpcabTestingApplyWinnerJson = (ApitrpcabTestingApplyWinnerJson) o;
    return Objects.equals(postId, apitrpcabTestingApplyWinnerJson.postId) &&
        Objects.equals(winningVariationIndex, apitrpcabTestingApplyWinnerJson.winningVariationIndex);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, winningVariationIndex);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingApplyWinnerJson {\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    winningVariationIndex: ").append(toIndentedString(winningVariationIndex)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
