package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ApitrpcsocialMediaSyncAnalyticsJson;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class TrpcSocialMediaSyncAnalyticsBody   {
  @JsonProperty("json")
  private ApitrpcsocialMediaSyncAnalyticsJson json = null;
  /**
   **/
  public TrpcSocialMediaSyncAnalyticsBody json(ApitrpcsocialMediaSyncAnalyticsJson json) {
    this.json = json;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("json")
  public ApitrpcsocialMediaSyncAnalyticsJson getJson() {
    return json;
  }
  public void setJson(ApitrpcsocialMediaSyncAnalyticsJson json) {
    this.json = json;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrpcSocialMediaSyncAnalyticsBody trpcSocialMediaSyncAnalyticsBody = (TrpcSocialMediaSyncAnalyticsBody) o;
    return Objects.equals(json, trpcSocialMediaSyncAnalyticsBody.json);
  }

  @Override
  public int hashCode() {
    return Objects.hash(json);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcSocialMediaSyncAnalyticsBody {\n");
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
