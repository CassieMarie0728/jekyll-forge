package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsocialMediaPublishContentJson   {
  @JsonProperty("repurposedContentId")
  private BigDecimal repurposedContentId = null;
  @JsonProperty("accountId")
  private BigDecimal accountId = null;
  /**
   **/
  public ApitrpcsocialMediaPublishContentJson repurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("repurposedContentId")
  public BigDecimal getRepurposedContentId() {
    return repurposedContentId;
  }
  public void setRepurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
  }

  /**
   **/
  public ApitrpcsocialMediaPublishContentJson accountId(BigDecimal accountId) {
    this.accountId = accountId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("accountId")
  public BigDecimal getAccountId() {
    return accountId;
  }
  public void setAccountId(BigDecimal accountId) {
    this.accountId = accountId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaPublishContentJson apitrpcsocialMediaPublishContentJson = (ApitrpcsocialMediaPublishContentJson) o;
    return Objects.equals(repurposedContentId, apitrpcsocialMediaPublishContentJson.repurposedContentId) &&
        Objects.equals(accountId, apitrpcsocialMediaPublishContentJson.accountId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repurposedContentId, accountId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaPublishContentJson {\n");
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
