package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcaiProvidersSaveJson   {
  @JsonProperty("provider")
  private Object provider = null;
  @JsonProperty("model")
  private String model = null;
  @JsonProperty("apiKey")
  private String apiKey = null;
  /**
   **/
  public ApitrpcaiProvidersSaveJson provider(Object provider) {
    this.provider = provider;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("provider")
  public Object getProvider() {
    return provider;
  }
  public void setProvider(Object provider) {
    this.provider = provider;
  }

  /**
   **/
  public ApitrpcaiProvidersSaveJson model(String model) {
    this.model = model;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("model")
  public String getModel() {
    return model;
  }
  public void setModel(String model) {
    this.model = model;
  }

  /**
   **/
  public ApitrpcaiProvidersSaveJson apiKey(String apiKey) {
    this.apiKey = apiKey;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("apiKey")
  public String getApiKey() {
    return apiKey;
  }
  public void setApiKey(String apiKey) {
    this.apiKey = apiKey;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiProvidersSaveJson apitrpcaiProvidersSaveJson = (ApitrpcaiProvidersSaveJson) o;
    return Objects.equals(provider, apitrpcaiProvidersSaveJson.provider) &&
        Objects.equals(model, apitrpcaiProvidersSaveJson.model) &&
        Objects.equals(apiKey, apitrpcaiProvidersSaveJson.apiKey);
  }

  @Override
  public int hashCode() {
    return Objects.hash(provider, model, apiKey);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiProvidersSaveJson {\n");
    sb.append("    provider: ").append(toIndentedString(provider)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    apiKey: ").append(toIndentedString(apiKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
