package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsocialMediaReschedulePostJson   {
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("scheduledAt")
  private Object scheduledAt = null;
  @JsonProperty("timezone")
  private String timezone = null;
  /**
   **/
  public ApitrpcsocialMediaReschedulePostJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcsocialMediaReschedulePostJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  public ApitrpcsocialMediaReschedulePostJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaReschedulePostJson apitrpcsocialMediaReschedulePostJson = (ApitrpcsocialMediaReschedulePostJson) o;
    return Objects.equals(postId, apitrpcsocialMediaReschedulePostJson.postId) &&
        Objects.equals(scheduledAt, apitrpcsocialMediaReschedulePostJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcsocialMediaReschedulePostJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaReschedulePostJson {\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
