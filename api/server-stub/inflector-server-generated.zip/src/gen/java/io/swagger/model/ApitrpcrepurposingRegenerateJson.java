package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcrepurposingRegenerateJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  /**
   **/
  public ApitrpcrepurposingRegenerateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcrepurposingRegenerateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcrepurposingRegenerateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingRegenerateJson apitrpcrepurposingRegenerateJson = (ApitrpcrepurposingRegenerateJson) o;
    return Objects.equals(id, apitrpcrepurposingRegenerateJson.id) &&
        Objects.equals(postId, apitrpcrepurposingRegenerateJson.postId) &&
        Objects.equals(siteId, apitrpcrepurposingRegenerateJson.siteId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, postId, siteId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingRegenerateJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
