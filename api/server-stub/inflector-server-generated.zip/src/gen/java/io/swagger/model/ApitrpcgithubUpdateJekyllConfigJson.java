package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcgithubUpdateJekyllConfigJson   {
  @JsonProperty("owner")
  private String owner = null;
  @JsonProperty("repo")
  private String repo = null;
  @JsonProperty("rootPath")
  private String rootPath = null;
  @JsonProperty("branch")
  private String branch = null;
  @JsonProperty("commitMessage")
  private String commitMessage = null;
  /**
   **/
  public ApitrpcgithubUpdateJekyllConfigJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubUpdateJekyllConfigJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubUpdateJekyllConfigJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("rootPath")
  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  public ApitrpcgithubUpdateJekyllConfigJson branch(String branch) {
    this.branch = branch;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("branch")
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  public ApitrpcgithubUpdateJekyllConfigJson commitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("commitMessage")
  public String getCommitMessage() {
    return commitMessage;
  }
  public void setCommitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubUpdateJekyllConfigJson apitrpcgithubUpdateJekyllConfigJson = (ApitrpcgithubUpdateJekyllConfigJson) o;
    return Objects.equals(owner, apitrpcgithubUpdateJekyllConfigJson.owner) &&
        Objects.equals(repo, apitrpcgithubUpdateJekyllConfigJson.repo) &&
        Objects.equals(rootPath, apitrpcgithubUpdateJekyllConfigJson.rootPath) &&
        Objects.equals(branch, apitrpcgithubUpdateJekyllConfigJson.branch) &&
        Objects.equals(commitMessage, apitrpcgithubUpdateJekyllConfigJson.commitMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, rootPath, branch, commitMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubUpdateJekyllConfigJson {\n");
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
