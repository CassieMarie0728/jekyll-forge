package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsocialMediaSyncAnalyticsJson   {
  @JsonProperty("analyticsId")
  private BigDecimal analyticsId = null;
  /**
   **/
  public ApitrpcsocialMediaSyncAnalyticsJson analyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("analyticsId")
  public BigDecimal getAnalyticsId() {
    return analyticsId;
  }
  public void setAnalyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSyncAnalyticsJson apitrpcsocialMediaSyncAnalyticsJson = (ApitrpcsocialMediaSyncAnalyticsJson) o;
    return Objects.equals(analyticsId, apitrpcsocialMediaSyncAnalyticsJson.analyticsId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(analyticsId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSyncAnalyticsJson {\n");
    sb.append("    analyticsId: ").append(toIndentedString(analyticsId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
