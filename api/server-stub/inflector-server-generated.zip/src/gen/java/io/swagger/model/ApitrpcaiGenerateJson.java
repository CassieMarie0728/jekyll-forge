package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcaiGenerateJson   {
  @JsonProperty("task")
  private String task = null;
  @JsonProperty("userPrompt")
  private String userPrompt = null;
  @JsonProperty("selectedText")
  private String selectedText = null;
  @JsonProperty("postMarkdown")
  private String postMarkdown = null;
  @JsonProperty("frontMatter")
  private Object frontMatter = null;
  @JsonProperty("tone")
  private String tone = null;
  @JsonProperty("voiceProfileId")
  private BigDecimal voiceProfileId = null;
  /**
   **/
  public ApitrpcaiGenerateJson task(String task) {
    this.task = task;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("task")
  public String getTask() {
    return task;
  }
  public void setTask(String task) {
    this.task = task;
  }

  /**
   **/
  public ApitrpcaiGenerateJson userPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("userPrompt")
  public String getUserPrompt() {
    return userPrompt;
  }
  public void setUserPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
  }

  /**
   **/
  public ApitrpcaiGenerateJson selectedText(String selectedText) {
    this.selectedText = selectedText;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("selectedText")
  public String getSelectedText() {
    return selectedText;
  }
  public void setSelectedText(String selectedText) {
    this.selectedText = selectedText;
  }

  /**
   **/
  public ApitrpcaiGenerateJson postMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("postMarkdown")
  public String getPostMarkdown() {
    return postMarkdown;
  }
  public void setPostMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
  }

  /**
   **/
  public ApitrpcaiGenerateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  public ApitrpcaiGenerateJson tone(String tone) {
    this.tone = tone;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("tone")
  public String getTone() {
    return tone;
  }
  public void setTone(String tone) {
    this.tone = tone;
  }

  /**
   **/
  public ApitrpcaiGenerateJson voiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("voiceProfileId")
  public BigDecimal getVoiceProfileId() {
    return voiceProfileId;
  }
  public void setVoiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiGenerateJson apitrpcaiGenerateJson = (ApitrpcaiGenerateJson) o;
    return Objects.equals(task, apitrpcaiGenerateJson.task) &&
        Objects.equals(userPrompt, apitrpcaiGenerateJson.userPrompt) &&
        Objects.equals(selectedText, apitrpcaiGenerateJson.selectedText) &&
        Objects.equals(postMarkdown, apitrpcaiGenerateJson.postMarkdown) &&
        Objects.equals(frontMatter, apitrpcaiGenerateJson.frontMatter) &&
        Objects.equals(tone, apitrpcaiGenerateJson.tone) &&
        Objects.equals(voiceProfileId, apitrpcaiGenerateJson.voiceProfileId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(task, userPrompt, selectedText, postMarkdown, frontMatter, tone, voiceProfileId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiGenerateJson {\n");
    sb.append("    task: ").append(toIndentedString(task)).append("\n");
    sb.append("    userPrompt: ").append(toIndentedString(userPrompt)).append("\n");
    sb.append("    selectedText: ").append(toIndentedString(selectedText)).append("\n");
    sb.append("    postMarkdown: ").append(toIndentedString(postMarkdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    tone: ").append(toIndentedString(tone)).append("\n");
    sb.append("    voiceProfileId: ").append(toIndentedString(voiceProfileId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
