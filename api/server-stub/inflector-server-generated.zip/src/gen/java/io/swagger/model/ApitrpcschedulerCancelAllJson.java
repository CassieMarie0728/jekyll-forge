package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcschedulerCancelAllJson   {
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  /**
   **/
  public ApitrpcschedulerCancelAllJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcschedulerCancelAllJson apitrpcschedulerCancelAllJson = (ApitrpcschedulerCancelAllJson) o;
    return Objects.equals(siteId, apitrpcschedulerCancelAllJson.siteId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcschedulerCancelAllJson {\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
