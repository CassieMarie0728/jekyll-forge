package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcgithubCommitFileJson   {
  @JsonProperty("owner")
  private String owner = null;
  @JsonProperty("repo")
  private String repo = null;
  @JsonProperty("path")
  private String path = null;
  @JsonProperty("branch")
  private String branch = null;
  @JsonProperty("content")
  private String content = null;
  @JsonProperty("message")
  private String message = null;
  @JsonProperty("sha")
  private String sha = null;
  /**
   **/
  public ApitrpcgithubCommitFileJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson path(String path) {
    this.path = path;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson branch(String branch) {
    this.branch = branch;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("branch")
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson content(String content) {
    this.content = content;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("content")
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson message(String message) {
    this.message = message;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   **/
  public ApitrpcgithubCommitFileJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("sha")
  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCommitFileJson apitrpcgithubCommitFileJson = (ApitrpcgithubCommitFileJson) o;
    return Objects.equals(owner, apitrpcgithubCommitFileJson.owner) &&
        Objects.equals(repo, apitrpcgithubCommitFileJson.repo) &&
        Objects.equals(path, apitrpcgithubCommitFileJson.path) &&
        Objects.equals(branch, apitrpcgithubCommitFileJson.branch) &&
        Objects.equals(content, apitrpcgithubCommitFileJson.content) &&
        Objects.equals(message, apitrpcgithubCommitFileJson.message) &&
        Objects.equals(sha, apitrpcgithubCommitFileJson.sha);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, path, branch, content, message, sha);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCommitFileJson {\n");
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
