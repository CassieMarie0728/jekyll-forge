package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcrepurposingGenerateJson   {
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  /**
   * Gets or Sets format
   */
  public enum FormatEnum {
    TWITTER("twitter"),
    
    LINKEDIN("linkedin"),
    
    TIKTOK("tiktok"),
    
    YOUTUBE("youtube"),
    
    NEWSLETTER("newsletter"),
    
    EMAIL("email"),
    
    PODCAST("podcast"),
    
    SLIDES("slides");

    private String value;

    FormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FormatEnum fromValue(String text) {
      for (FormatEnum b : FormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("format")
  private FormatEnum format = null;
  /**
   **/
  public ApitrpcrepurposingGenerateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcrepurposingGenerateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcrepurposingGenerateJson format(FormatEnum format) {
    this.format = format;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("format")
  public FormatEnum getFormat() {
    return format;
  }
  public void setFormat(FormatEnum format) {
    this.format = format;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingGenerateJson apitrpcrepurposingGenerateJson = (ApitrpcrepurposingGenerateJson) o;
    return Objects.equals(postId, apitrpcrepurposingGenerateJson.postId) &&
        Objects.equals(siteId, apitrpcrepurposingGenerateJson.siteId) &&
        Objects.equals(format, apitrpcrepurposingGenerateJson.format);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, siteId, format);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingGenerateJson {\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
