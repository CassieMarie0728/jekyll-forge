package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcassetsReoptimizeJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("maxWidth")
  private BigDecimal maxWidth = null;
  /**
   * Gets or Sets outputFormat
   */
  public enum OutputFormatEnum {
    WEBP("webp"),
    
    JPEG("jpeg"),
    
    PNG("png");

    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OutputFormatEnum fromValue(String text) {
      for (OutputFormatEnum b : OutputFormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("outputFormat")
  private OutputFormatEnum outputFormat = null;
  @JsonProperty("quality")
  private BigDecimal quality = null;
  /**
   **/
  public ApitrpcassetsReoptimizeJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcassetsReoptimizeJson maxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("maxWidth")
  public BigDecimal getMaxWidth() {
    return maxWidth;
  }
  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  /**
   **/
  public ApitrpcassetsReoptimizeJson outputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("outputFormat")
  public OutputFormatEnum getOutputFormat() {
    return outputFormat;
  }
  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  /**
   **/
  public ApitrpcassetsReoptimizeJson quality(BigDecimal quality) {
    this.quality = quality;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("quality")
  public BigDecimal getQuality() {
    return quality;
  }
  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsReoptimizeJson apitrpcassetsReoptimizeJson = (ApitrpcassetsReoptimizeJson) o;
    return Objects.equals(id, apitrpcassetsReoptimizeJson.id) &&
        Objects.equals(maxWidth, apitrpcassetsReoptimizeJson.maxWidth) &&
        Objects.equals(outputFormat, apitrpcassetsReoptimizeJson.outputFormat) &&
        Objects.equals(quality, apitrpcassetsReoptimizeJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsReoptimizeJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
