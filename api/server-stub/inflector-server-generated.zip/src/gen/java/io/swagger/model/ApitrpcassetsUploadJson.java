package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcassetsUploadJson   {
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  @JsonProperty("name")
  private String name = null;
  @JsonProperty("path")
  private String path = null;
  @JsonProperty("base64Content")
  private String base64Content = null;
  @JsonProperty("mimeType")
  private String mimeType = null;
  @JsonProperty("size")
  private BigDecimal size = null;
  @JsonProperty("width")
  private BigDecimal width = null;
  @JsonProperty("height")
  private BigDecimal height = null;
  @JsonProperty("optimize")
  private Boolean optimize = null;
  @JsonProperty("maxWidth")
  private BigDecimal maxWidth = null;
  /**
   * Gets or Sets outputFormat
   */
  public enum OutputFormatEnum {
    WEBP("webp"),
    
    JPEG("jpeg"),
    
    PNG("png"),
    
    ORIGINAL("original");

    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OutputFormatEnum fromValue(String text) {
      for (OutputFormatEnum b : OutputFormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("outputFormat")
  private OutputFormatEnum outputFormat = null;
  @JsonProperty("quality")
  private BigDecimal quality = null;
  /**
   **/
  public ApitrpcassetsUploadJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcassetsUploadJson name(String name) {
    this.name = name;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  public ApitrpcassetsUploadJson path(String path) {
    this.path = path;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcassetsUploadJson base64Content(String base64Content) {
    this.base64Content = base64Content;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("base64Content")
  public String getBase64Content() {
    return base64Content;
  }
  public void setBase64Content(String base64Content) {
    this.base64Content = base64Content;
  }

  /**
   **/
  public ApitrpcassetsUploadJson mimeType(String mimeType) {
    this.mimeType = mimeType;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("mimeType")
  public String getMimeType() {
    return mimeType;
  }
  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  /**
   **/
  public ApitrpcassetsUploadJson size(BigDecimal size) {
    this.size = size;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("size")
  public BigDecimal getSize() {
    return size;
  }
  public void setSize(BigDecimal size) {
    this.size = size;
  }

  /**
   **/
  public ApitrpcassetsUploadJson width(BigDecimal width) {
    this.width = width;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("width")
  public BigDecimal getWidth() {
    return width;
  }
  public void setWidth(BigDecimal width) {
    this.width = width;
  }

  /**
   **/
  public ApitrpcassetsUploadJson height(BigDecimal height) {
    this.height = height;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("height")
  public BigDecimal getHeight() {
    return height;
  }
  public void setHeight(BigDecimal height) {
    this.height = height;
  }

  /**
   **/
  public ApitrpcassetsUploadJson optimize(Boolean optimize) {
    this.optimize = optimize;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("optimize")
  public Boolean isOptimize() {
    return optimize;
  }
  public void setOptimize(Boolean optimize) {
    this.optimize = optimize;
  }

  /**
   **/
  public ApitrpcassetsUploadJson maxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("maxWidth")
  public BigDecimal getMaxWidth() {
    return maxWidth;
  }
  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  /**
   **/
  public ApitrpcassetsUploadJson outputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("outputFormat")
  public OutputFormatEnum getOutputFormat() {
    return outputFormat;
  }
  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  /**
   **/
  public ApitrpcassetsUploadJson quality(BigDecimal quality) {
    this.quality = quality;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("quality")
  public BigDecimal getQuality() {
    return quality;
  }
  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsUploadJson apitrpcassetsUploadJson = (ApitrpcassetsUploadJson) o;
    return Objects.equals(siteId, apitrpcassetsUploadJson.siteId) &&
        Objects.equals(name, apitrpcassetsUploadJson.name) &&
        Objects.equals(path, apitrpcassetsUploadJson.path) &&
        Objects.equals(base64Content, apitrpcassetsUploadJson.base64Content) &&
        Objects.equals(mimeType, apitrpcassetsUploadJson.mimeType) &&
        Objects.equals(size, apitrpcassetsUploadJson.size) &&
        Objects.equals(width, apitrpcassetsUploadJson.width) &&
        Objects.equals(height, apitrpcassetsUploadJson.height) &&
        Objects.equals(optimize, apitrpcassetsUploadJson.optimize) &&
        Objects.equals(maxWidth, apitrpcassetsUploadJson.maxWidth) &&
        Objects.equals(outputFormat, apitrpcassetsUploadJson.outputFormat) &&
        Objects.equals(quality, apitrpcassetsUploadJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, name, path, base64Content, mimeType, size, width, height, optimize, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsUploadJson {\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    base64Content: ").append(toIndentedString(base64Content)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    optimize: ").append(toIndentedString(optimize)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
