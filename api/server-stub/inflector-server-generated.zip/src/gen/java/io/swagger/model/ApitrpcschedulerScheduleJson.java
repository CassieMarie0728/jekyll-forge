package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcschedulerScheduleJson   {
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("draftPath")
  private String draftPath = null;
  @JsonProperty("targetPath")
  private String targetPath = null;
  @JsonProperty("scheduledAt")
  private Object scheduledAt = null;
  @JsonProperty("timezone")
  private String timezone = null;
  @JsonProperty("commitMessage")
  private String commitMessage = null;
  /**
   **/
  public ApitrpcschedulerScheduleJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcschedulerScheduleJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcschedulerScheduleJson draftPath(String draftPath) {
    this.draftPath = draftPath;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("draftPath")
  public String getDraftPath() {
    return draftPath;
  }
  public void setDraftPath(String draftPath) {
    this.draftPath = draftPath;
  }

  /**
   **/
  public ApitrpcschedulerScheduleJson targetPath(String targetPath) {
    this.targetPath = targetPath;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("targetPath")
  public String getTargetPath() {
    return targetPath;
  }
  public void setTargetPath(String targetPath) {
    this.targetPath = targetPath;
  }

  /**
   **/
  public ApitrpcschedulerScheduleJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  public ApitrpcschedulerScheduleJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  public ApitrpcschedulerScheduleJson commitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("commitMessage")
  public String getCommitMessage() {
    return commitMessage;
  }
  public void setCommitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcschedulerScheduleJson apitrpcschedulerScheduleJson = (ApitrpcschedulerScheduleJson) o;
    return Objects.equals(siteId, apitrpcschedulerScheduleJson.siteId) &&
        Objects.equals(postId, apitrpcschedulerScheduleJson.postId) &&
        Objects.equals(draftPath, apitrpcschedulerScheduleJson.draftPath) &&
        Objects.equals(targetPath, apitrpcschedulerScheduleJson.targetPath) &&
        Objects.equals(scheduledAt, apitrpcschedulerScheduleJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcschedulerScheduleJson.timezone) &&
        Objects.equals(commitMessage, apitrpcschedulerScheduleJson.commitMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, draftPath, targetPath, scheduledAt, timezone, commitMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcschedulerScheduleJson {\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    draftPath: ").append(toIndentedString(draftPath)).append("\n");
    sb.append("    targetPath: ").append(toIndentedString(targetPath)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
