package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcassetsUpdateJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("name")
  private String name = null;
  @JsonProperty("path")
  private String path = null;
  @JsonProperty("alt")
  private String alt = null;
  /**
   **/
  public ApitrpcassetsUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcassetsUpdateJson name(String name) {
    this.name = name;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  public ApitrpcassetsUpdateJson path(String path) {
    this.path = path;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcassetsUpdateJson alt(String alt) {
    this.alt = alt;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("alt")
  public String getAlt() {
    return alt;
  }
  public void setAlt(String alt) {
    this.alt = alt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsUpdateJson apitrpcassetsUpdateJson = (ApitrpcassetsUpdateJson) o;
    return Objects.equals(id, apitrpcassetsUpdateJson.id) &&
        Objects.equals(name, apitrpcassetsUpdateJson.name) &&
        Objects.equals(path, apitrpcassetsUpdateJson.path) &&
        Objects.equals(alt, apitrpcassetsUpdateJson.alt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, path, alt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsUpdateJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    alt: ").append(toIndentedString(alt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
