package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcnotificationsRegisterDeviceJson   {
  @JsonProperty("token")
  private String token = null;
  /**
   * Gets or Sets platform
   */
  public enum PlatformEnum {
    ANDROID("android");

    private String value;

    PlatformEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PlatformEnum fromValue(String text) {
      for (PlatformEnum b : PlatformEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("platform")
  private PlatformEnum platform = null;
  /**
   **/
  public ApitrpcnotificationsRegisterDeviceJson token(String token) {
    this.token = token;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  public ApitrpcnotificationsRegisterDeviceJson platform(PlatformEnum platform) {
    this.platform = platform;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("platform")
  public PlatformEnum getPlatform() {
    return platform;
  }
  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcnotificationsRegisterDeviceJson apitrpcnotificationsRegisterDeviceJson = (ApitrpcnotificationsRegisterDeviceJson) o;
    return Objects.equals(token, apitrpcnotificationsRegisterDeviceJson.token) &&
        Objects.equals(platform, apitrpcnotificationsRegisterDeviceJson.platform);
  }

  @Override
  public int hashCode() {
    return Objects.hash(token, platform);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcnotificationsRegisterDeviceJson {\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
