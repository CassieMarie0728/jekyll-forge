package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsnapshotsCreateJson   {
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("postPath")
  private String postPath = null;
  @JsonProperty("label")
  private String label = null;
  @JsonProperty("reason")
  private Object reason = null;
  @JsonProperty("markdown")
  private String markdown = null;
  @JsonProperty("frontMatter")
  private Object frontMatter = null;
  /**
   **/
  public ApitrpcsnapshotsCreateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson postPath(String postPath) {
    this.postPath = postPath;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("postPath")
  public String getPostPath() {
    return postPath;
  }
  public void setPostPath(String postPath) {
    this.postPath = postPath;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson label(String label) {
    this.label = label;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("label")
  public String getLabel() {
    return label;
  }
  public void setLabel(String label) {
    this.label = label;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson reason(Object reason) {
    this.reason = reason;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("reason")
  public Object getReason() {
    return reason;
  }
  public void setReason(Object reason) {
    this.reason = reason;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("markdown")
  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcsnapshotsCreateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsnapshotsCreateJson apitrpcsnapshotsCreateJson = (ApitrpcsnapshotsCreateJson) o;
    return Objects.equals(siteId, apitrpcsnapshotsCreateJson.siteId) &&
        Objects.equals(postId, apitrpcsnapshotsCreateJson.postId) &&
        Objects.equals(postPath, apitrpcsnapshotsCreateJson.postPath) &&
        Objects.equals(label, apitrpcsnapshotsCreateJson.label) &&
        Objects.equals(reason, apitrpcsnapshotsCreateJson.reason) &&
        Objects.equals(markdown, apitrpcsnapshotsCreateJson.markdown) &&
        Objects.equals(frontMatter, apitrpcsnapshotsCreateJson.frontMatter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, postPath, label, reason, markdown, frontMatter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsnapshotsCreateJson {\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    postPath: ").append(toIndentedString(postPath)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
