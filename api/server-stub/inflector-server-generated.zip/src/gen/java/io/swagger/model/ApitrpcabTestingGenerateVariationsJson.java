package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcabTestingGenerateVariationsJson   {
  @JsonProperty("postId")
  private BigDecimal postId = null;
  @JsonProperty("count")
  private BigDecimal count = null;
  @JsonProperty("tones")
  private List<String> tones = null;
  @JsonProperty("angles")
  private List<String> angles = null;
  @JsonProperty("headline")
  private String headline = null;
  @JsonProperty("content")
  private String content = null;
  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson count(BigDecimal count) {
    this.count = count;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("count")
  public BigDecimal getCount() {
    return count;
  }
  public void setCount(BigDecimal count) {
    this.count = count;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson tones(List<String> tones) {
    this.tones = tones;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("tones")
  public List<String> getTones() {
    return tones;
  }
  public void setTones(List<String> tones) {
    this.tones = tones;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson angles(List<String> angles) {
    this.angles = angles;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("angles")
  public List<String> getAngles() {
    return angles;
  }
  public void setAngles(List<String> angles) {
    this.angles = angles;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson headline(String headline) {
    this.headline = headline;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("headline")
  public String getHeadline() {
    return headline;
  }
  public void setHeadline(String headline) {
    this.headline = headline;
  }

  /**
   **/
  public ApitrpcabTestingGenerateVariationsJson content(String content) {
    this.content = content;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("content")
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingGenerateVariationsJson apitrpcabTestingGenerateVariationsJson = (ApitrpcabTestingGenerateVariationsJson) o;
    return Objects.equals(postId, apitrpcabTestingGenerateVariationsJson.postId) &&
        Objects.equals(count, apitrpcabTestingGenerateVariationsJson.count) &&
        Objects.equals(tones, apitrpcabTestingGenerateVariationsJson.tones) &&
        Objects.equals(angles, apitrpcabTestingGenerateVariationsJson.angles) &&
        Objects.equals(headline, apitrpcabTestingGenerateVariationsJson.headline) &&
        Objects.equals(content, apitrpcabTestingGenerateVariationsJson.content);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, count, tones, angles, headline, content);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingGenerateVariationsJson {\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    tones: ").append(toIndentedString(tones)).append("\n");
    sb.append("    angles: ").append(toIndentedString(angles)).append("\n");
    sb.append("    headline: ").append(toIndentedString(headline)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
