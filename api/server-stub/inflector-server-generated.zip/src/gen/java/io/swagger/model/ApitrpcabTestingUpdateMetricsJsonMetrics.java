package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcabTestingUpdateMetricsJsonMetrics   {
  @JsonProperty("impressions")
  private BigDecimal impressions = null;
  @JsonProperty("engagements")
  private BigDecimal engagements = null;
  @JsonProperty("clicks")
  private BigDecimal clicks = null;
  @JsonProperty("shares")
  private BigDecimal shares = null;
  @JsonProperty("likes")
  private BigDecimal likes = null;
  @JsonProperty("replies")
  private BigDecimal replies = null;
  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics impressions(BigDecimal impressions) {
    this.impressions = impressions;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("impressions")
  public BigDecimal getImpressions() {
    return impressions;
  }
  public void setImpressions(BigDecimal impressions) {
    this.impressions = impressions;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics engagements(BigDecimal engagements) {
    this.engagements = engagements;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("engagements")
  public BigDecimal getEngagements() {
    return engagements;
  }
  public void setEngagements(BigDecimal engagements) {
    this.engagements = engagements;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics clicks(BigDecimal clicks) {
    this.clicks = clicks;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("clicks")
  public BigDecimal getClicks() {
    return clicks;
  }
  public void setClicks(BigDecimal clicks) {
    this.clicks = clicks;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics shares(BigDecimal shares) {
    this.shares = shares;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("shares")
  public BigDecimal getShares() {
    return shares;
  }
  public void setShares(BigDecimal shares) {
    this.shares = shares;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics likes(BigDecimal likes) {
    this.likes = likes;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("likes")
  public BigDecimal getLikes() {
    return likes;
  }
  public void setLikes(BigDecimal likes) {
    this.likes = likes;
  }

  /**
   **/
  public ApitrpcabTestingUpdateMetricsJsonMetrics replies(BigDecimal replies) {
    this.replies = replies;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("replies")
  public BigDecimal getReplies() {
    return replies;
  }
  public void setReplies(BigDecimal replies) {
    this.replies = replies;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJsonMetrics apitrpcabTestingUpdateMetricsJsonMetrics = (ApitrpcabTestingUpdateMetricsJsonMetrics) o;
    return Objects.equals(impressions, apitrpcabTestingUpdateMetricsJsonMetrics.impressions) &&
        Objects.equals(engagements, apitrpcabTestingUpdateMetricsJsonMetrics.engagements) &&
        Objects.equals(clicks, apitrpcabTestingUpdateMetricsJsonMetrics.clicks) &&
        Objects.equals(shares, apitrpcabTestingUpdateMetricsJsonMetrics.shares) &&
        Objects.equals(likes, apitrpcabTestingUpdateMetricsJsonMetrics.likes) &&
        Objects.equals(replies, apitrpcabTestingUpdateMetricsJsonMetrics.replies);
  }

  @Override
  public int hashCode() {
    return Objects.hash(impressions, engagements, clicks, shares, likes, replies);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJsonMetrics {\n");
    sb.append("    impressions: ").append(toIndentedString(impressions)).append("\n");
    sb.append("    engagements: ").append(toIndentedString(engagements)).append("\n");
    sb.append("    clicks: ").append(toIndentedString(clicks)).append("\n");
    sb.append("    shares: ").append(toIndentedString(shares)).append("\n");
    sb.append("    likes: ").append(toIndentedString(likes)).append("\n");
    sb.append("    replies: ").append(toIndentedString(replies)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
