package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsocialMediaSchedulePostJson   {
  @JsonProperty("repurposedContentId")
  private BigDecimal repurposedContentId = null;
  @JsonProperty("socialMediaAccountId")
  private BigDecimal socialMediaAccountId = null;
  @JsonProperty("scheduledAt")
  private Object scheduledAt = null;
  @JsonProperty("timezone")
  private String timezone = null;
  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson repurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("repurposedContentId")
  public BigDecimal getRepurposedContentId() {
    return repurposedContentId;
  }
  public void setRepurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
  }

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson socialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("socialMediaAccountId")
  public BigDecimal getSocialMediaAccountId() {
    return socialMediaAccountId;
  }
  public void setSocialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
  }

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  public ApitrpcsocialMediaSchedulePostJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSchedulePostJson apitrpcsocialMediaSchedulePostJson = (ApitrpcsocialMediaSchedulePostJson) o;
    return Objects.equals(repurposedContentId, apitrpcsocialMediaSchedulePostJson.repurposedContentId) &&
        Objects.equals(socialMediaAccountId, apitrpcsocialMediaSchedulePostJson.socialMediaAccountId) &&
        Objects.equals(scheduledAt, apitrpcsocialMediaSchedulePostJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcsocialMediaSchedulePostJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repurposedContentId, socialMediaAccountId, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSchedulePostJson {\n");
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    socialMediaAccountId: ").append(toIndentedString(socialMediaAccountId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
