package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsocialMediaConnectAccountJson   {
  /**
   * Gets or Sets platform
   */
  public enum PlatformEnum {
    TWITTER("twitter"),
    
    LINKEDIN("linkedin"),
    
    FACEBOOK("facebook"),
    
    INSTAGRAM("instagram");

    private String value;

    PlatformEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PlatformEnum fromValue(String text) {
      for (PlatformEnum b : PlatformEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("platform")
  private PlatformEnum platform = null;
  @JsonProperty("accessToken")
  private String accessToken = null;
  @JsonProperty("refreshToken")
  private String refreshToken = null;
  @JsonProperty("expiresAt")
  private Object expiresAt = null;
  @JsonProperty("accountId")
  private String accountId = null;
  @JsonProperty("username")
  private String username = null;
  @JsonProperty("displayName")
  private String displayName = null;
  @JsonProperty("profileImageUrl")
  private String profileImageUrl = null;
  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson platform(PlatformEnum platform) {
    this.platform = platform;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("platform")
  public PlatformEnum getPlatform() {
    return platform;
  }
  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson accessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("accessToken")
  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson refreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("refreshToken")
  public String getRefreshToken() {
    return refreshToken;
  }
  public void setRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson expiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("expiresAt")
  public Object getExpiresAt() {
    return expiresAt;
  }
  public void setExpiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("accountId")
  public String getAccountId() {
    return accountId;
  }
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson username(String username) {
    this.username = username;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("displayName")
  public String getDisplayName() {
    return displayName;
  }
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   **/
  public ApitrpcsocialMediaConnectAccountJson profileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("profileImageUrl")
  public String getProfileImageUrl() {
    return profileImageUrl;
  }
  public void setProfileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaConnectAccountJson apitrpcsocialMediaConnectAccountJson = (ApitrpcsocialMediaConnectAccountJson) o;
    return Objects.equals(platform, apitrpcsocialMediaConnectAccountJson.platform) &&
        Objects.equals(accessToken, apitrpcsocialMediaConnectAccountJson.accessToken) &&
        Objects.equals(refreshToken, apitrpcsocialMediaConnectAccountJson.refreshToken) &&
        Objects.equals(expiresAt, apitrpcsocialMediaConnectAccountJson.expiresAt) &&
        Objects.equals(accountId, apitrpcsocialMediaConnectAccountJson.accountId) &&
        Objects.equals(username, apitrpcsocialMediaConnectAccountJson.username) &&
        Objects.equals(displayName, apitrpcsocialMediaConnectAccountJson.displayName) &&
        Objects.equals(profileImageUrl, apitrpcsocialMediaConnectAccountJson.profileImageUrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(platform, accessToken, refreshToken, expiresAt, accountId, username, displayName, profileImageUrl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaConnectAccountJson {\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    accessToken: ").append(toIndentedString(accessToken)).append("\n");
    sb.append("    refreshToken: ").append(toIndentedString(refreshToken)).append("\n");
    sb.append("    expiresAt: ").append(toIndentedString(expiresAt)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    profileImageUrl: ").append(toIndentedString(profileImageUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
