package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcpostsUpsertJson   {
  @JsonProperty("siteId")
  private BigDecimal siteId = null;
  @JsonProperty("path")
  private String path = null;
  @JsonProperty("filename")
  private String filename = null;
  @JsonProperty("slug")
  private String slug = null;
  @JsonProperty("title")
  private String title = null;
  @JsonProperty("status")
  private Object status = null;
  @JsonProperty("frontMatter")
  private Object frontMatter = null;
  @JsonProperty("markdown")
  private String markdown = null;
  @JsonProperty("sha")
  private String sha = null;
  @JsonProperty("scheduledAt")
  private Object scheduledAt = null;
  /**
   **/
  public ApitrpcpostsUpsertJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson path(String path) {
    this.path = path;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson filename(String filename) {
    this.filename = filename;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("filename")
  public String getFilename() {
    return filename;
  }
  public void setFilename(String filename) {
    this.filename = filename;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson slug(String slug) {
    this.slug = slug;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("slug")
  public String getSlug() {
    return slug;
  }
  public void setSlug(String slug) {
    this.slug = slug;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson title(String title) {
    this.title = title;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson status(Object status) {
    this.status = status;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("status")
  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("markdown")
  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson sha(String sha) {
    this.sha = sha;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("sha")
  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  public ApitrpcpostsUpsertJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpsertJson apitrpcpostsUpsertJson = (ApitrpcpostsUpsertJson) o;
    return Objects.equals(siteId, apitrpcpostsUpsertJson.siteId) &&
        Objects.equals(path, apitrpcpostsUpsertJson.path) &&
        Objects.equals(filename, apitrpcpostsUpsertJson.filename) &&
        Objects.equals(slug, apitrpcpostsUpsertJson.slug) &&
        Objects.equals(title, apitrpcpostsUpsertJson.title) &&
        Objects.equals(status, apitrpcpostsUpsertJson.status) &&
        Objects.equals(frontMatter, apitrpcpostsUpsertJson.frontMatter) &&
        Objects.equals(markdown, apitrpcpostsUpsertJson.markdown) &&
        Objects.equals(sha, apitrpcpostsUpsertJson.sha) &&
        Objects.equals(scheduledAt, apitrpcpostsUpsertJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, path, filename, slug, title, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpsertJson {\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
