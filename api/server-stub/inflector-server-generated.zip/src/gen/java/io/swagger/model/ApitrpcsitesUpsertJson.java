package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsitesUpsertJson   {
  @JsonProperty("owner")
  private String owner = null;
  @JsonProperty("repo")
  private String repo = null;
  @JsonProperty("defaultBranch")
  private String defaultBranch = null;
  @JsonProperty("selectedBranch")
  private String selectedBranch = null;
  @JsonProperty("rootPath")
  private String rootPath = null;
  @JsonProperty("isJekyll")
  private Boolean isJekyll = null;
  @JsonProperty("isFavorite")
  private Boolean isFavorite = null;
  @JsonProperty("timezone")
  private String timezone = null;
  @JsonProperty("defaultLayout")
  private String defaultLayout = null;
  @JsonProperty("defaultAssetPath")
  private String defaultAssetPath = null;
  /**
   **/
  public ApitrpcsitesUpsertJson owner(String owner) {
    this.owner = owner;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson repo(String repo) {
    this.repo = repo;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson defaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("defaultBranch")
  public String getDefaultBranch() {
    return defaultBranch;
  }
  public void setDefaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson selectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("selectedBranch")
  public String getSelectedBranch() {
    return selectedBranch;
  }
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("rootPath")
  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson isJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("isJekyll")
  public Boolean isIsJekyll() {
    return isJekyll;
  }
  public void setIsJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson isFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("isFavorite")
  public Boolean isIsFavorite() {
    return isFavorite;
  }
  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson defaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("defaultLayout")
  public String getDefaultLayout() {
    return defaultLayout;
  }
  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  /**
   **/
  public ApitrpcsitesUpsertJson defaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("defaultAssetPath")
  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }
  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpsertJson apitrpcsitesUpsertJson = (ApitrpcsitesUpsertJson) o;
    return Objects.equals(owner, apitrpcsitesUpsertJson.owner) &&
        Objects.equals(repo, apitrpcsitesUpsertJson.repo) &&
        Objects.equals(defaultBranch, apitrpcsitesUpsertJson.defaultBranch) &&
        Objects.equals(selectedBranch, apitrpcsitesUpsertJson.selectedBranch) &&
        Objects.equals(rootPath, apitrpcsitesUpsertJson.rootPath) &&
        Objects.equals(isJekyll, apitrpcsitesUpsertJson.isJekyll) &&
        Objects.equals(isFavorite, apitrpcsitesUpsertJson.isFavorite) &&
        Objects.equals(timezone, apitrpcsitesUpsertJson.timezone) &&
        Objects.equals(defaultLayout, apitrpcsitesUpsertJson.defaultLayout) &&
        Objects.equals(defaultAssetPath, apitrpcsitesUpsertJson.defaultAssetPath);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, defaultBranch, selectedBranch, rootPath, isJekyll, isFavorite, timezone, defaultLayout, defaultAssetPath);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpsertJson {\n");
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    defaultBranch: ").append(toIndentedString(defaultBranch)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    isJekyll: ").append(toIndentedString(isJekyll)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
