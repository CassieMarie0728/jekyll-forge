package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcblocksCreateJson   {
  @JsonProperty("name")
  private String name = null;
  @JsonProperty("category")
  private String category = null;
  @JsonProperty("content")
  private String content = null;
  /**
   * Gets or Sets contentType
   */
  public enum ContentTypeEnum {
    MARKDOWN("markdown"),
    
    HTML("html"),
    
    LIQUID("liquid");

    private String value;

    ContentTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ContentTypeEnum fromValue(String text) {
      for (ContentTypeEnum b : ContentTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("contentType")
  private ContentTypeEnum contentType = null;
  /**
   **/
  public ApitrpcblocksCreateJson name(String name) {
    this.name = name;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  public ApitrpcblocksCreateJson category(String category) {
    this.category = category;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("category")
  public String getCategory() {
    return category;
  }
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   **/
  public ApitrpcblocksCreateJson content(String content) {
    this.content = content;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("content")
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  public ApitrpcblocksCreateJson contentType(ContentTypeEnum contentType) {
    this.contentType = contentType;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("contentType")
  public ContentTypeEnum getContentType() {
    return contentType;
  }
  public void setContentType(ContentTypeEnum contentType) {
    this.contentType = contentType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcblocksCreateJson apitrpcblocksCreateJson = (ApitrpcblocksCreateJson) o;
    return Objects.equals(name, apitrpcblocksCreateJson.name) &&
        Objects.equals(category, apitrpcblocksCreateJson.category) &&
        Objects.equals(content, apitrpcblocksCreateJson.content) &&
        Objects.equals(contentType, apitrpcblocksCreateJson.contentType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, category, content, contentType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcblocksCreateJson {\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
