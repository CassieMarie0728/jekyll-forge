package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class ApitrpcsitesUpdateJson   {
  @JsonProperty("id")
  private BigDecimal id = null;
  @JsonProperty("isFavorite")
  private Boolean isFavorite = null;
  @JsonProperty("selectedBranch")
  private String selectedBranch = null;
  @JsonProperty("rootPath")
  private String rootPath = null;
  @JsonProperty("timezone")
  private String timezone = null;
  @JsonProperty("defaultLayout")
  private String defaultLayout = null;
  @JsonProperty("defaultAssetPath")
  private String defaultAssetPath = null;
  @JsonProperty("aiVoiceProfile")
  private String aiVoiceProfile = null;
  @JsonProperty("settings")
  private Object settings = null;
  /**
   **/
  public ApitrpcsitesUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson isFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("isFavorite")
  public Boolean isIsFavorite() {
    return isFavorite;
  }
  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson selectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("selectedBranch")
  public String getSelectedBranch() {
    return selectedBranch;
  }
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("rootPath")
  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("timezone")
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson defaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("defaultLayout")
  public String getDefaultLayout() {
    return defaultLayout;
  }
  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson defaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("defaultAssetPath")
  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }
  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson aiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("aiVoiceProfile")
  public String getAiVoiceProfile() {
    return aiVoiceProfile;
  }
  public void setAiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
  }

  /**
   **/
  public ApitrpcsitesUpdateJson settings(Object settings) {
    this.settings = settings;
    return this;
  }

  
  @Schema(description = "")
  @JsonProperty("settings")
  public Object getSettings() {
    return settings;
  }
  public void setSettings(Object settings) {
    this.settings = settings;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpdateJson apitrpcsitesUpdateJson = (ApitrpcsitesUpdateJson) o;
    return Objects.equals(id, apitrpcsitesUpdateJson.id) &&
        Objects.equals(isFavorite, apitrpcsitesUpdateJson.isFavorite) &&
        Objects.equals(selectedBranch, apitrpcsitesUpdateJson.selectedBranch) &&
        Objects.equals(rootPath, apitrpcsitesUpdateJson.rootPath) &&
        Objects.equals(timezone, apitrpcsitesUpdateJson.timezone) &&
        Objects.equals(defaultLayout, apitrpcsitesUpdateJson.defaultLayout) &&
        Objects.equals(defaultAssetPath, apitrpcsitesUpdateJson.defaultAssetPath) &&
        Objects.equals(aiVoiceProfile, apitrpcsitesUpdateJson.aiVoiceProfile) &&
        Objects.equals(settings, apitrpcsitesUpdateJson.settings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, isFavorite, selectedBranch, rootPath, timezone, defaultLayout, defaultAssetPath, aiVoiceProfile, settings);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpdateJson {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("    aiVoiceProfile: ").append(toIndentedString(aiVoiceProfile)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
