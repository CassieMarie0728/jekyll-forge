package io.swagger.model;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ApitrpcgithubUpdateJekyllConfigJson;
import io.swagger.v3.oas.annotations.media.Schema;



@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaInflectorServerCodegen", date = "2026-09-27T19:36:34.235944225Z[GMT]")

public class TrpcGithubUpdateJekyllConfigBody   {
  @JsonProperty("json")
  private ApitrpcgithubUpdateJekyllConfigJson json = null;
  /**
   **/
  public TrpcGithubUpdateJekyllConfigBody json(ApitrpcgithubUpdateJekyllConfigJson json) {
    this.json = json;
    return this;
  }

  
  @Schema(required = true, description = "")
  @JsonProperty("json")
  public ApitrpcgithubUpdateJekyllConfigJson getJson() {
    return json;
  }
  public void setJson(ApitrpcgithubUpdateJekyllConfigJson json) {
    this.json = json;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrpcGithubUpdateJekyllConfigBody trpcGithubUpdateJekyllConfigBody = (TrpcGithubUpdateJekyllConfigBody) o;
    return Objects.equals(json, trpcGithubUpdateJekyllConfigBody.json);
  }

  @Override
  public int hashCode() {
    return Objects.hash(json);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcGithubUpdateJekyllConfigBody {\n");
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
