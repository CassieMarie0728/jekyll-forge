package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_assets_update_body (
  json: apitrpcassets.update_json
)

