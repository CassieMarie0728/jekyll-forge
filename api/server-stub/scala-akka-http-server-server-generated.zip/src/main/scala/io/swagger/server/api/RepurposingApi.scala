package io.swagger.server.api

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.unmarshalling.FromRequestUnmarshaller
import akka.http.scaladsl.marshalling.ToEntityMarshaller
import io.swagger.server.AkkaHttpHelper._
import io.swagger.server.model.Error
import io.swagger.server.model.TRPCResponse
import io.swagger.server.model.Trpc_repurposing_delete_body
import io.swagger.server.model.Trpc_repurposing_generate_body
import io.swagger.server.model.Trpc_repurposing_regenerate_body
import io.swagger.server.model.Trpc_repurposing_update_body

class RepurposingApi(
    repurposingService: RepurposingApiService,
    repurposingMarshaller: RepurposingApiMarshaller
) {
  import repurposingMarshaller._

  lazy val route: Route =
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_repurposing_delete_body]){ body =>
                  repurposingService.repurposingDelete(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_repurposing_generate_body]){ body =>
                  repurposingService.repurposingGenerate(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  repurposingService.repurposingGetById(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  repurposingService.repurposingGetByPost(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_repurposing_regenerate_body]){ body =>
                  repurposingService.repurposingRegenerate(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_repurposing_update_body]){ body =>
                  repurposingService.repurposingUpdate(body = body)
                }
             
           
         
       
      }
    }
}

trait RepurposingApiService {

  def repurposingDelete200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def repurposingDelete400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def repurposingDelete401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def repurposingDelete500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def repurposingDelete(body: Trpc_repurposing_delete_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def repurposingGenerate200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def repurposingGenerate400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def repurposingGenerate401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def repurposingGenerate500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def repurposingGenerate(body: Trpc_repurposing_generate_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def repurposingGetById200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def repurposingGetById400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def repurposingGetById401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def repurposingGetById500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def repurposingGetById(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def repurposingGetByPost200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def repurposingGetByPost400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def repurposingGetByPost401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def repurposingGetByPost500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def repurposingGetByPost(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def repurposingRegenerate200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def repurposingRegenerate400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def repurposingRegenerate401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def repurposingRegenerate500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def repurposingRegenerate(body: Trpc_repurposing_regenerate_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def repurposingUpdate200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def repurposingUpdate400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def repurposingUpdate401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def repurposingUpdate500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def repurposingUpdate(body: Trpc_repurposing_update_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

}

trait RepurposingApiMarshaller {
  implicit def fromRequestUnmarshallerTrpc_repurposing_generate_body: FromRequestUnmarshaller[Trpc_repurposing_generate_body]

  implicit def fromRequestUnmarshallerTrpc_repurposing_update_body: FromRequestUnmarshaller[Trpc_repurposing_update_body]

  implicit def fromRequestUnmarshallerTrpc_repurposing_delete_body: FromRequestUnmarshaller[Trpc_repurposing_delete_body]

  implicit def fromRequestUnmarshallerTrpc_repurposing_regenerate_body: FromRequestUnmarshaller[Trpc_repurposing_regenerate_body]


  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

}

