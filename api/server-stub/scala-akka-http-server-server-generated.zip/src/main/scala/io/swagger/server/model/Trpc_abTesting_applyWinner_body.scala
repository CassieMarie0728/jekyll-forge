package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_abTesting_applyWinner_body (
  json: apitrpcabTesting.applyWinner_json
)

