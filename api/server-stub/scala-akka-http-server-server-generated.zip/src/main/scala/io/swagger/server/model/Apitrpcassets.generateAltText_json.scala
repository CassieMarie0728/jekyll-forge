package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param assetId 
 */
case class Apitrpcassets.generateAltText_json (
  assetId: BigDecimal
)

