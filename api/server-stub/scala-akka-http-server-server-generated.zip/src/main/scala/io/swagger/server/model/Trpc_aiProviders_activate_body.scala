package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_aiProviders_activate_body (
  json: apitrpcaiProviders.activate_json
)

