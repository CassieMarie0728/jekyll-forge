package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 * @param winningVariationIndex 
 */
case class ApitrpcabTesting.applyWinner_json (
  postId: BigDecimal,
  winningVariationIndex: BigDecimal
)

