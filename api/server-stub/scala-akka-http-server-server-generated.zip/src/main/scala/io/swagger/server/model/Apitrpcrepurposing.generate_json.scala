package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 * @param siteId 
 * @param format 
 */
case class Apitrpcrepurposing.generate_json (
  postId: BigDecimal,
  siteId: BigDecimal,
  format: String
)

