package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_assets_upload_body (
  json: apitrpcassets.upload_json
)

