package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_sites_upsert_body (
  json: apitrpcsites.upsert_json
)

