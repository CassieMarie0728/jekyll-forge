package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_commitFile_body (
  json: apitrpcgithub.commitFile_json
)

