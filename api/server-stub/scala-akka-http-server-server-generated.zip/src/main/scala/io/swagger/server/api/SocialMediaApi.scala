package io.swagger.server.api

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.unmarshalling.FromRequestUnmarshaller
import akka.http.scaladsl.marshalling.ToEntityMarshaller
import io.swagger.server.AkkaHttpHelper._
import io.swagger.server.model.Error
import io.swagger.server.model.TRPCResponse
import io.swagger.server.model.Trpc_socialMedia_cancelScheduledPost_body
import io.swagger.server.model.Trpc_socialMedia_connectAccount_body
import io.swagger.server.model.Trpc_socialMedia_disconnectAccount_body
import io.swagger.server.model.Trpc_socialMedia_publishContent_body
import io.swagger.server.model.Trpc_socialMedia_reschedulePost_body
import io.swagger.server.model.Trpc_socialMedia_schedulePost_body
import io.swagger.server.model.Trpc_socialMedia_syncAnalytics_body

class SocialMediaApi(
    socialMediaService: SocialMediaApiService,
    socialMediaMarshaller: SocialMediaApiMarshaller
) {
  import socialMediaMarshaller._

  lazy val route: Route =
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_cancelScheduledPost_body]){ body =>
                  socialMediaService.socialMediaCancelScheduledPost(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_connectAccount_body]){ body =>
                  socialMediaService.socialMediaConnectAccount(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_disconnectAccount_body]){ body =>
                  socialMediaService.socialMediaDisconnectAccount(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  socialMediaService.socialMediaGetAccountDetails(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      get {
        
          
            
              
                
                  socialMediaService.socialMediaGetAccounts()
               
             
           
         
       
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  socialMediaService.socialMediaGetAnalyticsByPlatform(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      get {
        
          
            
              
                
                  socialMediaService.socialMediaGetAnalyticsSummary()
               
             
           
         
       
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  socialMediaService.socialMediaGetContentAnalytics(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  socialMediaService.socialMediaGetScheduledPosts(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_publishContent_body]){ body =>
                  socialMediaService.socialMediaPublishContent(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_reschedulePost_body]){ body =>
                  socialMediaService.socialMediaReschedulePost(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_schedulePost_body]){ body =>
                  socialMediaService.socialMediaSchedulePost(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_socialMedia_syncAnalytics_body]){ body =>
                  socialMediaService.socialMediaSyncAnalytics(body = body)
                }
             
           
         
       
      }
    }
}

trait SocialMediaApiService {

  def socialMediaCancelScheduledPost200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaCancelScheduledPost400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaCancelScheduledPost401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaCancelScheduledPost500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaCancelScheduledPost(body: Trpc_socialMedia_cancelScheduledPost_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaConnectAccount200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaConnectAccount400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaConnectAccount401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaConnectAccount500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaConnectAccount(body: Trpc_socialMedia_connectAccount_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaDisconnectAccount200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaDisconnectAccount400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaDisconnectAccount401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaDisconnectAccount500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaDisconnectAccount(body: Trpc_socialMedia_disconnectAccount_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaGetAccountDetails200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaGetAccountDetails400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaGetAccountDetails401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaGetAccountDetails500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaGetAccountDetails(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaGetAccounts200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaGetAccounts400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaGetAccounts401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaGetAccounts500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaGetAccounts()
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaGetAnalyticsByPlatform200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaGetAnalyticsByPlatform400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaGetAnalyticsByPlatform401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaGetAnalyticsByPlatform500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaGetAnalyticsByPlatform(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaGetAnalyticsSummary200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaGetAnalyticsSummary400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaGetAnalyticsSummary401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaGetAnalyticsSummary500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaGetAnalyticsSummary()
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaGetContentAnalytics200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaGetContentAnalytics400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaGetContentAnalytics401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaGetContentAnalytics500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaGetContentAnalytics(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaGetScheduledPosts200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaGetScheduledPosts400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaGetScheduledPosts401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaGetScheduledPosts500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaGetScheduledPosts(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaPublishContent200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaPublishContent400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaPublishContent401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaPublishContent500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaPublishContent(body: Trpc_socialMedia_publishContent_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaReschedulePost200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaReschedulePost400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaReschedulePost401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaReschedulePost500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaReschedulePost(body: Trpc_socialMedia_reschedulePost_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaSchedulePost200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaSchedulePost400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaSchedulePost401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaSchedulePost500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaSchedulePost(body: Trpc_socialMedia_schedulePost_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def socialMediaSyncAnalytics200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def socialMediaSyncAnalytics400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def socialMediaSyncAnalytics401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def socialMediaSyncAnalytics500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def socialMediaSyncAnalytics(body: Trpc_socialMedia_syncAnalytics_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

}

trait SocialMediaApiMarshaller {
  implicit def fromRequestUnmarshallerTrpc_socialMedia_publishContent_body: FromRequestUnmarshaller[Trpc_socialMedia_publishContent_body]

  implicit def fromRequestUnmarshallerTrpc_socialMedia_reschedulePost_body: FromRequestUnmarshaller[Trpc_socialMedia_reschedulePost_body]

  implicit def fromRequestUnmarshallerTrpc_socialMedia_schedulePost_body: FromRequestUnmarshaller[Trpc_socialMedia_schedulePost_body]

  implicit def fromRequestUnmarshallerTrpc_socialMedia_connectAccount_body: FromRequestUnmarshaller[Trpc_socialMedia_connectAccount_body]

  implicit def fromRequestUnmarshallerTrpc_socialMedia_syncAnalytics_body: FromRequestUnmarshaller[Trpc_socialMedia_syncAnalytics_body]

  implicit def fromRequestUnmarshallerTrpc_socialMedia_disconnectAccount_body: FromRequestUnmarshaller[Trpc_socialMedia_disconnectAccount_body]

  implicit def fromRequestUnmarshallerTrpc_socialMedia_cancelScheduledPost_body: FromRequestUnmarshaller[Trpc_socialMedia_cancelScheduledPost_body]


  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

}

