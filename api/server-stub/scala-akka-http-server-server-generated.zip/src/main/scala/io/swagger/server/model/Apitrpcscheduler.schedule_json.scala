package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param siteId 
 * @param postId 
 * @param draftPath 
 * @param targetPath 
 * @param scheduledAt 
 * @param timezone 
 * @param commitMessage 
 */
case class Apitrpcscheduler.schedule_json (
  siteId: BigDecimal,
  postId: Option[BigDecimal],
  draftPath: String,
  targetPath: String,
  scheduledAt: ,
  timezone: String,
  commitMessage: Option[String]
)

