package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param path 
 * @param branch 
 * @param sha 
 * @param message 
 */
case class Apitrpcgithub.deleteFile_json (
  owner: String,
  repo: String,
  path: String,
  branch: String,
  sha: String,
  message: String
)

