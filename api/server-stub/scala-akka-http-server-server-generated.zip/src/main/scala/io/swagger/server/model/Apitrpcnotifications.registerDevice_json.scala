package io.swagger.server.model


/**
 * @param token 
 * @param platform 
 */
case class Apitrpcnotifications.registerDevice_json (
  token: String,
  platform: String
)

