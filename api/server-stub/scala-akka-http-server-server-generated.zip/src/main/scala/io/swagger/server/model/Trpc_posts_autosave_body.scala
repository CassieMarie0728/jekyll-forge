package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_posts_autosave_body (
  json: apitrpcposts.autosave_json
)

