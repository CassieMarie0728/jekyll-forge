package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param maxWidth 
 * @param outputFormat 
 * @param quality 
 */
case class Apitrpcassets.reoptimize_json (
  id: BigDecimal,
  maxWidth: Option[BigDecimal],
  outputFormat: Option[String],
  quality: Option[BigDecimal]
)

