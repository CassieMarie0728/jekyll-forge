package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param title 
 * @param head 
 * @param base 
 * @param body 
 */
case class Apitrpcgithub.createPullRequest_json (
  owner: String,
  repo: String,
  title: String,
  head: String,
  base: String,
  body: Option[String]
)

