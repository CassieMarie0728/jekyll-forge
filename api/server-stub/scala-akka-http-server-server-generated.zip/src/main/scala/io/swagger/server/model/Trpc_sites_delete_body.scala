package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_sites_delete_body (
  json: apitrpcassets.delete_json
)

