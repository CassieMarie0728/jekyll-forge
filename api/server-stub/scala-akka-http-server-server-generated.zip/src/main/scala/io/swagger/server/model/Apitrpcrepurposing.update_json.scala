package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param content 
 * @param status 
 * @param isCustomized 
 */
case class Apitrpcrepurposing.update_json (
  id: BigDecimal,
  content: Option[String],
  status: Option[],
  isCustomized: Option[Boolean]
)

