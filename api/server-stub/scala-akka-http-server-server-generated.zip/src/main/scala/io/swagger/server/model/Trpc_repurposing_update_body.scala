package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_repurposing_update_body (
  json: apitrpcrepurposing.update_json
)

