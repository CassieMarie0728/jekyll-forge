package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param name 
 * @param category 
 * @param content 
 * @param contentType 
 */
case class Apitrpcblocks.update_json (
  id: BigDecimal,
  name: Option[String],
  category: Option[String],
  content: Option[String],
  contentType: Option[String]
)

