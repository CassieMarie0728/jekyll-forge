package io.swagger.server.model


/**
 * @param token 
 */
case class Apitrpcgithub.connect_json (
  token: String
)

