package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param repurposedContentId 
 * @param accountId 
 */
case class ApitrpcsocialMedia.publishContent_json (
  repurposedContentId: BigDecimal,
  accountId: BigDecimal
)

