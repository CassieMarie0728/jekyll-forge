package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_updateJekyllConfig_body (
  json: apitrpcgithub.updateJekyllConfig_json
)

