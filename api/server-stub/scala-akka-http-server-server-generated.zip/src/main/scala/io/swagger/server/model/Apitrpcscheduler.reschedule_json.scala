package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param scheduledAt 
 * @param timezone 
 */
case class Apitrpcscheduler.reschedule_json (
  id: BigDecimal,
  scheduledAt: ,
  timezone: Option[String]
)

