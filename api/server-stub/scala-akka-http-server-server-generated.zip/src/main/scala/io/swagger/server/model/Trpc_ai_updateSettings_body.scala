package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_ai_updateSettings_body (
  json: apitrpcai.updateSettings_json
)

