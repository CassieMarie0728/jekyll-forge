package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param siteId 
 * @param path 
 * @param filename 
 * @param slug 
 * @param title 
 * @param status 
 * @param frontMatter 
 * @param markdown 
 * @param sha 
 * @param scheduledAt 
 */
case class Apitrpcposts.upsert_json (
  siteId: BigDecimal,
  path: String,
  filename: Option[String],
  slug: Option[String],
  title: Option[String],
  status: Option[],
  frontMatter: Option[],
  markdown: Option[String],
  sha: Option[String],
  scheduledAt: Option[]
)

