package io.swagger.server.model


/**
 * @param name 
 * @param category 
 * @param content 
 * @param contentType 
 */
case class Apitrpcblocks.create_json (
  name: String,
  category: Option[String],
  content: String,
  contentType: String
)

