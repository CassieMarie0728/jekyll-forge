package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param path 
 * @param branch 
 * @param content 
 * @param message 
 * @param sha 
 */
case class Apitrpcgithub.commitFile_json (
  owner: String,
  repo: String,
  path: String,
  branch: String,
  content: String,
  message: String,
  sha: Option[String]
)

