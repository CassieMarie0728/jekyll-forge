package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_aiProviders_test_body (
  json: apitrpcaiProviders.save_json
)

