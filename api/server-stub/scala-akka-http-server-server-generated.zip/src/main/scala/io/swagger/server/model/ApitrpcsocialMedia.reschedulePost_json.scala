package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 * @param scheduledAt 
 * @param timezone 
 */
case class ApitrpcsocialMedia.reschedulePost_json (
  postId: BigDecimal,
  scheduledAt: ,
  timezone: Option[String]
)

