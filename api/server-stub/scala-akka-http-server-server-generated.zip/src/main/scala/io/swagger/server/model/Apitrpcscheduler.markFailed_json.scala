package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param errorMessage 
 */
case class Apitrpcscheduler.markFailed_json (
  id: BigDecimal,
  errorMessage: String
)

