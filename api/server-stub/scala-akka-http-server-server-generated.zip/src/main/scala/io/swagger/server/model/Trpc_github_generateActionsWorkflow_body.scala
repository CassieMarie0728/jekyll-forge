package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_generateActionsWorkflow_body (
  json: apitrpcgithub.generateActionsWorkflow_json
)

