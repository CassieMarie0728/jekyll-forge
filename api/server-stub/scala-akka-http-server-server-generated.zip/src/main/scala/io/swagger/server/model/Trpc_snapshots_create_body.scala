package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_snapshots_create_body (
  json: apitrpcsnapshots.create_json
)

