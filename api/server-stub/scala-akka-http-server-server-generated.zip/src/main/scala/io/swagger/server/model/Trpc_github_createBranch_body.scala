package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_createBranch_body (
  json: apitrpcgithub.createBranch_json
)

