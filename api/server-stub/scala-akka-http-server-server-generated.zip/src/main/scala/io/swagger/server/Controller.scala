package io.swagger.server

import akka.http.scaladsl.Http
import akka.http.scaladsl.server.Route
import io.swagger.server.api.AbTestingApi
import io.swagger.server.api.AiApi
import io.swagger.server.api.AiProvidersApi
import io.swagger.server.api.AssetsApi
import io.swagger.server.api.BlocksApi
import io.swagger.server.api.GithubApi
import io.swagger.server.api.NotificationsApi
import io.swagger.server.api.PostsApi
import io.swagger.server.api.RepurposingApi
import io.swagger.server.api.SchedulerApi
import io.swagger.server.api.SitesApi
import io.swagger.server.api.SnapshotsApi
import io.swagger.server.api.SocialMediaApi
import akka.http.scaladsl.server.Directives._
import akka.actor.ActorSystem
import akka.stream.ActorMaterializer

class Controller(abTesting: AbTestingApi, ai: AiApi, aiProviders: AiProvidersApi, assets: AssetsApi, blocks: BlocksApi, github: GithubApi, notifications: NotificationsApi, posts: PostsApi, repurposing: RepurposingApi, scheduler: SchedulerApi, sites: SitesApi, snapshots: SnapshotsApi, socialMedia: SocialMediaApi)(implicit system: ActorSystem, materializer: ActorMaterializer) {

    lazy val routes: Route = abTesting.route ~ ai.route ~ aiProviders.route ~ assets.route ~ blocks.route ~ github.route ~ notifications.route ~ posts.route ~ repurposing.route ~ scheduler.route ~ sites.route ~ snapshots.route ~ socialMedia.route 

    Http().bindAndHandle(routes, "0.0.0.0", 9000)
}