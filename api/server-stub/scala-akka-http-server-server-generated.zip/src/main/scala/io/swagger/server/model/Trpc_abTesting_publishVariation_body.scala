package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_abTesting_publishVariation_body (
  json: apitrpcabTesting.publishVariation_json
)

