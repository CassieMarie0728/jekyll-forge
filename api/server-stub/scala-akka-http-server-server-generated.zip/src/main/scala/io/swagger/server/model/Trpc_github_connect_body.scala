package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_connect_body (
  json: apitrpcgithub.connect_json
)

