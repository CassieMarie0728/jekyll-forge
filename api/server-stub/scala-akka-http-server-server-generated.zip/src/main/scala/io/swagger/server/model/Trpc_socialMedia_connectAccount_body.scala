package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_connectAccount_body (
  json: apitrpcsocialMedia.connectAccount_json
)

