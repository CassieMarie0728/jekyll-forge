package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_scheduler_markFailed_body (
  json: apitrpcscheduler.markFailed_json
)

