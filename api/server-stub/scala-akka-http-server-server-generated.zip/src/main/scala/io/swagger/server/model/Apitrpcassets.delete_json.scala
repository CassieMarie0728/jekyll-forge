package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 */
case class Apitrpcassets.delete_json (
  id: BigDecimal
)

