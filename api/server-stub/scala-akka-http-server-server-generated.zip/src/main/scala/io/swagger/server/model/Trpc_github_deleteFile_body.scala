package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_deleteFile_body (
  json: apitrpcgithub.deleteFile_json
)

