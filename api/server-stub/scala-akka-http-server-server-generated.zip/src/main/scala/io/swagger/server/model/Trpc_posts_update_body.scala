package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_posts_update_body (
  json: apitrpcposts.update_json
)

