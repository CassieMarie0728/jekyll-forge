package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param siteId 
 * @param name 
 * @param path 
 * @param base64Content 
 * @param mimeType 
 * @param size 
 * @param width 
 * @param height 
 * @param optimize 
 * @param maxWidth 
 * @param outputFormat 
 * @param quality 
 */
case class Apitrpcassets.upload_json (
  siteId: BigDecimal,
  name: String,
  path: String,
  base64Content: String,
  mimeType: String,
  size: BigDecimal,
  width: Option[BigDecimal],
  height: Option[BigDecimal],
  optimize: Boolean,
  maxWidth: Option[BigDecimal],
  outputFormat: Option[String],
  quality: Option[BigDecimal]
)

