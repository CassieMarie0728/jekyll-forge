package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param repurposedContentId 
 * @param socialMediaAccountId 
 * @param scheduledAt 
 * @param timezone 
 */
case class ApitrpcsocialMedia.schedulePost_json (
  repurposedContentId: BigDecimal,
  socialMediaAccountId: BigDecimal,
  scheduledAt: ,
  timezone: Option[String]
)

