package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_schedulePost_body (
  json: apitrpcsocialMedia.schedulePost_json
)

