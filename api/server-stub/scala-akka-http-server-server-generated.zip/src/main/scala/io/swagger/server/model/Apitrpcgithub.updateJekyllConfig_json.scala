package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param rootPath 
 * @param branch 
 * @param commitMessage 
 */
case class Apitrpcgithub.updateJekyllConfig_json (
  owner: String,
  repo: String,
  rootPath: String,
  branch: String,
  commitMessage: Option[String]
)

