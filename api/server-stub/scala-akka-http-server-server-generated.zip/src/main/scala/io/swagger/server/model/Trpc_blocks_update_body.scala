package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_blocks_update_body (
  json: apitrpcblocks.update_json
)

