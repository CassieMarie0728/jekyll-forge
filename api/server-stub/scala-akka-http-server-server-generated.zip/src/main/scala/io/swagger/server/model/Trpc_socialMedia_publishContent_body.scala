package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_publishContent_body (
  json: apitrpcsocialMedia.publishContent_json
)

