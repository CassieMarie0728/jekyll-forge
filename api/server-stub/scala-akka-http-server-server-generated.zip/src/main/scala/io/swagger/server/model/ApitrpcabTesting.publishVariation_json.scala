package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 * @param variationIndex 
 * @param platforms 
 */
case class ApitrpcabTesting.publishVariation_json (
  postId: BigDecimal,
  variationIndex: BigDecimal,
  platforms: List[String]
)

