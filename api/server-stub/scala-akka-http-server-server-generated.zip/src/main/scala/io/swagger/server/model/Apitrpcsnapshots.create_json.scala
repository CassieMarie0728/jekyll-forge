package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param siteId 
 * @param postId 
 * @param postPath 
 * @param label 
 * @param reason 
 * @param markdown 
 * @param frontMatter 
 */
case class Apitrpcsnapshots.create_json (
  siteId: BigDecimal,
  postId: Option[BigDecimal],
  postPath: Option[String],
  label: String,
  reason: ,
  markdown: Option[String],
  frontMatter: Option[]
)

