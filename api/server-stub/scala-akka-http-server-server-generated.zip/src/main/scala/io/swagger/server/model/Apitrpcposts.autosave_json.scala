package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param markdown 
 * @param frontMatter 
 */
case class Apitrpcposts.autosave_json (
  id: BigDecimal,
  markdown: String,
  frontMatter: 
)

