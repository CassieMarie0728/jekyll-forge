package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_cancelScheduledPost_body (
  json: apitrpcabTesting.completeTest_json
)

