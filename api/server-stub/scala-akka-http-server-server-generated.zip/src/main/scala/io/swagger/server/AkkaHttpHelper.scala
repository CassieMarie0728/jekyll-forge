package io.swagger.server

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.{PathMatcher, PathMatcher1}


object AkkaHttpHelper {
  /**
   * A PathMatcher that matches and extracts a Float value. The matched string representation is the pure decimal,
   * optionally signed form of a float value, i.e. without exponent.
   *
   * @group pathmatcher
   */
  val FloatNumber: PathMatcher1[Float] =
    PathMatcher("""[+-]?\d*\.?\d*""".r) flatMap { string ⇒
      try Some(java.lang.Float.parseFloat(string))
      catch { case _: NumberFormatException ⇒ None }
     }

  /**
   * A PathMatcher that matches and extracts a Boolean value.
   *
   * @group pathmatcher
   */
  val Boolean: PathMatcher1[Boolean] =
    Segment.flatMap { string =>
      try Some(string.toBoolean)
      catch { case _: IllegalArgumentException => None }
    }
}
