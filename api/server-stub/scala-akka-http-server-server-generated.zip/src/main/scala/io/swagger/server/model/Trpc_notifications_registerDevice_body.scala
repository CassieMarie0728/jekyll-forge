package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_notifications_registerDevice_body (
  json: apitrpcnotifications.registerDevice_json
)

