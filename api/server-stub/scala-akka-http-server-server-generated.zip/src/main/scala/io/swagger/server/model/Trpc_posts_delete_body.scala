package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_posts_delete_body (
  json: apitrpcassets.delete_json
)

