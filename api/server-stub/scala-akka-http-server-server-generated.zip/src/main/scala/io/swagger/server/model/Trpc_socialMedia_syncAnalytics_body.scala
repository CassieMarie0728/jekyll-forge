package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_syncAnalytics_body (
  json: apitrpcsocialMedia.syncAnalytics_json
)

