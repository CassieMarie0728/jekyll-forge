package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_repurposing_regenerate_body (
  json: apitrpcrepurposing.regenerate_json
)

