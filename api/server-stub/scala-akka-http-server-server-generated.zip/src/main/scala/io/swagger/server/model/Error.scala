package io.swagger.server.model


/**
 */
case class Error (
)

