package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param enabled 
 * @param temperature 
 * @param maxTokens 
 * @param systemPrompt 
 * @param brandVoicePrompt 
 * @param safetyPrompt 
 * @param streaming 
 * @param defaultLanguage 
 * @param defaultTone 
 * @param budgetLimitCents 
 */
case class Apitrpcai.updateSettings_json (
  enabled: Option[Boolean],
  temperature: Option[BigDecimal],
  maxTokens: Option[BigDecimal],
  systemPrompt: Option[String],
  brandVoicePrompt: Option[String],
  safetyPrompt: Option[String],
  streaming: Option[Boolean],
  defaultLanguage: Option[String],
  defaultTone: Option[String],
  budgetLimitCents: Option[BigDecimal]
)

