package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_createPullRequest_body (
  json: apitrpcgithub.createPullRequest_json
)

