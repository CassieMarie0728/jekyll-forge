package io.swagger.server.model


/**
 * @param token 
 */
case class Apitrpcnotifications.unregisterDevice_json (
  token: String
)

