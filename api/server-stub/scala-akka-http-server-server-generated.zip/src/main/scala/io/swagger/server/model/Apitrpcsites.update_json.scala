package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param isFavorite 
 * @param selectedBranch 
 * @param rootPath 
 * @param timezone 
 * @param defaultLayout 
 * @param defaultAssetPath 
 * @param aiVoiceProfile 
 * @param settings 
 */
case class Apitrpcsites.update_json (
  id: BigDecimal,
  isFavorite: Option[Boolean],
  selectedBranch: Option[String],
  rootPath: Option[String],
  timezone: Option[String],
  defaultLayout: Option[String],
  defaultAssetPath: Option[String],
  aiVoiceProfile: Option[String],
  settings: Option[]
)

