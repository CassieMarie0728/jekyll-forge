package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_blocks_delete_body (
  json: apitrpcassets.delete_json
)

