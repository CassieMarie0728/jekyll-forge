package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_assets_generateAltText_body (
  json: apitrpcassets.generateAltText_json
)

