package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_reschedulePost_body (
  json: apitrpcsocialMedia.reschedulePost_json
)

