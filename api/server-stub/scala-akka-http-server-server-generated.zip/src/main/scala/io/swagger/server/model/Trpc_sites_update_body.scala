package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_sites_update_body (
  json: apitrpcsites.update_json
)

