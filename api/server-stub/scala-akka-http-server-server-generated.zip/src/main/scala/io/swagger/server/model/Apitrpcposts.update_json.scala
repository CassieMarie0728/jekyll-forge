package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param path 
 * @param title 
 * @param slug 
 * @param status 
 * @param frontMatter 
 * @param markdown 
 * @param sha 
 * @param scheduledAt 
 */
case class Apitrpcposts.update_json (
  id: BigDecimal,
  path: Option[String],
  title: Option[String],
  slug: Option[String],
  status: Option[],
  frontMatter: Option[],
  markdown: Option[String],
  sha: Option[String],
  scheduledAt: Option[]
)

