package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param siteId 
 */
case class Apitrpcscheduler.cancelAll_json (
  siteId: BigDecimal
)

