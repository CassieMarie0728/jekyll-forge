package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param impressions 
 * @param engagements 
 * @param clicks 
 * @param shares 
 * @param likes 
 * @param replies 
 */
case class ApitrpcabTesting.updateMetrics_json_metrics (
  impressions: Option[BigDecimal],
  engagements: Option[BigDecimal],
  clicks: Option[BigDecimal],
  shares: Option[BigDecimal],
  likes: Option[BigDecimal],
  replies: Option[BigDecimal]
)

