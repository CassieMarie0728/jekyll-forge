package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_notifications_unregisterDevice_body (
  json: apitrpcnotifications.unregisterDevice_json
)

