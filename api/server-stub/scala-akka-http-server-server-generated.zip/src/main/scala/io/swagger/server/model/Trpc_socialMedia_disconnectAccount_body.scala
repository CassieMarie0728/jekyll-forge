package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_socialMedia_disconnectAccount_body (
  json: apitrpcassets.delete_json
)

