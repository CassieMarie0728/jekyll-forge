package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 * @param count 
 * @param tones 
 * @param angles 
 * @param headline 
 * @param content 
 */
case class ApitrpcabTesting.generateVariations_json (
  postId: BigDecimal,
  count: Option[BigDecimal],
  tones: Option[List[String]],
  angles: Option[List[String]],
  headline: String,
  content: String
)

