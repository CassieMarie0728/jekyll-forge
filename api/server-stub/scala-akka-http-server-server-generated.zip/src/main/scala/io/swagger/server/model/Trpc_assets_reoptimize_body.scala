package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_assets_reoptimize_body (
  json: apitrpcassets.reoptimize_json
)

