package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_scheduler_schedule_body (
  json: apitrpcscheduler.schedule_json
)

