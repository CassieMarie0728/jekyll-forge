package io.swagger.server.api

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.unmarshalling.FromRequestUnmarshaller
import akka.http.scaladsl.marshalling.ToEntityMarshaller
import io.swagger.server.AkkaHttpHelper._
import io.swagger.server.model.Error
import io.swagger.server.model.TRPCResponse
import io.swagger.server.model.Trpc_assets_delete_body
import io.swagger.server.model.Trpc_assets_generateAltText_body
import io.swagger.server.model.Trpc_assets_reoptimize_body
import io.swagger.server.model.Trpc_assets_update_body
import io.swagger.server.model.Trpc_assets_upload_body

class AssetsApi(
    assetsService: AssetsApiService,
    assetsMarshaller: AssetsApiMarshaller
) {
  import assetsMarshaller._

  lazy val route: Route =
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_assets_delete_body]){ body =>
                  assetsService.assetsDelete(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_assets_generateAltText_body]){ body =>
                  assetsService.assetsGenerateAltText(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  assetsService.assetsList(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_assets_reoptimize_body]){ body =>
                  assetsService.assetsReoptimize(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_assets_update_body]){ body =>
                  assetsService.assetsUpdate(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_assets_upload_body]){ body =>
                  assetsService.assetsUpload(body = body)
                }
             
           
         
       
      }
    }
}

trait AssetsApiService {

  def assetsDelete200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def assetsDelete400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def assetsDelete401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def assetsDelete500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def assetsDelete(body: Trpc_assets_delete_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def assetsGenerateAltText200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def assetsGenerateAltText400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def assetsGenerateAltText401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def assetsGenerateAltText500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def assetsGenerateAltText(body: Trpc_assets_generateAltText_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def assetsList200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def assetsList400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def assetsList401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def assetsList500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def assetsList(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def assetsReoptimize200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def assetsReoptimize400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def assetsReoptimize401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def assetsReoptimize500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def assetsReoptimize(body: Trpc_assets_reoptimize_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def assetsUpdate200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def assetsUpdate400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def assetsUpdate401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def assetsUpdate500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def assetsUpdate(body: Trpc_assets_update_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def assetsUpload200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def assetsUpload400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def assetsUpload401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def assetsUpload500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def assetsUpload(body: Trpc_assets_upload_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

}

trait AssetsApiMarshaller {
  implicit def fromRequestUnmarshallerTrpc_assets_upload_body: FromRequestUnmarshaller[Trpc_assets_upload_body]

  implicit def fromRequestUnmarshallerTrpc_assets_delete_body: FromRequestUnmarshaller[Trpc_assets_delete_body]

  implicit def fromRequestUnmarshallerTrpc_assets_generateAltText_body: FromRequestUnmarshaller[Trpc_assets_generateAltText_body]

  implicit def fromRequestUnmarshallerTrpc_assets_reoptimize_body: FromRequestUnmarshaller[Trpc_assets_reoptimize_body]

  implicit def fromRequestUnmarshallerTrpc_assets_update_body: FromRequestUnmarshaller[Trpc_assets_update_body]


  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

}

