package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_ai_generate_body (
  json: apitrpcai.generate_json
)

