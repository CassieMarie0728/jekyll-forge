package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_scheduler_markPublished_body (
  json: apitrpcassets.delete_json
)

