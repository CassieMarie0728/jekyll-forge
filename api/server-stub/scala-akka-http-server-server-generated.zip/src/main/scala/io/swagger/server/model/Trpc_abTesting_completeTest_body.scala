package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_abTesting_completeTest_body (
  json: apitrpcabTesting.completeTest_json
)

