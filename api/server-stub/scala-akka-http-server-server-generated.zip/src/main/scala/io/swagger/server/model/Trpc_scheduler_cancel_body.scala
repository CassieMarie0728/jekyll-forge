package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_scheduler_cancel_body (
  json: apitrpcassets.delete_json
)

