package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param postId 
 * @param siteId 
 */
case class Apitrpcrepurposing.regenerate_json (
  id: BigDecimal,
  postId: BigDecimal,
  siteId: BigDecimal
)

