package io.swagger.server.model


/**
 * @param provider 
 * @param model 
 * @param apiKey 
 */
case class ApitrpcaiProviders.save_json (
  provider: ,
  model: String,
  apiKey: String
)

