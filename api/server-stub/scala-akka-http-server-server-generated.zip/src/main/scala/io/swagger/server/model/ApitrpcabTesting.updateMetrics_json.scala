package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 * @param variationIndex 
 * @param platform 
 * @param metrics 
 */
case class ApitrpcabTesting.updateMetrics_json (
  postId: BigDecimal,
  variationIndex: BigDecimal,
  platform: String,
  metrics: Option[apitrpcabTesting.updateMetrics_json_metrics]
)

