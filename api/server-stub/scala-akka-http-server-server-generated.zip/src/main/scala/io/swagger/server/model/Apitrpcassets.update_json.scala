package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param id 
 * @param name 
 * @param path 
 * @param alt 
 */
case class Apitrpcassets.update_json (
  id: BigDecimal,
  name: Option[String],
  path: Option[String],
  alt: Option[String]
)

