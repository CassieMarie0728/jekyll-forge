package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_repurposing_generate_body (
  json: apitrpcrepurposing.generate_json
)

