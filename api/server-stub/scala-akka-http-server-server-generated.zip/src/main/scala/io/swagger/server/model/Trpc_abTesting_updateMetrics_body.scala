package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_abTesting_updateMetrics_body (
  json: apitrpcabTesting.updateMetrics_json
)

