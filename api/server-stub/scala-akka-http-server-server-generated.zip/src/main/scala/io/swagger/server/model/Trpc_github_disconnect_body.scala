package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_github_disconnect_body (
  json: Option[]
)

