package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param branch 
 */
case class Apitrpcgithub.generateActionsWorkflow_json (
  owner: String,
  repo: String,
  branch: String
)

