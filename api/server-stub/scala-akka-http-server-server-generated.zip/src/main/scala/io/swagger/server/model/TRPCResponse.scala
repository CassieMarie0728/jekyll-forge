package io.swagger.server.model


/**
 * tRPC response envelope; payload shape varies by procedure
 *
 */
case class TRPCResponse (
)

