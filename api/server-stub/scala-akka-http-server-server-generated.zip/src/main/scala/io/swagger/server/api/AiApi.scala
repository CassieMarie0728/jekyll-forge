package io.swagger.server.api

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.unmarshalling.FromRequestUnmarshaller
import akka.http.scaladsl.marshalling.ToEntityMarshaller
import io.swagger.server.AkkaHttpHelper._
import io.swagger.server.model.Error
import io.swagger.server.model.TRPCResponse
import io.swagger.server.model.Trpc_ai_generate_body
import io.swagger.server.model.Trpc_ai_updateSettings_body

class AiApi(
    aiService: AiApiService,
    aiMarshaller: AiApiMarshaller
) {
  import aiMarshaller._

  lazy val route: Route =
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_ai_generate_body]){ body =>
                  aiService.aiGenerate(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      get {
        
          
            
              
                
                  aiService.aiGetSettings()
               
             
           
         
       
      }
    } ~
    path() { 
      get {
        
          
            
              
                
                  aiService.aiGetUsageStats()
               
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_ai_updateSettings_body]){ body =>
                  aiService.aiUpdateSettings(body = body)
                }
             
           
         
       
      }
    }
}

trait AiApiService {

  def aiGenerate200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def aiGenerate400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def aiGenerate401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def aiGenerate500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def aiGenerate(body: Trpc_ai_generate_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def aiGetSettings200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def aiGetSettings400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def aiGetSettings401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def aiGetSettings500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def aiGetSettings()
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def aiGetUsageStats200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def aiGetUsageStats400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def aiGetUsageStats401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def aiGetUsageStats500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def aiGetUsageStats()
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def aiUpdateSettings200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def aiUpdateSettings400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def aiUpdateSettings401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def aiUpdateSettings500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def aiUpdateSettings(body: Trpc_ai_updateSettings_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

}

trait AiApiMarshaller {
  implicit def fromRequestUnmarshallerTrpc_ai_updateSettings_body: FromRequestUnmarshaller[Trpc_ai_updateSettings_body]

  implicit def fromRequestUnmarshallerTrpc_ai_generate_body: FromRequestUnmarshaller[Trpc_ai_generate_body]


  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

}

