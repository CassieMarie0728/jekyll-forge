package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_aiProviders_save_body (
  json: apitrpcaiProviders.save_json
)

