package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_scheduler_reschedule_body (
  json: apitrpcscheduler.reschedule_json
)

