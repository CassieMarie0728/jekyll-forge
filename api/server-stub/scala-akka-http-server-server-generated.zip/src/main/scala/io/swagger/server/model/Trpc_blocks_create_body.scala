package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_blocks_create_body (
  json: apitrpcblocks.create_json
)

