package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_posts_upsert_body (
  json: apitrpcposts.upsert_json
)

