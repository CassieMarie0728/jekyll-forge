package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_scheduler_cancelAll_body (
  json: apitrpcscheduler.cancelAll_json
)

