package io.swagger.server.model


/**
 * @param json 
 */
case class Trpc_abTesting_generateVariations_body (
  json: apitrpcabTesting.generateVariations_json
)

