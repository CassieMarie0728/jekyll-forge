package io.swagger.server.api

import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.unmarshalling.FromRequestUnmarshaller
import akka.http.scaladsl.marshalling.ToEntityMarshaller
import io.swagger.server.AkkaHttpHelper._
import io.swagger.server.model.Error
import io.swagger.server.model.TRPCResponse
import io.swagger.server.model.Trpc_abTesting_applyWinner_body
import io.swagger.server.model.Trpc_abTesting_completeTest_body
import io.swagger.server.model.Trpc_abTesting_generateVariations_body
import io.swagger.server.model.Trpc_abTesting_publishVariation_body
import io.swagger.server.model.Trpc_abTesting_updateMetrics_body

class AbTestingApi(
    abTestingService: AbTestingApiService,
    abTestingMarshaller: AbTestingApiMarshaller
) {
  import abTestingMarshaller._

  lazy val route: Route =
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_abTesting_applyWinner_body]){ body =>
                  abTestingService.abTestingApplyWinner(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_abTesting_completeTest_body]){ body =>
                  abTestingService.abTestingCompleteTest(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_abTesting_generateVariations_body]){ body =>
                  abTestingService.abTestingGenerateVariations(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  abTestingService.abTestingGetResults(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      get {
        parameters("input".as[String]) { (input) =>
          
            
              
                
                  abTestingService.abTestingGetVariations(input = input)
               
             
           
         
        }
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_abTesting_publishVariation_body]){ body =>
                  abTestingService.abTestingPublishVariation(body = body)
                }
             
           
         
       
      }
    } ~
    path() { 
      post {
        
          
            
              
                entity(as[Trpc_abTesting_updateMetrics_body]){ body =>
                  abTestingService.abTestingUpdateMetrics(body = body)
                }
             
           
         
       
      }
    }
}

trait AbTestingApiService {

  def abTestingApplyWinner200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingApplyWinner400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingApplyWinner401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingApplyWinner500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingApplyWinner(body: Trpc_abTesting_applyWinner_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def abTestingCompleteTest200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingCompleteTest400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingCompleteTest401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingCompleteTest500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingCompleteTest(body: Trpc_abTesting_completeTest_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def abTestingGenerateVariations200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingGenerateVariations400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingGenerateVariations401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingGenerateVariations500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingGenerateVariations(body: Trpc_abTesting_generateVariations_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def abTestingGetResults200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingGetResults400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingGetResults401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingGetResults500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingGetResults(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def abTestingGetVariations200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingGetVariations400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingGetVariations401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingGetVariations500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingGetVariations(input: String)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def abTestingPublishVariation200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingPublishVariation400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingPublishVariation401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingPublishVariation500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingPublishVariation(body: Trpc_abTesting_publishVariation_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

  def abTestingUpdateMetrics200(responseTRPCResponse: TRPCResponse)(implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]): Route =
    complete((200, responseTRPCResponse))
  def abTestingUpdateMetrics400(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((400, responseError))
  def abTestingUpdateMetrics401(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((401, responseError))
  def abTestingUpdateMetrics500(responseError: Error)(implicit toEntityMarshallerError: ToEntityMarshaller[Error]): Route =
    complete((500, responseError))
  /**
   * Code: 200, Message: Successful tRPC response, DataType: TRPCResponse
   * Code: 400, Message: Bad request / invalid input, DataType: Error
   * Code: 401, Message: Authentication required, DataType: Error
   * Code: 500, Message: Server error, DataType: Error
   */
  def abTestingUpdateMetrics(body: Trpc_abTesting_updateMetrics_body)
      (implicit toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error], toEntityMarshallerError: ToEntityMarshaller[Error]): Route

}

trait AbTestingApiMarshaller {
  implicit def fromRequestUnmarshallerTrpc_abTesting_applyWinner_body: FromRequestUnmarshaller[Trpc_abTesting_applyWinner_body]

  implicit def fromRequestUnmarshallerTrpc_abTesting_generateVariations_body: FromRequestUnmarshaller[Trpc_abTesting_generateVariations_body]

  implicit def fromRequestUnmarshallerTrpc_abTesting_completeTest_body: FromRequestUnmarshaller[Trpc_abTesting_completeTest_body]

  implicit def fromRequestUnmarshallerTrpc_abTesting_updateMetrics_body: FromRequestUnmarshaller[Trpc_abTesting_updateMetrics_body]

  implicit def fromRequestUnmarshallerTrpc_abTesting_publishVariation_body: FromRequestUnmarshaller[Trpc_abTesting_publishVariation_body]


  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerTRPCResponse: ToEntityMarshaller[TRPCResponse]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

  implicit def toEntityMarshallerError: ToEntityMarshaller[Error]

}

