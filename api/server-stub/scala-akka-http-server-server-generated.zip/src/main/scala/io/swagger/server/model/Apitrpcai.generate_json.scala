package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param task 
 * @param userPrompt 
 * @param selectedText 
 * @param postMarkdown 
 * @param frontMatter 
 * @param tone 
 * @param voiceProfileId 
 */
case class Apitrpcai.generate_json (
  task: String,
  userPrompt: Option[String],
  selectedText: Option[String],
  postMarkdown: Option[String],
  frontMatter: Option[],
  tone: Option[String],
  voiceProfileId: Option[BigDecimal]
)

