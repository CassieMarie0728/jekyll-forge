package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param analyticsId 
 */
case class ApitrpcsocialMedia.syncAnalytics_json (
  analyticsId: BigDecimal
)

