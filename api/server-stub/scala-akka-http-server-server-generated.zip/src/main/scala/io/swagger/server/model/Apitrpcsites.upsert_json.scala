package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param defaultBranch 
 * @param selectedBranch 
 * @param rootPath 
 * @param isJekyll 
 * @param isFavorite 
 * @param timezone 
 * @param defaultLayout 
 * @param defaultAssetPath 
 */
case class Apitrpcsites.upsert_json (
  owner: String,
  repo: String,
  defaultBranch: Option[String],
  selectedBranch: Option[String],
  rootPath: Option[String],
  isJekyll: Option[Boolean],
  isFavorite: Option[Boolean],
  timezone: Option[String],
  defaultLayout: Option[String],
  defaultAssetPath: Option[String]
)

