package io.swagger.server.model


/**
 * @param provider 
 */
case class ApitrpcaiProviders.activate_json (
  provider: 
)

