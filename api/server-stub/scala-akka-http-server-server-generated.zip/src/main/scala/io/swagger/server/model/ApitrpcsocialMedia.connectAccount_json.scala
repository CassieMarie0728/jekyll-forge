package io.swagger.server.model


/**
 * @param platform 
 * @param accessToken 
 * @param refreshToken 
 * @param expiresAt 
 * @param accountId 
 * @param username 
 * @param displayName 
 * @param profileImageUrl 
 */
case class ApitrpcsocialMedia.connectAccount_json (
  platform: String,
  accessToken: String,
  refreshToken: Option[String],
  expiresAt: Option[],
  accountId: String,
  username: Option[String],
  displayName: Option[String],
  profileImageUrl: Option[String]
)

