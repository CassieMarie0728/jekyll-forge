package io.swagger.server.model

import java.math.BigDecimal

/**
 * @param postId 
 */
case class ApitrpcabTesting.completeTest_json (
  postId: BigDecimal
)

