package io.swagger.server.model


/**
 * @param owner 
 * @param repo 
 * @param branchName 
 * @param fromBranch 
 */
case class Apitrpcgithub.createBranch_json (
  owner: String,
  repo: String,
  branchName: String,
  fromBranch: String
)

