package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcaiGenerateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcaiGenerateJson   {
  @JsonProperty("task")

  private String task = null;

  @JsonProperty("userPrompt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String userPrompt = null;

  @JsonProperty("selectedText")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String selectedText = null;

  @JsonProperty("postMarkdown")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String postMarkdown = null;

  @JsonProperty("frontMatter")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object frontMatter = null;

  @JsonProperty("tone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String tone = null;

  @JsonProperty("voiceProfileId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal voiceProfileId = null;


  public ApitrpcaiGenerateJson task(String task) { 

    this.task = task;
    return this;
  }

  /**
   * Get task
   * @return task
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getTask() {  
    return task;
  }



  public void setTask(String task) { 

    this.task = task;
  }

  public ApitrpcaiGenerateJson userPrompt(String userPrompt) { 

    this.userPrompt = userPrompt;
    return this;
  }

  /**
   * Get userPrompt
   * @return userPrompt
   **/
  
  @Schema(description = "")
  
  public String getUserPrompt() {  
    return userPrompt;
  }



  public void setUserPrompt(String userPrompt) { 
    this.userPrompt = userPrompt;
  }

  public ApitrpcaiGenerateJson selectedText(String selectedText) { 

    this.selectedText = selectedText;
    return this;
  }

  /**
   * Get selectedText
   * @return selectedText
   **/
  
  @Schema(description = "")
  
  public String getSelectedText() {  
    return selectedText;
  }



  public void setSelectedText(String selectedText) { 
    this.selectedText = selectedText;
  }

  public ApitrpcaiGenerateJson postMarkdown(String postMarkdown) { 

    this.postMarkdown = postMarkdown;
    return this;
  }

  /**
   * Get postMarkdown
   * @return postMarkdown
   **/
  
  @Schema(description = "")
  
  public String getPostMarkdown() {  
    return postMarkdown;
  }



  public void setPostMarkdown(String postMarkdown) { 
    this.postMarkdown = postMarkdown;
  }

  public ApitrpcaiGenerateJson frontMatter(Object frontMatter) { 

    this.frontMatter = frontMatter;
    return this;
  }

  /**
   * Get frontMatter
   * @return frontMatter
   **/
  
  @Schema(description = "")
  
  public Object getFrontMatter() {  
    return frontMatter;
  }



  public void setFrontMatter(Object frontMatter) { 
    this.frontMatter = frontMatter;
  }

  public ApitrpcaiGenerateJson tone(String tone) { 

    this.tone = tone;
    return this;
  }

  /**
   * Get tone
   * @return tone
   **/
  
  @Schema(description = "")
  
  public String getTone() {  
    return tone;
  }



  public void setTone(String tone) { 
    this.tone = tone;
  }

  public ApitrpcaiGenerateJson voiceProfileId(BigDecimal voiceProfileId) { 

    this.voiceProfileId = voiceProfileId;
    return this;
  }

  /**
   * Get voiceProfileId
   * @return voiceProfileId
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getVoiceProfileId() {  
    return voiceProfileId;
  }



  public void setVoiceProfileId(BigDecimal voiceProfileId) { 
    this.voiceProfileId = voiceProfileId;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiGenerateJson apitrpcaiGenerateJson = (ApitrpcaiGenerateJson) o;
    return Objects.equals(this.task, apitrpcaiGenerateJson.task) &&
        Objects.equals(this.userPrompt, apitrpcaiGenerateJson.userPrompt) &&
        Objects.equals(this.selectedText, apitrpcaiGenerateJson.selectedText) &&
        Objects.equals(this.postMarkdown, apitrpcaiGenerateJson.postMarkdown) &&
        Objects.equals(this.frontMatter, apitrpcaiGenerateJson.frontMatter) &&
        Objects.equals(this.tone, apitrpcaiGenerateJson.tone) &&
        Objects.equals(this.voiceProfileId, apitrpcaiGenerateJson.voiceProfileId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(task, userPrompt, selectedText, postMarkdown, frontMatter, tone, voiceProfileId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiGenerateJson {\n");
    
    sb.append("    task: ").append(toIndentedString(task)).append("\n");
    sb.append("    userPrompt: ").append(toIndentedString(userPrompt)).append("\n");
    sb.append("    selectedText: ").append(toIndentedString(selectedText)).append("\n");
    sb.append("    postMarkdown: ").append(toIndentedString(postMarkdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    tone: ").append(toIndentedString(tone)).append("\n");
    sb.append("    voiceProfileId: ").append(toIndentedString(voiceProfileId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
