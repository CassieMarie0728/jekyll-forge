package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcabTestingUpdateMetricsJsonMetrics
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcabTestingUpdateMetricsJsonMetrics   {
  @JsonProperty("impressions")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal impressions = null;

  @JsonProperty("engagements")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal engagements = null;

  @JsonProperty("clicks")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal clicks = null;

  @JsonProperty("shares")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal shares = null;

  @JsonProperty("likes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal likes = null;

  @JsonProperty("replies")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal replies = null;


  public ApitrpcabTestingUpdateMetricsJsonMetrics impressions(BigDecimal impressions) { 

    this.impressions = impressions;
    return this;
  }

  /**
   * Get impressions
   * @return impressions
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getImpressions() {  
    return impressions;
  }



  public void setImpressions(BigDecimal impressions) { 
    this.impressions = impressions;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics engagements(BigDecimal engagements) { 

    this.engagements = engagements;
    return this;
  }

  /**
   * Get engagements
   * @return engagements
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getEngagements() {  
    return engagements;
  }



  public void setEngagements(BigDecimal engagements) { 
    this.engagements = engagements;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics clicks(BigDecimal clicks) { 

    this.clicks = clicks;
    return this;
  }

  /**
   * Get clicks
   * @return clicks
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getClicks() {  
    return clicks;
  }



  public void setClicks(BigDecimal clicks) { 
    this.clicks = clicks;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics shares(BigDecimal shares) { 

    this.shares = shares;
    return this;
  }

  /**
   * Get shares
   * @return shares
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getShares() {  
    return shares;
  }



  public void setShares(BigDecimal shares) { 
    this.shares = shares;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics likes(BigDecimal likes) { 

    this.likes = likes;
    return this;
  }

  /**
   * Get likes
   * @return likes
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getLikes() {  
    return likes;
  }



  public void setLikes(BigDecimal likes) { 
    this.likes = likes;
  }

  public ApitrpcabTestingUpdateMetricsJsonMetrics replies(BigDecimal replies) { 

    this.replies = replies;
    return this;
  }

  /**
   * Get replies
   * @return replies
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getReplies() {  
    return replies;
  }



  public void setReplies(BigDecimal replies) { 
    this.replies = replies;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJsonMetrics apitrpcabTestingUpdateMetricsJsonMetrics = (ApitrpcabTestingUpdateMetricsJsonMetrics) o;
    return Objects.equals(this.impressions, apitrpcabTestingUpdateMetricsJsonMetrics.impressions) &&
        Objects.equals(this.engagements, apitrpcabTestingUpdateMetricsJsonMetrics.engagements) &&
        Objects.equals(this.clicks, apitrpcabTestingUpdateMetricsJsonMetrics.clicks) &&
        Objects.equals(this.shares, apitrpcabTestingUpdateMetricsJsonMetrics.shares) &&
        Objects.equals(this.likes, apitrpcabTestingUpdateMetricsJsonMetrics.likes) &&
        Objects.equals(this.replies, apitrpcabTestingUpdateMetricsJsonMetrics.replies);
  }

  @Override
  public int hashCode() {
    return Objects.hash(impressions, engagements, clicks, shares, likes, replies);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJsonMetrics {\n");
    
    sb.append("    impressions: ").append(toIndentedString(impressions)).append("\n");
    sb.append("    engagements: ").append(toIndentedString(engagements)).append("\n");
    sb.append("    clicks: ").append(toIndentedString(clicks)).append("\n");
    sb.append("    shares: ").append(toIndentedString(shares)).append("\n");
    sb.append("    likes: ").append(toIndentedString(likes)).append("\n");
    sb.append("    replies: ").append(toIndentedString(replies)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
