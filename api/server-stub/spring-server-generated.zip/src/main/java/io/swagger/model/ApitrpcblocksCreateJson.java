package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcblocksCreateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcblocksCreateJson   {
  @JsonProperty("name")

  private String name = null;

  @JsonProperty("category")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String category = null;

  @JsonProperty("content")

  private String content = null;

  /**
   * Gets or Sets contentType
   */
  public enum ContentTypeEnum {
    MARKDOWN("markdown"),
    
    HTML("html"),
    
    LIQUID("liquid");

    private String value;

    ContentTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ContentTypeEnum fromValue(String text) {
      for (ContentTypeEnum b : ContentTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("contentType")

  private ContentTypeEnum contentType = null;


  public ApitrpcblocksCreateJson name(String name) { 

    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
@Size(min=1)   public String getName() {  
    return name;
  }



  public void setName(String name) { 

    this.name = name;
  }

  public ApitrpcblocksCreateJson category(String category) { 

    this.category = category;
    return this;
  }

  /**
   * Get category
   * @return category
   **/
  
  @Schema(description = "")
  
  public String getCategory() {  
    return category;
  }



  public void setCategory(String category) { 
    this.category = category;
  }

  public ApitrpcblocksCreateJson content(String content) { 

    this.content = content;
    return this;
  }

  /**
   * Get content
   * @return content
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
@Size(min=1)   public String getContent() {  
    return content;
  }



  public void setContent(String content) { 

    this.content = content;
  }

  public ApitrpcblocksCreateJson contentType(ContentTypeEnum contentType) { 

    this.contentType = contentType;
    return this;
  }

  /**
   * Get contentType
   * @return contentType
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public ContentTypeEnum getContentType() {  
    return contentType;
  }



  public void setContentType(ContentTypeEnum contentType) { 

    this.contentType = contentType;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcblocksCreateJson apitrpcblocksCreateJson = (ApitrpcblocksCreateJson) o;
    return Objects.equals(this.name, apitrpcblocksCreateJson.name) &&
        Objects.equals(this.category, apitrpcblocksCreateJson.category) &&
        Objects.equals(this.content, apitrpcblocksCreateJson.content) &&
        Objects.equals(this.contentType, apitrpcblocksCreateJson.contentType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, category, content, contentType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcblocksCreateJson {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
