package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcrepurposingGenerateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcrepurposingGenerateJson   {
  @JsonProperty("postId")

  private BigDecimal postId = null;

  @JsonProperty("siteId")

  private BigDecimal siteId = null;

  /**
   * Gets or Sets format
   */
  public enum FormatEnum {
    TWITTER("twitter"),
    
    LINKEDIN("linkedin"),
    
    TIKTOK("tiktok"),
    
    YOUTUBE("youtube"),
    
    NEWSLETTER("newsletter"),
    
    EMAIL("email"),
    
    PODCAST("podcast"),
    
    SLIDES("slides");

    private String value;

    FormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FormatEnum fromValue(String text) {
      for (FormatEnum b : FormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("format")

  private FormatEnum format = null;


  public ApitrpcrepurposingGenerateJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 

    this.postId = postId;
  }

  public ApitrpcrepurposingGenerateJson siteId(BigDecimal siteId) { 

    this.siteId = siteId;
    return this;
  }

  /**
   * Get siteId
   * @return siteId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSiteId() {  
    return siteId;
  }



  public void setSiteId(BigDecimal siteId) { 

    this.siteId = siteId;
  }

  public ApitrpcrepurposingGenerateJson format(FormatEnum format) { 

    this.format = format;
    return this;
  }

  /**
   * Get format
   * @return format
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public FormatEnum getFormat() {  
    return format;
  }



  public void setFormat(FormatEnum format) { 

    this.format = format;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingGenerateJson apitrpcrepurposingGenerateJson = (ApitrpcrepurposingGenerateJson) o;
    return Objects.equals(this.postId, apitrpcrepurposingGenerateJson.postId) &&
        Objects.equals(this.siteId, apitrpcrepurposingGenerateJson.siteId) &&
        Objects.equals(this.format, apitrpcrepurposingGenerateJson.format);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, siteId, format);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingGenerateJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
