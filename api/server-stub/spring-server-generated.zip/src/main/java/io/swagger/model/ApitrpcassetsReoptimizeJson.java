package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcassetsReoptimizeJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcassetsReoptimizeJson   {
  @JsonProperty("id")

  private BigDecimal id = null;

  @JsonProperty("maxWidth")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal maxWidth = null;

  /**
   * Gets or Sets outputFormat
   */
  public enum OutputFormatEnum {
    WEBP("webp"),
    
    JPEG("jpeg"),
    
    PNG("png");

    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OutputFormatEnum fromValue(String text) {
      for (OutputFormatEnum b : OutputFormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("outputFormat")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OutputFormatEnum outputFormat = null;

  @JsonProperty("quality")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal quality = null;


  public ApitrpcassetsReoptimizeJson id(BigDecimal id) { 

    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getId() {  
    return id;
  }



  public void setId(BigDecimal id) { 

    this.id = id;
  }

  public ApitrpcassetsReoptimizeJson maxWidth(BigDecimal maxWidth) { 

    this.maxWidth = maxWidth;
    return this;
  }

  /**
   * Get maxWidth
   * @return maxWidth
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getMaxWidth() {  
    return maxWidth;
  }



  public void setMaxWidth(BigDecimal maxWidth) { 
    this.maxWidth = maxWidth;
  }

  public ApitrpcassetsReoptimizeJson outputFormat(OutputFormatEnum outputFormat) { 

    this.outputFormat = outputFormat;
    return this;
  }

  /**
   * Get outputFormat
   * @return outputFormat
   **/
  
  @Schema(description = "")
  
  public OutputFormatEnum getOutputFormat() {  
    return outputFormat;
  }



  public void setOutputFormat(OutputFormatEnum outputFormat) { 
    this.outputFormat = outputFormat;
  }

  public ApitrpcassetsReoptimizeJson quality(BigDecimal quality) { 

    this.quality = quality;
    return this;
  }

  /**
   * Get quality
   * @return quality
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getQuality() {  
    return quality;
  }



  public void setQuality(BigDecimal quality) { 
    this.quality = quality;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsReoptimizeJson apitrpcassetsReoptimizeJson = (ApitrpcassetsReoptimizeJson) o;
    return Objects.equals(this.id, apitrpcassetsReoptimizeJson.id) &&
        Objects.equals(this.maxWidth, apitrpcassetsReoptimizeJson.maxWidth) &&
        Objects.equals(this.outputFormat, apitrpcassetsReoptimizeJson.outputFormat) &&
        Objects.equals(this.quality, apitrpcassetsReoptimizeJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsReoptimizeJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
