package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcsocialMediaSyncAnalyticsJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcsocialMediaSyncAnalyticsJson   {
  @JsonProperty("analyticsId")

  private BigDecimal analyticsId = null;


  public ApitrpcsocialMediaSyncAnalyticsJson analyticsId(BigDecimal analyticsId) { 

    this.analyticsId = analyticsId;
    return this;
  }

  /**
   * Get analyticsId
   * @return analyticsId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getAnalyticsId() {  
    return analyticsId;
  }



  public void setAnalyticsId(BigDecimal analyticsId) { 

    this.analyticsId = analyticsId;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSyncAnalyticsJson apitrpcsocialMediaSyncAnalyticsJson = (ApitrpcsocialMediaSyncAnalyticsJson) o;
    return Objects.equals(this.analyticsId, apitrpcsocialMediaSyncAnalyticsJson.analyticsId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(analyticsId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSyncAnalyticsJson {\n");
    
    sb.append("    analyticsId: ").append(toIndentedString(analyticsId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
