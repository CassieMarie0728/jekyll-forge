package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcsitesUpsertJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcsitesUpsertJson   {
  @JsonProperty("owner")

  private String owner = null;

  @JsonProperty("repo")

  private String repo = null;

  @JsonProperty("defaultBranch")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultBranch = null;

  @JsonProperty("selectedBranch")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String selectedBranch = null;

  @JsonProperty("rootPath")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String rootPath = null;

  @JsonProperty("isJekyll")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean isJekyll = null;

  @JsonProperty("isFavorite")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean isFavorite = null;

  @JsonProperty("timezone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String timezone = null;

  @JsonProperty("defaultLayout")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultLayout = null;

  @JsonProperty("defaultAssetPath")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultAssetPath = null;


  public ApitrpcsitesUpsertJson owner(String owner) { 

    this.owner = owner;
    return this;
  }

  /**
   * Get owner
   * @return owner
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getOwner() {  
    return owner;
  }



  public void setOwner(String owner) { 

    this.owner = owner;
  }

  public ApitrpcsitesUpsertJson repo(String repo) { 

    this.repo = repo;
    return this;
  }

  /**
   * Get repo
   * @return repo
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getRepo() {  
    return repo;
  }



  public void setRepo(String repo) { 

    this.repo = repo;
  }

  public ApitrpcsitesUpsertJson defaultBranch(String defaultBranch) { 

    this.defaultBranch = defaultBranch;
    return this;
  }

  /**
   * Get defaultBranch
   * @return defaultBranch
   **/
  
  @Schema(description = "")
  
  public String getDefaultBranch() {  
    return defaultBranch;
  }



  public void setDefaultBranch(String defaultBranch) { 
    this.defaultBranch = defaultBranch;
  }

  public ApitrpcsitesUpsertJson selectedBranch(String selectedBranch) { 

    this.selectedBranch = selectedBranch;
    return this;
  }

  /**
   * Get selectedBranch
   * @return selectedBranch
   **/
  
  @Schema(description = "")
  
  public String getSelectedBranch() {  
    return selectedBranch;
  }



  public void setSelectedBranch(String selectedBranch) { 
    this.selectedBranch = selectedBranch;
  }

  public ApitrpcsitesUpsertJson rootPath(String rootPath) { 

    this.rootPath = rootPath;
    return this;
  }

  /**
   * Get rootPath
   * @return rootPath
   **/
  
  @Schema(description = "")
  
  public String getRootPath() {  
    return rootPath;
  }



  public void setRootPath(String rootPath) { 
    this.rootPath = rootPath;
  }

  public ApitrpcsitesUpsertJson isJekyll(Boolean isJekyll) { 

    this.isJekyll = isJekyll;
    return this;
  }

  /**
   * Get isJekyll
   * @return isJekyll
   **/
  
  @Schema(description = "")
  
  public Boolean isIsJekyll() {  
    return isJekyll;
  }



  public void setIsJekyll(Boolean isJekyll) { 
    this.isJekyll = isJekyll;
  }

  public ApitrpcsitesUpsertJson isFavorite(Boolean isFavorite) { 

    this.isFavorite = isFavorite;
    return this;
  }

  /**
   * Get isFavorite
   * @return isFavorite
   **/
  
  @Schema(description = "")
  
  public Boolean isIsFavorite() {  
    return isFavorite;
  }



  public void setIsFavorite(Boolean isFavorite) { 
    this.isFavorite = isFavorite;
  }

  public ApitrpcsitesUpsertJson timezone(String timezone) { 

    this.timezone = timezone;
    return this;
  }

  /**
   * Get timezone
   * @return timezone
   **/
  
  @Schema(description = "")
  
  public String getTimezone() {  
    return timezone;
  }



  public void setTimezone(String timezone) { 
    this.timezone = timezone;
  }

  public ApitrpcsitesUpsertJson defaultLayout(String defaultLayout) { 

    this.defaultLayout = defaultLayout;
    return this;
  }

  /**
   * Get defaultLayout
   * @return defaultLayout
   **/
  
  @Schema(description = "")
  
  public String getDefaultLayout() {  
    return defaultLayout;
  }



  public void setDefaultLayout(String defaultLayout) { 
    this.defaultLayout = defaultLayout;
  }

  public ApitrpcsitesUpsertJson defaultAssetPath(String defaultAssetPath) { 

    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

  /**
   * Get defaultAssetPath
   * @return defaultAssetPath
   **/
  
  @Schema(description = "")
  
  public String getDefaultAssetPath() {  
    return defaultAssetPath;
  }



  public void setDefaultAssetPath(String defaultAssetPath) { 
    this.defaultAssetPath = defaultAssetPath;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpsertJson apitrpcsitesUpsertJson = (ApitrpcsitesUpsertJson) o;
    return Objects.equals(this.owner, apitrpcsitesUpsertJson.owner) &&
        Objects.equals(this.repo, apitrpcsitesUpsertJson.repo) &&
        Objects.equals(this.defaultBranch, apitrpcsitesUpsertJson.defaultBranch) &&
        Objects.equals(this.selectedBranch, apitrpcsitesUpsertJson.selectedBranch) &&
        Objects.equals(this.rootPath, apitrpcsitesUpsertJson.rootPath) &&
        Objects.equals(this.isJekyll, apitrpcsitesUpsertJson.isJekyll) &&
        Objects.equals(this.isFavorite, apitrpcsitesUpsertJson.isFavorite) &&
        Objects.equals(this.timezone, apitrpcsitesUpsertJson.timezone) &&
        Objects.equals(this.defaultLayout, apitrpcsitesUpsertJson.defaultLayout) &&
        Objects.equals(this.defaultAssetPath, apitrpcsitesUpsertJson.defaultAssetPath);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, defaultBranch, selectedBranch, rootPath, isJekyll, isFavorite, timezone, defaultLayout, defaultAssetPath);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpsertJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    defaultBranch: ").append(toIndentedString(defaultBranch)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    isJekyll: ").append(toIndentedString(isJekyll)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
