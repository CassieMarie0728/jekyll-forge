package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcgithubCreateBranchJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcgithubCreateBranchJson   {
  @JsonProperty("owner")

  private String owner = null;

  @JsonProperty("repo")

  private String repo = null;

  @JsonProperty("branchName")

  private String branchName = null;

  @JsonProperty("fromBranch")

  private String fromBranch = null;


  public ApitrpcgithubCreateBranchJson owner(String owner) { 

    this.owner = owner;
    return this;
  }

  /**
   * Get owner
   * @return owner
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getOwner() {  
    return owner;
  }



  public void setOwner(String owner) { 

    this.owner = owner;
  }

  public ApitrpcgithubCreateBranchJson repo(String repo) { 

    this.repo = repo;
    return this;
  }

  /**
   * Get repo
   * @return repo
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getRepo() {  
    return repo;
  }



  public void setRepo(String repo) { 

    this.repo = repo;
  }

  public ApitrpcgithubCreateBranchJson branchName(String branchName) { 

    this.branchName = branchName;
    return this;
  }

  /**
   * Get branchName
   * @return branchName
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getBranchName() {  
    return branchName;
  }



  public void setBranchName(String branchName) { 

    this.branchName = branchName;
  }

  public ApitrpcgithubCreateBranchJson fromBranch(String fromBranch) { 

    this.fromBranch = fromBranch;
    return this;
  }

  /**
   * Get fromBranch
   * @return fromBranch
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getFromBranch() {  
    return fromBranch;
  }



  public void setFromBranch(String fromBranch) { 

    this.fromBranch = fromBranch;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCreateBranchJson apitrpcgithubCreateBranchJson = (ApitrpcgithubCreateBranchJson) o;
    return Objects.equals(this.owner, apitrpcgithubCreateBranchJson.owner) &&
        Objects.equals(this.repo, apitrpcgithubCreateBranchJson.repo) &&
        Objects.equals(this.branchName, apitrpcgithubCreateBranchJson.branchName) &&
        Objects.equals(this.fromBranch, apitrpcgithubCreateBranchJson.fromBranch);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, branchName, fromBranch);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreateBranchJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    branchName: ").append(toIndentedString(branchName)).append("\n");
    sb.append("    fromBranch: ").append(toIndentedString(fromBranch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
