package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcgithubCreatePullRequestJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcgithubCreatePullRequestJson   {
  @JsonProperty("owner")

  private String owner = null;

  @JsonProperty("repo")

  private String repo = null;

  @JsonProperty("title")

  private String title = null;

  @JsonProperty("head")

  private String head = null;

  @JsonProperty("base")

  private String base = null;

  @JsonProperty("body")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String body = null;


  public ApitrpcgithubCreatePullRequestJson owner(String owner) { 

    this.owner = owner;
    return this;
  }

  /**
   * Get owner
   * @return owner
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getOwner() {  
    return owner;
  }



  public void setOwner(String owner) { 

    this.owner = owner;
  }

  public ApitrpcgithubCreatePullRequestJson repo(String repo) { 

    this.repo = repo;
    return this;
  }

  /**
   * Get repo
   * @return repo
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getRepo() {  
    return repo;
  }



  public void setRepo(String repo) { 

    this.repo = repo;
  }

  public ApitrpcgithubCreatePullRequestJson title(String title) { 

    this.title = title;
    return this;
  }

  /**
   * Get title
   * @return title
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getTitle() {  
    return title;
  }



  public void setTitle(String title) { 

    this.title = title;
  }

  public ApitrpcgithubCreatePullRequestJson head(String head) { 

    this.head = head;
    return this;
  }

  /**
   * Get head
   * @return head
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getHead() {  
    return head;
  }



  public void setHead(String head) { 

    this.head = head;
  }

  public ApitrpcgithubCreatePullRequestJson base(String base) { 

    this.base = base;
    return this;
  }

  /**
   * Get base
   * @return base
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getBase() {  
    return base;
  }



  public void setBase(String base) { 

    this.base = base;
  }

  public ApitrpcgithubCreatePullRequestJson body(String body) { 

    this.body = body;
    return this;
  }

  /**
   * Get body
   * @return body
   **/
  
  @Schema(description = "")
  
  public String getBody() {  
    return body;
  }



  public void setBody(String body) { 
    this.body = body;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCreatePullRequestJson apitrpcgithubCreatePullRequestJson = (ApitrpcgithubCreatePullRequestJson) o;
    return Objects.equals(this.owner, apitrpcgithubCreatePullRequestJson.owner) &&
        Objects.equals(this.repo, apitrpcgithubCreatePullRequestJson.repo) &&
        Objects.equals(this.title, apitrpcgithubCreatePullRequestJson.title) &&
        Objects.equals(this.head, apitrpcgithubCreatePullRequestJson.head) &&
        Objects.equals(this.base, apitrpcgithubCreatePullRequestJson.base) &&
        Objects.equals(this.body, apitrpcgithubCreatePullRequestJson.body);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, title, head, base, body);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreatePullRequestJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    head: ").append(toIndentedString(head)).append("\n");
    sb.append("    base: ").append(toIndentedString(base)).append("\n");
    sb.append("    body: ").append(toIndentedString(body)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
