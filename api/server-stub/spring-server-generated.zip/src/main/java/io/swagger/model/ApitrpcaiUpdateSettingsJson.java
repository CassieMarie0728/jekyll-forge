package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcaiUpdateSettingsJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcaiUpdateSettingsJson   {
  @JsonProperty("enabled")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean enabled = null;

  @JsonProperty("temperature")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal temperature = null;

  @JsonProperty("maxTokens")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal maxTokens = null;

  @JsonProperty("systemPrompt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String systemPrompt = null;

  @JsonProperty("brandVoicePrompt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String brandVoicePrompt = null;

  @JsonProperty("safetyPrompt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String safetyPrompt = null;

  @JsonProperty("streaming")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean streaming = null;

  @JsonProperty("defaultLanguage")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultLanguage = null;

  @JsonProperty("defaultTone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultTone = null;

  @JsonProperty("budgetLimitCents")

  private BigDecimal budgetLimitCents = null;


  public ApitrpcaiUpdateSettingsJson enabled(Boolean enabled) { 

    this.enabled = enabled;
    return this;
  }

  /**
   * Get enabled
   * @return enabled
   **/
  
  @Schema(description = "")
  
  public Boolean isEnabled() {  
    return enabled;
  }



  public void setEnabled(Boolean enabled) { 
    this.enabled = enabled;
  }

  public ApitrpcaiUpdateSettingsJson temperature(BigDecimal temperature) { 

    this.temperature = temperature;
    return this;
  }

  /**
   * Get temperature
   * @return temperature
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getTemperature() {  
    return temperature;
  }



  public void setTemperature(BigDecimal temperature) { 
    this.temperature = temperature;
  }

  public ApitrpcaiUpdateSettingsJson maxTokens(BigDecimal maxTokens) { 

    this.maxTokens = maxTokens;
    return this;
  }

  /**
   * Get maxTokens
   * @return maxTokens
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getMaxTokens() {  
    return maxTokens;
  }



  public void setMaxTokens(BigDecimal maxTokens) { 
    this.maxTokens = maxTokens;
  }

  public ApitrpcaiUpdateSettingsJson systemPrompt(String systemPrompt) { 

    this.systemPrompt = systemPrompt;
    return this;
  }

  /**
   * Get systemPrompt
   * @return systemPrompt
   **/
  
  @Schema(description = "")
  
  public String getSystemPrompt() {  
    return systemPrompt;
  }



  public void setSystemPrompt(String systemPrompt) { 
    this.systemPrompt = systemPrompt;
  }

  public ApitrpcaiUpdateSettingsJson brandVoicePrompt(String brandVoicePrompt) { 

    this.brandVoicePrompt = brandVoicePrompt;
    return this;
  }

  /**
   * Get brandVoicePrompt
   * @return brandVoicePrompt
   **/
  
  @Schema(description = "")
  
  public String getBrandVoicePrompt() {  
    return brandVoicePrompt;
  }



  public void setBrandVoicePrompt(String brandVoicePrompt) { 
    this.brandVoicePrompt = brandVoicePrompt;
  }

  public ApitrpcaiUpdateSettingsJson safetyPrompt(String safetyPrompt) { 

    this.safetyPrompt = safetyPrompt;
    return this;
  }

  /**
   * Get safetyPrompt
   * @return safetyPrompt
   **/
  
  @Schema(description = "")
  
  public String getSafetyPrompt() {  
    return safetyPrompt;
  }



  public void setSafetyPrompt(String safetyPrompt) { 
    this.safetyPrompt = safetyPrompt;
  }

  public ApitrpcaiUpdateSettingsJson streaming(Boolean streaming) { 

    this.streaming = streaming;
    return this;
  }

  /**
   * Get streaming
   * @return streaming
   **/
  
  @Schema(description = "")
  
  public Boolean isStreaming() {  
    return streaming;
  }



  public void setStreaming(Boolean streaming) { 
    this.streaming = streaming;
  }

  public ApitrpcaiUpdateSettingsJson defaultLanguage(String defaultLanguage) { 

    this.defaultLanguage = defaultLanguage;
    return this;
  }

  /**
   * Get defaultLanguage
   * @return defaultLanguage
   **/
  
  @Schema(description = "")
  
  public String getDefaultLanguage() {  
    return defaultLanguage;
  }



  public void setDefaultLanguage(String defaultLanguage) { 
    this.defaultLanguage = defaultLanguage;
  }

  public ApitrpcaiUpdateSettingsJson defaultTone(String defaultTone) { 

    this.defaultTone = defaultTone;
    return this;
  }

  /**
   * Get defaultTone
   * @return defaultTone
   **/
  
  @Schema(description = "")
  
  public String getDefaultTone() {  
    return defaultTone;
  }



  public void setDefaultTone(String defaultTone) { 
    this.defaultTone = defaultTone;
  }

  public ApitrpcaiUpdateSettingsJson budgetLimitCents(BigDecimal budgetLimitCents) { 

    this.budgetLimitCents = budgetLimitCents;
    return this;
  }

  /**
   * Get budgetLimitCents
   * @return budgetLimitCents
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getBudgetLimitCents() {
 
    return budgetLimitCents;
  }



  public void setBudgetLimitCents(BigDecimal budgetLimitCents) { 
    this.budgetLimitCents = budgetLimitCents;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiUpdateSettingsJson apitrpcaiUpdateSettingsJson = (ApitrpcaiUpdateSettingsJson) o;
    return Objects.equals(this.enabled, apitrpcaiUpdateSettingsJson.enabled) &&
        Objects.equals(this.temperature, apitrpcaiUpdateSettingsJson.temperature) &&
        Objects.equals(this.maxTokens, apitrpcaiUpdateSettingsJson.maxTokens) &&
        Objects.equals(this.systemPrompt, apitrpcaiUpdateSettingsJson.systemPrompt) &&
        Objects.equals(this.brandVoicePrompt, apitrpcaiUpdateSettingsJson.brandVoicePrompt) &&
        Objects.equals(this.safetyPrompt, apitrpcaiUpdateSettingsJson.safetyPrompt) &&
        Objects.equals(this.streaming, apitrpcaiUpdateSettingsJson.streaming) &&
        Objects.equals(this.defaultLanguage, apitrpcaiUpdateSettingsJson.defaultLanguage) &&
        Objects.equals(this.defaultTone, apitrpcaiUpdateSettingsJson.defaultTone) &&
        Objects.equals(this.budgetLimitCents, apitrpcaiUpdateSettingsJson.budgetLimitCents);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enabled, temperature, maxTokens, systemPrompt, brandVoicePrompt, safetyPrompt, streaming, defaultLanguage, defaultTone, budgetLimitCents);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiUpdateSettingsJson {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    temperature: ").append(toIndentedString(temperature)).append("\n");
    sb.append("    maxTokens: ").append(toIndentedString(maxTokens)).append("\n");
    sb.append("    systemPrompt: ").append(toIndentedString(systemPrompt)).append("\n");
    sb.append("    brandVoicePrompt: ").append(toIndentedString(brandVoicePrompt)).append("\n");
    sb.append("    safetyPrompt: ").append(toIndentedString(safetyPrompt)).append("\n");
    sb.append("    streaming: ").append(toIndentedString(streaming)).append("\n");
    sb.append("    defaultLanguage: ").append(toIndentedString(defaultLanguage)).append("\n");
    sb.append("    defaultTone: ").append(toIndentedString(defaultTone)).append("\n");
    sb.append("    budgetLimitCents: ").append(toIndentedString(budgetLimitCents)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
