package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcschedulerScheduleJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcschedulerScheduleJson   {
  @JsonProperty("siteId")

  private BigDecimal siteId = null;

  @JsonProperty("postId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal postId = null;

  @JsonProperty("draftPath")

  private String draftPath = null;

  @JsonProperty("targetPath")

  private String targetPath = null;

  @JsonProperty("scheduledAt")

  private Object scheduledAt = null;

  @JsonProperty("timezone")

  private String timezone = null;

  @JsonProperty("commitMessage")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String commitMessage = null;


  public ApitrpcschedulerScheduleJson siteId(BigDecimal siteId) { 

    this.siteId = siteId;
    return this;
  }

  /**
   * Get siteId
   * @return siteId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSiteId() {  
    return siteId;
  }



  public void setSiteId(BigDecimal siteId) { 

    this.siteId = siteId;
  }

  public ApitrpcschedulerScheduleJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 
    this.postId = postId;
  }

  public ApitrpcschedulerScheduleJson draftPath(String draftPath) { 

    this.draftPath = draftPath;
    return this;
  }

  /**
   * Get draftPath
   * @return draftPath
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getDraftPath() {  
    return draftPath;
  }



  public void setDraftPath(String draftPath) { 

    this.draftPath = draftPath;
  }

  public ApitrpcschedulerScheduleJson targetPath(String targetPath) { 

    this.targetPath = targetPath;
    return this;
  }

  /**
   * Get targetPath
   * @return targetPath
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getTargetPath() {  
    return targetPath;
  }



  public void setTargetPath(String targetPath) { 

    this.targetPath = targetPath;
  }

  public ApitrpcschedulerScheduleJson scheduledAt(Object scheduledAt) { 

    this.scheduledAt = scheduledAt;
    return this;
  }

  /**
   * Get scheduledAt
   * @return scheduledAt
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public Object getScheduledAt() {  
    return scheduledAt;
  }



  public void setScheduledAt(Object scheduledAt) { 

    this.scheduledAt = scheduledAt;
  }

  public ApitrpcschedulerScheduleJson timezone(String timezone) { 

    this.timezone = timezone;
    return this;
  }

  /**
   * Get timezone
   * @return timezone
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getTimezone() {  
    return timezone;
  }



  public void setTimezone(String timezone) { 

    this.timezone = timezone;
  }

  public ApitrpcschedulerScheduleJson commitMessage(String commitMessage) { 

    this.commitMessage = commitMessage;
    return this;
  }

  /**
   * Get commitMessage
   * @return commitMessage
   **/
  
  @Schema(description = "")
  
  public String getCommitMessage() {  
    return commitMessage;
  }



  public void setCommitMessage(String commitMessage) { 
    this.commitMessage = commitMessage;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcschedulerScheduleJson apitrpcschedulerScheduleJson = (ApitrpcschedulerScheduleJson) o;
    return Objects.equals(this.siteId, apitrpcschedulerScheduleJson.siteId) &&
        Objects.equals(this.postId, apitrpcschedulerScheduleJson.postId) &&
        Objects.equals(this.draftPath, apitrpcschedulerScheduleJson.draftPath) &&
        Objects.equals(this.targetPath, apitrpcschedulerScheduleJson.targetPath) &&
        Objects.equals(this.scheduledAt, apitrpcschedulerScheduleJson.scheduledAt) &&
        Objects.equals(this.timezone, apitrpcschedulerScheduleJson.timezone) &&
        Objects.equals(this.commitMessage, apitrpcschedulerScheduleJson.commitMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, draftPath, targetPath, scheduledAt, timezone, commitMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcschedulerScheduleJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    draftPath: ").append(toIndentedString(draftPath)).append("\n");
    sb.append("    targetPath: ").append(toIndentedString(targetPath)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
