package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcabTestingGenerateVariationsJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcabTestingGenerateVariationsJson   {
  @JsonProperty("postId")

  private BigDecimal postId = null;

  @JsonProperty("count")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal count = null;

  @JsonProperty("tones")
  @Valid
  private List<String> tones = null;
  @JsonProperty("angles")
  @Valid
  private List<String> angles = null;
  @JsonProperty("headline")

  private String headline = null;

  @JsonProperty("content")

  private String content = null;


  public ApitrpcabTestingGenerateVariationsJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 

    this.postId = postId;
  }

  public ApitrpcabTestingGenerateVariationsJson count(BigDecimal count) { 

    this.count = count;
    return this;
  }

  /**
   * Get count
   * @return count
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getCount() {  
    return count;
  }



  public void setCount(BigDecimal count) { 
    this.count = count;
  }

  public ApitrpcabTestingGenerateVariationsJson tones(List<String> tones) { 

    this.tones = tones;
    return this;
  }

  public ApitrpcabTestingGenerateVariationsJson addTonesItem(String tonesItem) {
    if (this.tones == null) {
      this.tones = new ArrayList<String>();
    }
    this.tones.add(tonesItem);
    return this;
  }

  /**
   * Get tones
   * @return tones
   **/
  
  @Schema(description = "")
  
  public List<String> getTones() {  
    return tones;
  }



  public void setTones(List<String> tones) { 
    this.tones = tones;
  }

  public ApitrpcabTestingGenerateVariationsJson angles(List<String> angles) { 

    this.angles = angles;
    return this;
  }

  public ApitrpcabTestingGenerateVariationsJson addAnglesItem(String anglesItem) {
    if (this.angles == null) {
      this.angles = new ArrayList<String>();
    }
    this.angles.add(anglesItem);
    return this;
  }

  /**
   * Get angles
   * @return angles
   **/
  
  @Schema(description = "")
  
  public List<String> getAngles() {  
    return angles;
  }



  public void setAngles(List<String> angles) { 
    this.angles = angles;
  }

  public ApitrpcabTestingGenerateVariationsJson headline(String headline) { 

    this.headline = headline;
    return this;
  }

  /**
   * Get headline
   * @return headline
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getHeadline() {  
    return headline;
  }



  public void setHeadline(String headline) { 

    this.headline = headline;
  }

  public ApitrpcabTestingGenerateVariationsJson content(String content) { 

    this.content = content;
    return this;
  }

  /**
   * Get content
   * @return content
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getContent() {  
    return content;
  }



  public void setContent(String content) { 

    this.content = content;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingGenerateVariationsJson apitrpcabTestingGenerateVariationsJson = (ApitrpcabTestingGenerateVariationsJson) o;
    return Objects.equals(this.postId, apitrpcabTestingGenerateVariationsJson.postId) &&
        Objects.equals(this.count, apitrpcabTestingGenerateVariationsJson.count) &&
        Objects.equals(this.tones, apitrpcabTestingGenerateVariationsJson.tones) &&
        Objects.equals(this.angles, apitrpcabTestingGenerateVariationsJson.angles) &&
        Objects.equals(this.headline, apitrpcabTestingGenerateVariationsJson.headline) &&
        Objects.equals(this.content, apitrpcabTestingGenerateVariationsJson.content);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, count, tones, angles, headline, content);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingGenerateVariationsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    tones: ").append(toIndentedString(tones)).append("\n");
    sb.append("    angles: ").append(toIndentedString(angles)).append("\n");
    sb.append("    headline: ").append(toIndentedString(headline)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
