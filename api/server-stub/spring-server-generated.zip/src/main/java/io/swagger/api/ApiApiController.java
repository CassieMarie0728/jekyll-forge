package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;
import io.swagger.model.TrpcAiGenerateBody;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;
import io.swagger.model.TrpcAiUpdateSettingsBody;
import io.swagger.model.TrpcAssetsDeleteBody;
import io.swagger.model.TrpcAssetsGenerateAltTextBody;
import io.swagger.model.TrpcAssetsReoptimizeBody;
import io.swagger.model.TrpcAssetsUpdateBody;
import io.swagger.model.TrpcAssetsUploadBody;
import io.swagger.model.TrpcBlocksCreateBody;
import io.swagger.model.TrpcBlocksDeleteBody;
import io.swagger.model.TrpcBlocksUpdateBody;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;
import io.swagger.model.TrpcNotificationsRegisterDeviceBody;
import io.swagger.model.TrpcNotificationsUnregisterDeviceBody;
import io.swagger.model.TrpcPostsAutosaveBody;
import io.swagger.model.TrpcPostsDeleteBody;
import io.swagger.model.TrpcPostsUpdateBody;
import io.swagger.model.TrpcPostsUpsertBody;
import io.swagger.model.TrpcRepurposingDeleteBody;
import io.swagger.model.TrpcRepurposingGenerateBody;
import io.swagger.model.TrpcRepurposingRegenerateBody;
import io.swagger.model.TrpcRepurposingUpdateBody;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;
import io.swagger.model.TrpcSitesDeleteBody;
import io.swagger.model.TrpcSitesUpdateBody;
import io.swagger.model.TrpcSitesUpsertBody;
import io.swagger.model.TrpcSnapshotsCreateBody;
import io.swagger.model.TrpcSocialMediaCancelScheduledPostBody;
import io.swagger.model.TrpcSocialMediaConnectAccountBody;
import io.swagger.model.TrpcSocialMediaDisconnectAccountBody;
import io.swagger.model.TrpcSocialMediaPublishContentBody;
import io.swagger.model.TrpcSocialMediaReschedulePostBody;
import io.swagger.model.TrpcSocialMediaSchedulePostBody;
import io.swagger.model.TrpcSocialMediaSyncAnalyticsBody;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")
@RestController
public class ApiApiController implements ApiApi {

    private static final Logger log = LoggerFactory.getLogger(ApiApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public ApiApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<TRPCResponse> abTestingApplyWinner(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAbTestingApplyWinnerBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> abTestingCompleteTest(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAbTestingCompleteTestBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> abTestingGenerateVariations(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAbTestingGenerateVariationsBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> abTestingGetResults(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> abTestingGetVariations(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> abTestingPublishVariation(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAbTestingPublishVariationBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> abTestingUpdateMetrics(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAbTestingUpdateMetricsBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiGenerate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAiGenerateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiGetSettings() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiGetUsageStats() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiProvidersActivate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAiProvidersActivateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiProvidersGetSettings() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiProvidersRemove(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAiProvidersRemoveBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiProvidersSave(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAiProvidersSaveBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiProvidersTest(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAiProvidersTestBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> aiUpdateSettings(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAiUpdateSettingsBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> assetsDelete(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAssetsDeleteBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> assetsGenerateAltText(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAssetsGenerateAltTextBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> assetsList(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> assetsReoptimize(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAssetsReoptimizeBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> assetsUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAssetsUpdateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> assetsUpload(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcAssetsUploadBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> blocksCreate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcBlocksCreateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> blocksDelete(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcBlocksDeleteBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> blocksList() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> blocksUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcBlocksUpdateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubCheckPluginCompatibility(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubCommitFile(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubCommitFileBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubConnect(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubConnectBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubCreateBranch(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubCreateBranchBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubCreatePullRequest(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubCreatePullRequestBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubDeleteFile(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubDeleteFileBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubDetectJekyll(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubDisconnect(@Parameter(in = ParameterIn.DEFAULT, description = "", schema=@Schema()) @Valid @RequestBody TrpcGithubDisconnectBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubGenerateActionsWorkflow(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubGenerateActionsWorkflowBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubGetFile(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubGetJekyllConfig(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubGetPagesStatus(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubGetRateLimit() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubInventory(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubListBranches(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubListFiles(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubListRepos(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubRepositories(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubReviewFile(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubStatus() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> githubUpdateJekyllConfig(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcGithubUpdateJekyllConfigBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> notificationsRegisterDevice(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcNotificationsRegisterDeviceBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> notificationsUnregisterDevice(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcNotificationsUnregisterDeviceBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsAutosave(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcPostsAutosaveBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsDelete(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcPostsDeleteBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsGet(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsGetFrontMatterTemplates(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsList(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcPostsUpdateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> postsUpsert(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcPostsUpsertBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> repurposingDelete(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcRepurposingDeleteBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> repurposingGenerate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcRepurposingGenerateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> repurposingGetById(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> repurposingGetByPost(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> repurposingRegenerate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcRepurposingRegenerateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> repurposingUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcRepurposingUpdateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerCancel(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSchedulerCancelBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerCancelAll(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSchedulerCancelAllBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerList(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerListHeartbeatJobs(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerMarkFailed(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSchedulerMarkFailedBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerMarkPublished(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSchedulerMarkPublishedBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerReschedule(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSchedulerRescheduleBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> schedulerSchedule(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSchedulerScheduleBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> sitesDelete(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSitesDeleteBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> sitesGet(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> sitesList() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> sitesUpdate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSitesUpdateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> sitesUpsert(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSitesUpsertBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> snapshotsCreate(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSnapshotsCreateBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> snapshotsGet(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> snapshotsListByPost(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaCancelScheduledPost(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaCancelScheduledPostBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaConnectAccount(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaConnectAccountBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaDisconnectAccount(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaDisconnectAccountBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaGetAccountDetails(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaGetAccounts() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaGetAnalyticsByPlatform(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaGetAnalyticsSummary() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaGetContentAnalytics(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaGetScheduledPosts(@NotNull @Parameter(in = ParameterIn.QUERY, description = "URL-encoded tRPC input envelope, e.g. {\"json\":{...}}" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "input", required = true) String input
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaPublishContent(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaPublishContentBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaReschedulePost(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaReschedulePostBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaSchedulePost(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaSchedulePostBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<TRPCResponse> socialMediaSyncAnalytics(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody TrpcSocialMediaSyncAnalyticsBody body
) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<TRPCResponse>(objectMapper.readValue("\"\"", TRPCResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<TRPCResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<TRPCResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
