package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcpostsAutosaveJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcpostsAutosaveJson   {
  @JsonProperty("id")

  private BigDecimal id = null;

  @JsonProperty("markdown")

  private String markdown = null;

  @JsonProperty("frontMatter")

  private Object frontMatter = null;


  public ApitrpcpostsAutosaveJson id(BigDecimal id) { 

    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getId() {  
    return id;
  }



  public void setId(BigDecimal id) { 

    this.id = id;
  }

  public ApitrpcpostsAutosaveJson markdown(String markdown) { 

    this.markdown = markdown;
    return this;
  }

  /**
   * Get markdown
   * @return markdown
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getMarkdown() {  
    return markdown;
  }



  public void setMarkdown(String markdown) { 

    this.markdown = markdown;
  }

  public ApitrpcpostsAutosaveJson frontMatter(Object frontMatter) { 

    this.frontMatter = frontMatter;
    return this;
  }

  /**
   * Get frontMatter
   * @return frontMatter
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public Object getFrontMatter() {  
    return frontMatter;
  }



  public void setFrontMatter(Object frontMatter) { 

    this.frontMatter = frontMatter;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsAutosaveJson apitrpcpostsAutosaveJson = (ApitrpcpostsAutosaveJson) o;
    return Objects.equals(this.id, apitrpcpostsAutosaveJson.id) &&
        Objects.equals(this.markdown, apitrpcpostsAutosaveJson.markdown) &&
        Objects.equals(this.frontMatter, apitrpcpostsAutosaveJson.frontMatter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, markdown, frontMatter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsAutosaveJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
