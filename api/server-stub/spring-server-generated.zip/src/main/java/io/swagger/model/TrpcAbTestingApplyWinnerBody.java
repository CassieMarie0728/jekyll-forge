package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ApitrpcabTestingApplyWinnerJson;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TrpcAbTestingApplyWinnerBody
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class TrpcAbTestingApplyWinnerBody   {
  @JsonProperty("json")

  private ApitrpcabTestingApplyWinnerJson json = null;


  public TrpcAbTestingApplyWinnerBody json(ApitrpcabTestingApplyWinnerJson json) { 

    this.json = json;
    return this;
  }

  /**
   * Get json
   * @return json
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public ApitrpcabTestingApplyWinnerJson getJson() {  
    return json;
  }



  public void setJson(ApitrpcabTestingApplyWinnerJson json) { 

    this.json = json;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrpcAbTestingApplyWinnerBody trpcAbTestingApplyWinnerBody = (TrpcAbTestingApplyWinnerBody) o;
    return Objects.equals(this.json, trpcAbTestingApplyWinnerBody.json);
  }

  @Override
  public int hashCode() {
    return Objects.hash(json);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcAbTestingApplyWinnerBody {\n");
    
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
