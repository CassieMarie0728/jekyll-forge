package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcrepurposingRegenerateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcrepurposingRegenerateJson   {
  @JsonProperty("id")

  private BigDecimal id = null;

  @JsonProperty("postId")

  private BigDecimal postId = null;

  @JsonProperty("siteId")

  private BigDecimal siteId = null;


  public ApitrpcrepurposingRegenerateJson id(BigDecimal id) { 

    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getId() {  
    return id;
  }



  public void setId(BigDecimal id) { 

    this.id = id;
  }

  public ApitrpcrepurposingRegenerateJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 

    this.postId = postId;
  }

  public ApitrpcrepurposingRegenerateJson siteId(BigDecimal siteId) { 

    this.siteId = siteId;
    return this;
  }

  /**
   * Get siteId
   * @return siteId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSiteId() {  
    return siteId;
  }



  public void setSiteId(BigDecimal siteId) { 

    this.siteId = siteId;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingRegenerateJson apitrpcrepurposingRegenerateJson = (ApitrpcrepurposingRegenerateJson) o;
    return Objects.equals(this.id, apitrpcrepurposingRegenerateJson.id) &&
        Objects.equals(this.postId, apitrpcrepurposingRegenerateJson.postId) &&
        Objects.equals(this.siteId, apitrpcrepurposingRegenerateJson.siteId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, postId, siteId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingRegenerateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
