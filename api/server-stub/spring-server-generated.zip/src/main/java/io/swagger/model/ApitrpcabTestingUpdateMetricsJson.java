package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ApitrpcabTestingUpdateMetricsJsonMetrics;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcabTestingUpdateMetricsJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcabTestingUpdateMetricsJson   {
  @JsonProperty("postId")

  private BigDecimal postId = null;

  @JsonProperty("variationIndex")

  private BigDecimal variationIndex = null;

  @JsonProperty("platform")

  private String platform = null;

  @JsonProperty("metrics")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private ApitrpcabTestingUpdateMetricsJsonMetrics metrics = null;


  public ApitrpcabTestingUpdateMetricsJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 

    this.postId = postId;
  }

  public ApitrpcabTestingUpdateMetricsJson variationIndex(BigDecimal variationIndex) { 

    this.variationIndex = variationIndex;
    return this;
  }

  /**
   * Get variationIndex
   * @return variationIndex
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getVariationIndex() {  
    return variationIndex;
  }



  public void setVariationIndex(BigDecimal variationIndex) { 

    this.variationIndex = variationIndex;
  }

  public ApitrpcabTestingUpdateMetricsJson platform(String platform) { 

    this.platform = platform;
    return this;
  }

  /**
   * Get platform
   * @return platform
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getPlatform() {  
    return platform;
  }



  public void setPlatform(String platform) { 

    this.platform = platform;
  }

  public ApitrpcabTestingUpdateMetricsJson metrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) { 

    this.metrics = metrics;
    return this;
  }

  /**
   * Get metrics
   * @return metrics
   **/
  
  @Schema(description = "")
  
@Valid
  public ApitrpcabTestingUpdateMetricsJsonMetrics getMetrics() {  
    return metrics;
  }



  public void setMetrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) { 
    this.metrics = metrics;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJson apitrpcabTestingUpdateMetricsJson = (ApitrpcabTestingUpdateMetricsJson) o;
    return Objects.equals(this.postId, apitrpcabTestingUpdateMetricsJson.postId) &&
        Objects.equals(this.variationIndex, apitrpcabTestingUpdateMetricsJson.variationIndex) &&
        Objects.equals(this.platform, apitrpcabTestingUpdateMetricsJson.platform) &&
        Objects.equals(this.metrics, apitrpcabTestingUpdateMetricsJson.metrics);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, variationIndex, platform, metrics);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    metrics: ").append(toIndentedString(metrics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
