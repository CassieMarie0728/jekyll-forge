package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcaiProvidersSaveJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcaiProvidersSaveJson   {
  @JsonProperty("provider")

  private Object provider = null;

  @JsonProperty("model")

  private String model = null;

  @JsonProperty("apiKey")

  private String apiKey = null;


  public ApitrpcaiProvidersSaveJson provider(Object provider) { 

    this.provider = provider;
    return this;
  }

  /**
   * Get provider
   * @return provider
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public Object getProvider() {  
    return provider;
  }



  public void setProvider(Object provider) { 

    this.provider = provider;
  }

  public ApitrpcaiProvidersSaveJson model(String model) { 

    this.model = model;
    return this;
  }

  /**
   * Get model
   * @return model
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
@Size(min=1,max=160)   public String getModel() {  
    return model;
  }



  public void setModel(String model) { 

    this.model = model;
  }

  public ApitrpcaiProvidersSaveJson apiKey(String apiKey) { 

    this.apiKey = apiKey;
    return this;
  }

  /**
   * Get apiKey
   * @return apiKey
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
@Size(min=8,max=1024)   public String getApiKey() {  
    return apiKey;
  }



  public void setApiKey(String apiKey) { 

    this.apiKey = apiKey;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiProvidersSaveJson apitrpcaiProvidersSaveJson = (ApitrpcaiProvidersSaveJson) o;
    return Objects.equals(this.provider, apitrpcaiProvidersSaveJson.provider) &&
        Objects.equals(this.model, apitrpcaiProvidersSaveJson.model) &&
        Objects.equals(this.apiKey, apitrpcaiProvidersSaveJson.apiKey);
  }

  @Override
  public int hashCode() {
    return Objects.hash(provider, model, apiKey);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiProvidersSaveJson {\n");
    
    sb.append("    provider: ").append(toIndentedString(provider)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    apiKey: ").append(toIndentedString(apiKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
