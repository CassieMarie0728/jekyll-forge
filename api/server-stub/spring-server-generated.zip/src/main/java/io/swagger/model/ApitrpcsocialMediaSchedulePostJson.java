package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcsocialMediaSchedulePostJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcsocialMediaSchedulePostJson   {
  @JsonProperty("repurposedContentId")

  private BigDecimal repurposedContentId = null;

  @JsonProperty("socialMediaAccountId")

  private BigDecimal socialMediaAccountId = null;

  @JsonProperty("scheduledAt")

  private Object scheduledAt = null;

  @JsonProperty("timezone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String timezone = null;


  public ApitrpcsocialMediaSchedulePostJson repurposedContentId(BigDecimal repurposedContentId) { 

    this.repurposedContentId = repurposedContentId;
    return this;
  }

  /**
   * Get repurposedContentId
   * @return repurposedContentId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getRepurposedContentId() {  
    return repurposedContentId;
  }



  public void setRepurposedContentId(BigDecimal repurposedContentId) { 

    this.repurposedContentId = repurposedContentId;
  }

  public ApitrpcsocialMediaSchedulePostJson socialMediaAccountId(BigDecimal socialMediaAccountId) { 

    this.socialMediaAccountId = socialMediaAccountId;
    return this;
  }

  /**
   * Get socialMediaAccountId
   * @return socialMediaAccountId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSocialMediaAccountId() {  
    return socialMediaAccountId;
  }



  public void setSocialMediaAccountId(BigDecimal socialMediaAccountId) { 

    this.socialMediaAccountId = socialMediaAccountId;
  }

  public ApitrpcsocialMediaSchedulePostJson scheduledAt(Object scheduledAt) { 

    this.scheduledAt = scheduledAt;
    return this;
  }

  /**
   * Get scheduledAt
   * @return scheduledAt
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public Object getScheduledAt() {  
    return scheduledAt;
  }



  public void setScheduledAt(Object scheduledAt) { 

    this.scheduledAt = scheduledAt;
  }

  public ApitrpcsocialMediaSchedulePostJson timezone(String timezone) { 

    this.timezone = timezone;
    return this;
  }

  /**
   * Get timezone
   * @return timezone
   **/
  
  @Schema(description = "")
  
  public String getTimezone() {  
    return timezone;
  }



  public void setTimezone(String timezone) { 
    this.timezone = timezone;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSchedulePostJson apitrpcsocialMediaSchedulePostJson = (ApitrpcsocialMediaSchedulePostJson) o;
    return Objects.equals(this.repurposedContentId, apitrpcsocialMediaSchedulePostJson.repurposedContentId) &&
        Objects.equals(this.socialMediaAccountId, apitrpcsocialMediaSchedulePostJson.socialMediaAccountId) &&
        Objects.equals(this.scheduledAt, apitrpcsocialMediaSchedulePostJson.scheduledAt) &&
        Objects.equals(this.timezone, apitrpcsocialMediaSchedulePostJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repurposedContentId, socialMediaAccountId, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSchedulePostJson {\n");
    
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    socialMediaAccountId: ").append(toIndentedString(socialMediaAccountId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
