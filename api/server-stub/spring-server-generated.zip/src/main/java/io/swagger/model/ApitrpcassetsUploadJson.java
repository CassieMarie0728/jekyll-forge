package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcassetsUploadJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcassetsUploadJson   {
  @JsonProperty("siteId")

  private BigDecimal siteId = null;

  @JsonProperty("name")

  private String name = null;

  @JsonProperty("path")

  private String path = null;

  @JsonProperty("base64Content")

  private String base64Content = null;

  @JsonProperty("mimeType")

  private String mimeType = null;

  @JsonProperty("size")

  private BigDecimal size = null;

  @JsonProperty("width")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal width = null;

  @JsonProperty("height")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal height = null;

  @JsonProperty("optimize")

  private Boolean optimize = null;

  @JsonProperty("maxWidth")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal maxWidth = null;

  /**
   * Gets or Sets outputFormat
   */
  public enum OutputFormatEnum {
    WEBP("webp"),
    
    JPEG("jpeg"),
    
    PNG("png"),
    
    ORIGINAL("original");

    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OutputFormatEnum fromValue(String text) {
      for (OutputFormatEnum b : OutputFormatEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("outputFormat")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OutputFormatEnum outputFormat = null;

  @JsonProperty("quality")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal quality = null;


  public ApitrpcassetsUploadJson siteId(BigDecimal siteId) { 

    this.siteId = siteId;
    return this;
  }

  /**
   * Get siteId
   * @return siteId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSiteId() {  
    return siteId;
  }



  public void setSiteId(BigDecimal siteId) { 

    this.siteId = siteId;
  }

  public ApitrpcassetsUploadJson name(String name) { 

    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
@Size(min=1,max=256)   public String getName() {  
    return name;
  }



  public void setName(String name) { 

    this.name = name;
  }

  public ApitrpcassetsUploadJson path(String path) { 

    this.path = path;
    return this;
  }

  /**
   * Get path
   * @return path
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getPath() {  
    return path;
  }



  public void setPath(String path) { 

    this.path = path;
  }

  public ApitrpcassetsUploadJson base64Content(String base64Content) { 

    this.base64Content = base64Content;
    return this;
  }

  /**
   * Get base64Content
   * @return base64Content
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getBase64Content() {  
    return base64Content;
  }



  public void setBase64Content(String base64Content) { 

    this.base64Content = base64Content;
  }

  public ApitrpcassetsUploadJson mimeType(String mimeType) { 

    this.mimeType = mimeType;
    return this;
  }

  /**
   * Get mimeType
   * @return mimeType
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getMimeType() {  
    return mimeType;
  }



  public void setMimeType(String mimeType) { 

    this.mimeType = mimeType;
  }

  public ApitrpcassetsUploadJson size(BigDecimal size) { 

    this.size = size;
    return this;
  }

  /**
   * Get size
   * @return size
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSize() {  
    return size;
  }



  public void setSize(BigDecimal size) { 

    this.size = size;
  }

  public ApitrpcassetsUploadJson width(BigDecimal width) { 

    this.width = width;
    return this;
  }

  /**
   * Get width
   * @return width
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getWidth() {  
    return width;
  }



  public void setWidth(BigDecimal width) { 
    this.width = width;
  }

  public ApitrpcassetsUploadJson height(BigDecimal height) { 

    this.height = height;
    return this;
  }

  /**
   * Get height
   * @return height
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getHeight() {  
    return height;
  }



  public void setHeight(BigDecimal height) { 
    this.height = height;
  }

  public ApitrpcassetsUploadJson optimize(Boolean optimize) { 

    this.optimize = optimize;
    return this;
  }

  /**
   * Get optimize
   * @return optimize
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public Boolean isOptimize() {  
    return optimize;
  }



  public void setOptimize(Boolean optimize) { 

    this.optimize = optimize;
  }

  public ApitrpcassetsUploadJson maxWidth(BigDecimal maxWidth) { 

    this.maxWidth = maxWidth;
    return this;
  }

  /**
   * Get maxWidth
   * @return maxWidth
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getMaxWidth() {  
    return maxWidth;
  }



  public void setMaxWidth(BigDecimal maxWidth) { 
    this.maxWidth = maxWidth;
  }

  public ApitrpcassetsUploadJson outputFormat(OutputFormatEnum outputFormat) { 

    this.outputFormat = outputFormat;
    return this;
  }

  /**
   * Get outputFormat
   * @return outputFormat
   **/
  
  @Schema(description = "")
  
  public OutputFormatEnum getOutputFormat() {  
    return outputFormat;
  }



  public void setOutputFormat(OutputFormatEnum outputFormat) { 
    this.outputFormat = outputFormat;
  }

  public ApitrpcassetsUploadJson quality(BigDecimal quality) { 

    this.quality = quality;
    return this;
  }

  /**
   * Get quality
   * @return quality
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getQuality() {  
    return quality;
  }



  public void setQuality(BigDecimal quality) { 
    this.quality = quality;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsUploadJson apitrpcassetsUploadJson = (ApitrpcassetsUploadJson) o;
    return Objects.equals(this.siteId, apitrpcassetsUploadJson.siteId) &&
        Objects.equals(this.name, apitrpcassetsUploadJson.name) &&
        Objects.equals(this.path, apitrpcassetsUploadJson.path) &&
        Objects.equals(this.base64Content, apitrpcassetsUploadJson.base64Content) &&
        Objects.equals(this.mimeType, apitrpcassetsUploadJson.mimeType) &&
        Objects.equals(this.size, apitrpcassetsUploadJson.size) &&
        Objects.equals(this.width, apitrpcassetsUploadJson.width) &&
        Objects.equals(this.height, apitrpcassetsUploadJson.height) &&
        Objects.equals(this.optimize, apitrpcassetsUploadJson.optimize) &&
        Objects.equals(this.maxWidth, apitrpcassetsUploadJson.maxWidth) &&
        Objects.equals(this.outputFormat, apitrpcassetsUploadJson.outputFormat) &&
        Objects.equals(this.quality, apitrpcassetsUploadJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, name, path, base64Content, mimeType, size, width, height, optimize, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsUploadJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    base64Content: ").append(toIndentedString(base64Content)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    optimize: ").append(toIndentedString(optimize)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
