package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcgithubDeleteFileJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcgithubDeleteFileJson   {
  @JsonProperty("owner")

  private String owner = null;

  @JsonProperty("repo")

  private String repo = null;

  @JsonProperty("path")

  private String path = null;

  @JsonProperty("branch")

  private String branch = null;

  @JsonProperty("sha")

  private String sha = null;

  @JsonProperty("message")

  private String message = null;


  public ApitrpcgithubDeleteFileJson owner(String owner) { 

    this.owner = owner;
    return this;
  }

  /**
   * Get owner
   * @return owner
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getOwner() {  
    return owner;
  }



  public void setOwner(String owner) { 

    this.owner = owner;
  }

  public ApitrpcgithubDeleteFileJson repo(String repo) { 

    this.repo = repo;
    return this;
  }

  /**
   * Get repo
   * @return repo
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getRepo() {  
    return repo;
  }



  public void setRepo(String repo) { 

    this.repo = repo;
  }

  public ApitrpcgithubDeleteFileJson path(String path) { 

    this.path = path;
    return this;
  }

  /**
   * Get path
   * @return path
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getPath() {  
    return path;
  }



  public void setPath(String path) { 

    this.path = path;
  }

  public ApitrpcgithubDeleteFileJson branch(String branch) { 

    this.branch = branch;
    return this;
  }

  /**
   * Get branch
   * @return branch
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getBranch() {  
    return branch;
  }



  public void setBranch(String branch) { 

    this.branch = branch;
  }

  public ApitrpcgithubDeleteFileJson sha(String sha) { 

    this.sha = sha;
    return this;
  }

  /**
   * Get sha
   * @return sha
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getSha() {  
    return sha;
  }



  public void setSha(String sha) { 

    this.sha = sha;
  }

  public ApitrpcgithubDeleteFileJson message(String message) { 

    this.message = message;
    return this;
  }

  /**
   * Get message
   * @return message
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getMessage() {  
    return message;
  }



  public void setMessage(String message) { 

    this.message = message;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubDeleteFileJson apitrpcgithubDeleteFileJson = (ApitrpcgithubDeleteFileJson) o;
    return Objects.equals(this.owner, apitrpcgithubDeleteFileJson.owner) &&
        Objects.equals(this.repo, apitrpcgithubDeleteFileJson.repo) &&
        Objects.equals(this.path, apitrpcgithubDeleteFileJson.path) &&
        Objects.equals(this.branch, apitrpcgithubDeleteFileJson.branch) &&
        Objects.equals(this.sha, apitrpcgithubDeleteFileJson.sha) &&
        Objects.equals(this.message, apitrpcgithubDeleteFileJson.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, path, branch, sha, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubDeleteFileJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
