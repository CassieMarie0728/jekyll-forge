package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcgithubUpdateJekyllConfigJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcgithubUpdateJekyllConfigJson   {
  @JsonProperty("owner")

  private String owner = null;

  @JsonProperty("repo")

  private String repo = null;

  @JsonProperty("rootPath")

  private String rootPath = null;

  @JsonProperty("branch")

  private String branch = null;

  @JsonProperty("commitMessage")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String commitMessage = null;


  public ApitrpcgithubUpdateJekyllConfigJson owner(String owner) { 

    this.owner = owner;
    return this;
  }

  /**
   * Get owner
   * @return owner
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getOwner() {  
    return owner;
  }



  public void setOwner(String owner) { 

    this.owner = owner;
  }

  public ApitrpcgithubUpdateJekyllConfigJson repo(String repo) { 

    this.repo = repo;
    return this;
  }

  /**
   * Get repo
   * @return repo
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getRepo() {  
    return repo;
  }



  public void setRepo(String repo) { 

    this.repo = repo;
  }

  public ApitrpcgithubUpdateJekyllConfigJson rootPath(String rootPath) { 

    this.rootPath = rootPath;
    return this;
  }

  /**
   * Get rootPath
   * @return rootPath
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getRootPath() {  
    return rootPath;
  }



  public void setRootPath(String rootPath) { 

    this.rootPath = rootPath;
  }

  public ApitrpcgithubUpdateJekyllConfigJson branch(String branch) { 

    this.branch = branch;
    return this;
  }

  /**
   * Get branch
   * @return branch
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getBranch() {  
    return branch;
  }



  public void setBranch(String branch) { 

    this.branch = branch;
  }

  public ApitrpcgithubUpdateJekyllConfigJson commitMessage(String commitMessage) { 

    this.commitMessage = commitMessage;
    return this;
  }

  /**
   * Get commitMessage
   * @return commitMessage
   **/
  
  @Schema(description = "")
  
  public String getCommitMessage() {  
    return commitMessage;
  }



  public void setCommitMessage(String commitMessage) { 
    this.commitMessage = commitMessage;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubUpdateJekyllConfigJson apitrpcgithubUpdateJekyllConfigJson = (ApitrpcgithubUpdateJekyllConfigJson) o;
    return Objects.equals(this.owner, apitrpcgithubUpdateJekyllConfigJson.owner) &&
        Objects.equals(this.repo, apitrpcgithubUpdateJekyllConfigJson.repo) &&
        Objects.equals(this.rootPath, apitrpcgithubUpdateJekyllConfigJson.rootPath) &&
        Objects.equals(this.branch, apitrpcgithubUpdateJekyllConfigJson.branch) &&
        Objects.equals(this.commitMessage, apitrpcgithubUpdateJekyllConfigJson.commitMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, rootPath, branch, commitMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubUpdateJekyllConfigJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
