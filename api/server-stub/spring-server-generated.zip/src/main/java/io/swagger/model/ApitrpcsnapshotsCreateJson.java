package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcsnapshotsCreateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcsnapshotsCreateJson   {
  @JsonProperty("siteId")

  private BigDecimal siteId = null;

  @JsonProperty("postId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal postId = null;

  @JsonProperty("postPath")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String postPath = null;

  @JsonProperty("label")

  private String label = null;

  @JsonProperty("reason")

  private Object reason = null;

  @JsonProperty("markdown")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String markdown = null;

  @JsonProperty("frontMatter")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object frontMatter = null;


  public ApitrpcsnapshotsCreateJson siteId(BigDecimal siteId) { 

    this.siteId = siteId;
    return this;
  }

  /**
   * Get siteId
   * @return siteId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSiteId() {  
    return siteId;
  }



  public void setSiteId(BigDecimal siteId) { 

    this.siteId = siteId;
  }

  public ApitrpcsnapshotsCreateJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(description = "")
  
@Valid
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 
    this.postId = postId;
  }

  public ApitrpcsnapshotsCreateJson postPath(String postPath) { 

    this.postPath = postPath;
    return this;
  }

  /**
   * Get postPath
   * @return postPath
   **/
  
  @Schema(description = "")
  
  public String getPostPath() {  
    return postPath;
  }



  public void setPostPath(String postPath) { 
    this.postPath = postPath;
  }

  public ApitrpcsnapshotsCreateJson label(String label) { 

    this.label = label;
    return this;
  }

  /**
   * Get label
   * @return label
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getLabel() {  
    return label;
  }



  public void setLabel(String label) { 

    this.label = label;
  }

  public ApitrpcsnapshotsCreateJson reason(Object reason) { 

    this.reason = reason;
    return this;
  }

  /**
   * Get reason
   * @return reason
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public Object getReason() {  
    return reason;
  }



  public void setReason(Object reason) { 

    this.reason = reason;
  }

  public ApitrpcsnapshotsCreateJson markdown(String markdown) { 

    this.markdown = markdown;
    return this;
  }

  /**
   * Get markdown
   * @return markdown
   **/
  
  @Schema(description = "")
  
  public String getMarkdown() {  
    return markdown;
  }



  public void setMarkdown(String markdown) { 
    this.markdown = markdown;
  }

  public ApitrpcsnapshotsCreateJson frontMatter(Object frontMatter) { 

    this.frontMatter = frontMatter;
    return this;
  }

  /**
   * Get frontMatter
   * @return frontMatter
   **/
  
  @Schema(description = "")
  
  public Object getFrontMatter() {  
    return frontMatter;
  }



  public void setFrontMatter(Object frontMatter) { 
    this.frontMatter = frontMatter;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsnapshotsCreateJson apitrpcsnapshotsCreateJson = (ApitrpcsnapshotsCreateJson) o;
    return Objects.equals(this.siteId, apitrpcsnapshotsCreateJson.siteId) &&
        Objects.equals(this.postId, apitrpcsnapshotsCreateJson.postId) &&
        Objects.equals(this.postPath, apitrpcsnapshotsCreateJson.postPath) &&
        Objects.equals(this.label, apitrpcsnapshotsCreateJson.label) &&
        Objects.equals(this.reason, apitrpcsnapshotsCreateJson.reason) &&
        Objects.equals(this.markdown, apitrpcsnapshotsCreateJson.markdown) &&
        Objects.equals(this.frontMatter, apitrpcsnapshotsCreateJson.frontMatter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, postPath, label, reason, markdown, frontMatter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsnapshotsCreateJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    postPath: ").append(toIndentedString(postPath)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
