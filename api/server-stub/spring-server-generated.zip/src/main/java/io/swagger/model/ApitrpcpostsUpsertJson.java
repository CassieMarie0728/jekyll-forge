package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcpostsUpsertJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcpostsUpsertJson   {
  @JsonProperty("siteId")

  private BigDecimal siteId = null;

  @JsonProperty("path")

  private String path = null;

  @JsonProperty("filename")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String filename = null;

  @JsonProperty("slug")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String slug = null;

  @JsonProperty("title")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String title = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object status = null;

  @JsonProperty("frontMatter")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object frontMatter = null;

  @JsonProperty("markdown")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String markdown = null;

  @JsonProperty("sha")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String sha = null;

  @JsonProperty("scheduledAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object scheduledAt = null;


  public ApitrpcpostsUpsertJson siteId(BigDecimal siteId) { 

    this.siteId = siteId;
    return this;
  }

  /**
   * Get siteId
   * @return siteId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getSiteId() {  
    return siteId;
  }



  public void setSiteId(BigDecimal siteId) { 

    this.siteId = siteId;
  }

  public ApitrpcpostsUpsertJson path(String path) { 

    this.path = path;
    return this;
  }

  /**
   * Get path
   * @return path
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public String getPath() {  
    return path;
  }



  public void setPath(String path) { 

    this.path = path;
  }

  public ApitrpcpostsUpsertJson filename(String filename) { 

    this.filename = filename;
    return this;
  }

  /**
   * Get filename
   * @return filename
   **/
  
  @Schema(description = "")
  
  public String getFilename() {  
    return filename;
  }



  public void setFilename(String filename) { 
    this.filename = filename;
  }

  public ApitrpcpostsUpsertJson slug(String slug) { 

    this.slug = slug;
    return this;
  }

  /**
   * Get slug
   * @return slug
   **/
  
  @Schema(description = "")
  
  public String getSlug() {  
    return slug;
  }



  public void setSlug(String slug) { 
    this.slug = slug;
  }

  public ApitrpcpostsUpsertJson title(String title) { 

    this.title = title;
    return this;
  }

  /**
   * Get title
   * @return title
   **/
  
  @Schema(description = "")
  
  public String getTitle() {  
    return title;
  }



  public void setTitle(String title) { 
    this.title = title;
  }

  public ApitrpcpostsUpsertJson status(Object status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
  public Object getStatus() {  
    return status;
  }



  public void setStatus(Object status) { 
    this.status = status;
  }

  public ApitrpcpostsUpsertJson frontMatter(Object frontMatter) { 

    this.frontMatter = frontMatter;
    return this;
  }

  /**
   * Get frontMatter
   * @return frontMatter
   **/
  
  @Schema(description = "")
  
  public Object getFrontMatter() {  
    return frontMatter;
  }



  public void setFrontMatter(Object frontMatter) { 
    this.frontMatter = frontMatter;
  }

  public ApitrpcpostsUpsertJson markdown(String markdown) { 

    this.markdown = markdown;
    return this;
  }

  /**
   * Get markdown
   * @return markdown
   **/
  
  @Schema(description = "")
  
  public String getMarkdown() {  
    return markdown;
  }



  public void setMarkdown(String markdown) { 
    this.markdown = markdown;
  }

  public ApitrpcpostsUpsertJson sha(String sha) { 

    this.sha = sha;
    return this;
  }

  /**
   * Get sha
   * @return sha
   **/
  
  @Schema(description = "")
  
  public String getSha() {  
    return sha;
  }



  public void setSha(String sha) { 
    this.sha = sha;
  }

  public ApitrpcpostsUpsertJson scheduledAt(Object scheduledAt) { 

    this.scheduledAt = scheduledAt;
    return this;
  }

  /**
   * Get scheduledAt
   * @return scheduledAt
   **/
  
  @Schema(description = "")
  
  public Object getScheduledAt() {  
    return scheduledAt;
  }



  public void setScheduledAt(Object scheduledAt) { 
    this.scheduledAt = scheduledAt;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpsertJson apitrpcpostsUpsertJson = (ApitrpcpostsUpsertJson) o;
    return Objects.equals(this.siteId, apitrpcpostsUpsertJson.siteId) &&
        Objects.equals(this.path, apitrpcpostsUpsertJson.path) &&
        Objects.equals(this.filename, apitrpcpostsUpsertJson.filename) &&
        Objects.equals(this.slug, apitrpcpostsUpsertJson.slug) &&
        Objects.equals(this.title, apitrpcpostsUpsertJson.title) &&
        Objects.equals(this.status, apitrpcpostsUpsertJson.status) &&
        Objects.equals(this.frontMatter, apitrpcpostsUpsertJson.frontMatter) &&
        Objects.equals(this.markdown, apitrpcpostsUpsertJson.markdown) &&
        Objects.equals(this.sha, apitrpcpostsUpsertJson.sha) &&
        Objects.equals(this.scheduledAt, apitrpcpostsUpsertJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, path, filename, slug, title, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpsertJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
