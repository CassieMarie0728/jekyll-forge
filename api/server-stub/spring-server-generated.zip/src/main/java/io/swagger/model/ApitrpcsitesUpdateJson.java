package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcsitesUpdateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcsitesUpdateJson   {
  @JsonProperty("id")

  private BigDecimal id = null;

  @JsonProperty("isFavorite")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean isFavorite = null;

  @JsonProperty("selectedBranch")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String selectedBranch = null;

  @JsonProperty("rootPath")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String rootPath = null;

  @JsonProperty("timezone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String timezone = null;

  @JsonProperty("defaultLayout")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultLayout = null;

  @JsonProperty("defaultAssetPath")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String defaultAssetPath = null;

  @JsonProperty("aiVoiceProfile")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String aiVoiceProfile = null;

  @JsonProperty("settings")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object settings = null;


  public ApitrpcsitesUpdateJson id(BigDecimal id) { 

    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getId() {  
    return id;
  }



  public void setId(BigDecimal id) { 

    this.id = id;
  }

  public ApitrpcsitesUpdateJson isFavorite(Boolean isFavorite) { 

    this.isFavorite = isFavorite;
    return this;
  }

  /**
   * Get isFavorite
   * @return isFavorite
   **/
  
  @Schema(description = "")
  
  public Boolean isIsFavorite() {  
    return isFavorite;
  }



  public void setIsFavorite(Boolean isFavorite) { 
    this.isFavorite = isFavorite;
  }

  public ApitrpcsitesUpdateJson selectedBranch(String selectedBranch) { 

    this.selectedBranch = selectedBranch;
    return this;
  }

  /**
   * Get selectedBranch
   * @return selectedBranch
   **/
  
  @Schema(description = "")
  
  public String getSelectedBranch() {  
    return selectedBranch;
  }



  public void setSelectedBranch(String selectedBranch) { 
    this.selectedBranch = selectedBranch;
  }

  public ApitrpcsitesUpdateJson rootPath(String rootPath) { 

    this.rootPath = rootPath;
    return this;
  }

  /**
   * Get rootPath
   * @return rootPath
   **/
  
  @Schema(description = "")
  
  public String getRootPath() {  
    return rootPath;
  }



  public void setRootPath(String rootPath) { 
    this.rootPath = rootPath;
  }

  public ApitrpcsitesUpdateJson timezone(String timezone) { 

    this.timezone = timezone;
    return this;
  }

  /**
   * Get timezone
   * @return timezone
   **/
  
  @Schema(description = "")
  
  public String getTimezone() {  
    return timezone;
  }



  public void setTimezone(String timezone) { 
    this.timezone = timezone;
  }

  public ApitrpcsitesUpdateJson defaultLayout(String defaultLayout) { 

    this.defaultLayout = defaultLayout;
    return this;
  }

  /**
   * Get defaultLayout
   * @return defaultLayout
   **/
  
  @Schema(description = "")
  
  public String getDefaultLayout() {  
    return defaultLayout;
  }



  public void setDefaultLayout(String defaultLayout) { 
    this.defaultLayout = defaultLayout;
  }

  public ApitrpcsitesUpdateJson defaultAssetPath(String defaultAssetPath) { 

    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

  /**
   * Get defaultAssetPath
   * @return defaultAssetPath
   **/
  
  @Schema(description = "")
  
  public String getDefaultAssetPath() {  
    return defaultAssetPath;
  }



  public void setDefaultAssetPath(String defaultAssetPath) { 
    this.defaultAssetPath = defaultAssetPath;
  }

  public ApitrpcsitesUpdateJson aiVoiceProfile(String aiVoiceProfile) { 

    this.aiVoiceProfile = aiVoiceProfile;
    return this;
  }

  /**
   * Get aiVoiceProfile
   * @return aiVoiceProfile
   **/
  
  @Schema(description = "")
  
  public String getAiVoiceProfile() {  
    return aiVoiceProfile;
  }



  public void setAiVoiceProfile(String aiVoiceProfile) { 
    this.aiVoiceProfile = aiVoiceProfile;
  }

  public ApitrpcsitesUpdateJson settings(Object settings) { 

    this.settings = settings;
    return this;
  }

  /**
   * Get settings
   * @return settings
   **/
  
  @Schema(description = "")
  
  public Object getSettings() {  
    return settings;
  }



  public void setSettings(Object settings) { 
    this.settings = settings;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpdateJson apitrpcsitesUpdateJson = (ApitrpcsitesUpdateJson) o;
    return Objects.equals(this.id, apitrpcsitesUpdateJson.id) &&
        Objects.equals(this.isFavorite, apitrpcsitesUpdateJson.isFavorite) &&
        Objects.equals(this.selectedBranch, apitrpcsitesUpdateJson.selectedBranch) &&
        Objects.equals(this.rootPath, apitrpcsitesUpdateJson.rootPath) &&
        Objects.equals(this.timezone, apitrpcsitesUpdateJson.timezone) &&
        Objects.equals(this.defaultLayout, apitrpcsitesUpdateJson.defaultLayout) &&
        Objects.equals(this.defaultAssetPath, apitrpcsitesUpdateJson.defaultAssetPath) &&
        Objects.equals(this.aiVoiceProfile, apitrpcsitesUpdateJson.aiVoiceProfile) &&
        Objects.equals(this.settings, apitrpcsitesUpdateJson.settings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, isFavorite, selectedBranch, rootPath, timezone, defaultLayout, defaultAssetPath, aiVoiceProfile, settings);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("    aiVoiceProfile: ").append(toIndentedString(aiVoiceProfile)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
