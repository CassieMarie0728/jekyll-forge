package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcrepurposingUpdateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcrepurposingUpdateJson   {
  @JsonProperty("id")

  private BigDecimal id = null;

  @JsonProperty("content")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String content = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object status = null;

  @JsonProperty("isCustomized")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean isCustomized = null;


  public ApitrpcrepurposingUpdateJson id(BigDecimal id) { 

    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getId() {  
    return id;
  }



  public void setId(BigDecimal id) { 

    this.id = id;
  }

  public ApitrpcrepurposingUpdateJson content(String content) { 

    this.content = content;
    return this;
  }

  /**
   * Get content
   * @return content
   **/
  
  @Schema(description = "")
  
  public String getContent() {  
    return content;
  }



  public void setContent(String content) { 
    this.content = content;
  }

  public ApitrpcrepurposingUpdateJson status(Object status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
  public Object getStatus() {  
    return status;
  }



  public void setStatus(Object status) { 
    this.status = status;
  }

  public ApitrpcrepurposingUpdateJson isCustomized(Boolean isCustomized) { 

    this.isCustomized = isCustomized;
    return this;
  }

  /**
   * Get isCustomized
   * @return isCustomized
   **/
  
  @Schema(description = "")
  
  public Boolean isIsCustomized() {  
    return isCustomized;
  }



  public void setIsCustomized(Boolean isCustomized) { 
    this.isCustomized = isCustomized;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingUpdateJson apitrpcrepurposingUpdateJson = (ApitrpcrepurposingUpdateJson) o;
    return Objects.equals(this.id, apitrpcrepurposingUpdateJson.id) &&
        Objects.equals(this.content, apitrpcrepurposingUpdateJson.content) &&
        Objects.equals(this.status, apitrpcrepurposingUpdateJson.status) &&
        Objects.equals(this.isCustomized, apitrpcrepurposingUpdateJson.isCustomized);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, content, status, isCustomized);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isCustomized: ").append(toIndentedString(isCustomized)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
