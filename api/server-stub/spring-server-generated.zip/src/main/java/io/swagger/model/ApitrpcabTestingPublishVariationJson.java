package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcabTestingPublishVariationJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcabTestingPublishVariationJson   {
  @JsonProperty("postId")

  private BigDecimal postId = null;

  @JsonProperty("variationIndex")

  private BigDecimal variationIndex = null;

  /**
   * Gets or Sets platforms
   */
  public enum PlatformsEnum {
    TWITTER("twitter"),
    
    LINKEDIN("linkedin"),
    
    FACEBOOK("facebook"),
    
    INSTAGRAM("instagram"),
    
    EMAIL("email"),
    
    DIRECT("direct");

    private String value;

    PlatformsEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PlatformsEnum fromValue(String text) {
      for (PlatformsEnum b : PlatformsEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("platforms")
  @Valid
  private List<PlatformsEnum> platforms = new ArrayList<PlatformsEnum>();

  public ApitrpcabTestingPublishVariationJson postId(BigDecimal postId) { 

    this.postId = postId;
    return this;
  }

  /**
   * Get postId
   * @return postId
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getPostId() {  
    return postId;
  }



  public void setPostId(BigDecimal postId) { 

    this.postId = postId;
  }

  public ApitrpcabTestingPublishVariationJson variationIndex(BigDecimal variationIndex) { 

    this.variationIndex = variationIndex;
    return this;
  }

  /**
   * Get variationIndex
   * @return variationIndex
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getVariationIndex() {  
    return variationIndex;
  }



  public void setVariationIndex(BigDecimal variationIndex) { 

    this.variationIndex = variationIndex;
  }

  public ApitrpcabTestingPublishVariationJson platforms(List<PlatformsEnum> platforms) { 

    this.platforms = platforms;
    return this;
  }

  public ApitrpcabTestingPublishVariationJson addPlatformsItem(PlatformsEnum platformsItem) {
    this.platforms.add(platformsItem);
    return this;
  }

  /**
   * Get platforms
   * @return platforms
   **/
  
  @Schema(required = true, description = "")
  
  @NotNull
  public List<PlatformsEnum> getPlatforms() {  
    return platforms;
  }



  public void setPlatforms(List<PlatformsEnum> platforms) { 

    this.platforms = platforms;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingPublishVariationJson apitrpcabTestingPublishVariationJson = (ApitrpcabTestingPublishVariationJson) o;
    return Objects.equals(this.postId, apitrpcabTestingPublishVariationJson.postId) &&
        Objects.equals(this.variationIndex, apitrpcabTestingPublishVariationJson.variationIndex) &&
        Objects.equals(this.platforms, apitrpcabTestingPublishVariationJson.platforms);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, variationIndex, platforms);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingPublishVariationJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platforms: ").append(toIndentedString(platforms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
