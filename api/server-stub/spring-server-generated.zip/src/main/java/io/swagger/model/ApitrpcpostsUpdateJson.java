package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ApitrpcpostsUpdateJson
 */
@Validated
@NotUndefined
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-09-27T19:38:22.028316410Z[GMT]")


public class ApitrpcpostsUpdateJson   {
  @JsonProperty("id")

  private BigDecimal id = null;

  @JsonProperty("path")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String path = null;

  @JsonProperty("title")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String title = null;

  @JsonProperty("slug")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String slug = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object status = null;

  @JsonProperty("frontMatter")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Object frontMatter = null;

  @JsonProperty("markdown")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String markdown = null;

  @JsonProperty("sha")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String sha = null;

  @JsonProperty("scheduledAt")

  private Object scheduledAt = null;


  public ApitrpcpostsUpdateJson id(BigDecimal id) { 

    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public BigDecimal getId() {  
    return id;
  }



  public void setId(BigDecimal id) { 

    this.id = id;
  }

  public ApitrpcpostsUpdateJson path(String path) { 

    this.path = path;
    return this;
  }

  /**
   * Get path
   * @return path
   **/
  
  @Schema(description = "")
  
  public String getPath() {  
    return path;
  }



  public void setPath(String path) { 
    this.path = path;
  }

  public ApitrpcpostsUpdateJson title(String title) { 

    this.title = title;
    return this;
  }

  /**
   * Get title
   * @return title
   **/
  
  @Schema(description = "")
  
  public String getTitle() {  
    return title;
  }



  public void setTitle(String title) { 
    this.title = title;
  }

  public ApitrpcpostsUpdateJson slug(String slug) { 

    this.slug = slug;
    return this;
  }

  /**
   * Get slug
   * @return slug
   **/
  
  @Schema(description = "")
  
  public String getSlug() {  
    return slug;
  }



  public void setSlug(String slug) { 
    this.slug = slug;
  }

  public ApitrpcpostsUpdateJson status(Object status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
  public Object getStatus() {  
    return status;
  }



  public void setStatus(Object status) { 
    this.status = status;
  }

  public ApitrpcpostsUpdateJson frontMatter(Object frontMatter) { 

    this.frontMatter = frontMatter;
    return this;
  }

  /**
   * Get frontMatter
   * @return frontMatter
   **/
  
  @Schema(description = "")
  
  public Object getFrontMatter() {  
    return frontMatter;
  }



  public void setFrontMatter(Object frontMatter) { 
    this.frontMatter = frontMatter;
  }

  public ApitrpcpostsUpdateJson markdown(String markdown) { 

    this.markdown = markdown;
    return this;
  }

  /**
   * Get markdown
   * @return markdown
   **/
  
  @Schema(description = "")
  
  public String getMarkdown() {  
    return markdown;
  }



  public void setMarkdown(String markdown) { 
    this.markdown = markdown;
  }

  public ApitrpcpostsUpdateJson sha(String sha) { 

    this.sha = sha;
    return this;
  }

  /**
   * Get sha
   * @return sha
   **/
  
  @Schema(description = "")
  
  public String getSha() {  
    return sha;
  }



  public void setSha(String sha) { 
    this.sha = sha;
  }

  public ApitrpcpostsUpdateJson scheduledAt(Object scheduledAt) { 

    this.scheduledAt = scheduledAt;
    return this;
  }

  /**
   * Get scheduledAt
   * @return scheduledAt
   **/
  
  @Schema(description = "")
  
  public Object getScheduledAt() {
 
    return scheduledAt;
  }



  public void setScheduledAt(Object scheduledAt) { 
    this.scheduledAt = scheduledAt;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpdateJson apitrpcpostsUpdateJson = (ApitrpcpostsUpdateJson) o;
    return Objects.equals(this.id, apitrpcpostsUpdateJson.id) &&
        Objects.equals(this.path, apitrpcpostsUpdateJson.path) &&
        Objects.equals(this.title, apitrpcpostsUpdateJson.title) &&
        Objects.equals(this.slug, apitrpcpostsUpdateJson.slug) &&
        Objects.equals(this.status, apitrpcpostsUpdateJson.status) &&
        Objects.equals(this.frontMatter, apitrpcpostsUpdateJson.frontMatter) &&
        Objects.equals(this.markdown, apitrpcpostsUpdateJson.markdown) &&
        Objects.equals(this.sha, apitrpcpostsUpdateJson.sha) &&
        Objects.equals(this.scheduledAt, apitrpcpostsUpdateJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, path, title, slug, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
