package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcrepurposingGenerateJson   {
  private BigDecimal postId = null;
  private BigDecimal siteId = null;
  /**
   * Gets or Sets format
   */
  public enum FormatEnum {
    TWITTER("twitter"),
    LINKEDIN("linkedin"),
    TIKTOK("tiktok"),
    YOUTUBE("youtube"),
    NEWSLETTER("newsletter"),
    EMAIL("email"),
    PODCAST("podcast"),
    SLIDES("slides");
    private String value;

    FormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private FormatEnum format = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("format")
  @NotNull
  public FormatEnum getFormat() {
    return format;
  }
  public void setFormat(FormatEnum format) {
    this.format = format;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingGenerateJson apitrpcrepurposingGenerateJson = (ApitrpcrepurposingGenerateJson) o;
    return Objects.equals(postId, apitrpcrepurposingGenerateJson.postId) &&
        Objects.equals(siteId, apitrpcrepurposingGenerateJson.siteId) &&
        Objects.equals(format, apitrpcrepurposingGenerateJson.format);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, siteId, format);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingGenerateJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
