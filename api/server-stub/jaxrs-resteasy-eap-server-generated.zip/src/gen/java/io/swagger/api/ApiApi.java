package io.swagger.api;

import io.swagger.model.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;
import io.swagger.model.TrpcAiGenerateBody;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;
import io.swagger.model.TrpcAiUpdateSettingsBody;
import io.swagger.model.TrpcAssetsDeleteBody;
import io.swagger.model.TrpcAssetsGenerateAltTextBody;
import io.swagger.model.TrpcAssetsReoptimizeBody;
import io.swagger.model.TrpcAssetsUpdateBody;
import io.swagger.model.TrpcAssetsUploadBody;
import io.swagger.model.TrpcBlocksCreateBody;
import io.swagger.model.TrpcBlocksDeleteBody;
import io.swagger.model.TrpcBlocksUpdateBody;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;
import io.swagger.model.TrpcNotificationsRegisterDeviceBody;
import io.swagger.model.TrpcNotificationsUnregisterDeviceBody;
import io.swagger.model.TrpcPostsAutosaveBody;
import io.swagger.model.TrpcPostsDeleteBody;
import io.swagger.model.TrpcPostsUpdateBody;
import io.swagger.model.TrpcPostsUpsertBody;
import io.swagger.model.TrpcRepurposingDeleteBody;
import io.swagger.model.TrpcRepurposingGenerateBody;
import io.swagger.model.TrpcRepurposingRegenerateBody;
import io.swagger.model.TrpcRepurposingUpdateBody;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;
import io.swagger.model.TrpcSitesDeleteBody;
import io.swagger.model.TrpcSitesUpdateBody;
import io.swagger.model.TrpcSitesUpsertBody;
import io.swagger.model.TrpcSnapshotsCreateBody;
import io.swagger.model.TrpcSocialMediaCancelScheduledPostBody;
import io.swagger.model.TrpcSocialMediaConnectAccountBody;
import io.swagger.model.TrpcSocialMediaDisconnectAccountBody;
import io.swagger.model.TrpcSocialMediaPublishContentBody;
import io.swagger.model.TrpcSocialMediaReschedulePostBody;
import io.swagger.model.TrpcSocialMediaSchedulePostBody;
import io.swagger.model.TrpcSocialMediaSyncAnalyticsBody;

import java.util.List;
import java.util.Map;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;
@Path("/api")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public interface ApiApi  {
   
    @POST
    @Path("/trpc/abTesting.applyWinner")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Apply Winner", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingApplyWinner(@Parameter(description = "" ,required=true) TrpcAbTestingApplyWinnerBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/abTesting.completeTest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Complete Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingCompleteTest(@Parameter(description = "" ,required=true) TrpcAbTestingCompleteTestBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/abTesting.generateVariations")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingGenerateVariations(@Parameter(description = "" ,required=true) TrpcAbTestingGenerateVariationsBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/abTesting.getResults")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Results", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingGetResults( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/abTesting.getVariations")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingGetVariations( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/abTesting.publishVariation")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Variation", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingPublishVariation(@Parameter(description = "" ,required=true) TrpcAbTestingPublishVariationBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/abTesting.updateMetrics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Metrics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ab Testing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response abTestingUpdateMetrics(@Parameter(description = "" ,required=true) TrpcAbTestingUpdateMetricsBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/ai.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiGenerate(@Parameter(description = "" ,required=true) TrpcAiGenerateBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/ai.getSettings")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiGetSettings(@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/ai.getUsageStats")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Usage Stats", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiGetUsageStats(@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/aiProviders.activate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Activate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiProvidersActivate(@Parameter(description = "" ,required=true) TrpcAiProvidersActivateBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/aiProviders.getSettings")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiProvidersGetSettings(@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/aiProviders.remove")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Remove", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiProvidersRemove(@Parameter(description = "" ,required=true) TrpcAiProvidersRemoveBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/aiProviders.save")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Save", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiProvidersSave(@Parameter(description = "" ,required=true) TrpcAiProvidersSaveBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/aiProviders.test")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai Providers" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiProvidersTest(@Parameter(description = "" ,required=true) TrpcAiProvidersTestBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/ai.updateSettings")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Ai" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response aiUpdateSettings(@Parameter(description = "" ,required=true) TrpcAiUpdateSettingsBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/assets.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response assetsDelete(@Parameter(description = "" ,required=true) TrpcAssetsDeleteBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/assets.generateAltText")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Alt Text", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response assetsGenerateAltText(@Parameter(description = "" ,required=true) TrpcAssetsGenerateAltTextBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/assets.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response assetsList( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/assets.reoptimize")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reoptimize", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response assetsReoptimize(@Parameter(description = "" ,required=true) TrpcAssetsReoptimizeBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/assets.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response assetsUpdate(@Parameter(description = "" ,required=true) TrpcAssetsUpdateBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/assets.upload")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upload", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Assets" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response assetsUpload(@Parameter(description = "" ,required=true) TrpcAssetsUploadBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/blocks.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response blocksCreate(@Parameter(description = "" ,required=true) TrpcBlocksCreateBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/blocks.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response blocksDelete(@Parameter(description = "" ,required=true) TrpcBlocksDeleteBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/blocks.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response blocksList(@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/blocks.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Blocks" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response blocksUpdate(@Parameter(description = "" ,required=true) TrpcBlocksUpdateBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.checkPluginCompatibility")
    
    @Produces({ "application/json" })
    @Operation(summary = "Check Plugin Compatibility", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubCheckPluginCompatibility( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.commitFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Commit File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubCommitFile(@Parameter(description = "" ,required=true) TrpcGithubCommitFileBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.connect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubConnect(@Parameter(description = "" ,required=true) TrpcGithubConnectBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.createBranch")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Branch", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubCreateBranch(@Parameter(description = "" ,required=true) TrpcGithubCreateBranchBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.createPullRequest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Pull Request", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubCreatePullRequest(@Parameter(description = "" ,required=true) TrpcGithubCreatePullRequestBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.deleteFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubDeleteFile(@Parameter(description = "" ,required=true) TrpcGithubDeleteFileBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.detectJekyll")
    
    @Produces({ "application/json" })
    @Operation(summary = "Detect Jekyll", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubDetectJekyll( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.disconnect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubDisconnect(@Parameter(description = "" ) TrpcGithubDisconnectBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.generateActionsWorkflow")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Actions Workflow", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubGenerateActionsWorkflow(@Parameter(description = "" ,required=true) TrpcGithubGenerateActionsWorkflowBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.getFile")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubGetFile( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.getJekyllConfig")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubGetJekyllConfig( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.getPagesStatus")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Pages Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubGetPagesStatus( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.getRateLimit")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Rate Limit", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubGetRateLimit(@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.inventory")
    
    @Produces({ "application/json" })
    @Operation(summary = "Inventory", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubInventory( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.listBranches")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Branches", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubListBranches( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.listFiles")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Files", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubListFiles( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.listRepos")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Repos", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubListRepos( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.repositories")
    
    @Produces({ "application/json" })
    @Operation(summary = "Repositories", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubRepositories( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.reviewFile")
    
    @Produces({ "application/json" })
    @Operation(summary = "Review File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubReviewFile( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/github.status")
    
    @Produces({ "application/json" })
    @Operation(summary = "Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubStatus(@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/github.updateJekyllConfig")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Github" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response githubUpdateJekyllConfig(@Parameter(description = "" ,required=true) TrpcGithubUpdateJekyllConfigBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/notifications.registerDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Register Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Notifications" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response notificationsRegisterDevice(@Parameter(description = "" ,required=true) TrpcNotificationsRegisterDeviceBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/notifications.unregisterDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Unregister Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Notifications" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response notificationsUnregisterDevice(@Parameter(description = "" ,required=true) TrpcNotificationsUnregisterDeviceBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/posts.autosave")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Autosave", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsAutosave(@Parameter(description = "" ,required=true) TrpcPostsAutosaveBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/posts.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsDelete(@Parameter(description = "" ,required=true) TrpcPostsDeleteBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/posts.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsGet( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/posts.getFrontMatterTemplates")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Front Matter Templates", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsGetFrontMatterTemplates( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/posts.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsList( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/posts.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsUpdate(@Parameter(description = "" ,required=true) TrpcPostsUpdateBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/posts.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Posts" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response postsUpsert(@Parameter(description = "" ,required=true) TrpcPostsUpsertBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/repurposing.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response repurposingDelete(@Parameter(description = "" ,required=true) TrpcRepurposingDeleteBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/repurposing.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response repurposingGenerate(@Parameter(description = "" ,required=true) TrpcRepurposingGenerateBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/repurposing.getById")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get By Id", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response repurposingGetById( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/repurposing.getByPost")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response repurposingGetByPost( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/repurposing.regenerate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Regenerate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response repurposingRegenerate(@Parameter(description = "" ,required=true) TrpcRepurposingRegenerateBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/repurposing.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Repurposing" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response repurposingUpdate(@Parameter(description = "" ,required=true) TrpcRepurposingUpdateBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/scheduler.cancel")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerCancel(@Parameter(description = "" ,required=true) TrpcSchedulerCancelBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/scheduler.cancelAll")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel All", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerCancelAll(@Parameter(description = "" ,required=true) TrpcSchedulerCancelAllBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/scheduler.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerList( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/scheduler.listHeartbeatJobs")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Heartbeat Jobs", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerListHeartbeatJobs( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/scheduler.markFailed")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Failed", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerMarkFailed(@Parameter(description = "" ,required=true) TrpcSchedulerMarkFailedBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/scheduler.markPublished")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Published", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerMarkPublished(@Parameter(description = "" ,required=true) TrpcSchedulerMarkPublishedBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/scheduler.reschedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerReschedule(@Parameter(description = "" ,required=true) TrpcSchedulerRescheduleBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/scheduler.schedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Scheduler" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response schedulerSchedule(@Parameter(description = "" ,required=true) TrpcSchedulerScheduleBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/sites.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response sitesDelete(@Parameter(description = "" ,required=true) TrpcSitesDeleteBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/sites.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response sitesGet( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/sites.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response sitesList(@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/sites.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response sitesUpdate(@Parameter(description = "" ,required=true) TrpcSitesUpdateBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/sites.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Sites" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response sitesUpsert(@Parameter(description = "" ,required=true) TrpcSitesUpsertBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/snapshots.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response snapshotsCreate(@Parameter(description = "" ,required=true) TrpcSnapshotsCreateBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/snapshots.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response snapshotsGet( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/snapshots.listByPost")
    
    @Produces({ "application/json" })
    @Operation(summary = "List By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Snapshots" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response snapshotsListByPost( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.cancelScheduledPost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel Scheduled Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaCancelScheduledPost(@Parameter(description = "" ,required=true) TrpcSocialMediaCancelScheduledPostBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.connectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaConnectAccount(@Parameter(description = "" ,required=true) TrpcSocialMediaConnectAccountBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.disconnectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaDisconnectAccount(@Parameter(description = "" ,required=true) TrpcSocialMediaDisconnectAccountBody body,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/socialMedia.getAccountDetails")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Account Details", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaGetAccountDetails( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/socialMedia.getAccounts")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Accounts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaGetAccounts(@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/socialMedia.getAnalyticsByPlatform")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics By Platform", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaGetAnalyticsByPlatform( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/socialMedia.getAnalyticsSummary")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics Summary", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaGetAnalyticsSummary(@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/socialMedia.getContentAnalytics")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Content Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaGetContentAnalytics( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @GET
    @Path("/trpc/socialMedia.getScheduledPosts")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Scheduled Posts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaGetScheduledPosts( @NotNull @QueryParam("input") String input,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.publishContent")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Content", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaPublishContent(@Parameter(description = "" ,required=true) TrpcSocialMediaPublishContentBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.reschedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaReschedulePost(@Parameter(description = "" ,required=true) TrpcSocialMediaReschedulePostBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.schedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaSchedulePost(@Parameter(description = "" ,required=true) TrpcSocialMediaSchedulePostBody body,@Context SecurityContext securityContext);

    @POST
    @Path("/trpc/socialMedia.syncAnalytics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Sync Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")    }, tags={ "Social Media" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
                @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
                @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class)))
         })
    Response socialMediaSyncAnalytics(@Parameter(description = "" ,required=true) TrpcSocialMediaSyncAnalyticsBody body,@Context SecurityContext securityContext);

}
