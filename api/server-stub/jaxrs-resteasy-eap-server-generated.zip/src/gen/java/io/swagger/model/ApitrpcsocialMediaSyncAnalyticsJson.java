package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcsocialMediaSyncAnalyticsJson   {
  private BigDecimal analyticsId = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("analyticsId")
  @NotNull
  public BigDecimal getAnalyticsId() {
    return analyticsId;
  }
  public void setAnalyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSyncAnalyticsJson apitrpcsocialMediaSyncAnalyticsJson = (ApitrpcsocialMediaSyncAnalyticsJson) o;
    return Objects.equals(analyticsId, apitrpcsocialMediaSyncAnalyticsJson.analyticsId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(analyticsId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSyncAnalyticsJson {\n");
    
    sb.append("    analyticsId: ").append(toIndentedString(analyticsId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
