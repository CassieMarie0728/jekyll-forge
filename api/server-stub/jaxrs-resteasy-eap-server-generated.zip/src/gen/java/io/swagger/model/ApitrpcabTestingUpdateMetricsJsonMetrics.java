package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcabTestingUpdateMetricsJsonMetrics   {
  private BigDecimal impressions = null;
  private BigDecimal engagements = null;
  private BigDecimal clicks = null;
  private BigDecimal shares = null;
  private BigDecimal likes = null;
  private BigDecimal replies = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("impressions")
  @NotNull
  public BigDecimal getImpressions() {
    return impressions;
  }
  public void setImpressions(BigDecimal impressions) {
    this.impressions = impressions;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("engagements")
  @NotNull
  public BigDecimal getEngagements() {
    return engagements;
  }
  public void setEngagements(BigDecimal engagements) {
    this.engagements = engagements;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clicks")
  @NotNull
  public BigDecimal getClicks() {
    return clicks;
  }
  public void setClicks(BigDecimal clicks) {
    this.clicks = clicks;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("shares")
  @NotNull
  public BigDecimal getShares() {
    return shares;
  }
  public void setShares(BigDecimal shares) {
    this.shares = shares;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("likes")
  @NotNull
  public BigDecimal getLikes() {
    return likes;
  }
  public void setLikes(BigDecimal likes) {
    this.likes = likes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("replies")
  @NotNull
  public BigDecimal getReplies() {
    return replies;
  }
  public void setReplies(BigDecimal replies) {
    this.replies = replies;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJsonMetrics apitrpcabTestingUpdateMetricsJsonMetrics = (ApitrpcabTestingUpdateMetricsJsonMetrics) o;
    return Objects.equals(impressions, apitrpcabTestingUpdateMetricsJsonMetrics.impressions) &&
        Objects.equals(engagements, apitrpcabTestingUpdateMetricsJsonMetrics.engagements) &&
        Objects.equals(clicks, apitrpcabTestingUpdateMetricsJsonMetrics.clicks) &&
        Objects.equals(shares, apitrpcabTestingUpdateMetricsJsonMetrics.shares) &&
        Objects.equals(likes, apitrpcabTestingUpdateMetricsJsonMetrics.likes) &&
        Objects.equals(replies, apitrpcabTestingUpdateMetricsJsonMetrics.replies);
  }

  @Override
  public int hashCode() {
    return Objects.hash(impressions, engagements, clicks, shares, likes, replies);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJsonMetrics {\n");
    
    sb.append("    impressions: ").append(toIndentedString(impressions)).append("\n");
    sb.append("    engagements: ").append(toIndentedString(engagements)).append("\n");
    sb.append("    clicks: ").append(toIndentedString(clicks)).append("\n");
    sb.append("    shares: ").append(toIndentedString(shares)).append("\n");
    sb.append("    likes: ").append(toIndentedString(likes)).append("\n");
    sb.append("    replies: ").append(toIndentedString(replies)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
