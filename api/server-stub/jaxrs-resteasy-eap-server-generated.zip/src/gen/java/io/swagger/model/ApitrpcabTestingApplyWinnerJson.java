package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcabTestingApplyWinnerJson   {
  private BigDecimal postId = null;
  private BigDecimal winningVariationIndex = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("winningVariationIndex")
  @NotNull
  public BigDecimal getWinningVariationIndex() {
    return winningVariationIndex;
  }
  public void setWinningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingApplyWinnerJson apitrpcabTestingApplyWinnerJson = (ApitrpcabTestingApplyWinnerJson) o;
    return Objects.equals(postId, apitrpcabTestingApplyWinnerJson.postId) &&
        Objects.equals(winningVariationIndex, apitrpcabTestingApplyWinnerJson.winningVariationIndex);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, winningVariationIndex);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingApplyWinnerJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    winningVariationIndex: ").append(toIndentedString(winningVariationIndex)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
