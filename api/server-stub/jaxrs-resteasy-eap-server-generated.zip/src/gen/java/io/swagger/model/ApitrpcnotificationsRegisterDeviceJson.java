package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcnotificationsRegisterDeviceJson   {
  private String token = null;
  /**
   * Gets or Sets platform
   */
  public enum PlatformEnum {
    ANDROID("android");
    private String value;

    PlatformEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private PlatformEnum platform = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("token")
  @NotNull
  @Size(min=1,max=512)
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("platform")
  @NotNull
  public PlatformEnum getPlatform() {
    return platform;
  }
  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcnotificationsRegisterDeviceJson apitrpcnotificationsRegisterDeviceJson = (ApitrpcnotificationsRegisterDeviceJson) o;
    return Objects.equals(token, apitrpcnotificationsRegisterDeviceJson.token) &&
        Objects.equals(platform, apitrpcnotificationsRegisterDeviceJson.platform);
  }

  @Override
  public int hashCode() {
    return Objects.hash(token, platform);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcnotificationsRegisterDeviceJson {\n");
    
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
