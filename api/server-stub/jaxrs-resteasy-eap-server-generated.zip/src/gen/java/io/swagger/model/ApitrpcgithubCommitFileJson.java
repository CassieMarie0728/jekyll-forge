package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcgithubCommitFileJson   {
  private String owner = null;
  private String repo = null;
  private String path = null;
  private String branch = null;
  private String content = null;
  private String message = null;
  private String sha = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("path")
  @NotNull
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("branch")
  @NotNull
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("content")
  @NotNull
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("message")
  @NotNull
  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sha")
  @NotNull
  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCommitFileJson apitrpcgithubCommitFileJson = (ApitrpcgithubCommitFileJson) o;
    return Objects.equals(owner, apitrpcgithubCommitFileJson.owner) &&
        Objects.equals(repo, apitrpcgithubCommitFileJson.repo) &&
        Objects.equals(path, apitrpcgithubCommitFileJson.path) &&
        Objects.equals(branch, apitrpcgithubCommitFileJson.branch) &&
        Objects.equals(content, apitrpcgithubCommitFileJson.content) &&
        Objects.equals(message, apitrpcgithubCommitFileJson.message) &&
        Objects.equals(sha, apitrpcgithubCommitFileJson.sha);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, path, branch, content, message, sha);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCommitFileJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
