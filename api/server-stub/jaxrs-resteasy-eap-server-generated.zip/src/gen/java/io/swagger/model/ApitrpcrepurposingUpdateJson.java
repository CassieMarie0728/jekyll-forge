package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcrepurposingUpdateJson   {
  private BigDecimal id = null;
  private String content = null;
  private Object status = null;
  private Boolean isCustomized = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("content")
  @NotNull
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("status")
  @NotNull
  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("isCustomized")
  @NotNull
  public Boolean isIsCustomized() {
    return isCustomized;
  }
  public void setIsCustomized(Boolean isCustomized) {
    this.isCustomized = isCustomized;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingUpdateJson apitrpcrepurposingUpdateJson = (ApitrpcrepurposingUpdateJson) o;
    return Objects.equals(id, apitrpcrepurposingUpdateJson.id) &&
        Objects.equals(content, apitrpcrepurposingUpdateJson.content) &&
        Objects.equals(status, apitrpcrepurposingUpdateJson.status) &&
        Objects.equals(isCustomized, apitrpcrepurposingUpdateJson.isCustomized);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, content, status, isCustomized);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isCustomized: ").append(toIndentedString(isCustomized)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
