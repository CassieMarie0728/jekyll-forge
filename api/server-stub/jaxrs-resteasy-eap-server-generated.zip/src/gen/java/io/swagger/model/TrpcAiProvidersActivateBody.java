package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ApitrpcaiProvidersActivateJson;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class TrpcAiProvidersActivateBody   {
  private ApitrpcaiProvidersActivateJson json = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("json")
  @NotNull
  public ApitrpcaiProvidersActivateJson getJson() {
    return json;
  }
  public void setJson(ApitrpcaiProvidersActivateJson json) {
    this.json = json;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrpcAiProvidersActivateBody trpcAiProvidersActivateBody = (TrpcAiProvidersActivateBody) o;
    return Objects.equals(json, trpcAiProvidersActivateBody.json);
  }

  @Override
  public int hashCode() {
    return Objects.hash(json);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcAiProvidersActivateBody {\n");
    
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
