package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcaiGenerateJson   {
  private String task = null;
  private String userPrompt = null;
  private String selectedText = null;
  private String postMarkdown = null;
  private Object frontMatter = null;
  private String tone = null;
  private BigDecimal voiceProfileId = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("task")
  @NotNull
  public String getTask() {
    return task;
  }
  public void setTask(String task) {
    this.task = task;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userPrompt")
  @NotNull
  public String getUserPrompt() {
    return userPrompt;
  }
  public void setUserPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("selectedText")
  @NotNull
  public String getSelectedText() {
    return selectedText;
  }
  public void setSelectedText(String selectedText) {
    this.selectedText = selectedText;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("postMarkdown")
  @NotNull
  public String getPostMarkdown() {
    return postMarkdown;
  }
  public void setPostMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  @NotNull
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tone")
  @NotNull
  public String getTone() {
    return tone;
  }
  public void setTone(String tone) {
    this.tone = tone;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("voiceProfileId")
  @NotNull
  public BigDecimal getVoiceProfileId() {
    return voiceProfileId;
  }
  public void setVoiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiGenerateJson apitrpcaiGenerateJson = (ApitrpcaiGenerateJson) o;
    return Objects.equals(task, apitrpcaiGenerateJson.task) &&
        Objects.equals(userPrompt, apitrpcaiGenerateJson.userPrompt) &&
        Objects.equals(selectedText, apitrpcaiGenerateJson.selectedText) &&
        Objects.equals(postMarkdown, apitrpcaiGenerateJson.postMarkdown) &&
        Objects.equals(frontMatter, apitrpcaiGenerateJson.frontMatter) &&
        Objects.equals(tone, apitrpcaiGenerateJson.tone) &&
        Objects.equals(voiceProfileId, apitrpcaiGenerateJson.voiceProfileId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(task, userPrompt, selectedText, postMarkdown, frontMatter, tone, voiceProfileId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiGenerateJson {\n");
    
    sb.append("    task: ").append(toIndentedString(task)).append("\n");
    sb.append("    userPrompt: ").append(toIndentedString(userPrompt)).append("\n");
    sb.append("    selectedText: ").append(toIndentedString(selectedText)).append("\n");
    sb.append("    postMarkdown: ").append(toIndentedString(postMarkdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    tone: ").append(toIndentedString(tone)).append("\n");
    sb.append("    voiceProfileId: ").append(toIndentedString(voiceProfileId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
