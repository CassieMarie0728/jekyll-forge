package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcassetsUploadJson   {
  private BigDecimal siteId = null;
  private String name = null;
  private String path = null;
  private String base64Content = null;
  private String mimeType = null;
  private BigDecimal size = null;
  private BigDecimal width = null;
  private BigDecimal height = null;
  private Boolean optimize = null;
  private BigDecimal maxWidth = null;
  /**
   * Gets or Sets outputFormat
   */
  public enum OutputFormatEnum {
    WEBP("webp"),
    JPEG("jpeg"),
    PNG("png"),
    ORIGINAL("original");
    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private OutputFormatEnum outputFormat = null;
  private BigDecimal quality = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("name")
  @NotNull
  @Size(min=1,max=256)
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("path")
  @NotNull
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("base64Content")
  @NotNull
  public String getBase64Content() {
    return base64Content;
  }
  public void setBase64Content(String base64Content) {
    this.base64Content = base64Content;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("mimeType")
  @NotNull
  public String getMimeType() {
    return mimeType;
  }
  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("size")
  @NotNull
  public BigDecimal getSize() {
    return size;
  }
  public void setSize(BigDecimal size) {
    this.size = size;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("width")
  @NotNull
  public BigDecimal getWidth() {
    return width;
  }
  public void setWidth(BigDecimal width) {
    this.width = width;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("height")
  @NotNull
  public BigDecimal getHeight() {
    return height;
  }
  public void setHeight(BigDecimal height) {
    this.height = height;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("optimize")
  @NotNull
  public Boolean isOptimize() {
    return optimize;
  }
  public void setOptimize(Boolean optimize) {
    this.optimize = optimize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxWidth")
  @NotNull
  public BigDecimal getMaxWidth() {
    return maxWidth;
  }
  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("outputFormat")
  @NotNull
  public OutputFormatEnum getOutputFormat() {
    return outputFormat;
  }
  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("quality")
  @NotNull
  public BigDecimal getQuality() {
    return quality;
  }
  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsUploadJson apitrpcassetsUploadJson = (ApitrpcassetsUploadJson) o;
    return Objects.equals(siteId, apitrpcassetsUploadJson.siteId) &&
        Objects.equals(name, apitrpcassetsUploadJson.name) &&
        Objects.equals(path, apitrpcassetsUploadJson.path) &&
        Objects.equals(base64Content, apitrpcassetsUploadJson.base64Content) &&
        Objects.equals(mimeType, apitrpcassetsUploadJson.mimeType) &&
        Objects.equals(size, apitrpcassetsUploadJson.size) &&
        Objects.equals(width, apitrpcassetsUploadJson.width) &&
        Objects.equals(height, apitrpcassetsUploadJson.height) &&
        Objects.equals(optimize, apitrpcassetsUploadJson.optimize) &&
        Objects.equals(maxWidth, apitrpcassetsUploadJson.maxWidth) &&
        Objects.equals(outputFormat, apitrpcassetsUploadJson.outputFormat) &&
        Objects.equals(quality, apitrpcassetsUploadJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, name, path, base64Content, mimeType, size, width, height, optimize, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsUploadJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    base64Content: ").append(toIndentedString(base64Content)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    optimize: ").append(toIndentedString(optimize)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
