package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcpostsUpdateJson   {
  private BigDecimal id = null;
  private String path = null;
  private String title = null;
  private String slug = null;
  private Object status = null;
  private Object frontMatter = null;
  private String markdown = null;
  private String sha = null;
  private Object scheduledAt = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("path")
  @NotNull
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("title")
  @NotNull
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("slug")
  @NotNull
  public String getSlug() {
    return slug;
  }
  public void setSlug(String slug) {
    this.slug = slug;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("status")
  @NotNull
  public Object getStatus() {
    return status;
  }
  public void setStatus(Object status) {
    this.status = status;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  @NotNull
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("markdown")
  @NotNull
  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sha")
  @NotNull
  public String getSha() {
    return sha;
  }
  public void setSha(String sha) {
    this.sha = sha;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("scheduledAt")
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcpostsUpdateJson apitrpcpostsUpdateJson = (ApitrpcpostsUpdateJson) o;
    return Objects.equals(id, apitrpcpostsUpdateJson.id) &&
        Objects.equals(path, apitrpcpostsUpdateJson.path) &&
        Objects.equals(title, apitrpcpostsUpdateJson.title) &&
        Objects.equals(slug, apitrpcpostsUpdateJson.slug) &&
        Objects.equals(status, apitrpcpostsUpdateJson.status) &&
        Objects.equals(frontMatter, apitrpcpostsUpdateJson.frontMatter) &&
        Objects.equals(markdown, apitrpcpostsUpdateJson.markdown) &&
        Objects.equals(sha, apitrpcpostsUpdateJson.sha) &&
        Objects.equals(scheduledAt, apitrpcpostsUpdateJson.scheduledAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, path, title, slug, status, frontMatter, markdown, sha, scheduledAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
