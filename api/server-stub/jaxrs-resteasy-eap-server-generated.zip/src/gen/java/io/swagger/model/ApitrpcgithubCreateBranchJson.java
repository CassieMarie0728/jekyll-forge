package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyEapServerCodegen", date = "2026-09-27T19:37:24.647383722Z[GMT]")
public class ApitrpcgithubCreateBranchJson   {
  private String owner = null;
  private String repo = null;
  private String branchName = null;
  private String fromBranch = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("branchName")
  @NotNull
  public String getBranchName() {
    return branchName;
  }
  public void setBranchName(String branchName) {
    this.branchName = branchName;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("fromBranch")
  @NotNull
  public String getFromBranch() {
    return fromBranch;
  }
  public void setFromBranch(String fromBranch) {
    this.fromBranch = fromBranch;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCreateBranchJson apitrpcgithubCreateBranchJson = (ApitrpcgithubCreateBranchJson) o;
    return Objects.equals(owner, apitrpcgithubCreateBranchJson.owner) &&
        Objects.equals(repo, apitrpcgithubCreateBranchJson.repo) &&
        Objects.equals(branchName, apitrpcgithubCreateBranchJson.branchName) &&
        Objects.equals(fromBranch, apitrpcgithubCreateBranchJson.fromBranch);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, branchName, fromBranch);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreateBranchJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    branchName: ").append(toIndentedString(branchName)).append("\n");
    sb.append("    fromBranch: ").append(toIndentedString(fromBranch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
