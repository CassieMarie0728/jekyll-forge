'use strict';

var utils = require('../utils/writer.js');
var AbTesting = require('../service/AbTestingService');

module.exports.abTesting_applyWinner = function abTesting_applyWinner (req, res, next, body) {
  AbTesting.abTesting_applyWinner(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.abTesting_completeTest = function abTesting_completeTest (req, res, next, body) {
  AbTesting.abTesting_completeTest(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.abTesting_generateVariations = function abTesting_generateVariations (req, res, next, body) {
  AbTesting.abTesting_generateVariations(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.abTesting_getResults = function abTesting_getResults (req, res, next, input) {
  AbTesting.abTesting_getResults(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.abTesting_getVariations = function abTesting_getVariations (req, res, next, input) {
  AbTesting.abTesting_getVariations(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.abTesting_publishVariation = function abTesting_publishVariation (req, res, next, body) {
  AbTesting.abTesting_publishVariation(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.abTesting_updateMetrics = function abTesting_updateMetrics (req, res, next, body) {
  AbTesting.abTesting_updateMetrics(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
