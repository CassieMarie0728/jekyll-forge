'use strict';

var utils = require('../utils/writer.js');
var Blocks = require('../service/BlocksService');

module.exports.blocks_create = function blocks_create (req, res, next, body) {
  Blocks.blocks_create(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.blocks_delete = function blocks_delete (req, res, next, body) {
  Blocks.blocks_delete(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.blocks_list = function blocks_list (req, res, next) {
  Blocks.blocks_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.blocks_update = function blocks_update (req, res, next, body) {
  Blocks.blocks_update(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
