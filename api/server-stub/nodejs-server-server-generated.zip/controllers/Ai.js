'use strict';

var utils = require('../utils/writer.js');
var Ai = require('../service/AiService');

module.exports.ai_generate = function ai_generate (req, res, next, body) {
  Ai.ai_generate(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ai_getSettings = function ai_getSettings (req, res, next) {
  Ai.ai_getSettings()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ai_getUsageStats = function ai_getUsageStats (req, res, next) {
  Ai.ai_getUsageStats()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ai_updateSettings = function ai_updateSettings (req, res, next, body) {
  Ai.ai_updateSettings(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
