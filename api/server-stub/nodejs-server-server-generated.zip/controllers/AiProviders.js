'use strict';

var utils = require('../utils/writer.js');
var AiProviders = require('../service/AiProvidersService');

module.exports.aiProviders_activate = function aiProviders_activate (req, res, next, body) {
  AiProviders.aiProviders_activate(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.aiProviders_getSettings = function aiProviders_getSettings (req, res, next) {
  AiProviders.aiProviders_getSettings()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.aiProviders_remove = function aiProviders_remove (req, res, next, body) {
  AiProviders.aiProviders_remove(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.aiProviders_save = function aiProviders_save (req, res, next, body) {
  AiProviders.aiProviders_save(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.aiProviders_test = function aiProviders_test (req, res, next, body) {
  AiProviders.aiProviders_test(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
