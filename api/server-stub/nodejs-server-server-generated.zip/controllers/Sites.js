'use strict';

var utils = require('../utils/writer.js');
var Sites = require('../service/SitesService');

module.exports.sites_delete = function sites_delete (req, res, next, body) {
  Sites.sites_delete(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.sites_get = function sites_get (req, res, next, input) {
  Sites.sites_get(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.sites_list = function sites_list (req, res, next) {
  Sites.sites_list()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.sites_update = function sites_update (req, res, next, body) {
  Sites.sites_update(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.sites_upsert = function sites_upsert (req, res, next, body) {
  Sites.sites_upsert(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
