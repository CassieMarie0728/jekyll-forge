'use strict';

var utils = require('../utils/writer.js');
var Snapshots = require('../service/SnapshotsService');

module.exports.snapshots_create = function snapshots_create (req, res, next, body) {
  Snapshots.snapshots_create(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.snapshots_get = function snapshots_get (req, res, next, input) {
  Snapshots.snapshots_get(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.snapshots_listByPost = function snapshots_listByPost (req, res, next, input) {
  Snapshots.snapshots_listByPost(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
