'use strict';

var utils = require('../utils/writer.js');
var Scheduler = require('../service/SchedulerService');

module.exports.scheduler_cancel = function scheduler_cancel (req, res, next, body) {
  Scheduler.scheduler_cancel(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_cancelAll = function scheduler_cancelAll (req, res, next, body) {
  Scheduler.scheduler_cancelAll(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_list = function scheduler_list (req, res, next, input) {
  Scheduler.scheduler_list(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_listHeartbeatJobs = function scheduler_listHeartbeatJobs (req, res, next, input) {
  Scheduler.scheduler_listHeartbeatJobs(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_markFailed = function scheduler_markFailed (req, res, next, body) {
  Scheduler.scheduler_markFailed(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_markPublished = function scheduler_markPublished (req, res, next, body) {
  Scheduler.scheduler_markPublished(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_reschedule = function scheduler_reschedule (req, res, next, body) {
  Scheduler.scheduler_reschedule(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.scheduler_schedule = function scheduler_schedule (req, res, next, body) {
  Scheduler.scheduler_schedule(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
