'use strict';

var utils = require('../utils/writer.js');
var SocialMedia = require('../service/SocialMediaService');

module.exports.socialMedia_cancelScheduledPost = function socialMedia_cancelScheduledPost (req, res, next, body) {
  SocialMedia.socialMedia_cancelScheduledPost(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_connectAccount = function socialMedia_connectAccount (req, res, next, body) {
  SocialMedia.socialMedia_connectAccount(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_disconnectAccount = function socialMedia_disconnectAccount (req, res, next, body) {
  SocialMedia.socialMedia_disconnectAccount(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_getAccountDetails = function socialMedia_getAccountDetails (req, res, next, input) {
  SocialMedia.socialMedia_getAccountDetails(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_getAccounts = function socialMedia_getAccounts (req, res, next) {
  SocialMedia.socialMedia_getAccounts()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_getAnalyticsByPlatform = function socialMedia_getAnalyticsByPlatform (req, res, next, input) {
  SocialMedia.socialMedia_getAnalyticsByPlatform(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_getAnalyticsSummary = function socialMedia_getAnalyticsSummary (req, res, next) {
  SocialMedia.socialMedia_getAnalyticsSummary()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_getContentAnalytics = function socialMedia_getContentAnalytics (req, res, next, input) {
  SocialMedia.socialMedia_getContentAnalytics(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_getScheduledPosts = function socialMedia_getScheduledPosts (req, res, next, input) {
  SocialMedia.socialMedia_getScheduledPosts(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_publishContent = function socialMedia_publishContent (req, res, next, body) {
  SocialMedia.socialMedia_publishContent(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_reschedulePost = function socialMedia_reschedulePost (req, res, next, body) {
  SocialMedia.socialMedia_reschedulePost(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_schedulePost = function socialMedia_schedulePost (req, res, next, body) {
  SocialMedia.socialMedia_schedulePost(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.socialMedia_syncAnalytics = function socialMedia_syncAnalytics (req, res, next, body) {
  SocialMedia.socialMedia_syncAnalytics(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
