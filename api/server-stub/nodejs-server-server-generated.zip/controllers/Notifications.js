'use strict';

var utils = require('../utils/writer.js');
var Notifications = require('../service/NotificationsService');

module.exports.notifications_registerDevice = function notifications_registerDevice (req, res, next, body) {
  Notifications.notifications_registerDevice(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.notifications_unregisterDevice = function notifications_unregisterDevice (req, res, next, body) {
  Notifications.notifications_unregisterDevice(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
