'use strict';

var utils = require('../utils/writer.js');
var Github = require('../service/GithubService');

module.exports.github_checkPluginCompatibility = function github_checkPluginCompatibility (req, res, next, input) {
  Github.github_checkPluginCompatibility(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_commitFile = function github_commitFile (req, res, next, body) {
  Github.github_commitFile(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_connect = function github_connect (req, res, next, body) {
  Github.github_connect(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_createBranch = function github_createBranch (req, res, next, body) {
  Github.github_createBranch(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_createPullRequest = function github_createPullRequest (req, res, next, body) {
  Github.github_createPullRequest(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_deleteFile = function github_deleteFile (req, res, next, body) {
  Github.github_deleteFile(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_detectJekyll = function github_detectJekyll (req, res, next, input) {
  Github.github_detectJekyll(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_disconnect = function github_disconnect (req, res, next, body) {
  Github.github_disconnect(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_generateActionsWorkflow = function github_generateActionsWorkflow (req, res, next, body) {
  Github.github_generateActionsWorkflow(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_getFile = function github_getFile (req, res, next, input) {
  Github.github_getFile(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_getJekyllConfig = function github_getJekyllConfig (req, res, next, input) {
  Github.github_getJekyllConfig(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_getPagesStatus = function github_getPagesStatus (req, res, next, input) {
  Github.github_getPagesStatus(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_getRateLimit = function github_getRateLimit (req, res, next) {
  Github.github_getRateLimit()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_inventory = function github_inventory (req, res, next, input) {
  Github.github_inventory(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_listBranches = function github_listBranches (req, res, next, input) {
  Github.github_listBranches(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_listFiles = function github_listFiles (req, res, next, input) {
  Github.github_listFiles(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_listRepos = function github_listRepos (req, res, next, input) {
  Github.github_listRepos(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_repositories = function github_repositories (req, res, next, input) {
  Github.github_repositories(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_reviewFile = function github_reviewFile (req, res, next, input) {
  Github.github_reviewFile(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_status = function github_status (req, res, next) {
  Github.github_status()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.github_updateJekyllConfig = function github_updateJekyllConfig (req, res, next, body) {
  Github.github_updateJekyllConfig(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
