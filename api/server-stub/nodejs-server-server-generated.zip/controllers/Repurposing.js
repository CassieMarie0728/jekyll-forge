'use strict';

var utils = require('../utils/writer.js');
var Repurposing = require('../service/RepurposingService');

module.exports.repurposing_delete = function repurposing_delete (req, res, next, body) {
  Repurposing.repurposing_delete(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.repurposing_generate = function repurposing_generate (req, res, next, body) {
  Repurposing.repurposing_generate(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.repurposing_getById = function repurposing_getById (req, res, next, input) {
  Repurposing.repurposing_getById(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.repurposing_getByPost = function repurposing_getByPost (req, res, next, input) {
  Repurposing.repurposing_getByPost(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.repurposing_regenerate = function repurposing_regenerate (req, res, next, body) {
  Repurposing.repurposing_regenerate(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.repurposing_update = function repurposing_update (req, res, next, body) {
  Repurposing.repurposing_update(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
