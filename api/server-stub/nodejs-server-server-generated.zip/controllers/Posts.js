'use strict';

var utils = require('../utils/writer.js');
var Posts = require('../service/PostsService');

module.exports.posts_autosave = function posts_autosave (req, res, next, body) {
  Posts.posts_autosave(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.posts_delete = function posts_delete (req, res, next, body) {
  Posts.posts_delete(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.posts_get = function posts_get (req, res, next, input) {
  Posts.posts_get(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.posts_getFrontMatterTemplates = function posts_getFrontMatterTemplates (req, res, next, input) {
  Posts.posts_getFrontMatterTemplates(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.posts_list = function posts_list (req, res, next, input) {
  Posts.posts_list(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.posts_update = function posts_update (req, res, next, body) {
  Posts.posts_update(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.posts_upsert = function posts_upsert (req, res, next, body) {
  Posts.posts_upsert(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
