'use strict';

var utils = require('../utils/writer.js');
var Assets = require('../service/AssetsService');

module.exports.assets_delete = function assets_delete (req, res, next, body) {
  Assets.assets_delete(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.assets_generateAltText = function assets_generateAltText (req, res, next, body) {
  Assets.assets_generateAltText(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.assets_list = function assets_list (req, res, next, input) {
  Assets.assets_list(input)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.assets_reoptimize = function assets_reoptimize (req, res, next, body) {
  Assets.assets_reoptimize(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.assets_update = function assets_update (req, res, next, body) {
  Assets.assets_update(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.assets_upload = function assets_upload (req, res, next, body) {
  Assets.assets_upload(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
