'use strict';


/**
 * Autosave
 *
 * body Trpc_posts_autosave_body 
 * returns TRPCResponse
 **/
exports.posts_autosave = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete
 *
 * body Trpc_posts_delete_body 
 * returns TRPCResponse
 **/
exports.posts_delete = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.posts_get = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Front Matter Templates
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.posts_getFrontMatterTemplates = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.posts_list = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update
 *
 * body Trpc_posts_update_body 
 * returns TRPCResponse
 **/
exports.posts_update = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Upsert
 *
 * body Trpc_posts_upsert_body 
 * returns TRPCResponse
 **/
exports.posts_upsert = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

