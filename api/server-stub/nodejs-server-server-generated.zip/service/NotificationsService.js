'use strict';


/**
 * Register Device
 *
 * body Trpc_notifications_registerDevice_body 
 * returns TRPCResponse
 **/
exports.notifications_registerDevice = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Unregister Device
 *
 * body Trpc_notifications_unregisterDevice_body 
 * returns TRPCResponse
 **/
exports.notifications_unregisterDevice = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

