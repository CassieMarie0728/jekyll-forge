'use strict';


/**
 * Delete
 *
 * body Trpc_sites_delete_body 
 * returns TRPCResponse
 **/
exports.sites_delete = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.sites_get = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List
 *
 * returns TRPCResponse
 **/
exports.sites_list = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update
 *
 * body Trpc_sites_update_body 
 * returns TRPCResponse
 **/
exports.sites_update = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Upsert
 *
 * body Trpc_sites_upsert_body 
 * returns TRPCResponse
 **/
exports.sites_upsert = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

