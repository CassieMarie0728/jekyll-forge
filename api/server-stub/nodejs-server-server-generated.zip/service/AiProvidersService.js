'use strict';


/**
 * Activate
 *
 * body Trpc_aiProviders_activate_body 
 * returns TRPCResponse
 **/
exports.aiProviders_activate = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Settings
 *
 * returns TRPCResponse
 **/
exports.aiProviders_getSettings = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Remove
 *
 * body Trpc_aiProviders_remove_body 
 * returns TRPCResponse
 **/
exports.aiProviders_remove = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Save
 *
 * body Trpc_aiProviders_save_body 
 * returns TRPCResponse
 **/
exports.aiProviders_save = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Test
 *
 * body Trpc_aiProviders_test_body 
 * returns TRPCResponse
 **/
exports.aiProviders_test = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

