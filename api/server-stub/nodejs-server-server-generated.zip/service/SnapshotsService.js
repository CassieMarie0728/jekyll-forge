'use strict';


/**
 * Create
 *
 * body Trpc_snapshots_create_body 
 * returns TRPCResponse
 **/
exports.snapshots_create = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.snapshots_get = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List By Post
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.snapshots_listByPost = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

