'use strict';


/**
 * Delete
 *
 * body Trpc_assets_delete_body 
 * returns TRPCResponse
 **/
exports.assets_delete = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Generate Alt Text
 *
 * body Trpc_assets_generateAltText_body 
 * returns TRPCResponse
 **/
exports.assets_generateAltText = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.assets_list = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Reoptimize
 *
 * body Trpc_assets_reoptimize_body 
 * returns TRPCResponse
 **/
exports.assets_reoptimize = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update
 *
 * body Trpc_assets_update_body 
 * returns TRPCResponse
 **/
exports.assets_update = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Upload
 *
 * body Trpc_assets_upload_body 
 * returns TRPCResponse
 **/
exports.assets_upload = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

