'use strict';


/**
 * Cancel
 *
 * body Trpc_scheduler_cancel_body 
 * returns TRPCResponse
 **/
exports.scheduler_cancel = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Cancel All
 *
 * body Trpc_scheduler_cancelAll_body 
 * returns TRPCResponse
 **/
exports.scheduler_cancelAll = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.scheduler_list = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Heartbeat Jobs
 *
 * input String URL-encoded tRPC input envelope, e.g. {\"json\":{...}}
 * returns TRPCResponse
 **/
exports.scheduler_listHeartbeatJobs = function(input) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Mark Failed
 *
 * body Trpc_scheduler_markFailed_body 
 * returns TRPCResponse
 **/
exports.scheduler_markFailed = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Mark Published
 *
 * body Trpc_scheduler_markPublished_body 
 * returns TRPCResponse
 **/
exports.scheduler_markPublished = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Reschedule
 *
 * body Trpc_scheduler_reschedule_body 
 * returns TRPCResponse
 **/
exports.scheduler_reschedule = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Schedule
 *
 * body Trpc_scheduler_schedule_body 
 * returns TRPCResponse
 **/
exports.scheduler_schedule = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

