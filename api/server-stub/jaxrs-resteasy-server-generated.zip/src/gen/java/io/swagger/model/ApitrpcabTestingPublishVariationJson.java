package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcabTestingPublishVariationJson   {
  private BigDecimal postId = null;  private BigDecimal variationIndex = null;  /**
   * Gets or Sets platforms
   */
  public enum PlatformsEnum {
    TWITTER("twitter"),
    LINKEDIN("linkedin"),
    FACEBOOK("facebook"),
    INSTAGRAM("instagram"),
    EMAIL("email"),
    DIRECT("direct");
    private String value;

    PlatformsEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private List<PlatformsEnum> platforms = new ArrayList<PlatformsEnum>();

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("variationIndex")
  @NotNull
  public BigDecimal getVariationIndex() {
    return variationIndex;
  }
  public void setVariationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("platforms")
  @NotNull
  public List<PlatformsEnum> getPlatforms() {
    return platforms;
  }
  public void setPlatforms(List<PlatformsEnum> platforms) {
    this.platforms = platforms;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingPublishVariationJson apitrpcabTestingPublishVariationJson = (ApitrpcabTestingPublishVariationJson) o;
    return Objects.equals(postId, apitrpcabTestingPublishVariationJson.postId) &&
        Objects.equals(variationIndex, apitrpcabTestingPublishVariationJson.variationIndex) &&
        Objects.equals(platforms, apitrpcabTestingPublishVariationJson.platforms);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, variationIndex, platforms);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingPublishVariationJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platforms: ").append(toIndentedString(platforms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
