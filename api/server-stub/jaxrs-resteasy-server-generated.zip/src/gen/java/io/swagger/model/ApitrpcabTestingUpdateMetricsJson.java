package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ApitrpcabTestingUpdateMetricsJsonMetrics;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcabTestingUpdateMetricsJson   {
  private BigDecimal postId = null;  private BigDecimal variationIndex = null;  private String platform = null;  private ApitrpcabTestingUpdateMetricsJsonMetrics metrics = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("variationIndex")
  @NotNull
  public BigDecimal getVariationIndex() {
    return variationIndex;
  }
  public void setVariationIndex(BigDecimal variationIndex) {
    this.variationIndex = variationIndex;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("platform")
  @NotNull
  public String getPlatform() {
    return platform;
  }
  public void setPlatform(String platform) {
    this.platform = platform;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("metrics")
  @NotNull
  public ApitrpcabTestingUpdateMetricsJsonMetrics getMetrics() {
    return metrics;
  }
  public void setMetrics(ApitrpcabTestingUpdateMetricsJsonMetrics metrics) {
    this.metrics = metrics;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingUpdateMetricsJson apitrpcabTestingUpdateMetricsJson = (ApitrpcabTestingUpdateMetricsJson) o;
    return Objects.equals(postId, apitrpcabTestingUpdateMetricsJson.postId) &&
        Objects.equals(variationIndex, apitrpcabTestingUpdateMetricsJson.variationIndex) &&
        Objects.equals(platform, apitrpcabTestingUpdateMetricsJson.platform) &&
        Objects.equals(metrics, apitrpcabTestingUpdateMetricsJson.metrics);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, variationIndex, platform, metrics);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingUpdateMetricsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    variationIndex: ").append(toIndentedString(variationIndex)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    metrics: ").append(toIndentedString(metrics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
