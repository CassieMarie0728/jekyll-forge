package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcassetsReoptimizeJson   {
  private BigDecimal id = null;  private BigDecimal maxWidth = null;  /**
   * Gets or Sets outputFormat
   */
  public enum OutputFormatEnum {
    WEBP("webp"),
    JPEG("jpeg"),
    PNG("png");
    private String value;

    OutputFormatEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private OutputFormatEnum outputFormat = null;  private BigDecimal quality = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxWidth")
  @NotNull
  public BigDecimal getMaxWidth() {
    return maxWidth;
  }
  public void setMaxWidth(BigDecimal maxWidth) {
    this.maxWidth = maxWidth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("outputFormat")
  @NotNull
  public OutputFormatEnum getOutputFormat() {
    return outputFormat;
  }
  public void setOutputFormat(OutputFormatEnum outputFormat) {
    this.outputFormat = outputFormat;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("quality")
  @NotNull
  public BigDecimal getQuality() {
    return quality;
  }
  public void setQuality(BigDecimal quality) {
    this.quality = quality;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcassetsReoptimizeJson apitrpcassetsReoptimizeJson = (ApitrpcassetsReoptimizeJson) o;
    return Objects.equals(id, apitrpcassetsReoptimizeJson.id) &&
        Objects.equals(maxWidth, apitrpcassetsReoptimizeJson.maxWidth) &&
        Objects.equals(outputFormat, apitrpcassetsReoptimizeJson.outputFormat) &&
        Objects.equals(quality, apitrpcassetsReoptimizeJson.quality);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, maxWidth, outputFormat, quality);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcassetsReoptimizeJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    maxWidth: ").append(toIndentedString(maxWidth)).append("\n");
    sb.append("    outputFormat: ").append(toIndentedString(outputFormat)).append("\n");
    sb.append("    quality: ").append(toIndentedString(quality)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
