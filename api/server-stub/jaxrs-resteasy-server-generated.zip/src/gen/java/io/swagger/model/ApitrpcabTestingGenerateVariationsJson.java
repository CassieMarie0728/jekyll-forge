package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcabTestingGenerateVariationsJson   {
  private BigDecimal postId = null;  private BigDecimal count = null;  private List<String> tones = new ArrayList<String>();  private List<String> angles = new ArrayList<String>();  private String headline = null;  private String content = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("count")
  @NotNull
  public BigDecimal getCount() {
    return count;
  }
  public void setCount(BigDecimal count) {
    this.count = count;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tones")
  @NotNull
  public List<String> getTones() {
    return tones;
  }
  public void setTones(List<String> tones) {
    this.tones = tones;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("angles")
  @NotNull
  public List<String> getAngles() {
    return angles;
  }
  public void setAngles(List<String> angles) {
    this.angles = angles;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("headline")
  @NotNull
  public String getHeadline() {
    return headline;
  }
  public void setHeadline(String headline) {
    this.headline = headline;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("content")
  @NotNull
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcabTestingGenerateVariationsJson apitrpcabTestingGenerateVariationsJson = (ApitrpcabTestingGenerateVariationsJson) o;
    return Objects.equals(postId, apitrpcabTestingGenerateVariationsJson.postId) &&
        Objects.equals(count, apitrpcabTestingGenerateVariationsJson.count) &&
        Objects.equals(tones, apitrpcabTestingGenerateVariationsJson.tones) &&
        Objects.equals(angles, apitrpcabTestingGenerateVariationsJson.angles) &&
        Objects.equals(headline, apitrpcabTestingGenerateVariationsJson.headline) &&
        Objects.equals(content, apitrpcabTestingGenerateVariationsJson.content);
  }

  @Override
  public int hashCode() {
    return Objects.hash(postId, count, tones, angles, headline, content);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingGenerateVariationsJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    tones: ").append(toIndentedString(tones)).append("\n");
    sb.append("    angles: ").append(toIndentedString(angles)).append("\n");
    sb.append("    headline: ").append(toIndentedString(headline)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
