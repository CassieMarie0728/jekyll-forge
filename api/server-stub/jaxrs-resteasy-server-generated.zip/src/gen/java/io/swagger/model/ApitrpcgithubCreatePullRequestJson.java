package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcgithubCreatePullRequestJson   {
  private String owner = null;  private String repo = null;  private String title = null;  private String head = null;  private String base = null;  private String body = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("title")
  @NotNull
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("head")
  @NotNull
  public String getHead() {
    return head;
  }
  public void setHead(String head) {
    this.head = head;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("base")
  @NotNull
  public String getBase() {
    return base;
  }
  public void setBase(String base) {
    this.base = base;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("body")
  @NotNull
  public String getBody() {
    return body;
  }
  public void setBody(String body) {
    this.body = body;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubCreatePullRequestJson apitrpcgithubCreatePullRequestJson = (ApitrpcgithubCreatePullRequestJson) o;
    return Objects.equals(owner, apitrpcgithubCreatePullRequestJson.owner) &&
        Objects.equals(repo, apitrpcgithubCreatePullRequestJson.repo) &&
        Objects.equals(title, apitrpcgithubCreatePullRequestJson.title) &&
        Objects.equals(head, apitrpcgithubCreatePullRequestJson.head) &&
        Objects.equals(base, apitrpcgithubCreatePullRequestJson.base) &&
        Objects.equals(body, apitrpcgithubCreatePullRequestJson.body);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, title, head, base, body);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreatePullRequestJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    head: ").append(toIndentedString(head)).append("\n");
    sb.append("    base: ").append(toIndentedString(base)).append("\n");
    sb.append("    body: ").append(toIndentedString(body)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
