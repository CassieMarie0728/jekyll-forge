package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcgithubUpdateJekyllConfigJson   {
  private String owner = null;  private String repo = null;  private String rootPath = null;  private String branch = null;  private String commitMessage = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("rootPath")
  @NotNull
  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("branch")
  @NotNull
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("commitMessage")
  @NotNull
  public String getCommitMessage() {
    return commitMessage;
  }
  public void setCommitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubUpdateJekyllConfigJson apitrpcgithubUpdateJekyllConfigJson = (ApitrpcgithubUpdateJekyllConfigJson) o;
    return Objects.equals(owner, apitrpcgithubUpdateJekyllConfigJson.owner) &&
        Objects.equals(repo, apitrpcgithubUpdateJekyllConfigJson.repo) &&
        Objects.equals(rootPath, apitrpcgithubUpdateJekyllConfigJson.rootPath) &&
        Objects.equals(branch, apitrpcgithubUpdateJekyllConfigJson.branch) &&
        Objects.equals(commitMessage, apitrpcgithubUpdateJekyllConfigJson.commitMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, rootPath, branch, commitMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubUpdateJekyllConfigJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
