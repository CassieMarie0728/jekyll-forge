package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcsocialMediaSchedulePostJson   {
  private BigDecimal repurposedContentId = null;  private BigDecimal socialMediaAccountId = null;  private Object scheduledAt = null;  private String timezone = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repurposedContentId")
  @NotNull
  public BigDecimal getRepurposedContentId() {
    return repurposedContentId;
  }
  public void setRepurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("socialMediaAccountId")
  @NotNull
  public BigDecimal getSocialMediaAccountId() {
    return socialMediaAccountId;
  }
  public void setSocialMediaAccountId(BigDecimal socialMediaAccountId) {
    this.socialMediaAccountId = socialMediaAccountId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("scheduledAt")
  @NotNull
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timezone")
  @NotNull
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaSchedulePostJson apitrpcsocialMediaSchedulePostJson = (ApitrpcsocialMediaSchedulePostJson) o;
    return Objects.equals(repurposedContentId, apitrpcsocialMediaSchedulePostJson.repurposedContentId) &&
        Objects.equals(socialMediaAccountId, apitrpcsocialMediaSchedulePostJson.socialMediaAccountId) &&
        Objects.equals(scheduledAt, apitrpcsocialMediaSchedulePostJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcsocialMediaSchedulePostJson.timezone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repurposedContentId, socialMediaAccountId, scheduledAt, timezone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSchedulePostJson {\n");
    
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    socialMediaAccountId: ").append(toIndentedString(socialMediaAccountId)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
