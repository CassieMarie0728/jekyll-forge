package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.ApiApiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;
import io.swagger.model.TrpcAiGenerateBody;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;
import io.swagger.model.TrpcAiUpdateSettingsBody;
import io.swagger.model.TrpcAssetsDeleteBody;
import io.swagger.model.TrpcAssetsGenerateAltTextBody;
import io.swagger.model.TrpcAssetsReoptimizeBody;
import io.swagger.model.TrpcAssetsUpdateBody;
import io.swagger.model.TrpcAssetsUploadBody;
import io.swagger.model.TrpcBlocksCreateBody;
import io.swagger.model.TrpcBlocksDeleteBody;
import io.swagger.model.TrpcBlocksUpdateBody;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;
import io.swagger.model.TrpcNotificationsRegisterDeviceBody;
import io.swagger.model.TrpcNotificationsUnregisterDeviceBody;
import io.swagger.model.TrpcPostsAutosaveBody;
import io.swagger.model.TrpcPostsDeleteBody;
import io.swagger.model.TrpcPostsUpdateBody;
import io.swagger.model.TrpcPostsUpsertBody;
import io.swagger.model.TrpcRepurposingDeleteBody;
import io.swagger.model.TrpcRepurposingGenerateBody;
import io.swagger.model.TrpcRepurposingRegenerateBody;
import io.swagger.model.TrpcRepurposingUpdateBody;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;
import io.swagger.model.TrpcSitesDeleteBody;
import io.swagger.model.TrpcSitesUpdateBody;
import io.swagger.model.TrpcSitesUpsertBody;
import io.swagger.model.TrpcSnapshotsCreateBody;
import io.swagger.model.TrpcSocialMediaCancelScheduledPostBody;
import io.swagger.model.TrpcSocialMediaConnectAccountBody;
import io.swagger.model.TrpcSocialMediaDisconnectAccountBody;
import io.swagger.model.TrpcSocialMediaPublishContentBody;
import io.swagger.model.TrpcSocialMediaReschedulePostBody;
import io.swagger.model.TrpcSocialMediaSchedulePostBody;
import io.swagger.model.TrpcSocialMediaSyncAnalyticsBody;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.inject.Inject;

import javax.validation.constraints.*;
@Path("/api")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApiApi  {

    @Inject ApiApiService service;

    @POST
    @Path("/trpc/abTesting.applyWinner")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Apply Winner", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingApplyWinner(
@Parameter(description = "" ,required=true) TrpcAbTestingApplyWinnerBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingApplyWinner(body,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.completeTest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Complete Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingCompleteTest(
@Parameter(description = "" ,required=true) TrpcAbTestingCompleteTestBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingCompleteTest(body,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.generateVariations")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingGenerateVariations(
@Parameter(description = "" ,required=true) TrpcAbTestingGenerateVariationsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingGenerateVariations(body,securityContext);
    }
    @GET
    @Path("/trpc/abTesting.getResults")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Results", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingGetResults( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingGetResults(input,securityContext);
    }
    @GET
    @Path("/trpc/abTesting.getVariations")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Variations", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingGetVariations( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingGetVariations(input,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.publishVariation")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Variation", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingPublishVariation(
@Parameter(description = "" ,required=true) TrpcAbTestingPublishVariationBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingPublishVariation(body,securityContext);
    }
    @POST
    @Path("/trpc/abTesting.updateMetrics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Metrics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response abTestingUpdateMetrics(
@Parameter(description = "" ,required=true) TrpcAbTestingUpdateMetricsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.abTestingUpdateMetrics(body,securityContext);
    }
    @POST
    @Path("/trpc/ai.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiGenerate(
@Parameter(description = "" ,required=true) TrpcAiGenerateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiGenerate(body,securityContext);
    }
    @GET
    @Path("/trpc/ai.getSettings")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiGetSettings(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiGetSettings(securityContext);
    }
    @GET
    @Path("/trpc/ai.getUsageStats")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Usage Stats", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiGetUsageStats(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiGetUsageStats(securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.activate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Activate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersActivate(
@Parameter(description = "" ,required=true) TrpcAiProvidersActivateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiProvidersActivate(body,securityContext);
    }
    @GET
    @Path("/trpc/aiProviders.getSettings")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersGetSettings(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiProvidersGetSettings(securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.remove")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Remove", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersRemove(
@Parameter(description = "" ,required=true) TrpcAiProvidersRemoveBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiProvidersRemove(body,securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.save")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Save", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersSave(
@Parameter(description = "" ,required=true) TrpcAiProvidersSaveBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiProvidersSave(body,securityContext);
    }
    @POST
    @Path("/trpc/aiProviders.test")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Test", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiProvidersTest(
@Parameter(description = "" ,required=true) TrpcAiProvidersTestBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiProvidersTest(body,securityContext);
    }
    @POST
    @Path("/trpc/ai.updateSettings")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Settings", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Ai" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response aiUpdateSettings(
@Parameter(description = "" ,required=true) TrpcAiUpdateSettingsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.aiUpdateSettings(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsDelete(
@Parameter(description = "" ,required=true) TrpcAssetsDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.assetsDelete(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.generateAltText")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Alt Text", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsGenerateAltText(
@Parameter(description = "" ,required=true) TrpcAssetsGenerateAltTextBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.assetsGenerateAltText(body,securityContext);
    }
    @GET
    @Path("/trpc/assets.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsList( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.assetsList(input,securityContext);
    }
    @POST
    @Path("/trpc/assets.reoptimize")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reoptimize", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsReoptimize(
@Parameter(description = "" ,required=true) TrpcAssetsReoptimizeBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.assetsReoptimize(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsUpdate(
@Parameter(description = "" ,required=true) TrpcAssetsUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.assetsUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/assets.upload")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upload", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Assets" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response assetsUpload(
@Parameter(description = "" ,required=true) TrpcAssetsUploadBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.assetsUpload(body,securityContext);
    }
    @POST
    @Path("/trpc/blocks.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksCreate(
@Parameter(description = "" ,required=true) TrpcBlocksCreateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.blocksCreate(body,securityContext);
    }
    @POST
    @Path("/trpc/blocks.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksDelete(
@Parameter(description = "" ,required=true) TrpcBlocksDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.blocksDelete(body,securityContext);
    }
    @GET
    @Path("/trpc/blocks.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksList(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.blocksList(securityContext);
    }
    @POST
    @Path("/trpc/blocks.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Blocks" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response blocksUpdate(
@Parameter(description = "" ,required=true) TrpcBlocksUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.blocksUpdate(body,securityContext);
    }
    @GET
    @Path("/trpc/github.checkPluginCompatibility")
    
    @Produces({ "application/json" })
    @Operation(summary = "Check Plugin Compatibility", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCheckPluginCompatibility( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubCheckPluginCompatibility(input,securityContext);
    }
    @POST
    @Path("/trpc/github.commitFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Commit File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCommitFile(
@Parameter(description = "" ,required=true) TrpcGithubCommitFileBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubCommitFile(body,securityContext);
    }
    @POST
    @Path("/trpc/github.connect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubConnect(
@Parameter(description = "" ,required=true) TrpcGithubConnectBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubConnect(body,securityContext);
    }
    @POST
    @Path("/trpc/github.createBranch")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Branch", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCreateBranch(
@Parameter(description = "" ,required=true) TrpcGithubCreateBranchBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubCreateBranch(body,securityContext);
    }
    @POST
    @Path("/trpc/github.createPullRequest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create Pull Request", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubCreatePullRequest(
@Parameter(description = "" ,required=true) TrpcGithubCreatePullRequestBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubCreatePullRequest(body,securityContext);
    }
    @POST
    @Path("/trpc/github.deleteFile")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubDeleteFile(
@Parameter(description = "" ,required=true) TrpcGithubDeleteFileBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubDeleteFile(body,securityContext);
    }
    @GET
    @Path("/trpc/github.detectJekyll")
    
    @Produces({ "application/json" })
    @Operation(summary = "Detect Jekyll", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubDetectJekyll( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubDetectJekyll(input,securityContext);
    }
    @POST
    @Path("/trpc/github.disconnect")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubDisconnect(
@Parameter(description = "" ) TrpcGithubDisconnectBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubDisconnect(body,securityContext);
    }
    @POST
    @Path("/trpc/github.generateActionsWorkflow")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Actions Workflow", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGenerateActionsWorkflow(
@Parameter(description = "" ,required=true) TrpcGithubGenerateActionsWorkflowBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubGenerateActionsWorkflow(body,securityContext);
    }
    @GET
    @Path("/trpc/github.getFile")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetFile( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubGetFile(input,securityContext);
    }
    @GET
    @Path("/trpc/github.getJekyllConfig")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetJekyllConfig( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubGetJekyllConfig(input,securityContext);
    }
    @GET
    @Path("/trpc/github.getPagesStatus")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Pages Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetPagesStatus( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubGetPagesStatus(input,securityContext);
    }
    @GET
    @Path("/trpc/github.getRateLimit")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Rate Limit", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubGetRateLimit(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubGetRateLimit(securityContext);
    }
    @GET
    @Path("/trpc/github.inventory")
    
    @Produces({ "application/json" })
    @Operation(summary = "Inventory", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubInventory( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubInventory(input,securityContext);
    }
    @GET
    @Path("/trpc/github.listBranches")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Branches", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubListBranches( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubListBranches(input,securityContext);
    }
    @GET
    @Path("/trpc/github.listFiles")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Files", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubListFiles( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubListFiles(input,securityContext);
    }
    @GET
    @Path("/trpc/github.listRepos")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Repos", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubListRepos( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubListRepos(input,securityContext);
    }
    @GET
    @Path("/trpc/github.repositories")
    
    @Produces({ "application/json" })
    @Operation(summary = "Repositories", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubRepositories( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubRepositories(input,securityContext);
    }
    @GET
    @Path("/trpc/github.reviewFile")
    
    @Produces({ "application/json" })
    @Operation(summary = "Review File", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubReviewFile( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubReviewFile(input,securityContext);
    }
    @GET
    @Path("/trpc/github.status")
    
    @Produces({ "application/json" })
    @Operation(summary = "Status", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubStatus(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubStatus(securityContext);
    }
    @POST
    @Path("/trpc/github.updateJekyllConfig")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Jekyll Config", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Github" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response githubUpdateJekyllConfig(
@Parameter(description = "" ,required=true) TrpcGithubUpdateJekyllConfigBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.githubUpdateJekyllConfig(body,securityContext);
    }
    @POST
    @Path("/trpc/notifications.registerDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Register Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Notifications" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response notificationsRegisterDevice(
@Parameter(description = "" ,required=true) TrpcNotificationsRegisterDeviceBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.notificationsRegisterDevice(body,securityContext);
    }
    @POST
    @Path("/trpc/notifications.unregisterDevice")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Unregister Device", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Notifications" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response notificationsUnregisterDevice(
@Parameter(description = "" ,required=true) TrpcNotificationsUnregisterDeviceBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.notificationsUnregisterDevice(body,securityContext);
    }
    @POST
    @Path("/trpc/posts.autosave")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Autosave", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsAutosave(
@Parameter(description = "" ,required=true) TrpcPostsAutosaveBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsAutosave(body,securityContext);
    }
    @POST
    @Path("/trpc/posts.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsDelete(
@Parameter(description = "" ,required=true) TrpcPostsDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsDelete(body,securityContext);
    }
    @GET
    @Path("/trpc/posts.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsGet( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsGet(input,securityContext);
    }
    @GET
    @Path("/trpc/posts.getFrontMatterTemplates")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Front Matter Templates", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsGetFrontMatterTemplates( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsGetFrontMatterTemplates(input,securityContext);
    }
    @GET
    @Path("/trpc/posts.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsList( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsList(input,securityContext);
    }
    @POST
    @Path("/trpc/posts.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsUpdate(
@Parameter(description = "" ,required=true) TrpcPostsUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/posts.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Posts" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response postsUpsert(
@Parameter(description = "" ,required=true) TrpcPostsUpsertBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postsUpsert(body,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingDelete(
@Parameter(description = "" ,required=true) TrpcRepurposingDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.repurposingDelete(body,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.generate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingGenerate(
@Parameter(description = "" ,required=true) TrpcRepurposingGenerateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.repurposingGenerate(body,securityContext);
    }
    @GET
    @Path("/trpc/repurposing.getById")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get By Id", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingGetById( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.repurposingGetById(input,securityContext);
    }
    @GET
    @Path("/trpc/repurposing.getByPost")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingGetByPost( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.repurposingGetByPost(input,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.regenerate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Regenerate", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingRegenerate(
@Parameter(description = "" ,required=true) TrpcRepurposingRegenerateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.repurposingRegenerate(body,securityContext);
    }
    @POST
    @Path("/trpc/repurposing.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Repurposing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response repurposingUpdate(
@Parameter(description = "" ,required=true) TrpcRepurposingUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.repurposingUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.cancel")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerCancel(
@Parameter(description = "" ,required=true) TrpcSchedulerCancelBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerCancel(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.cancelAll")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel All", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerCancelAll(
@Parameter(description = "" ,required=true) TrpcSchedulerCancelAllBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerCancelAll(body,securityContext);
    }
    @GET
    @Path("/trpc/scheduler.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerList( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerList(input,securityContext);
    }
    @GET
    @Path("/trpc/scheduler.listHeartbeatJobs")
    
    @Produces({ "application/json" })
    @Operation(summary = "List Heartbeat Jobs", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerListHeartbeatJobs( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerListHeartbeatJobs(input,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.markFailed")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Failed", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerMarkFailed(
@Parameter(description = "" ,required=true) TrpcSchedulerMarkFailedBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerMarkFailed(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.markPublished")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Mark Published", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerMarkPublished(
@Parameter(description = "" ,required=true) TrpcSchedulerMarkPublishedBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerMarkPublished(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.reschedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerReschedule(
@Parameter(description = "" ,required=true) TrpcSchedulerRescheduleBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerReschedule(body,securityContext);
    }
    @POST
    @Path("/trpc/scheduler.schedule")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Scheduler" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response schedulerSchedule(
@Parameter(description = "" ,required=true) TrpcSchedulerScheduleBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.schedulerSchedule(body,securityContext);
    }
    @POST
    @Path("/trpc/sites.delete")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Delete", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesDelete(
@Parameter(description = "" ,required=true) TrpcSitesDeleteBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sitesDelete(body,securityContext);
    }
    @GET
    @Path("/trpc/sites.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesGet( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sitesGet(input,securityContext);
    }
    @GET
    @Path("/trpc/sites.list")
    
    @Produces({ "application/json" })
    @Operation(summary = "List", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesList(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sitesList(securityContext);
    }
    @POST
    @Path("/trpc/sites.update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesUpdate(
@Parameter(description = "" ,required=true) TrpcSitesUpdateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sitesUpdate(body,securityContext);
    }
    @POST
    @Path("/trpc/sites.upsert")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Upsert", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Sites" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response sitesUpsert(
@Parameter(description = "" ,required=true) TrpcSitesUpsertBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sitesUpsert(body,securityContext);
    }
    @POST
    @Path("/trpc/snapshots.create")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Create", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response snapshotsCreate(
@Parameter(description = "" ,required=true) TrpcSnapshotsCreateBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.snapshotsCreate(body,securityContext);
    }
    @GET
    @Path("/trpc/snapshots.get")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response snapshotsGet( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.snapshotsGet(input,securityContext);
    }
    @GET
    @Path("/trpc/snapshots.listByPost")
    
    @Produces({ "application/json" })
    @Operation(summary = "List By Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Snapshots" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response snapshotsListByPost( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.snapshotsListByPost(input,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.cancelScheduledPost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Cancel Scheduled Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaCancelScheduledPost(
@Parameter(description = "" ,required=true) TrpcSocialMediaCancelScheduledPostBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaCancelScheduledPost(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.connectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Connect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaConnectAccount(
@Parameter(description = "" ,required=true) TrpcSocialMediaConnectAccountBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaConnectAccount(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.disconnectAccount")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Disconnect Account", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaDisconnectAccount(
@Parameter(description = "" ,required=true) TrpcSocialMediaDisconnectAccountBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaDisconnectAccount(body,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAccountDetails")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Account Details", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAccountDetails( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaGetAccountDetails(input,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAccounts")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Accounts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAccounts(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaGetAccounts(securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAnalyticsByPlatform")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics By Platform", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAnalyticsByPlatform( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaGetAnalyticsByPlatform(input,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getAnalyticsSummary")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Analytics Summary", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetAnalyticsSummary(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaGetAnalyticsSummary(securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getContentAnalytics")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Content Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetContentAnalytics( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaGetContentAnalytics(input,securityContext);
    }
    @GET
    @Path("/trpc/socialMedia.getScheduledPosts")
    
    @Produces({ "application/json" })
    @Operation(summary = "Get Scheduled Posts", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaGetScheduledPosts( @NotNull  @QueryParam("input") String input,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaGetScheduledPosts(input,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.publishContent")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Content", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaPublishContent(
@Parameter(description = "" ,required=true) TrpcSocialMediaPublishContentBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaPublishContent(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.reschedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Reschedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaReschedulePost(
@Parameter(description = "" ,required=true) TrpcSocialMediaReschedulePostBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaReschedulePost(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.schedulePost")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Schedule Post", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaSchedulePost(
@Parameter(description = "" ,required=true) TrpcSocialMediaSchedulePostBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaSchedulePost(body,securityContext);
    }
    @POST
    @Path("/trpc/socialMedia.syncAnalytics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Sync Analytics", description = "", security = {
        @SecurityRequirement(name = "bearerAuth")
    }, tags={ "Social Media" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public Response socialMediaSyncAnalytics(
@Parameter(description = "" ,required=true) TrpcSocialMediaSyncAnalyticsBody body
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.socialMediaSyncAnalytics(body,securityContext);
    }
}
