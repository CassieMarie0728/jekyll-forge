package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcgithubGenerateActionsWorkflowJson   {
  private String owner = null;  private String repo = null;  private String branch = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("branch")
  @NotNull
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcgithubGenerateActionsWorkflowJson apitrpcgithubGenerateActionsWorkflowJson = (ApitrpcgithubGenerateActionsWorkflowJson) o;
    return Objects.equals(owner, apitrpcgithubGenerateActionsWorkflowJson.owner) &&
        Objects.equals(repo, apitrpcgithubGenerateActionsWorkflowJson.repo) &&
        Objects.equals(branch, apitrpcgithubGenerateActionsWorkflowJson.branch);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, branch);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubGenerateActionsWorkflowJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
