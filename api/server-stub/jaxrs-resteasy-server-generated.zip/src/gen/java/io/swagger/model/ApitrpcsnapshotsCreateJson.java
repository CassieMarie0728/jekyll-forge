package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcsnapshotsCreateJson   {
  private BigDecimal siteId = null;  private BigDecimal postId = null;  private String postPath = null;  private String label = null;  private Object reason = null;  private String markdown = null;  private Object frontMatter = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("postPath")
  @NotNull
  public String getPostPath() {
    return postPath;
  }
  public void setPostPath(String postPath) {
    this.postPath = postPath;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("label")
  @NotNull
  public String getLabel() {
    return label;
  }
  public void setLabel(String label) {
    this.label = label;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("reason")
  @NotNull
  public Object getReason() {
    return reason;
  }
  public void setReason(Object reason) {
    this.reason = reason;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("markdown")
  @NotNull
  public String getMarkdown() {
    return markdown;
  }
  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("frontMatter")
  @NotNull
  public Object getFrontMatter() {
    return frontMatter;
  }
  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsnapshotsCreateJson apitrpcsnapshotsCreateJson = (ApitrpcsnapshotsCreateJson) o;
    return Objects.equals(siteId, apitrpcsnapshotsCreateJson.siteId) &&
        Objects.equals(postId, apitrpcsnapshotsCreateJson.postId) &&
        Objects.equals(postPath, apitrpcsnapshotsCreateJson.postPath) &&
        Objects.equals(label, apitrpcsnapshotsCreateJson.label) &&
        Objects.equals(reason, apitrpcsnapshotsCreateJson.reason) &&
        Objects.equals(markdown, apitrpcsnapshotsCreateJson.markdown) &&
        Objects.equals(frontMatter, apitrpcsnapshotsCreateJson.frontMatter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, postPath, label, reason, markdown, frontMatter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsnapshotsCreateJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    postPath: ").append(toIndentedString(postPath)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
