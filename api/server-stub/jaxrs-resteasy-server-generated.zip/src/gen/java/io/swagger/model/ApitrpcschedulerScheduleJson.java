package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcschedulerScheduleJson   {
  private BigDecimal siteId = null;  private BigDecimal postId = null;  private String draftPath = null;  private String targetPath = null;  private Object scheduledAt = null;  private String timezone = null;  private String commitMessage = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("draftPath")
  @NotNull
  public String getDraftPath() {
    return draftPath;
  }
  public void setDraftPath(String draftPath) {
    this.draftPath = draftPath;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("targetPath")
  @NotNull
  public String getTargetPath() {
    return targetPath;
  }
  public void setTargetPath(String targetPath) {
    this.targetPath = targetPath;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("scheduledAt")
  @NotNull
  public Object getScheduledAt() {
    return scheduledAt;
  }
  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("timezone")
  @NotNull
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("commitMessage")
  @NotNull
  public String getCommitMessage() {
    return commitMessage;
  }
  public void setCommitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcschedulerScheduleJson apitrpcschedulerScheduleJson = (ApitrpcschedulerScheduleJson) o;
    return Objects.equals(siteId, apitrpcschedulerScheduleJson.siteId) &&
        Objects.equals(postId, apitrpcschedulerScheduleJson.postId) &&
        Objects.equals(draftPath, apitrpcschedulerScheduleJson.draftPath) &&
        Objects.equals(targetPath, apitrpcschedulerScheduleJson.targetPath) &&
        Objects.equals(scheduledAt, apitrpcschedulerScheduleJson.scheduledAt) &&
        Objects.equals(timezone, apitrpcschedulerScheduleJson.timezone) &&
        Objects.equals(commitMessage, apitrpcschedulerScheduleJson.commitMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(siteId, postId, draftPath, targetPath, scheduledAt, timezone, commitMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcschedulerScheduleJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    draftPath: ").append(toIndentedString(draftPath)).append("\n");
    sb.append("    targetPath: ").append(toIndentedString(targetPath)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
