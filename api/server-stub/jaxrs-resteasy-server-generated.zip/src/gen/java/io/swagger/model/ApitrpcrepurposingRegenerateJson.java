package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcrepurposingRegenerateJson   {
  private BigDecimal id = null;  private BigDecimal postId = null;  private BigDecimal siteId = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }
  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }
  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcrepurposingRegenerateJson apitrpcrepurposingRegenerateJson = (ApitrpcrepurposingRegenerateJson) o;
    return Objects.equals(id, apitrpcrepurposingRegenerateJson.id) &&
        Objects.equals(postId, apitrpcrepurposingRegenerateJson.postId) &&
        Objects.equals(siteId, apitrpcrepurposingRegenerateJson.siteId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, postId, siteId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingRegenerateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
