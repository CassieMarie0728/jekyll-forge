package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcsitesUpdateJson   {
  private BigDecimal id = null;  private Boolean isFavorite = null;  private String selectedBranch = null;  private String rootPath = null;  private String timezone = null;  private String defaultLayout = null;  private String defaultAssetPath = null;  private String aiVoiceProfile = null;  private Object settings = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }
  public void setId(BigDecimal id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("isFavorite")
  @NotNull
  public Boolean isIsFavorite() {
    return isFavorite;
  }
  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("selectedBranch")
  @NotNull
  public String getSelectedBranch() {
    return selectedBranch;
  }
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("rootPath")
  @NotNull
  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timezone")
  @NotNull
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultLayout")
  @NotNull
  public String getDefaultLayout() {
    return defaultLayout;
  }
  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultAssetPath")
  @NotNull
  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }
  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("aiVoiceProfile")
  @NotNull
  public String getAiVoiceProfile() {
    return aiVoiceProfile;
  }
  public void setAiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("settings")
  @NotNull
  public Object getSettings() {
    return settings;
  }
  public void setSettings(Object settings) {
    this.settings = settings;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpdateJson apitrpcsitesUpdateJson = (ApitrpcsitesUpdateJson) o;
    return Objects.equals(id, apitrpcsitesUpdateJson.id) &&
        Objects.equals(isFavorite, apitrpcsitesUpdateJson.isFavorite) &&
        Objects.equals(selectedBranch, apitrpcsitesUpdateJson.selectedBranch) &&
        Objects.equals(rootPath, apitrpcsitesUpdateJson.rootPath) &&
        Objects.equals(timezone, apitrpcsitesUpdateJson.timezone) &&
        Objects.equals(defaultLayout, apitrpcsitesUpdateJson.defaultLayout) &&
        Objects.equals(defaultAssetPath, apitrpcsitesUpdateJson.defaultAssetPath) &&
        Objects.equals(aiVoiceProfile, apitrpcsitesUpdateJson.aiVoiceProfile) &&
        Objects.equals(settings, apitrpcsitesUpdateJson.settings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, isFavorite, selectedBranch, rootPath, timezone, defaultLayout, defaultAssetPath, aiVoiceProfile, settings);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("    aiVoiceProfile: ").append(toIndentedString(aiVoiceProfile)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
