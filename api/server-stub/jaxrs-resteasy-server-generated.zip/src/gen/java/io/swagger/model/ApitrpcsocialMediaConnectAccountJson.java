package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcsocialMediaConnectAccountJson   {
  /**
   * Gets or Sets platform
   */
  public enum PlatformEnum {
    TWITTER("twitter"),
    LINKEDIN("linkedin"),
    FACEBOOK("facebook"),
    INSTAGRAM("instagram");
    private String value;

    PlatformEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private PlatformEnum platform = null;  private String accessToken = null;  private String refreshToken = null;  private Object expiresAt = null;  private String accountId = null;  private String username = null;  private String displayName = null;  private String profileImageUrl = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("platform")
  @NotNull
  public PlatformEnum getPlatform() {
    return platform;
  }
  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("accessToken")
  @NotNull
  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("refreshToken")
  @NotNull
  public String getRefreshToken() {
    return refreshToken;
  }
  public void setRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("expiresAt")
  @NotNull
  public Object getExpiresAt() {
    return expiresAt;
  }
  public void setExpiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("accountId")
  @NotNull
  public String getAccountId() {
    return accountId;
  }
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  @NotNull
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("displayName")
  @NotNull
  public String getDisplayName() {
    return displayName;
  }
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("profileImageUrl")
  @NotNull
  public String getProfileImageUrl() {
    return profileImageUrl;
  }
  public void setProfileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsocialMediaConnectAccountJson apitrpcsocialMediaConnectAccountJson = (ApitrpcsocialMediaConnectAccountJson) o;
    return Objects.equals(platform, apitrpcsocialMediaConnectAccountJson.platform) &&
        Objects.equals(accessToken, apitrpcsocialMediaConnectAccountJson.accessToken) &&
        Objects.equals(refreshToken, apitrpcsocialMediaConnectAccountJson.refreshToken) &&
        Objects.equals(expiresAt, apitrpcsocialMediaConnectAccountJson.expiresAt) &&
        Objects.equals(accountId, apitrpcsocialMediaConnectAccountJson.accountId) &&
        Objects.equals(username, apitrpcsocialMediaConnectAccountJson.username) &&
        Objects.equals(displayName, apitrpcsocialMediaConnectAccountJson.displayName) &&
        Objects.equals(profileImageUrl, apitrpcsocialMediaConnectAccountJson.profileImageUrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(platform, accessToken, refreshToken, expiresAt, accountId, username, displayName, profileImageUrl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaConnectAccountJson {\n");
    
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    accessToken: ").append(toIndentedString(accessToken)).append("\n");
    sb.append("    refreshToken: ").append(toIndentedString(refreshToken)).append("\n");
    sb.append("    expiresAt: ").append(toIndentedString(expiresAt)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    profileImageUrl: ").append(toIndentedString(profileImageUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
