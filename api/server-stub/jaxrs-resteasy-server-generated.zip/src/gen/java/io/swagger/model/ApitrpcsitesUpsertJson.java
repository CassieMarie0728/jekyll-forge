package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcsitesUpsertJson   {
  private String owner = null;  private String repo = null;  private String defaultBranch = null;  private String selectedBranch = null;  private String rootPath = null;  private Boolean isJekyll = null;  private Boolean isFavorite = null;  private String timezone = null;  private String defaultLayout = null;  private String defaultAssetPath = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }
  public void setRepo(String repo) {
    this.repo = repo;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultBranch")
  @NotNull
  public String getDefaultBranch() {
    return defaultBranch;
  }
  public void setDefaultBranch(String defaultBranch) {
    this.defaultBranch = defaultBranch;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("selectedBranch")
  @NotNull
  public String getSelectedBranch() {
    return selectedBranch;
  }
  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("rootPath")
  @NotNull
  public String getRootPath() {
    return rootPath;
  }
  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("isJekyll")
  @NotNull
  public Boolean isIsJekyll() {
    return isJekyll;
  }
  public void setIsJekyll(Boolean isJekyll) {
    this.isJekyll = isJekyll;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("isFavorite")
  @NotNull
  public Boolean isIsFavorite() {
    return isFavorite;
  }
  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timezone")
  @NotNull
  public String getTimezone() {
    return timezone;
  }
  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultLayout")
  @NotNull
  public String getDefaultLayout() {
    return defaultLayout;
  }
  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultAssetPath")
  @NotNull
  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }
  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcsitesUpsertJson apitrpcsitesUpsertJson = (ApitrpcsitesUpsertJson) o;
    return Objects.equals(owner, apitrpcsitesUpsertJson.owner) &&
        Objects.equals(repo, apitrpcsitesUpsertJson.repo) &&
        Objects.equals(defaultBranch, apitrpcsitesUpsertJson.defaultBranch) &&
        Objects.equals(selectedBranch, apitrpcsitesUpsertJson.selectedBranch) &&
        Objects.equals(rootPath, apitrpcsitesUpsertJson.rootPath) &&
        Objects.equals(isJekyll, apitrpcsitesUpsertJson.isJekyll) &&
        Objects.equals(isFavorite, apitrpcsitesUpsertJson.isFavorite) &&
        Objects.equals(timezone, apitrpcsitesUpsertJson.timezone) &&
        Objects.equals(defaultLayout, apitrpcsitesUpsertJson.defaultLayout) &&
        Objects.equals(defaultAssetPath, apitrpcsitesUpsertJson.defaultAssetPath);
  }

  @Override
  public int hashCode() {
    return Objects.hash(owner, repo, defaultBranch, selectedBranch, rootPath, isJekyll, isFavorite, timezone, defaultLayout, defaultAssetPath);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpsertJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    defaultBranch: ").append(toIndentedString(defaultBranch)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    isJekyll: ").append(toIndentedString(isJekyll)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
