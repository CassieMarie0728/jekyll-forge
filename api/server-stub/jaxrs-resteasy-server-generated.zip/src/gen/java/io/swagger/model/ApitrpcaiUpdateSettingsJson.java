package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2026-09-27T19:37:15.587817508Z[GMT]")
public class ApitrpcaiUpdateSettingsJson   {
  private Boolean enabled = null;  private BigDecimal temperature = null;  private BigDecimal maxTokens = null;  private String systemPrompt = null;  private String brandVoicePrompt = null;  private String safetyPrompt = null;  private Boolean streaming = null;  private String defaultLanguage = null;  private String defaultTone = null;  private BigDecimal budgetLimitCents = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  @NotNull
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("temperature")
  @NotNull
  public BigDecimal getTemperature() {
    return temperature;
  }
  public void setTemperature(BigDecimal temperature) {
    this.temperature = temperature;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxTokens")
  @NotNull
  public BigDecimal getMaxTokens() {
    return maxTokens;
  }
  public void setMaxTokens(BigDecimal maxTokens) {
    this.maxTokens = maxTokens;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("systemPrompt")
  @NotNull
  public String getSystemPrompt() {
    return systemPrompt;
  }
  public void setSystemPrompt(String systemPrompt) {
    this.systemPrompt = systemPrompt;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("brandVoicePrompt")
  @NotNull
  public String getBrandVoicePrompt() {
    return brandVoicePrompt;
  }
  public void setBrandVoicePrompt(String brandVoicePrompt) {
    this.brandVoicePrompt = brandVoicePrompt;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("safetyPrompt")
  @NotNull
  public String getSafetyPrompt() {
    return safetyPrompt;
  }
  public void setSafetyPrompt(String safetyPrompt) {
    this.safetyPrompt = safetyPrompt;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("streaming")
  @NotNull
  public Boolean isStreaming() {
    return streaming;
  }
  public void setStreaming(Boolean streaming) {
    this.streaming = streaming;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultLanguage")
  @NotNull
  public String getDefaultLanguage() {
    return defaultLanguage;
  }
  public void setDefaultLanguage(String defaultLanguage) {
    this.defaultLanguage = defaultLanguage;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultTone")
  @NotNull
  public String getDefaultTone() {
    return defaultTone;
  }
  public void setDefaultTone(String defaultTone) {
    this.defaultTone = defaultTone;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("budgetLimitCents")
  public BigDecimal getBudgetLimitCents() {
    return budgetLimitCents;
  }
  public void setBudgetLimitCents(BigDecimal budgetLimitCents) {
    this.budgetLimitCents = budgetLimitCents;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApitrpcaiUpdateSettingsJson apitrpcaiUpdateSettingsJson = (ApitrpcaiUpdateSettingsJson) o;
    return Objects.equals(enabled, apitrpcaiUpdateSettingsJson.enabled) &&
        Objects.equals(temperature, apitrpcaiUpdateSettingsJson.temperature) &&
        Objects.equals(maxTokens, apitrpcaiUpdateSettingsJson.maxTokens) &&
        Objects.equals(systemPrompt, apitrpcaiUpdateSettingsJson.systemPrompt) &&
        Objects.equals(brandVoicePrompt, apitrpcaiUpdateSettingsJson.brandVoicePrompt) &&
        Objects.equals(safetyPrompt, apitrpcaiUpdateSettingsJson.safetyPrompt) &&
        Objects.equals(streaming, apitrpcaiUpdateSettingsJson.streaming) &&
        Objects.equals(defaultLanguage, apitrpcaiUpdateSettingsJson.defaultLanguage) &&
        Objects.equals(defaultTone, apitrpcaiUpdateSettingsJson.defaultTone) &&
        Objects.equals(budgetLimitCents, apitrpcaiUpdateSettingsJson.budgetLimitCents);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enabled, temperature, maxTokens, systemPrompt, brandVoicePrompt, safetyPrompt, streaming, defaultLanguage, defaultTone, budgetLimitCents);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiUpdateSettingsJson {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    temperature: ").append(toIndentedString(temperature)).append("\n");
    sb.append("    maxTokens: ").append(toIndentedString(maxTokens)).append("\n");
    sb.append("    systemPrompt: ").append(toIndentedString(systemPrompt)).append("\n");
    sb.append("    brandVoicePrompt: ").append(toIndentedString(brandVoicePrompt)).append("\n");
    sb.append("    safetyPrompt: ").append(toIndentedString(safetyPrompt)).append("\n");
    sb.append("    streaming: ").append(toIndentedString(streaming)).append("\n");
    sb.append("    defaultLanguage: ").append(toIndentedString(defaultLanguage)).append("\n");
    sb.append("    defaultTone: ").append(toIndentedString(defaultTone)).append("\n");
    sb.append("    budgetLimitCents: ").append(toIndentedString(budgetLimitCents)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
