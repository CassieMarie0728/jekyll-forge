package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class AbTestingApiServiceImpl implements AbTestingApi {
    /**
     * Apply Winner
     *
     */
    public TRPCResponse abTestingApplyWinner(TrpcAbTestingApplyWinnerBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Complete Test
     *
     */
    public TRPCResponse abTestingCompleteTest(TrpcAbTestingCompleteTestBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Generate Variations
     *
     */
    public TRPCResponse abTestingGenerateVariations(TrpcAbTestingGenerateVariationsBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Results
     *
     */
    public TRPCResponse abTestingGetResults(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Variations
     *
     */
    public TRPCResponse abTestingGetVariations(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Publish Variation
     *
     */
    public TRPCResponse abTestingPublishVariation(TrpcAbTestingPublishVariationBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Update Metrics
     *
     */
    public TRPCResponse abTestingUpdateMetrics(TrpcAbTestingUpdateMetricsBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

