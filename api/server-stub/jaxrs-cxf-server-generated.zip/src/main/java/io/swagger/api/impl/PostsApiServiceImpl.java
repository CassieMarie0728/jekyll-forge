package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcPostsAutosaveBody;
import io.swagger.model.TrpcPostsDeleteBody;
import io.swagger.model.TrpcPostsUpdateBody;
import io.swagger.model.TrpcPostsUpsertBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class PostsApiServiceImpl implements PostsApi {
    /**
     * Autosave
     *
     */
    public TRPCResponse postsAutosave(TrpcPostsAutosaveBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Delete
     *
     */
    public TRPCResponse postsDelete(TrpcPostsDeleteBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get
     *
     */
    public TRPCResponse postsGet(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Front Matter Templates
     *
     */
    public TRPCResponse postsGetFrontMatterTemplates(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List
     *
     */
    public TRPCResponse postsList(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Update
     *
     */
    public TRPCResponse postsUpdate(TrpcPostsUpdateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Upsert
     *
     */
    public TRPCResponse postsUpsert(TrpcPostsUpsertBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

