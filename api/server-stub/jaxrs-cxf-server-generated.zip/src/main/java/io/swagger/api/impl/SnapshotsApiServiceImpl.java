package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcSnapshotsCreateBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class SnapshotsApiServiceImpl implements SnapshotsApi {
    /**
     * Create
     *
     */
    public TRPCResponse snapshotsCreate(TrpcSnapshotsCreateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get
     *
     */
    public TRPCResponse snapshotsGet(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List By Post
     *
     */
    public TRPCResponse snapshotsListByPost(String input) {
        // TODO: Implement...
        
        return null;
    }
    
}

