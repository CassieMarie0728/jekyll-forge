package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcSchedulerCancelAllBody;
import io.swagger.model.TrpcSchedulerCancelBody;
import io.swagger.model.TrpcSchedulerMarkFailedBody;
import io.swagger.model.TrpcSchedulerMarkPublishedBody;
import io.swagger.model.TrpcSchedulerRescheduleBody;
import io.swagger.model.TrpcSchedulerScheduleBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class SchedulerApiServiceImpl implements SchedulerApi {
    /**
     * Cancel
     *
     */
    public TRPCResponse schedulerCancel(TrpcSchedulerCancelBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Cancel All
     *
     */
    public TRPCResponse schedulerCancelAll(TrpcSchedulerCancelAllBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List
     *
     */
    public TRPCResponse schedulerList(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List Heartbeat Jobs
     *
     */
    public TRPCResponse schedulerListHeartbeatJobs(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Mark Failed
     *
     */
    public TRPCResponse schedulerMarkFailed(TrpcSchedulerMarkFailedBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Mark Published
     *
     */
    public TRPCResponse schedulerMarkPublished(TrpcSchedulerMarkPublishedBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Reschedule
     *
     */
    public TRPCResponse schedulerReschedule(TrpcSchedulerRescheduleBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Schedule
     *
     */
    public TRPCResponse schedulerSchedule(TrpcSchedulerScheduleBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

