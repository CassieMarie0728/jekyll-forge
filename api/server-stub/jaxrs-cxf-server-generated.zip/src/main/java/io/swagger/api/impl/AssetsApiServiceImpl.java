package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAssetsDeleteBody;
import io.swagger.model.TrpcAssetsGenerateAltTextBody;
import io.swagger.model.TrpcAssetsReoptimizeBody;
import io.swagger.model.TrpcAssetsUpdateBody;
import io.swagger.model.TrpcAssetsUploadBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class AssetsApiServiceImpl implements AssetsApi {
    /**
     * Delete
     *
     */
    public TRPCResponse assetsDelete(TrpcAssetsDeleteBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Generate Alt Text
     *
     */
    public TRPCResponse assetsGenerateAltText(TrpcAssetsGenerateAltTextBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List
     *
     */
    public TRPCResponse assetsList(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Reoptimize
     *
     */
    public TRPCResponse assetsReoptimize(TrpcAssetsReoptimizeBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Update
     *
     */
    public TRPCResponse assetsUpdate(TrpcAssetsUpdateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Upload
     *
     */
    public TRPCResponse assetsUpload(TrpcAssetsUploadBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

