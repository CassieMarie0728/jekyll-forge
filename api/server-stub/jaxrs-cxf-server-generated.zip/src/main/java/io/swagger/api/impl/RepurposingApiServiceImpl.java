package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcRepurposingDeleteBody;
import io.swagger.model.TrpcRepurposingGenerateBody;
import io.swagger.model.TrpcRepurposingRegenerateBody;
import io.swagger.model.TrpcRepurposingUpdateBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class RepurposingApiServiceImpl implements RepurposingApi {
    /**
     * Delete
     *
     */
    public TRPCResponse repurposingDelete(TrpcRepurposingDeleteBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Generate
     *
     */
    public TRPCResponse repurposingGenerate(TrpcRepurposingGenerateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get By Id
     *
     */
    public TRPCResponse repurposingGetById(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get By Post
     *
     */
    public TRPCResponse repurposingGetByPost(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Regenerate
     *
     */
    public TRPCResponse repurposingRegenerate(TrpcRepurposingRegenerateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Update
     *
     */
    public TRPCResponse repurposingUpdate(TrpcRepurposingUpdateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

