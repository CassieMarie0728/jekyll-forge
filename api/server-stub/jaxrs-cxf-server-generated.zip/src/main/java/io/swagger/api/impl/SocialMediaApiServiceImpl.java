package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcSocialMediaCancelScheduledPostBody;
import io.swagger.model.TrpcSocialMediaConnectAccountBody;
import io.swagger.model.TrpcSocialMediaDisconnectAccountBody;
import io.swagger.model.TrpcSocialMediaPublishContentBody;
import io.swagger.model.TrpcSocialMediaReschedulePostBody;
import io.swagger.model.TrpcSocialMediaSchedulePostBody;
import io.swagger.model.TrpcSocialMediaSyncAnalyticsBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class SocialMediaApiServiceImpl implements SocialMediaApi {
    /**
     * Cancel Scheduled Post
     *
     */
    public TRPCResponse socialMediaCancelScheduledPost(TrpcSocialMediaCancelScheduledPostBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Connect Account
     *
     */
    public TRPCResponse socialMediaConnectAccount(TrpcSocialMediaConnectAccountBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Disconnect Account
     *
     */
    public TRPCResponse socialMediaDisconnectAccount(TrpcSocialMediaDisconnectAccountBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Account Details
     *
     */
    public TRPCResponse socialMediaGetAccountDetails(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Accounts
     *
     */
    public TRPCResponse socialMediaGetAccounts() {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Analytics By Platform
     *
     */
    public TRPCResponse socialMediaGetAnalyticsByPlatform(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Analytics Summary
     *
     */
    public TRPCResponse socialMediaGetAnalyticsSummary() {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Content Analytics
     *
     */
    public TRPCResponse socialMediaGetContentAnalytics(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Scheduled Posts
     *
     */
    public TRPCResponse socialMediaGetScheduledPosts(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Publish Content
     *
     */
    public TRPCResponse socialMediaPublishContent(TrpcSocialMediaPublishContentBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Reschedule Post
     *
     */
    public TRPCResponse socialMediaReschedulePost(TrpcSocialMediaReschedulePostBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Schedule Post
     *
     */
    public TRPCResponse socialMediaSchedulePost(TrpcSocialMediaSchedulePostBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Sync Analytics
     *
     */
    public TRPCResponse socialMediaSyncAnalytics(TrpcSocialMediaSyncAnalyticsBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

