package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcBlocksCreateBody;
import io.swagger.model.TrpcBlocksDeleteBody;
import io.swagger.model.TrpcBlocksUpdateBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class BlocksApiServiceImpl implements BlocksApi {
    /**
     * Create
     *
     */
    public TRPCResponse blocksCreate(TrpcBlocksCreateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Delete
     *
     */
    public TRPCResponse blocksDelete(TrpcBlocksDeleteBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List
     *
     */
    public TRPCResponse blocksList() {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Update
     *
     */
    public TRPCResponse blocksUpdate(TrpcBlocksUpdateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

