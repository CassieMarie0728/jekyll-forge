package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcGithubCommitFileBody;
import io.swagger.model.TrpcGithubConnectBody;
import io.swagger.model.TrpcGithubCreateBranchBody;
import io.swagger.model.TrpcGithubCreatePullRequestBody;
import io.swagger.model.TrpcGithubDeleteFileBody;
import io.swagger.model.TrpcGithubDisconnectBody;
import io.swagger.model.TrpcGithubGenerateActionsWorkflowBody;
import io.swagger.model.TrpcGithubUpdateJekyllConfigBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class GithubApiServiceImpl implements GithubApi {
    /**
     * Check Plugin Compatibility
     *
     */
    public TRPCResponse githubCheckPluginCompatibility(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Commit File
     *
     */
    public TRPCResponse githubCommitFile(TrpcGithubCommitFileBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Connect
     *
     */
    public TRPCResponse githubConnect(TrpcGithubConnectBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Create Branch
     *
     */
    public TRPCResponse githubCreateBranch(TrpcGithubCreateBranchBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Create Pull Request
     *
     */
    public TRPCResponse githubCreatePullRequest(TrpcGithubCreatePullRequestBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Delete File
     *
     */
    public TRPCResponse githubDeleteFile(TrpcGithubDeleteFileBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Detect Jekyll
     *
     */
    public TRPCResponse githubDetectJekyll(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Disconnect
     *
     */
    public TRPCResponse githubDisconnect(TrpcGithubDisconnectBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Generate Actions Workflow
     *
     */
    public TRPCResponse githubGenerateActionsWorkflow(TrpcGithubGenerateActionsWorkflowBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get File
     *
     */
    public TRPCResponse githubGetFile(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Jekyll Config
     *
     */
    public TRPCResponse githubGetJekyllConfig(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Pages Status
     *
     */
    public TRPCResponse githubGetPagesStatus(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Rate Limit
     *
     */
    public TRPCResponse githubGetRateLimit() {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Inventory
     *
     */
    public TRPCResponse githubInventory(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List Branches
     *
     */
    public TRPCResponse githubListBranches(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List Files
     *
     */
    public TRPCResponse githubListFiles(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * List Repos
     *
     */
    public TRPCResponse githubListRepos(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Repositories
     *
     */
    public TRPCResponse githubRepositories(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Review File
     *
     */
    public TRPCResponse githubReviewFile(String input) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Status
     *
     */
    public TRPCResponse githubStatus() {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Update Jekyll Config
     *
     */
    public TRPCResponse githubUpdateJekyllConfig(TrpcGithubUpdateJekyllConfigBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

