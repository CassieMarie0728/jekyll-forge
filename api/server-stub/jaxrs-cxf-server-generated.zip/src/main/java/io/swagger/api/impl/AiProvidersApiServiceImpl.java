package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;

import org.apache.cxf.jaxrs.ext.multipart.*;


/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
public class AiProvidersApiServiceImpl implements AiProvidersApi {
    /**
     * Activate
     *
     */
    public TRPCResponse aiProvidersActivate(TrpcAiProvidersActivateBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Get Settings
     *
     */
    public TRPCResponse aiProvidersGetSettings() {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Remove
     *
     */
    public TRPCResponse aiProvidersRemove(TrpcAiProvidersRemoveBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Save
     *
     */
    public TRPCResponse aiProvidersSave(TrpcAiProvidersSaveBody body) {
        // TODO: Implement...
        
        return null;
    }
    
    /**
     * Test
     *
     */
    public TRPCResponse aiProvidersTest(TrpcAiProvidersTestBody body) {
        // TODO: Implement...
        
        return null;
    }
    
}

