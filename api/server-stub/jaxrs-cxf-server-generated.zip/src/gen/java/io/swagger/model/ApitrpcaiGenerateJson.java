package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcaiGenerateJson   {
  
  @Schema(required = true, description = "")
  private String task = null;
  
  @Schema(description = "")
  private String userPrompt = null;
  
  @Schema(description = "")
  private String selectedText = null;
  
  @Schema(description = "")
  private String postMarkdown = null;
  
  @Schema(description = "")
  private Object frontMatter = null;
  
  @Schema(description = "")
  private String tone = null;
  
  @Schema(description = "")
  private BigDecimal voiceProfileId = null;
 /**
   * Get task
   * @return task
  **/
  @JsonProperty("task")
  @NotNull
  public String getTask() {
    return task;
  }

  public void setTask(String task) {
    this.task = task;
  }

  public ApitrpcaiGenerateJson task(String task) {
    this.task = task;
    return this;
  }

 /**
   * Get userPrompt
   * @return userPrompt
  **/
  @JsonProperty("userPrompt")
  @NotNull
  public String getUserPrompt() {
    return userPrompt;
  }

  public void setUserPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
  }

  public ApitrpcaiGenerateJson userPrompt(String userPrompt) {
    this.userPrompt = userPrompt;
    return this;
  }

 /**
   * Get selectedText
   * @return selectedText
  **/
  @JsonProperty("selectedText")
  @NotNull
  public String getSelectedText() {
    return selectedText;
  }

  public void setSelectedText(String selectedText) {
    this.selectedText = selectedText;
  }

  public ApitrpcaiGenerateJson selectedText(String selectedText) {
    this.selectedText = selectedText;
    return this;
  }

 /**
   * Get postMarkdown
   * @return postMarkdown
  **/
  @JsonProperty("postMarkdown")
  @NotNull
  public String getPostMarkdown() {
    return postMarkdown;
  }

  public void setPostMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
  }

  public ApitrpcaiGenerateJson postMarkdown(String postMarkdown) {
    this.postMarkdown = postMarkdown;
    return this;
  }

 /**
   * Get frontMatter
   * @return frontMatter
  **/
  @JsonProperty("frontMatter")
  @NotNull
  public Object getFrontMatter() {
    return frontMatter;
  }

  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  public ApitrpcaiGenerateJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

 /**
   * Get tone
   * @return tone
  **/
  @JsonProperty("tone")
  @NotNull
  public String getTone() {
    return tone;
  }

  public void setTone(String tone) {
    this.tone = tone;
  }

  public ApitrpcaiGenerateJson tone(String tone) {
    this.tone = tone;
    return this;
  }

 /**
   * Get voiceProfileId
   * @return voiceProfileId
  **/
  @JsonProperty("voiceProfileId")
  @NotNull
  public BigDecimal getVoiceProfileId() {
    return voiceProfileId;
  }

  public void setVoiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
  }

  public ApitrpcaiGenerateJson voiceProfileId(BigDecimal voiceProfileId) {
    this.voiceProfileId = voiceProfileId;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiGenerateJson {\n");
    
    sb.append("    task: ").append(toIndentedString(task)).append("\n");
    sb.append("    userPrompt: ").append(toIndentedString(userPrompt)).append("\n");
    sb.append("    selectedText: ").append(toIndentedString(selectedText)).append("\n");
    sb.append("    postMarkdown: ").append(toIndentedString(postMarkdown)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    tone: ").append(toIndentedString(tone)).append("\n");
    sb.append("    voiceProfileId: ").append(toIndentedString(voiceProfileId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
