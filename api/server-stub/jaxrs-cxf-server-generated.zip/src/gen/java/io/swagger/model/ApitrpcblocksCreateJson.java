package io.swagger.model;

import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcblocksCreateJson   {
  
  @Schema(required = true, description = "")
  private String name = null;
  
  @Schema(description = "")
  private String category = null;
  
  @Schema(required = true, description = "")
  private String content = null;
  public enum ContentTypeEnum {
    MARKDOWN("markdown"),
    HTML("html"),
    LIQUID("liquid");

    private String value;

    ContentTypeEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static ContentTypeEnum fromValue(String text) {
      for (ContentTypeEnum b : ContentTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(required = true, description = "")
  private ContentTypeEnum contentType = null;
 /**
   * Get name
   * @return name
  **/
  @JsonProperty("name")
  @NotNull
 @Size(min=1)  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ApitrpcblocksCreateJson name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get category
   * @return category
  **/
  @JsonProperty("category")
  @NotNull
  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public ApitrpcblocksCreateJson category(String category) {
    this.category = category;
    return this;
  }

 /**
   * Get content
   * @return content
  **/
  @JsonProperty("content")
  @NotNull
 @Size(min=1)  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ApitrpcblocksCreateJson content(String content) {
    this.content = content;
    return this;
  }

 /**
   * Get contentType
   * @return contentType
  **/
  @JsonProperty("contentType")
  @NotNull
  public String getContentType() {
    if (contentType == null) {
      return null;
    }
    return contentType.getValue();
  }

  public void setContentType(ContentTypeEnum contentType) {
    this.contentType = contentType;
  }

  public ApitrpcblocksCreateJson contentType(ContentTypeEnum contentType) {
    this.contentType = contentType;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcblocksCreateJson {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
