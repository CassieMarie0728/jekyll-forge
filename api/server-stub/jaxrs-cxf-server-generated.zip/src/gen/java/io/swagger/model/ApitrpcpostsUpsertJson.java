package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcpostsUpsertJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal siteId = null;
  
  @Schema(required = true, description = "")
  private String path = null;
  
  @Schema(description = "")
  private String filename = null;
  
  @Schema(description = "")
  private String slug = null;
  
  @Schema(description = "")
  private String title = null;
  
  @Schema(description = "")
  private Object status = null;
  
  @Schema(description = "")
  private Object frontMatter = null;
  
  @Schema(description = "")
  private String markdown = null;
  
  @Schema(description = "")
  private String sha = null;
  
  @Schema(description = "")
  private Object scheduledAt = null;
 /**
   * Get siteId
   * @return siteId
  **/
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public ApitrpcpostsUpsertJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

 /**
   * Get path
   * @return path
  **/
  @JsonProperty("path")
  @NotNull
  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public ApitrpcpostsUpsertJson path(String path) {
    this.path = path;
    return this;
  }

 /**
   * Get filename
   * @return filename
  **/
  @JsonProperty("filename")
  @NotNull
  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public ApitrpcpostsUpsertJson filename(String filename) {
    this.filename = filename;
    return this;
  }

 /**
   * Get slug
   * @return slug
  **/
  @JsonProperty("slug")
  @NotNull
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public ApitrpcpostsUpsertJson slug(String slug) {
    this.slug = slug;
    return this;
  }

 /**
   * Get title
   * @return title
  **/
  @JsonProperty("title")
  @NotNull
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ApitrpcpostsUpsertJson title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Get status
   * @return status
  **/
  @JsonProperty("status")
  @NotNull
  public Object getStatus() {
    return status;
  }

  public void setStatus(Object status) {
    this.status = status;
  }

  public ApitrpcpostsUpsertJson status(Object status) {
    this.status = status;
    return this;
  }

 /**
   * Get frontMatter
   * @return frontMatter
  **/
  @JsonProperty("frontMatter")
  @NotNull
  public Object getFrontMatter() {
    return frontMatter;
  }

  public void setFrontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
  }

  public ApitrpcpostsUpsertJson frontMatter(Object frontMatter) {
    this.frontMatter = frontMatter;
    return this;
  }

 /**
   * Get markdown
   * @return markdown
  **/
  @JsonProperty("markdown")
  @NotNull
  public String getMarkdown() {
    return markdown;
  }

  public void setMarkdown(String markdown) {
    this.markdown = markdown;
  }

  public ApitrpcpostsUpsertJson markdown(String markdown) {
    this.markdown = markdown;
    return this;
  }

 /**
   * Get sha
   * @return sha
  **/
  @JsonProperty("sha")
  @NotNull
  public String getSha() {
    return sha;
  }

  public void setSha(String sha) {
    this.sha = sha;
  }

  public ApitrpcpostsUpsertJson sha(String sha) {
    this.sha = sha;
    return this;
  }

 /**
   * Get scheduledAt
   * @return scheduledAt
  **/
  @JsonProperty("scheduledAt")
  @NotNull
  public Object getScheduledAt() {
    return scheduledAt;
  }

  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  public ApitrpcpostsUpsertJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcpostsUpsertJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    frontMatter: ").append(toIndentedString(frontMatter)).append("\n");
    sb.append("    markdown: ").append(toIndentedString(markdown)).append("\n");
    sb.append("    sha: ").append(toIndentedString(sha)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
