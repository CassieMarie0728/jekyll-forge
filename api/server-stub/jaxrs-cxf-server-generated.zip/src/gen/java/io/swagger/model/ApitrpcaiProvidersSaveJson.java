package io.swagger.model;

import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcaiProvidersSaveJson   {
  
  @Schema(required = true, description = "")
  private Object provider = null;
  
  @Schema(required = true, description = "")
  private String model = null;
  
  @Schema(required = true, description = "")
  private String apiKey = null;
 /**
   * Get provider
   * @return provider
  **/
  @JsonProperty("provider")
  @NotNull
  public Object getProvider() {
    return provider;
  }

  public void setProvider(Object provider) {
    this.provider = provider;
  }

  public ApitrpcaiProvidersSaveJson provider(Object provider) {
    this.provider = provider;
    return this;
  }

 /**
   * Get model
   * @return model
  **/
  @JsonProperty("model")
  @NotNull
 @Size(min=1,max=160)  public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public ApitrpcaiProvidersSaveJson model(String model) {
    this.model = model;
    return this;
  }

 /**
   * Get apiKey
   * @return apiKey
  **/
  @JsonProperty("apiKey")
  @NotNull
 @Size(min=8,max=1024)  public String getApiKey() {
    return apiKey;
  }

  public void setApiKey(String apiKey) {
    this.apiKey = apiKey;
  }

  public ApitrpcaiProvidersSaveJson apiKey(String apiKey) {
    this.apiKey = apiKey;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcaiProvidersSaveJson {\n");
    
    sb.append("    provider: ").append(toIndentedString(provider)).append("\n");
    sb.append("    model: ").append(toIndentedString(model)).append("\n");
    sb.append("    apiKey: ").append(toIndentedString(apiKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
