package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsocialMediaSyncAnalyticsJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal analyticsId = null;
 /**
   * Get analyticsId
   * @return analyticsId
  **/
  @JsonProperty("analyticsId")
  @NotNull
  public BigDecimal getAnalyticsId() {
    return analyticsId;
  }

  public void setAnalyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
  }

  public ApitrpcsocialMediaSyncAnalyticsJson analyticsId(BigDecimal analyticsId) {
    this.analyticsId = analyticsId;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaSyncAnalyticsJson {\n");
    
    sb.append("    analyticsId: ").append(toIndentedString(analyticsId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
