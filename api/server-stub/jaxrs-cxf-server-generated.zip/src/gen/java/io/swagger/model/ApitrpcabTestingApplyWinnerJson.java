package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcabTestingApplyWinnerJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal winningVariationIndex = null;
 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcabTestingApplyWinnerJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get winningVariationIndex
   * @return winningVariationIndex
  **/
  @JsonProperty("winningVariationIndex")
  @NotNull
  public BigDecimal getWinningVariationIndex() {
    return winningVariationIndex;
  }

  public void setWinningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
  }

  public ApitrpcabTestingApplyWinnerJson winningVariationIndex(BigDecimal winningVariationIndex) {
    this.winningVariationIndex = winningVariationIndex;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcabTestingApplyWinnerJson {\n");
    
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    winningVariationIndex: ").append(toIndentedString(winningVariationIndex)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
