package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAiProvidersActivateBody;
import io.swagger.model.TrpcAiProvidersRemoveBody;
import io.swagger.model.TrpcAiProvidersSaveBody;
import io.swagger.model.TrpcAiProvidersTestBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.*;
import javax.validation.Valid;

/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
@Path("/")
public interface AiProvidersApi  {

    /**
     * Activate
     *
     */
    @POST
    @Path("/api/trpc/aiProviders.activate")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Activate", tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse aiProvidersActivate(@Valid TrpcAiProvidersActivateBody body);

    /**
     * Get Settings
     *
     */
    @GET
    @Path("/api/trpc/aiProviders.getSettings")
    @Produces({ "application/json" })
    @Operation(summary = "Get Settings", tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse aiProvidersGetSettings();

    /**
     * Remove
     *
     */
    @POST
    @Path("/api/trpc/aiProviders.remove")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Remove", tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse aiProvidersRemove(@Valid TrpcAiProvidersRemoveBody body);

    /**
     * Save
     *
     */
    @POST
    @Path("/api/trpc/aiProviders.save")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Save", tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse aiProvidersSave(@Valid TrpcAiProvidersSaveBody body);

    /**
     * Test
     *
     */
    @POST
    @Path("/api/trpc/aiProviders.test")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Test", tags={ "Ai Providers" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse aiProvidersTest(@Valid TrpcAiProvidersTestBody body);
}
