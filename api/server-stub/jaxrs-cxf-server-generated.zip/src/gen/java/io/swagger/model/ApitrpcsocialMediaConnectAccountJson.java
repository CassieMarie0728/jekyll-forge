package io.swagger.model;

import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsocialMediaConnectAccountJson   {
  public enum PlatformEnum {
    TWITTER("twitter"),
    LINKEDIN("linkedin"),
    FACEBOOK("facebook"),
    INSTAGRAM("instagram");

    private String value;

    PlatformEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static PlatformEnum fromValue(String text) {
      for (PlatformEnum b : PlatformEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(required = true, description = "")
  private PlatformEnum platform = null;
  
  @Schema(required = true, description = "")
  private String accessToken = null;
  
  @Schema(description = "")
  private String refreshToken = null;
  
  @Schema(description = "")
  private Object expiresAt = null;
  
  @Schema(required = true, description = "")
  private String accountId = null;
  
  @Schema(description = "")
  private String username = null;
  
  @Schema(description = "")
  private String displayName = null;
  
  @Schema(description = "")
  private String profileImageUrl = null;
 /**
   * Get platform
   * @return platform
  **/
  @JsonProperty("platform")
  @NotNull
  public String getPlatform() {
    if (platform == null) {
      return null;
    }
    return platform.getValue();
  }

  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }

  public ApitrpcsocialMediaConnectAccountJson platform(PlatformEnum platform) {
    this.platform = platform;
    return this;
  }

 /**
   * Get accessToken
   * @return accessToken
  **/
  @JsonProperty("accessToken")
  @NotNull
  public String getAccessToken() {
    return accessToken;
  }

  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }

  public ApitrpcsocialMediaConnectAccountJson accessToken(String accessToken) {
    this.accessToken = accessToken;
    return this;
  }

 /**
   * Get refreshToken
   * @return refreshToken
  **/
  @JsonProperty("refreshToken")
  @NotNull
  public String getRefreshToken() {
    return refreshToken;
  }

  public void setRefreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
  }

  public ApitrpcsocialMediaConnectAccountJson refreshToken(String refreshToken) {
    this.refreshToken = refreshToken;
    return this;
  }

 /**
   * Get expiresAt
   * @return expiresAt
  **/
  @JsonProperty("expiresAt")
  @NotNull
  public Object getExpiresAt() {
    return expiresAt;
  }

  public void setExpiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
  }

  public ApitrpcsocialMediaConnectAccountJson expiresAt(Object expiresAt) {
    this.expiresAt = expiresAt;
    return this;
  }

 /**
   * Get accountId
   * @return accountId
  **/
  @JsonProperty("accountId")
  @NotNull
  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public ApitrpcsocialMediaConnectAccountJson accountId(String accountId) {
    this.accountId = accountId;
    return this;
  }

 /**
   * Get username
   * @return username
  **/
  @JsonProperty("username")
  @NotNull
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public ApitrpcsocialMediaConnectAccountJson username(String username) {
    this.username = username;
    return this;
  }

 /**
   * Get displayName
   * @return displayName
  **/
  @JsonProperty("displayName")
  @NotNull
  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public ApitrpcsocialMediaConnectAccountJson displayName(String displayName) {
    this.displayName = displayName;
    return this;
  }

 /**
   * Get profileImageUrl
   * @return profileImageUrl
  **/
  @JsonProperty("profileImageUrl")
  @NotNull
  public String getProfileImageUrl() {
    return profileImageUrl;
  }

  public void setProfileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
  }

  public ApitrpcsocialMediaConnectAccountJson profileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaConnectAccountJson {\n");
    
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    accessToken: ").append(toIndentedString(accessToken)).append("\n");
    sb.append("    refreshToken: ").append(toIndentedString(refreshToken)).append("\n");
    sb.append("    expiresAt: ").append(toIndentedString(expiresAt)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    profileImageUrl: ").append(toIndentedString(profileImageUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
