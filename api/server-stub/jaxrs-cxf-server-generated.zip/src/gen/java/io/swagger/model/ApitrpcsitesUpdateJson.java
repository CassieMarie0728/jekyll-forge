package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsitesUpdateJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal id = null;
  
  @Schema(description = "")
  private Boolean isFavorite = null;
  
  @Schema(description = "")
  private String selectedBranch = null;
  
  @Schema(description = "")
  private String rootPath = null;
  
  @Schema(description = "")
  private String timezone = null;
  
  @Schema(description = "")
  private String defaultLayout = null;
  
  @Schema(description = "")
  private String defaultAssetPath = null;
  
  @Schema(description = "")
  private String aiVoiceProfile = null;
  
  @Schema(description = "")
  private Object settings = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }

  public void setId(BigDecimal id) {
    this.id = id;
  }

  public ApitrpcsitesUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

 /**
   * Get isFavorite
   * @return isFavorite
  **/
  @JsonProperty("isFavorite")
  @NotNull
  public Boolean isIsFavorite() {
    return isFavorite;
  }

  public void setIsFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
  }

  public ApitrpcsitesUpdateJson isFavorite(Boolean isFavorite) {
    this.isFavorite = isFavorite;
    return this;
  }

 /**
   * Get selectedBranch
   * @return selectedBranch
  **/
  @JsonProperty("selectedBranch")
  @NotNull
  public String getSelectedBranch() {
    return selectedBranch;
  }

  public void setSelectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
  }

  public ApitrpcsitesUpdateJson selectedBranch(String selectedBranch) {
    this.selectedBranch = selectedBranch;
    return this;
  }

 /**
   * Get rootPath
   * @return rootPath
  **/
  @JsonProperty("rootPath")
  @NotNull
  public String getRootPath() {
    return rootPath;
  }

  public void setRootPath(String rootPath) {
    this.rootPath = rootPath;
  }

  public ApitrpcsitesUpdateJson rootPath(String rootPath) {
    this.rootPath = rootPath;
    return this;
  }

 /**
   * Get timezone
   * @return timezone
  **/
  @JsonProperty("timezone")
  @NotNull
  public String getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public ApitrpcsitesUpdateJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

 /**
   * Get defaultLayout
   * @return defaultLayout
  **/
  @JsonProperty("defaultLayout")
  @NotNull
  public String getDefaultLayout() {
    return defaultLayout;
  }

  public void setDefaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
  }

  public ApitrpcsitesUpdateJson defaultLayout(String defaultLayout) {
    this.defaultLayout = defaultLayout;
    return this;
  }

 /**
   * Get defaultAssetPath
   * @return defaultAssetPath
  **/
  @JsonProperty("defaultAssetPath")
  @NotNull
  public String getDefaultAssetPath() {
    return defaultAssetPath;
  }

  public void setDefaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
  }

  public ApitrpcsitesUpdateJson defaultAssetPath(String defaultAssetPath) {
    this.defaultAssetPath = defaultAssetPath;
    return this;
  }

 /**
   * Get aiVoiceProfile
   * @return aiVoiceProfile
  **/
  @JsonProperty("aiVoiceProfile")
  @NotNull
  public String getAiVoiceProfile() {
    return aiVoiceProfile;
  }

  public void setAiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
  }

  public ApitrpcsitesUpdateJson aiVoiceProfile(String aiVoiceProfile) {
    this.aiVoiceProfile = aiVoiceProfile;
    return this;
  }

 /**
   * Get settings
   * @return settings
  **/
  @JsonProperty("settings")
  @NotNull
  public Object getSettings() {
    return settings;
  }

  public void setSettings(Object settings) {
    this.settings = settings;
  }

  public ApitrpcsitesUpdateJson settings(Object settings) {
    this.settings = settings;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsitesUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isFavorite: ").append(toIndentedString(isFavorite)).append("\n");
    sb.append("    selectedBranch: ").append(toIndentedString(selectedBranch)).append("\n");
    sb.append("    rootPath: ").append(toIndentedString(rootPath)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    defaultLayout: ").append(toIndentedString(defaultLayout)).append("\n");
    sb.append("    defaultAssetPath: ").append(toIndentedString(defaultAssetPath)).append("\n");
    sb.append("    aiVoiceProfile: ").append(toIndentedString(aiVoiceProfile)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
