package io.swagger.model;

import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcgithubCreateBranchJson   {
  
  @Schema(required = true, description = "")
  private String owner = null;
  
  @Schema(required = true, description = "")
  private String repo = null;
  
  @Schema(required = true, description = "")
  private String branchName = null;
  
  @Schema(required = true, description = "")
  private String fromBranch = null;
 /**
   * Get owner
   * @return owner
  **/
  @JsonProperty("owner")
  @NotNull
  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public ApitrpcgithubCreateBranchJson owner(String owner) {
    this.owner = owner;
    return this;
  }

 /**
   * Get repo
   * @return repo
  **/
  @JsonProperty("repo")
  @NotNull
  public String getRepo() {
    return repo;
  }

  public void setRepo(String repo) {
    this.repo = repo;
  }

  public ApitrpcgithubCreateBranchJson repo(String repo) {
    this.repo = repo;
    return this;
  }

 /**
   * Get branchName
   * @return branchName
  **/
  @JsonProperty("branchName")
  @NotNull
  public String getBranchName() {
    return branchName;
  }

  public void setBranchName(String branchName) {
    this.branchName = branchName;
  }

  public ApitrpcgithubCreateBranchJson branchName(String branchName) {
    this.branchName = branchName;
    return this;
  }

 /**
   * Get fromBranch
   * @return fromBranch
  **/
  @JsonProperty("fromBranch")
  @NotNull
  public String getFromBranch() {
    return fromBranch;
  }

  public void setFromBranch(String fromBranch) {
    this.fromBranch = fromBranch;
  }

  public ApitrpcgithubCreateBranchJson fromBranch(String fromBranch) {
    this.fromBranch = fromBranch;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcgithubCreateBranchJson {\n");
    
    sb.append("    owner: ").append(toIndentedString(owner)).append("\n");
    sb.append("    repo: ").append(toIndentedString(repo)).append("\n");
    sb.append("    branchName: ").append(toIndentedString(branchName)).append("\n");
    sb.append("    fromBranch: ").append(toIndentedString(fromBranch)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
