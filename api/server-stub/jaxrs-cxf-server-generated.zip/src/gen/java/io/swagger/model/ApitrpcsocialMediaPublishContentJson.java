package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcsocialMediaPublishContentJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal repurposedContentId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal accountId = null;
 /**
   * Get repurposedContentId
   * @return repurposedContentId
  **/
  @JsonProperty("repurposedContentId")
  @NotNull
  public BigDecimal getRepurposedContentId() {
    return repurposedContentId;
  }

  public void setRepurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
  }

  public ApitrpcsocialMediaPublishContentJson repurposedContentId(BigDecimal repurposedContentId) {
    this.repurposedContentId = repurposedContentId;
    return this;
  }

 /**
   * Get accountId
   * @return accountId
  **/
  @JsonProperty("accountId")
  @NotNull
  public BigDecimal getAccountId() {
    return accountId;
  }

  public void setAccountId(BigDecimal accountId) {
    this.accountId = accountId;
  }

  public ApitrpcsocialMediaPublishContentJson accountId(BigDecimal accountId) {
    this.accountId = accountId;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcsocialMediaPublishContentJson {\n");
    
    sb.append("    repurposedContentId: ").append(toIndentedString(repurposedContentId)).append("\n");
    sb.append("    accountId: ").append(toIndentedString(accountId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
