package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcrepurposingUpdateJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal id = null;
  
  @Schema(description = "")
  private String content = null;
  
  @Schema(description = "")
  private Object status = null;
  
  @Schema(description = "")
  private Boolean isCustomized = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }

  public void setId(BigDecimal id) {
    this.id = id;
  }

  public ApitrpcrepurposingUpdateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

 /**
   * Get content
   * @return content
  **/
  @JsonProperty("content")
  @NotNull
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ApitrpcrepurposingUpdateJson content(String content) {
    this.content = content;
    return this;
  }

 /**
   * Get status
   * @return status
  **/
  @JsonProperty("status")
  @NotNull
  public Object getStatus() {
    return status;
  }

  public void setStatus(Object status) {
    this.status = status;
  }

  public ApitrpcrepurposingUpdateJson status(Object status) {
    this.status = status;
    return this;
  }

 /**
   * Get isCustomized
   * @return isCustomized
  **/
  @JsonProperty("isCustomized")
  @NotNull
  public Boolean isIsCustomized() {
    return isCustomized;
  }

  public void setIsCustomized(Boolean isCustomized) {
    this.isCustomized = isCustomized;
  }

  public ApitrpcrepurposingUpdateJson isCustomized(Boolean isCustomized) {
    this.isCustomized = isCustomized;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingUpdateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isCustomized: ").append(toIndentedString(isCustomized)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
