package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcschedulerScheduleJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal siteId = null;
  
  @Schema(description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private String draftPath = null;
  
  @Schema(required = true, description = "")
  private String targetPath = null;
  
  @Schema(required = true, description = "")
  private Object scheduledAt = null;
  
  @Schema(required = true, description = "")
  private String timezone = null;
  
  @Schema(description = "")
  private String commitMessage = null;
 /**
   * Get siteId
   * @return siteId
  **/
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public ApitrpcschedulerScheduleJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }

 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcschedulerScheduleJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get draftPath
   * @return draftPath
  **/
  @JsonProperty("draftPath")
  @NotNull
  public String getDraftPath() {
    return draftPath;
  }

  public void setDraftPath(String draftPath) {
    this.draftPath = draftPath;
  }

  public ApitrpcschedulerScheduleJson draftPath(String draftPath) {
    this.draftPath = draftPath;
    return this;
  }

 /**
   * Get targetPath
   * @return targetPath
  **/
  @JsonProperty("targetPath")
  @NotNull
  public String getTargetPath() {
    return targetPath;
  }

  public void setTargetPath(String targetPath) {
    this.targetPath = targetPath;
  }

  public ApitrpcschedulerScheduleJson targetPath(String targetPath) {
    this.targetPath = targetPath;
    return this;
  }

 /**
   * Get scheduledAt
   * @return scheduledAt
  **/
  @JsonProperty("scheduledAt")
  @NotNull
  public Object getScheduledAt() {
    return scheduledAt;
  }

  public void setScheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
  }

  public ApitrpcschedulerScheduleJson scheduledAt(Object scheduledAt) {
    this.scheduledAt = scheduledAt;
    return this;
  }

 /**
   * Get timezone
   * @return timezone
  **/
  @JsonProperty("timezone")
  @NotNull
  public String getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    this.timezone = timezone;
  }

  public ApitrpcschedulerScheduleJson timezone(String timezone) {
    this.timezone = timezone;
    return this;
  }

 /**
   * Get commitMessage
   * @return commitMessage
  **/
  @JsonProperty("commitMessage")
  @NotNull
  public String getCommitMessage() {
    return commitMessage;
  }

  public void setCommitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
  }

  public ApitrpcschedulerScheduleJson commitMessage(String commitMessage) {
    this.commitMessage = commitMessage;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcschedulerScheduleJson {\n");
    
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    draftPath: ").append(toIndentedString(draftPath)).append("\n");
    sb.append("    targetPath: ").append(toIndentedString(targetPath)).append("\n");
    sb.append("    scheduledAt: ").append(toIndentedString(scheduledAt)).append("\n");
    sb.append("    timezone: ").append(toIndentedString(timezone)).append("\n");
    sb.append("    commitMessage: ").append(toIndentedString(commitMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
