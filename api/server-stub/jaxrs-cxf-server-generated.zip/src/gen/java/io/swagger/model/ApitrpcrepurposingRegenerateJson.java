package io.swagger.model;

import java.math.BigDecimal;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class ApitrpcrepurposingRegenerateJson   {
  
  @Schema(required = true, description = "")
  private BigDecimal id = null;
  
  @Schema(required = true, description = "")
  private BigDecimal postId = null;
  
  @Schema(required = true, description = "")
  private BigDecimal siteId = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("id")
  @NotNull
  public BigDecimal getId() {
    return id;
  }

  public void setId(BigDecimal id) {
    this.id = id;
  }

  public ApitrpcrepurposingRegenerateJson id(BigDecimal id) {
    this.id = id;
    return this;
  }

 /**
   * Get postId
   * @return postId
  **/
  @JsonProperty("postId")
  @NotNull
  public BigDecimal getPostId() {
    return postId;
  }

  public void setPostId(BigDecimal postId) {
    this.postId = postId;
  }

  public ApitrpcrepurposingRegenerateJson postId(BigDecimal postId) {
    this.postId = postId;
    return this;
  }

 /**
   * Get siteId
   * @return siteId
  **/
  @JsonProperty("siteId")
  @NotNull
  public BigDecimal getSiteId() {
    return siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public ApitrpcrepurposingRegenerateJson siteId(BigDecimal siteId) {
    this.siteId = siteId;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApitrpcrepurposingRegenerateJson {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    postId: ").append(toIndentedString(postId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
