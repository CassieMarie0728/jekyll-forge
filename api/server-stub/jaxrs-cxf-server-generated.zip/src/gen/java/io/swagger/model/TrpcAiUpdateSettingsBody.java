package io.swagger.model;

import io.swagger.model.ApitrpcaiUpdateSettingsJson;
import javax.validation.constraints.*;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class TrpcAiUpdateSettingsBody   {
  
  @Schema(required = true, description = "")
  private ApitrpcaiUpdateSettingsJson json = null;
 /**
   * Get json
   * @return json
  **/
  @JsonProperty("json")
  @NotNull
  public ApitrpcaiUpdateSettingsJson getJson() {
    return json;
  }

  public void setJson(ApitrpcaiUpdateSettingsJson json) {
    this.json = json;
  }

  public TrpcAiUpdateSettingsBody json(ApitrpcaiUpdateSettingsJson json) {
    this.json = json;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrpcAiUpdateSettingsBody {\n");
    
    sb.append("    json: ").append(toIndentedString(json)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
