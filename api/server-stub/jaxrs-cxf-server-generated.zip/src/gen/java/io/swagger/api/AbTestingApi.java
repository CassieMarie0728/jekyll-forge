package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.TRPCResponse;
import io.swagger.model.TrpcAbTestingApplyWinnerBody;
import io.swagger.model.TrpcAbTestingCompleteTestBody;
import io.swagger.model.TrpcAbTestingGenerateVariationsBody;
import io.swagger.model.TrpcAbTestingPublishVariationBody;
import io.swagger.model.TrpcAbTestingUpdateMetricsBody;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.*;
import javax.validation.Valid;

/**
 * Jekyll Forge API
 *
 * <p>OpenAPI map generated from the Jekyll Forge tRPC server source. Query procedures use GET with tRPC input in the `input` query parameter; mutations use POST with a `{ \"json\": ... }` body. Protected procedures accept the application session/authentication mechanism.
 *
 */
@Path("/")
public interface AbTestingApi  {

    /**
     * Apply Winner
     *
     */
    @POST
    @Path("/api/trpc/abTesting.applyWinner")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Apply Winner", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingApplyWinner(@Valid TrpcAbTestingApplyWinnerBody body);

    /**
     * Complete Test
     *
     */
    @POST
    @Path("/api/trpc/abTesting.completeTest")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Complete Test", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingCompleteTest(@Valid TrpcAbTestingCompleteTestBody body);

    /**
     * Generate Variations
     *
     */
    @POST
    @Path("/api/trpc/abTesting.generateVariations")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Generate Variations", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingGenerateVariations(@Valid TrpcAbTestingGenerateVariationsBody body);

    /**
     * Get Results
     *
     */
    @GET
    @Path("/api/trpc/abTesting.getResults")
    @Produces({ "application/json" })
    @Operation(summary = "Get Results", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingGetResults(@QueryParam("input") @NotNull String input);

    /**
     * Get Variations
     *
     */
    @GET
    @Path("/api/trpc/abTesting.getVariations")
    @Produces({ "application/json" })
    @Operation(summary = "Get Variations", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingGetVariations(@QueryParam("input") @NotNull String input);

    /**
     * Publish Variation
     *
     */
    @POST
    @Path("/api/trpc/abTesting.publishVariation")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Publish Variation", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingPublishVariation(@Valid TrpcAbTestingPublishVariationBody body);

    /**
     * Update Metrics
     *
     */
    @POST
    @Path("/api/trpc/abTesting.updateMetrics")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Update Metrics", tags={ "Ab Testing" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful tRPC response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TRPCResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request / invalid input", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "401", description = "Authentication required", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))),
        @ApiResponse(responseCode = "500", description = "Server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    public TRPCResponse abTestingUpdateMetrics(@Valid TrpcAbTestingUpdateMetricsBody body);
}
